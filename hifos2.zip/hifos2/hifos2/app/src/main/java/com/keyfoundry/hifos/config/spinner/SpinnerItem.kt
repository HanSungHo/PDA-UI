package com.keyfoundry.hifos.config.spinner

class SpinnerItem(val key: String, val value: String) {
    override fun toString(): String {
        return value
    }

    override fun equals(other: Any?): Boolean {
        if (other is SpinnerItem) {
            if (other.value == value && other.key === key) return true
        }
        return false
    }

    override fun hashCode(): Int {
        var result = key.hashCode()
        result = 31 * result + value.hashCode()
        return result
    }
}