package com.keyfoundry.hifos.view.pr

import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import androidx.core.view.isGone
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityPrChangeBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.batch.BatchActivity
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PRChangeActivity : HFActivity() {
    companion object {
        private const val TAG = "PRChangeActivity"
    }

    private lateinit var viewBinding: ActivityPrChangeBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)
    private var m_sEQPID = ""
    private var m_sTIME = ""
    private var currentFlag = false
    private var m_Flag = false
    private var b_Leak= false;

    enum class RadioType { LEAK_Y, LEAK_N }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityPrChangeBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        viewBinding.txtViscosity.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtExpDate.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtProductName.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtVendor.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtPrId.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtLotNo.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtProductNameMaster.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtPrIdMaster.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtVendorMaster.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtPumpName.movementMethod = ScrollingMovementMethod.getInstance()

        viewBinding.btnChange.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                prChange()
            }
        })

        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
            }
        })

        viewBinding.btnSearchPumpId.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                getPumpStats()
            }
        })

        viewBinding.editPumpId.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                if (getBarcodePrId(viewBinding.editPumpId)) {
                    getPumpStats()
                }
            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    if (getBarcodePrId(viewBinding.editPumpId)) {
                        getPumpStats()
                    }
                }
            }

            true
        }

        viewBinding.editCurrentPr.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                if (checkPrLength(viewBinding.editCurrentPr)) {
                    getCurrentPrInfo()
                }

            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    if (checkPrLength(viewBinding.editCurrentPr)) {
                        getCurrentPrInfo()
                    }
                }
            }

            true
        }

        viewBinding.editChangePr.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                if (checkPrLength(viewBinding.editChangePr)) {
                    getPRInfo()
                }

            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    if (checkPrLength(viewBinding.editChangePr)) {
                        getPRInfo()
                    }
                }
            }

            true
        }

        viewBinding.editInDate.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                if (checkDateLength(viewBinding.editInDate)) {
                    viewBinding.editOutPr.requestFocus()
                }
            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    if (checkDateLength(viewBinding.editInDate)) {
                        viewBinding.editOutPr.requestFocus()
                    }
                }
            }

            true
        }

        viewBinding.editOutPr.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                if (checkPrLength(viewBinding.editOutPr)) {
                    getComparePRInfo()
                }
            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    if (checkPrLength(viewBinding.editOutPr)) {
                        getComparePRInfo()
                    }
                }
            }

            true
        }

        viewBinding.radioLEAKY.setOnCheckedChangeListener { buttonView, isChecked ->
            if(isChecked){
                checkedRadioButton(PRChangeActivity.RadioType.LEAK_Y)
                }
            }


        viewBinding.radioLEAKN.setOnCheckedChangeListener { buttonView, isChecked ->
            if(isChecked){
                checkedRadioButton(PRChangeActivity.RadioType.LEAK_N)
                }
            }

    }

    private fun getBarcodePrId(editPrId: EditText): Boolean {
        val prId = editPrId.text.toString()
        if (prId.length <= 2) {
            OkDialog.show(
                supportFragmentManager, "READING ERROR", "조회하실 PUMP를 읽어주세요.", GetString.BTNOKSTR
            )
            editPrId.setText("")
            return false
        }
        val returnPrId = prId.substring(1, prId.length - 1)

        editPrId.setText(returnPrId)
        return true
    }

    private fun checkPrLength(pr: EditText): Boolean {
        val prLength = pr.text.length
        if (prLength != 25 && prLength != 28 && prLength != 29) {
            pr.setText("")
            pr.requestFocus()
            mainScope.launch {
                OkDialog.show(
                    supportFragmentManager, "READING ERROR",
                    "BARCODE형식이 일치하지 않습니다. PR병의 BARCODE를 다시 읽어주세요.", GetString.BTNOKSTR
                )
            }
            return false
        }
        return true
    }

    private fun checkDateLength(date: EditText): Boolean {
        val dateLength = date.text.length
        if (dateLength != 12) {
            date.setText("")
            date.requestFocus()
            mainScope.launch {
                OkDialog.show(
                    supportFragmentManager, "READING ERROR",
                    "날짜형식이 일치하지 않습니다. 상온입고 BARCODE를 다시 읽어주세요.", GetString.BTNOKSTR
                )
            }
            return false
        }
        return true
    }

    private fun extractPrInfo(sFromPR: String): HashMap<String, String> {
        val extractPr: HashMap<String, String> = HashMap()

        when (sFromPR.length) {
            25 -> {
                extractPr["PRID"] = sFromPR.substring(0, 4)
                extractPr["VISCOSITY"] = sFromPR.substring(4, 8)
                extractPr["PRLOTNO"] = sFromPR.substring(14, 19)
                extractPr["VALIDATE"] = sFromPR.substring(19)
            }
            28 -> {
                extractPr["PRID"] = sFromPR.substring(0, 4)
                extractPr["VISCOSITY"] = sFromPR.substring(4, 8)
                extractPr["PRLOTNO"] = sFromPR.substring(14, 19) + "-" + sFromPR.substring(19, 22)
                extractPr["VALIDATE"] = sFromPR.substring(22)
            }
            29 -> {
                extractPr["PRID"] = sFromPR.substring(0, 4)
                extractPr["VISCOSITY"] = sFromPR.substring(4, 8)
                extractPr["PRLOTNO"] = sFromPR.substring(14, 20) + "-" + sFromPR.substring(19, 22)
                extractPr["VALIDATE"] = sFromPR.substring(23)
            }
        }
        return extractPr
    }


    private fun getPRInfo() {
        mainScope.launch {
            if (!m_Flag) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "현재 PR을 먼저 조회하시기 바랍니다.", GetString.BTNOKSTR
                )

                viewBinding.editChangePr.setText("")
                return@launch
            }

            val prMap = extractPrInfo(viewBinding.editChangePr.text.toString())

            val sendMessage = MessageFactoryUtil.prInfo(
                m_sEQPID, viewBinding.txtPumpName.text.toString(),
                prMap.getValue("PRID"), prMap.getValue("VISCOSITY"),
                prMap.getValue("PRLOTNO"), prMap.getValue("VALIDATE")
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.PRINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sPRID = messageBody.optString("PRID")
                val sCompany = messageBody.optString("PRCOMP")
                val sPRDesc = messageBody.optString("PRDESC")
                m_sTIME = messageBody.optString("TIME")

                viewBinding.txtPrId.text = sPRID
                viewBinding.txtVendor.text = sCompany
                viewBinding.txtProductName.text = sPRDesc
                viewBinding.txtViscosity.text = prMap.getValue("PRID")
                viewBinding.txtLotNo.text = prMap.getValue("PRLOTNO")
                viewBinding.txtExpDate.text = prMap.getValue("VALIDATE")


                if (!currentFlag) {
                    viewBinding.btnChange.isEnabled = true
                } else {
                    viewBinding.editInDate.requestFocus()
                }
            } else {
                viewBinding.editChangePr.setText("")
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun getComparePRInfo() {
        mainScope.launch {
            val prMap = extractPrInfo(viewBinding.editOutPr.text.toString())

            val sendMessage = MessageFactoryUtil.comparePrInfo(
                m_sEQPID, viewBinding.txtPumpName.text.toString(),
                prMap.getValue("PRID"), prMap.getValue("PRLOTNO"),
                prMap.getValue("VISCOSITY"), m_sTIME, viewBinding.editUserId.text.toString()
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.COMPAREPRINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {

                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val sConfrimPR = messageBody.optString("PRID")

                if (sConfrimPR == "") {
                    val msg = """
                        |MSG 수신에 실패하였습니다.
                        |잠시후 시도해 주시기 바랍니다.
                    """.trimMargin()
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        msg, GetString.BTNOKSTR
                    )
                } else {
                    viewBinding.btnChange.isEnabled = true
                }
            } else {
     //           viewBinding.editUserId.setText("")
                viewBinding.editOutPr.setText("")
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun getPumpStats() {
        mainScope.launch {
            val pumpId = viewBinding.editPumpId.text.toString()
            val sendMessage = MessageFactoryUtil.pumpStatus(pumpId)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.PUMPSTATUS)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sFAB = messageBody.optString("FAB")
                m_sEQPID = messageBody.optString("EQPID")
                val sPUMPNAME = messageBody.optString("PUMPNAME")
                val sMPRID = messageBody.optString("PRID")
                val sMCompany = messageBody.optString("PRCOMP")
                val sMPRDesc = messageBody.optString("PRDESC")
                val sUSEFLAG = messageBody.optString("FLAG")

                viewBinding.txtPumpName.text = sPUMPNAME
                viewBinding.txtVendorMaster.text = sMCompany
                viewBinding.txtProductNameMaster.text = sMPRDesc
                viewBinding.txtPrIdMaster.text = sMPRID

                if (sUSEFLAG == "1") {
                    viewBinding.editCurrentPr.isEnabled = true
                    viewBinding.editCurrentPr.requestFocus()
                    currentFlag = true
                    m_Flag = false
                } else {
                    viewBinding.editCurrentPr.setText("이전 사용 이력 없음")
                    viewBinding.editCurrentPr.isEnabled = false
                    viewBinding.editInDate.isEnabled = false
                    viewBinding.editOutPr.isEnabled = false
                    viewBinding.editUserId.isEnabled = false
                    viewBinding.editChangePr.requestFocus()
                    currentFlag = false
                    m_Flag = true
                }
            } else {
                m_Flag = false
                viewBinding.editPumpId.setText("")
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }

        }
    }


    private fun getCurrentPrInfo() {
        mainScope.launch {
            if (m_sEQPID.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "PUMP를 먼저 조회하시기 바랍니다.", GetString.BTNOKSTR
                )
                viewBinding.editPumpId.requestFocus()
                return@launch
            }

            val prMap = extractPrInfo(viewBinding.editCurrentPr.text.toString())

            val sendMessage = MessageFactoryUtil.currentPrInfo(
                m_sEQPID, viewBinding.txtPumpName.text.toString(),
                prMap.getValue("PRID"), prMap.getValue("PRLOTNO"), prMap.getValue("VISCOSITY")
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.CURRENTPRINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val sConfrimPR = messageBody.optString("PRID")

                if (sConfrimPR == "") {
                    m_Flag = false
                    val msg = """
                        |MSG 수신에 실패하였습니다.
                        |잠시후 시도해 주시기 바랍니다.
                    """.trimMargin()
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        msg, GetString.BTNOKSTR
                    )
                } else {
                    m_Flag = true
                    viewBinding.editChangePr.requestFocus()
                }

            } else {
                viewBinding.editCurrentPr.setText("")
                m_Flag = false
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun prChange() {


        if(b_Leak==false) {
            val returnCode = OkCancelDialog.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_INFORM,
                "PR LEAK 이상이 없습니다." +
                        " 계속 진행하시겠습니까?",
                GetString.BTNYESSTR,
                GetString.BTNNOSTR
            )
            if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                return;
            }
        }

        mainScope.launch {
            val sendMessage = MessageFactoryUtil.prChange(
                m_sEQPID, viewBinding.txtPumpName.text.toString(),
                viewBinding.txtPrId.text.toString(), viewBinding.txtProductName.text.toString(),
                viewBinding.txtVendor.text.toString(), viewBinding.txtViscosity.text.toString(),
                viewBinding.txtLotNo.text.toString(), viewBinding.txtExpDate.text.toString(),
                DeviceInfo.OPERATOR_ID, DeviceInfo.OPERATOR_NAME,b_Leak.toString(), viewBinding.editInDate.text.toString()
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.CURRENTPRINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                    "교체되었습니다.", GetString.BTNOKSTR
                )

                clearData()

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearData() {
        viewBinding.editUserId.setText("")
        viewBinding.editPumpId.setText("")
        viewBinding.editOutPr.setText("")
        viewBinding.editChangePr.setText("")
        viewBinding.editCurrentPr.setText("")
        viewBinding.editInDate.setText("")      //pr indate 추가 230612 - wyw
        viewBinding.txtPumpName.text = ""
        viewBinding.txtVendorMaster.text = ""
        viewBinding.txtVendor.text = ""
        viewBinding.txtPrIdMaster.text = ""
        viewBinding.txtPrId.text = ""
        viewBinding.txtProductNameMaster.text = ""
        viewBinding.txtLotNo.text = ""
        viewBinding.txtExpDate.text = ""
        viewBinding.txtViscosity.text = ""
        viewBinding.txtPrIdMaster.text = ""
        viewBinding.radioLEAKN.isChecked = true;
        viewBinding.radioLEAKY.isChecked = false;
        b_Leak = false;

        viewBinding.editPumpId.requestFocus()

    }


    private fun checkedRadioButton(radioType : PRChangeActivity.RadioType){
        when(radioType){
            PRChangeActivity.RadioType.LEAK_Y -> {
                viewBinding.radioLEAKY.isChecked = true
                viewBinding.radioLEAKN.isChecked = false
                b_Leak = true;

            }
            PRChangeActivity.RadioType.LEAK_N -> {
                viewBinding.radioLEAKY.isChecked = false
                viewBinding.radioLEAKN.isChecked = true
                b_Leak = false;
            }
        }
    }



}