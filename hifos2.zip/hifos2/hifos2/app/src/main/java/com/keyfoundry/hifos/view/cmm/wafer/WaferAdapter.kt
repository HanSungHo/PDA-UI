package com.keyfoundry.hifos.view.cmm.wafer

import android.app.Activity
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.RecyclerView
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog

class WaferAdapter(
    private val activity: Activity,
    private val itemList: MutableList<WaferInfo>,
    private val editable: Boolean,
    private val disableList: String?,
    private val selectList: String?,
    private val selectWafer: SelectWafer,
    private val fragmentManager: FragmentManager
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    override fun getItemCount() = itemList.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflatedView = LayoutInflater.from(parent.context)
            .inflate(R.layout.wafer_button, parent, false)

        return ViewHolder(inflatedView)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val waferHolder = holder as ViewHolder
        val waferList = activity.findViewById<TextView>(R.id.txt_wafer_list)

        val listener = View.OnClickListener {
            if (!editable || it.isSelected || selectWafer.currentCount < selectWafer.maxCount) {
                // 버튼 클릭시 색상 변경
                it.isSelected = !it.isSelected

                val waferInfo = it.tag as WaferInfo
                // WaferList 값 변경
                if (it.isSelected) {
                    selectWafer.currentCount++
                    waferInfo.machine = "Empty"

                    if (waferList.text.isEmpty())
                        waferList.text = waferInfo.waferName
                    else {
                        val text = waferList.text.toString() + ",${waferInfo.waferName}"
                        val list = text.split(",")

                        val newText = list.sorted().joinToString(",")

                        waferList.text = newText
                    }
                } else {
                    selectWafer.currentCount--
                    waferInfo.machine = ""
                    (it as Button).text = waferInfo.waferId

                    val list = waferList.text.toString().split(",")

                    val categoryList = list.toCollection(ArrayList())
                    categoryList.remove(waferInfo.waferName)

                    val newText = categoryList.sorted().joinToString(",")
                    waferList.text = newText
                }
            } else {
                OkDialog.show(
                    fragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "선택한 WAFER개수가 지정된 개수를 초과하였습니다.", GetString.BTNOKSTR
                )
            }
        }

        waferHolder.apply {
            bind(listener, itemList[position])
        }
    }

    internal inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val waferButton: Button = itemView.findViewById(R.id.btn_rc_wafer)

        fun bind(listener: View.OnClickListener, waferInfo: WaferInfo) {
            if(waferInfo.waferName=="empty"){
                waferButton.setBackgroundColor(Color.GRAY)
                waferButton.isEnabled = false
            } else {
                waferButton.text = waferInfo.waferId
                waferButton.tag = waferInfo
                waferButton.setOnClickListener(listener)
            }

            if (!editable) {
                waferButton.performClick()
                selectWafer.disableCount++
                waferButton.isClickable = false
            } else {
                if (disableList != null) {
                    if (disableList.contains(waferInfo.waferName)) {
                        waferButton.isEnabled = false
                        selectWafer.disableCount++
                    }
                }

                if (selectList != null) {
                    if (selectList.contains(waferInfo.waferName)) {
                        waferButton.performClick()
                    }
                }
            }
        }
    }
}