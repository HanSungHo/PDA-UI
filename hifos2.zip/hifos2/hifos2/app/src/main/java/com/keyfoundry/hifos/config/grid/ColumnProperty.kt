package com.keyfoundry.hifos.config.grid

import android.graphics.Color
import android.view.ViewGroup

/*
* Grid 컬럼 옵션 설정
* */
class ColumnProperty(var columnVale: String, var gravity: Int, var fixed: Boolean) {
    var columnSize: Int = ViewGroup.LayoutParams.WRAP_CONTENT
    var backColor: Int = Color.parseColor("#00000000")
    var textColor: Int = Color.parseColor("#808080")
    var editable: Boolean = false

    constructor(columnVale: String, gravity: Int, fixed: Boolean, editable: Boolean)
            : this(columnVale, gravity, fixed) {
        this.editable = editable
    }

    constructor(
        columnVale: String, gravity: Int, fixed: Boolean, columnSize: Int, editable: Boolean
    ) : this(columnVale, gravity, fixed) {
        this.columnSize = columnSize
        this.editable = editable
    }

    constructor(columnVale: String, gravity: Int, fixed: Boolean, columnSize: Int)
            : this(columnVale, gravity, fixed) {
        this.columnSize = columnSize
    }

    constructor(columnVale: String, gravity: Int, fixed: Boolean, backColor: Int, textColor: Int)
            : this(columnVale, gravity, fixed) {
        this.backColor = backColor
        this.textColor = textColor
    }

    constructor(
        columnVale: String, gravity: Int, fixed: Boolean, columnSize: Int,
        backColor: Int, textColor: Int
    ) : this(columnVale, gravity, fixed) {
        this.columnSize = columnSize
        this.backColor = backColor
        this.textColor = textColor
    }
}