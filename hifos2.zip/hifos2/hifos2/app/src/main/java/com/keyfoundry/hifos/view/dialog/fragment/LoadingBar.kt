package com.keyfoundry.hifos.view.dialog.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.databinding.FragmentLoadingCircleBinding

class LoadingBar : DialogFragment() {

    companion object {
        const val TAG = "LoadingBar"
        private val circle = LoadingBar()

        fun show(supportFragmentManager: FragmentManager) {
            supportFragmentManager.beginTransaction().add(circle, TAG).commitAllowingStateLoss()
        }

        fun hide(supportFragmentManager: FragmentManager) {
            supportFragmentManager.beginTransaction().remove(circle).commitAllowingStateLoss()
        }

        fun getInstance(): LoadingBar = LoadingBar()
    }

    private var _binding: FragmentLoadingCircleBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setStyle(STYLE_NO_TITLE, R.style.LoadingDialog)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        dialog?.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog?.setCancelable(false)
        _binding = FragmentLoadingCircleBinding.inflate(inflater, container, false)

        return binding.root
    }

    fun close() {
        dialog?.dismiss()
    }
}

