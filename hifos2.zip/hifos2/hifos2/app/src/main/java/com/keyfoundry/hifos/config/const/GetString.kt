package com.keyfoundry.hifos.config.const

//
interface GetString {
    companion object {
        const val OPERID = "OPERID"
        const val OPERNAME = "OPERNAME"
        const val PERMISSTION = "PERMISSION"
        const val ERRMSG = "ERRMSG"

        const val FACILITY = "FACILITY"
        const val AREA = "AREA"
        const val BAY = "BAY"
        const val BAYS = "BAYS"

        const val ITEM = "ITEM"
        const val ITEMS = "ITEMS"
        const val VALUE = "VALUE"

        const val JSONOBJECT = "JSONObject"
        const val JSONARRAY = "JSONArray"

        const val STATUS = "STATUS"
        const val PASS = "PASS"
        const val MSGBODY = "MSGBODY"

        const val BTNOKSTR = "확인"
        const val BTNYESSTR = "예"
        const val BTNNOSTR = "아니오"
        
        const val TXTDIALOGTITLE_OK = "확  인"
        const val TXTDIALOGTITLE_ERROR = "에  러"
        const val TXTDIALOGTITLE_WARNING = "경  고"
        const val TXTDIALOGTITLE_INFORM = "알  림"

        const val POSITIVEBTNSTR = "확인"
        const val NEGATIVEBTNSTR = "취소"

        const val TXTDIALOGMESSAGE_LOGOUT = "로그아웃 하시겠습니까?"
        const val TXTDIALOGTITLE_LOGOUT = "LOG OUT"
        const val TXTDIALOGTITLE_LOGIN = "LOG IN"
        const val TXTDIALOGTITLE_SETTING = "환경설정"

        const val TXTDIALOGMESSAGE_SYSTEMCONF = "시스템 환경설정을 변경 하시겠습니까?"
        const val TXTDIALOGTITLE_SYSTEMCONF = "System Configuration"

        const val UDP_LEVEL = "LEVEL"
        const val UDP_MESSAGE = "MESSAGE"

        const val MESSAGE_LOW_LEVEL = "LOW"
        const val MESSAGE_HIGH_LEVEL = "HIGH"
    }
}