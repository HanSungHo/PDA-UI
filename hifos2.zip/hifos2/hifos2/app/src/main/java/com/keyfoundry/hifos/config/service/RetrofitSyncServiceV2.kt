package com.keyfoundry.hifos.config.service

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.ServerType
import com.keyfoundry.hifos.config.service.dto.ErrorData
import com.keyfoundry.hifos.config.service.dto.ResponseData
import com.keyfoundry.hifos.config.service.dto.RequestData
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

/*
* 모바일서버 네트워크 설정
* */
interface RetrofitSyncServiceV2 {

    @POST("/hifos/pdaerror") // Call<InitializeResponse> 데이터를 받을 data class
    fun pdaError(@Body ErrorData: ErrorData): Call<ResponseData> // InitializeRequest 요청을 보낼 Json Data Class

    @GET("/hifos/check")
    suspend fun hifosCheck(): ResponseData

    @POST("/hifos/message") // Call<InitializeResponse> 데이터를 받을 data class
    suspend fun hifosProcess(@Body RequestData: RequestData): ResponseData // InitializeRequest 요청을 보낼 Json Data Class

    @POST("/hifos/{messageName}")
    suspend fun hifosProcessMessage(@Body RequestData: RequestData, @Path("messageName") messageName : String): ResponseData

    companion object { // static 처럼 공유객체로 사용가능함. 모든 인스턴스가 공유하는 객체로서 동작함.
        var BASE_URL = ServerType.MOBILE_SERVER_URL // 주소

        var API : RetrofitSyncServiceV2

        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(50L, TimeUnit.SECONDS)
            .readTimeout(50L,TimeUnit.SECONDS)
            .writeTimeout(50L,TimeUnit.SECONDS)
            .build()

        init {
            val gson :Gson =   GsonBuilder().setLenient().create()

            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()

            API = retrofit.create(RetrofitSyncServiceV2::class.java)
        }

        fun reInit(url : String) {
            BASE_URL = url
            val gson :Gson =   GsonBuilder().setLenient().create()

            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()

            API = retrofit.create(RetrofitSyncServiceV2::class.java)
        }
    }

}