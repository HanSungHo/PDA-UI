package com.keyfoundry.hifos.view.chat

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.service.RetrofitSyncService
import com.keyfoundry.hifos.config.utils.CommonUtil.Companion.getLocalIpAddress
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.message.MessageSender
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ChatListActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var treeAdapter: TreeAdapter
    private lateinit var chatAdapter: ChatRoomAdapter
    private lateinit var selectedCountText: TextView
    private lateinit var sendFab: FloatingActionButton

    private val deviceList = mutableListOf<Device>()
    private val wifiIp = getLocalIpAddress() // 기존 코드 참고



    private var ipAddrList = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_list)

        val sendLayout = findViewById<LinearLayout>(R.id.sendLayout)
        recyclerView = findViewById(R.id.recyclerView)
        selectedCountText = findViewById(R.id.selectedCount)
        sendFab = findViewById(R.id.sendFab)

        recyclerView.layoutManager = LinearLayoutManager(this)

        // 초기 TreeAdapter/ChatAdapter
        treeAdapter = TreeAdapter(buildTreeFromDevices(deviceList)) { selectedCount ->
            selectedCountText.text = "선택: $selectedCount"
        }

        chatAdapter = ChatRoomAdapter(emptyList()) { chatRoom ->
            openChatRoom(chatRoom)
        }

        recyclerView.adapter = treeAdapter

        // FAB 클릭: 선택된 Device 메시지 전송
        sendFab.setOnClickListener {
            val selectedDevices = treeAdapter.getSelectedDevices()
            if (selectedDevices.isEmpty()) {
                Toast.makeText(this, "선택된 PDA가 없습니다", Toast.LENGTH_SHORT).show()
            } else {
                sendMessageToDevices(selectedDevices)
            }
        }

        // BottomNavigation 클릭
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menu_friend -> {
                    recyclerView.adapter = treeAdapter
                    sendLayout.visibility = View.VISIBLE // PDA 탭에서만 보이게
                    true
                }
                R.id.menu_chat -> {
                    recyclerView.adapter = chatAdapter
                    refreshChatTab()
                    sendLayout.visibility = View.GONE // PDA 탭에서만 보이게
                    true
                }
                else -> false
            }
        }

        bottomNav.selectedItemId = R.id.menu_chat

        // 초기 서버 데이터 불러오기
        getPdaList { devices ->
            deviceList.clear()
            deviceList.addAll(devices)
            val treeItems = buildTreeFromDevices(devices)
            treeAdapter.updateTree(treeItems)

            // 자동 스크롤: 5DP01 BAY
            val index = treeAdapter.getPositionOfBay(DeviceInfo.BAY)
            if (index >= 0) recyclerView.scrollToPosition(index)
        }
    }

    override fun onResume() {
        super.onResume()
        // 채팅 탭이 선택되어 있으면 서버에서 새로 불러오기
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        if (bottomNav.selectedItemId == R.id.menu_chat) {
            refreshChatTab()
        }
    }

    private fun refreshChatTab() {
        getRoomList { chatRooms ->
            chatAdapter.updateData(chatRooms)
        }
    }

    private fun sendMessageToDevices(devices: List<Device>) {
        val ids = devices.joinToString(",") { it.id }

        ipAddrList.clear()  // 중요!!
        ipAddrList.add(wifiIp.toString())

        if(devices.size>1){

            ipAddrList.addAll(devices.map { it.ip })
            ipAddrList.sort()

            showGroupNameDialog(this) { roomName ->
                createGroupChatroom(roomName)
            }
        } else if (devices.size == 1) {

            ipAddrList.add(devices[0].ip)
            ipAddrList.sort()

            val roomName = "${ipAddrList[0]}_${ipAddrList[1]}"
            createPrivateChatroom(roomName)
        }

    }

    private fun showGroupNameDialog(
        context: Context,
        onConfirm: (String) -> Unit
    ) {
        val editText = EditText(context).apply {
            hint = "그룹 이름 입력"
        }

        AlertDialog.Builder(context)
            .setTitle("채팅방 이름")
            .setView(editText)
            .setPositiveButton("확인") { _, _ ->
                val name = editText.text.toString().trim()
                if (name.isNotEmpty()) {
                    onConfirm(name)
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun openChatRoom(chatRoom: ChatRoom) {
        val intent = Intent(this, ChatRoomActivity::class.java)
        intent.putExtra("roomId", chatRoom.roomId)
        intent.putExtra("roomName", chatRoom.roomName)
        startActivity(intent)
    }

    // 서버에서 채팅방 리스트 가져오기
    private fun getRoomList(callback: (List<ChatRoom>) -> Unit) {
        CoroutineScope(Dispatchers.Main).launch {
            val roomList = mutableListOf<ChatRoom>()
            val sendMessage = MessageFactoryUtil.getPdaMessage(DeviceInfo.FACILITY, "", wifiIp)
            val message = MessageSender.send(supportFragmentManager, sendMessage, MessageName.NEWPDALIST)
            if (message.isSuccessFul) {
                val pdaList = ResponseDataToJsonUtil.getMessageBodyList(message.result, "ITEMS")
                for (i in 0 until pdaList.length()) {
                    val item = pdaList.getJSONObject(i)
                    roomList.add(
                        ChatRoom(
                            item.optString("ROOM_ID"),
                            item.optString("ROOM_KEY"),
                            item.optString("LAST_MESSAGE"),
                            item.optString("LAST_MESSAGE_AT"),
                            item.optString("UNREAD_COUNT")
                        )
                    )
                }
            }
            callback(roomList)
        }
    }

    // 서버에서 PDA(Device) 리스트 가져오기
    private fun getPdaList(callback: (List<Device>) -> Unit) {
        CoroutineScope(Dispatchers.Main).launch {
            val devices = mutableListOf<Device>()
            val message = MessageSender.send(
                supportFragmentManager,
                MessageFactoryUtil.newPdaList(DeviceInfo.FACILITY, "", "", wifiIp.toString()),
                MessageName.NEWPDALIST
            )
            if (message.isSuccessFul) {
                val pdaList = ResponseDataToJsonUtil.getMessageBodyList(message.result, "PDAS")
                for (i in 0 until pdaList.length()) {
                    val item = pdaList.getJSONObject(i)
                    devices.add(
                        Device(
                            item.optString("PDAID"),
                            item.optString("IPADDRESS"),
                            item.optString("BAY"),
                            item.optString("AREA"),
                            item.optString("USERNAME")
                        )
                    )
                }
            }
            callback(devices)
        }
    }

    private fun createPrivateChatroom(roomName : String){
        val request = CreateChatRoom(
            roomType = "PRIVATE",
            roomName = roomName,
            creatorId = "",
            ipAddrList = ipAddrList
        )

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)

        RetrofitSyncService.API.createPdaMessage(request)
            .enqueue(object : retrofit2.Callback<Void> {

                override fun onResponse(
                    call: retrofit2.Call<Void>,
                    response: retrofit2.Response<Void>
                ) {
                    if (response.isSuccessful) {
                        bottomNav.selectedItemId = R.id.menu_chat
                        println("메시지 전송 성공")
                    } else {
                        println("전송 실패: ${response.code()}")
                    }
                }

                override fun onFailure(call: retrofit2.Call<Void>, t: Throwable) {
                    println("에러 발생: ${t.message}")
                }
            })

    }


    private fun createGroupChatroom(roomName : String){

        val request = CreateChatRoom(
            roomType = "GROUP",
            roomName = roomName,
            creatorId = "",
            ipAddrList = ipAddrList
        )


        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)

        RetrofitSyncService.API.createPdaMessage(request)
            .enqueue(object : retrofit2.Callback<Void> {

                override fun onResponse(
                    call: retrofit2.Call<Void>,
                    response: retrofit2.Response<Void>
                ) {
                    if (response.isSuccessful) {
                        bottomNav.selectedItemId = R.id.menu_chat
                        println("메시지 전송 성공")
                    } else {
                        println("전송 실패: ${response.code()}")
                    }
                }

                override fun onFailure(call: retrofit2.Call<Void>, t: Throwable) {
                    println("에러 발생: ${t.message}")
                }
            })

    }

    // Device 리스트 → TreeItem 변환
    private fun buildTreeFromDevices(devices: List<Device>): List<TreeItem> {
        val treeItems = mutableListOf<TreeItem>()
        val areaMap = devices.groupBy { it.area }

        areaMap.forEach { (areaName, areaDevices) ->
            val bays = areaDevices.groupBy { it.bay }.map { (bayName, bayDevices) ->
                BayGroup(bayName, bayDevices.toMutableList())
            }.toMutableList()

            val areaGroup = AreaGroup(areaName, bays)
            val areaItem = TreeItem.AreaItem(areaGroup)
            treeItems.add(areaItem)

            bays.forEach { bay ->
                val bayItem = TreeItem.BayItem(bay)
                treeItems.add(bayItem)
                bay.devices.forEach { device ->
                    treeItems.add(TreeItem.DeviceItem(device))
                }
            }
        }
        return treeItems
    }
}