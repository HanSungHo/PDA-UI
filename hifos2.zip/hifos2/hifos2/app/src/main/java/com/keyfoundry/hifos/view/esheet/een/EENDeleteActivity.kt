package com.keyfoundry.hifos.view.esheet.een

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.spinner.SpinnerItem
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityEenDeleteBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.lang.Exception
import java.util.ArrayList


/*
*   EEN 등록하기 기능 화면 (Addition by Sunggil Hwang, 2024.01.19)
    Requested by 제조팀 김택용 FL
* */
class EENDeleteActivity :  HFActivity() {
     companion object {
         private const val TAG = "SettingEEN"
     }

    private lateinit var viewBinding: ActivityEenDeleteBinding
    private lateinit var keyboardVisibilityUtils: KeyboardVisibilityUtils

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    lateinit var lotId: String
    lateinit var operation: String
    lateinit var processStep: String
    lateinit var operSeq: String
    lateinit var factoryname: String
    lateinit var product: String
    lateinit var route: String
    lateinit var eenId: String
    lateinit var tagId: String
    lateinit var tagComment: String
    lateinit var oldTagComment: String
    lateinit var actionPoint: String
    lateinit var poDesc: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityEenDeleteBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        keyboardVisibilityUtils = KeyboardVisibilityUtils(window,
            onShowKeyboard = { keyboardHeight ->
                viewBinding.svRoot.run {
                    smoothScrollTo(scrollX, scrollY + keyboardHeight)
                }
            })

        lotId = intent.getStringExtra("LOTID").toString()
        factoryname = intent.getStringExtra("FACTORYNAME").toString()
        product = intent.getStringExtra("PRODUCT").toString()
        route = intent.getStringExtra("ROUTE").toString()
        operation = intent.getStringExtra("OPERATION").toString()
        processStep = intent.getStringExtra("PROCESSSTEP").toString()
        operSeq = intent.getStringExtra("OPERSEQUENCE").toString()
        eenId = intent.getStringExtra("EENID").toString()
        tagComment = intent.getStringExtra("TAGCOMMENT").toString()
        actionPoint = intent.getStringExtra("ACTIONPOINT").toString()
        tagId = intent.getStringExtra("TAGID").toString()
        poDesc = intent.getStringExtra("PODESC").toString()

        oldTagComment = tagComment

        viewBinding.txtLotId.text = lotId
        viewBinding.txtFacility.text = factoryname
        viewBinding.txtProduct.text = product
        viewBinding.txtRoute.text = route
        viewBinding.txtOperation.text = operation
        viewBinding.txtEenid.text = eenId
        viewBinding.txtPodesc.text = poDesc
        viewBinding.txtComment.setText(tagComment)
        viewBinding.txtTagId.text = tagId
        viewBinding.txtActionPoint.text = actionPoint
        viewBinding.btnConfirm.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)


    }


    private fun deleteEEN(){
        if (viewBinding.editDeleteReason.text.toString().trim() == "")
        {
            OkDialog.show(
                supportFragmentManager, "삭제 사유 입력",
                "삭제 사유를 입력하세요.", GetString.BTNOKSTR)
            return;
        }

        val returnCode = OkCancelDialog.show(
            supportFragmentManager,
            GetString.TXTDIALOGTITLE_OK,
            "삭제하시겠습니까?",
            GetString.BTNYESSTR,
            GetString.BTNNOSTR
        )

        if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
            return
        }

        val sendMessage = MessageFactoryUtil.deleteEen(
            viewBinding.txtLotId.text.toString(),
            DeviceInfo.OPERATOR_ID,
            viewBinding.txtFacility.text.toString().trim(),
            viewBinding.txtProduct.text.toString().trim(),
            viewBinding.txtOperation.text.toString().trim(),
            viewBinding.txtActionPoint.text.toString().trim(),
            viewBinding.txtEenid.text.toString().trim(),
            viewBinding.txtRoute.text.toString().trim(),
            viewBinding.txtComment.text.toString(),
            viewBinding.txtTagId.text.toString().trim(),
            viewBinding.editDeleteReason.text.toString()
        )

        mainScope.launch {
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_OK,
                    "EEN 삭제가 완료 되었습니다.",
                    GetString.BTNOKSTR
                )

                val returnIntent = Intent()
                returnIntent.putExtra("LOTID", lotId)
                setResult(Activity.RESULT_OK, returnIntent)
                finish()

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )

            }
        }
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnConfirm.id -> {
                    deleteEEN()
                }
                viewBinding.btnCancel.id ->{
                    CommonUtil.hideKeyboard(this@EENDeleteActivity, currentFocus)
                    finish()
                }
            }
        }
    }
}