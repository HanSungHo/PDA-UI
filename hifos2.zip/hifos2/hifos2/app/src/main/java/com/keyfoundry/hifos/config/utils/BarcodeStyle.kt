package com.keyfoundry.hifos.config.utils

import android.widget.EditText
import androidx.fragment.app.FragmentActivity
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.view.dialog.fragment.OkDialogFragment
/*
* Barcode 읽었을 경우 Lot, EQP 에 대한 파싱 로직
* */
class BarcodeStyle(val activity: FragmentActivity) {
    private lateinit var okDialogFragment: OkDialogFragment

    fun lotId(editLotId: EditText): Boolean {
        val lotId = editLotId.text.toString()
        val returnLotId: String

        if (!lotId.startsWith(" ")) {
            returnLotId = ""
//            val returnCode = OkDialog.show(activity.supportFragmentManager,"READING ERROR", "LOT#를 읽어주세요.", GetString.BTNOKSTR)
            okDialogFragment = OkDialogFragment("READING ERROR", "LOT#를 읽어주세요.", GetString.BTNOKSTR)
            okDialogFragment.show(activity.supportFragmentManager, "okDialog")
        } else {
            var replaceLotId = lotId.replaceFirst(" ", "")

            //2024.10.08 Barcode Lot 가장 왼쪽 문자에 $표시 있을 경우 제거후 반환하도록 개선
            if(replaceLotId.startsWith("$")){
                replaceLotId = lotId.replaceFirst("$", "").trimStart()
            }

            returnLotId = if (replaceLotId.isNotEmpty())
                replaceLotId.substring(0, replaceLotId.length - 1)
            else
                replaceLotId
        }

        editLotId.setText(returnLotId)

        return returnLotId.isNotEmpty()
    }

    fun eqpId(editEqpId: EditText): Boolean {
        val eqpId = editEqpId.text.toString()
        val returnEqpId: String

        if (!eqpId.startsWith("EQP-")) {
            returnEqpId = ""
//            val returnCode = OkDialog.show(activity.supportFragmentManager,"READING ERROR", "진행할 장비를 읽어주세요.", GetString.BTNOKSTR)
            okDialogFragment =
                OkDialogFragment("READING ERROR", "진행할 장비를 읽어주세요.", GetString.BTNOKSTR)
            okDialogFragment.show(activity.supportFragmentManager, "okDialog")
        } else {
            val replaceEqpId = eqpId.replaceFirst("EQP-", "")

            returnEqpId = if (replaceEqpId.isNotEmpty())
                replaceEqpId.substring(0, replaceEqpId.length - 1)
            else
                replaceEqpId
        }

        editEqpId.setText(returnEqpId)

        return returnEqpId.isNotEmpty()
    }

    fun ProbeCardId(editProbeCardId: EditText): Boolean {
        val ProbeCardId = editProbeCardId.text.toString()
        val returnProbeCard: String

        if (!ProbeCardId.startsWith(" ")) {
            returnProbeCard = ""
            okDialogFragment = OkDialogFragment("READING ERROR", "ProbeCard#를 읽어주세요.", GetString.BTNOKSTR)
            okDialogFragment.show(activity.supportFragmentManager, "okDialog")
        } else {
            val replaceProbeCardId = ProbeCardId.replaceFirst(" ", "")
            returnProbeCard = if (replaceProbeCardId.isNotEmpty())
                replaceProbeCardId.substring(0, replaceProbeCardId.length - 1)  // -1을 할지 말지 다시 확인을 해야함.
            else
                replaceProbeCardId
        }

        editProbeCardId.setText(returnProbeCard)

        return returnProbeCard.isNotEmpty()
    }
}