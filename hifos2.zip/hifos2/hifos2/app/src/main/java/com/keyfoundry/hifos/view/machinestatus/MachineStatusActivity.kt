package com.keyfoundry.hifos.view.machinestatus

import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.GestureDetectorCompat
import androidx.core.view.children
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityMachineStatusBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.machinestatus.detail.MachineStatusDetailActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MachineStatusActivity : HFActivity() {
    companion object {
        private const val TAG = "MachineStatusActivity"
    }

    private lateinit var viewBinding: ActivityMachineStatusBinding

    private lateinit var gridService: GridService

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    inner class MachineGestureListener(private val eqpId: String) :
        GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(e: MotionEvent?): Boolean {
            viewBinding.editEqpId.setText("")
            viewBinding.editEqpId.setText(eqpId)

            return super.onSingleTapUp(e)
        }

        override fun onDoubleTap(e: MotionEvent?): Boolean {
            showDetailMachine()

            return super.onDoubleTap(e)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityMachineStatusBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editEqpId.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        gridService = GridService(applicationContext)

        setBaySpinner()

        viewBinding.editEqpId.setOnEditorActionListener(onEditorActionListener)

        viewBinding.btnSearchMachine.setOnClickListener(onSingleClickListener)
        viewBinding.btnDetailMachine.setOnClickListener(onSingleClickListener)
        viewBinding.btnClose.setOnClickListener(onSingleClickListener)
    }

    private val onEditorActionListener =
        TextView.OnEditorActionListener { v, actionId, event ->
            when (v.id) {
                viewBinding.editEqpId.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        val check = BarcodeStyle(this).eqpId(viewBinding.editEqpId)

                        if (check)
                            showDetailMachine()
                        else
                            clearData()

                        viewBinding.editEqpId.requestFocus()
                        viewBinding.editEqpId.selectAll()
                    } else if (event != null) {
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            val check = BarcodeStyle(this).eqpId(viewBinding.editEqpId)

                            if (check)
                                showDetailMachine()
                            else
                                clearData()

                            viewBinding.editEqpId.requestFocus()
                            viewBinding.editEqpId.selectAll()
                        }
                    }
                }
            }

            true
        }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchMachine.id -> {
                    setEQPList()
                }
                viewBinding.btnDetailMachine.id -> {
                    showDetailMachine()
                }
                viewBinding.btnClose.id -> {
                    finish()
                }
            }
        }
    }

    private fun showDetailMachine() {
        CommonUtil.hideKeyboard(this, currentFocus)
        if (viewBinding.editEqpId.text.isEmpty()) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "장비를 입력해주세요", GetString.BTNOKSTR
            )
            return
        }

        viewBinding.editEqpId.requestFocus()
        viewBinding.editEqpId.selectAll()

        val machineStatusDialogIntent = Intent(this, MachineStatusDetailActivity::class.java)
        machineStatusDialogIntent.putExtra("EQPID", viewBinding.editEqpId.text.toString())

        activityFactoryResultLauncher.launch(machineStatusDialogIntent)
    }

    private val activityFactoryResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                setEQPList()
            }
        }

    private fun setBaySpinner() {
        mainScope.launch {
            clearData()

            val sendMessage = MessageFactoryUtil.areaBayInfo(DeviceInfo.AREA, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.AREABAYINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val bayListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "BAYS")

                val spinnerBayItems = arrayListOf<String>()

                for (i in 0 until bayListJSON.length()) {
                    val bay = bayListJSON.getJSONObject(i)
                    spinnerBayItems.add(bay.getString("BAY"))
                }

                val spinnerAdapter = ArrayAdapter(
                    applicationContext, R.layout.contact_spinner_row_init, spinnerBayItems
                )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerBay.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                //---[Addition] May 07, 2007. by I. H. Lee
                viewBinding.editEqpId.requestFocus()
                viewBinding.editEqpId.selectAll()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearData() {
        viewBinding.editEqpId.setText("")
        viewBinding.mainBody.removeAllViews()
    }

    private fun setEQPList() {
        mainScope.launch {
            if (viewBinding.spinnerBay.selectedItem == null)
                return@launch

            clearData()

            val sendMessage = MessageFactoryUtil.bayEQPInfo(
                viewBinding.spinnerBay.selectedItem.toString(), DeviceInfo.FACILITY
            )
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.BAYEQPINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val eqpDataList = ResponseDataToJsonUtil.getMessageBodyList(result, "EQPITEMS")

                val columnData = linkedMapOf(
                    "EQPID" to ColumnProperty("장비", Gravity.CENTER, false),
                    "EQPSTATUS" to ColumnProperty("상태", Gravity.CENTER, false),
                    "EQPDESCRIPTION" to ColumnProperty("DESCRIPTION", Gravity.START, false),
                    "EQPTYPE" to ColumnProperty("TYPE", Gravity.CENTER, false)
                )

                val eqpList = gridService.setGridPropData(columnData, eqpDataList)
                setGridTouchEvent(eqpList)
                viewBinding.mainBody.addView(eqpList)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setGridTouchEvent(eqpList: CTMainLayout) {
        for (mainRow in eqpList.mainTable.children) {
            val eqpId = gridService.getCellValue(mainRow, "EQPID")

            val mDetector =
                GestureDetectorCompat(this, MachineGestureListener(eqpId))
            mainRow.setOnTouchListener { v, event ->
                mDetector.onTouchEvent(event)
                v.performClick()
            }
        }
    }
}