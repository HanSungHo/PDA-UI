package com.keyfoundry.hifos.view

import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.util.Log
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.domain.UserInfo
import com.keyfoundry.hifos.config.service.dto.ResponseData
import com.keyfoundry.hifos.config.service.room.SettingInfoService
import com.keyfoundry.hifos.config.service.room.UserInfoService
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityLoginBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*

class LoginActivity : HFActivity() {
    companion object {
        private const val TAG = "LoginActivity"
    }

    private lateinit var viewBinding: ActivityLoginBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var keyboardVisibilityUtils: KeyboardVisibilityUtils

    private lateinit var settingInfoService: SettingInfoService
    private lateinit var userInfoService: UserInfoService

    private var facility = ""
    private var area = ""
    private var bay = ""

    private var isEmptySetting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.editUserId.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        keyboardVisibilityUtils = KeyboardVisibilityUtils(window,
            onShowKeyboard = { keyboardHeight ->
                viewBinding.svRoot.run {
                    smoothScrollTo(scrollX, scrollY + keyboardHeight)
                }
            })

        settingInfoService = SettingInfoService(applicationContext)
        userInfoService = UserInfoService(applicationContext)

        checkHistoryUser()
        CommonUtil.checkPDAName(this)

        viewBinding.editPassword.setOnEditorActionListener(onEditorActionListener)

        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
    }

    override fun onResume() {
        super.onResume()

        CommonUtil.checkPDAName(this)
    }

    private val onEditorActionListener = TextView.OnEditorActionListener { v, actionId, event ->
        when (v.id) {
            viewBinding.editPassword.id -> {
                if (actionId == EditorInfo.IME_ACTION_DONE)
                    executeLogin()
            }
        }

        true
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnOk.id -> {
                    executeLogin()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    private fun executeLogin() {
        CommonUtil.hideKeyboard(this, currentFocus)

        //-- 0. check validation
        val userId = viewBinding.editUserId.text.toString().trim().toUpperCase(Locale.ROOT)
        val password = viewBinding.editPassword.text.toString().toUpperCase(Locale.ROOT)

        if (userId.isEmpty()) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_WARNING,
                "아이디를 입력해주세요", GetString.BTNOKSTR
            )
            return
        }

        if (password.isEmpty()) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_WARNING,
                "패스워드를 입력해주세요", GetString.BTNOKSTR
            )
            return
        }

        //userId = "GGUKJIN"
        //password = "WLSDHR"
        loginCheck(userId, password)
    }

    // 1. check Login Info
    private fun loginCheck(userId: String, password: String) {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.login(userId, password, facility, bay)

            val message = MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOGIN)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                // 성공시 로직
                loginOK(result)
            } else {
                // 성공 실패시 로직
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)

                val returnCode = OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                if (returnCode == OkDialog.RETURN_CODE_OK) {
                    viewBinding.editPassword.setText("")
                }
            }
        }
    }

    // 2. save Login Info
    private fun loginOK(responseData: ResponseData) {
        ioScope.launch {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(responseData)
            val operatorId = messageBody.optString(GetString.OPERID)
            val operatorName = messageBody.optString(GetString.OPERNAME)
            val permission = messageBody.optString(GetString.PERMISSTION)
            val gasInput = messageBody.optString("GASINPUT")
            userInfoService.insert(
                UserInfo(
                    operatorId, operatorName, facility,
                    area, bay, permission, true, System.currentTimeMillis()
                )
            )

            // set DeviceInfo
            DeviceInfo.OPERATOR_ID = operatorId
            DeviceInfo.OPERATOR_NAME = operatorName
            DeviceInfo.PERMISSION = permission
            DeviceInfo.GASINPUT = gasInput

            Log.d("loginOK", "SUCCESS $operatorId, $operatorName, $facility ,$area ,$bay")

            mainScope.launch {
                val resultIntent = Intent()
                resultIntent.putExtra(GetString.OPERID, operatorId)
                resultIntent.putExtra(GetString.OPERNAME, operatorName)
                setResult(RESULT_OK, resultIntent)

                val success = """
                    |$operatorName 님
                    |로그인 성공 하였습니다.
                """.trimMargin()
                val returnCode = OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_LOGIN,
                    success, GetString.BTNOKSTR
                )

                if (returnCode == OkDialog.RETURN_CODE_OK) {
                    val wifiIp = CommonUtil.wifiIpAddress(this@LoginActivity)
                    if (wifiIp != null)
                        sendConfig(wifiIp)

                    finish()
                }
            }
        }

    }

    private suspend fun sendConfig(wifiIp: String) {
        val sendMessage = MessageFactoryUtil.config(
            facility, area, bay, DeviceInfo.DEVICE_NAME, wifiIp, DeviceInfo.OPERATOR_ID
        )

        val message = MessageSender.send(supportFragmentManager, sendMessage, MessageName.CONFIG)
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {

        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)

            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )
        }
    }

    // check UserInfo DB
    private fun checkHistoryUser() {
        ioScope.launch {
            // 1. set Setting Info
            val settingInfo = settingInfoService.selectSettingInfo()
            facility = settingInfo.facility
            area = settingInfo.area
            bay = settingInfo.bay
            isEmptySetting = facility.isEmpty() && area.isEmpty() && bay.isEmpty()

            val userInfo = userInfoService.selectUserInfo()

            if (userInfo != null) {
                val operId = userInfo.operId
                if (operId.isNotEmpty()) {
                    mainScope.launch {
                        viewBinding.editUserId.setText(operId)
                        viewBinding.editPassword.requestFocus()
                    }
                }
            }
        }

    }
}