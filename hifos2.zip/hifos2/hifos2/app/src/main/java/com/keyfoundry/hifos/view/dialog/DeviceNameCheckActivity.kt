package com.keyfoundry.hifos.view.dialog

import android.bluetooth.BluetoothAdapter
import android.os.Bundle
import android.view.View
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.utils.CommonUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivityDeviceNameCheckBinding
import com.keyfoundry.hifos.view.dialog.fragment.LoadingBar
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class DeviceNameCheckActivity : AppCompatActivity() {
    private lateinit var viewBinding: ActivityDeviceNameCheckBinding
    private lateinit var bluetoothAdapter: BluetoothAdapter

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setFinishOnTouchOutside(false)

        viewBinding = ActivityDeviceNameCheckBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()

        val btName = bluetoothAdapter.name.toString()
        val wifiIp = CommonUtil.wifiIpAddress(this)
        val msg = """
            |PDA 기기명이 잘못 설정 되었습니다.
            |반장님께 PDA 기기명 변경을 요청 하시기 바랍니다.
        """.trimMargin()

        viewBinding.txtPdaIp.text = wifiIp
        viewBinding.txtContent.text = msg
        viewBinding.txtCurrentPda.text = btName

        viewBinding.editNewPda.setOnEditorActionListener(onEditorActionListener)
        viewBinding.btnOk.setOnClickListener(singleClickListener)
    }

    override fun onBackPressed() {
        return
    }

    private val onEditorActionListener =
        TextView.OnEditorActionListener { v, actionId, event ->
            when (v.id) {
                viewBinding.editNewPda.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        changeDeviceName()
                    }
                }
            }

            true
        }

    private val singleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnOk.id -> {
                    changeDeviceName()
                }
            }
        }
    }

    private fun changeDeviceName() {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@DeviceNameCheckActivity, currentFocus)

            val changeDeviceName = viewBinding.editNewPda.text.toString()

            if (changeDeviceName.trim().isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "새로운 PDA 명이 비어있습니다.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (changeDeviceName.length != 3) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "3자리 숫자를 입력해주세요.", GetString.BTNOKSTR
                )

                return@launch
            }

            LoadingBar.show(supportFragmentManager)
            if (!bluetoothAdapter.isEnabled)
                bluetoothAdapter.enable()

            // 블루투스가 꺼지고 켜지는 시간을 기다리기 위해서 Delay 적용
            delay(1000L)

            val newName = "AR${viewBinding.editNewPda.text}"

            while (bluetoothAdapter.name != newName)
                bluetoothAdapter.name = newName

            DeviceInfo.DEVICE_NAME = bluetoothAdapter.name.toString()
            bluetoothAdapter.disable()

            // 변경 후 Main화면에 기기명 업데이트 하기위해 Delay 좀 더 적용
            delay(2000L)
            LoadingBar.hide(supportFragmentManager)

            finish()
        }
    }
}