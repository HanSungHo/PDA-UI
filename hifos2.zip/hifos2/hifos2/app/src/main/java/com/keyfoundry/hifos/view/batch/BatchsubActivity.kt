package com.keyfoundry.hifos.view.batch

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import androidx.core.view.GestureDetectorCompat
import androidx.core.view.children
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.utils.GridService
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityBatchsubBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.diff.DiffInstParameterActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BatchsubActivity : HFActivity() {

    companion object{
        private const val TAG = "BatchsubActivity"
    }
    private lateinit var viewBinding: ActivityBatchsubBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)
    lateinit var gridService: GridService
    private lateinit var gridList: CTMainLayout
    private lateinit var columnData : LinkedHashMap<String, ColumnProperty>
    private var psbatchid = ""
    private var returnlotname = ""

    inner class batchGestureListener (private val Jalotname: String) :
        GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(e: MotionEvent?): Boolean {
            //main폼으로 전달해주고 조회 해주면 끝~!
            returnlotname = Jalotname
            sendjalotname()
            return super.onSingleTapUp(e)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityBatchsubBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.btnCancle.setOnClickListener(onSingleClickListener)

        if(intent.getStringExtra("MOBATCHID")?.isNotEmpty() == true){
            val mobatchid = intent.getStringExtra("MOBATCHID").toString()
            Log.d(TAG, mobatchid)
            psbatchid = mobatchid

            getbatch()
        }

        gridService = GridService(applicationContext)

    }

    private val onSingleClickListener = object : OnSingleClickListener(){
        override fun onSingleClick(it: View) {
            when(it.id) {
                viewBinding.btnCancle.id ->{
                    cancel()
                }
            }
        }
    }

    private fun cancel() {
        val returnIntent = Intent()
        returnIntent.putExtra("JALOTNAME","" )
        setResult(Activity.RESULT_CANCELED, returnIntent)

        finish()
    }

    private fun getbatch (){
        var serchType = "C"
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.batchType(DeviceInfo.FACILITY, psbatchid, serchType)
            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.BATCHTYPE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if(isSuccessFul){

                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val itemList = ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "ITEMS")

                columnData = linkedMapOf(
                    "ROWNUM" to ColumnProperty("N0", Gravity.CENTER, false,100),
                    "BATCHID" to ColumnProperty("BATCHID", Gravity.CENTER, false, 300),
                    "LOT1" to ColumnProperty("Lot No", Gravity.CENTER, false,250)
                )
                val mainGrid = gridService.setGridPropData(columnData, itemList)
                setGridTouchEvent(mainGrid)
                viewBinding.mainbody.addView(mainGrid)
            }
        }
    }

    private fun setGridTouchEvent(itemList: CTMainLayout) {
        for (mainRow in itemList.mainTable.children) {
            val Jalotname = gridService.getCellValue(mainRow, "LOT1")

            val mDetector = GestureDetectorCompat(this, batchGestureListener(Jalotname))
            mainRow.setOnTouchListener { v, event ->
                mDetector.onTouchEvent(event)
                v.performClick()
            }
        }
    }

    private fun sendjalotname(){
        val returnIntent = Intent()
        returnIntent.putExtra("JALOTNAME",returnlotname )
        setResult(Activity.RESULT_OK, returnIntent)
        finish()
    }
}