package com.keyfoundry.hifos.view.esheet.moveout

import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.spinner.SpinnerItem
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityLossBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.cmm.WaferSelectActivity
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class LossActivity : HFActivity() {
    companion object {
        private const val TAG = "LossActivity"
    }

    private lateinit var viewBinding: ActivityLossBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var targetSpinner = 0
    private var waferList = ""
    private var initSpinnerPosition = hashMapOf<String, Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityLossBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true
            && intent.getStringExtra("OPERATION")?.isNotEmpty() == true
            && intent.getStringExtra("SUBOPERATION")?.isNotEmpty() == true
        ) {

            val lotId = intent.getStringExtra("LOTID").toString()
            val operation = intent.getStringExtra("OPERATION").toString()
            val subOperation = intent.getStringExtra("SUBOPERATION").toString()

            viewBinding.editLotNo.setText(lotId)

            searchLossInfo(lotId, operation, subOperation)
        }

        viewBinding.spinnerCurrentQty.setOnTouchListener(onTouchListener)
        viewBinding.spinnerLossCode.setOnTouchListener(onTouchListener)
        viewBinding.spinnerLossCode2.setOnTouchListener(onTouchListener)
        viewBinding.spinnerLossCode3.setOnTouchListener(onTouchListener)
        viewBinding.spinnerLossCode4.setOnTouchListener(onTouchListener)
        viewBinding.spinnerLossCode5.setOnTouchListener(onTouchListener)
        viewBinding.spinnerQty.setOnTouchListener(onTouchListener)
        viewBinding.spinnerQty2.setOnTouchListener(onTouchListener)
        viewBinding.spinnerQty3.setOnTouchListener(onTouchListener)
        viewBinding.spinnerQty4.setOnTouchListener(onTouchListener)
        viewBinding.spinnerQty5.setOnTouchListener(onTouchListener)

        viewBinding.spinnerCurrentQty.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerLossCode.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerLossCode2.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerLossCode3.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerLossCode4.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerLossCode5.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerQty.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerQty2.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerQty3.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerQty4.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerQty5.onItemSelectedListener = itemSelectListener

        viewBinding.btnWafer.setOnClickListener(onSingleClickListener)
        viewBinding.btnWafer2.setOnClickListener(onSingleClickListener)
        viewBinding.btnWafer3.setOnClickListener(onSingleClickListener)
        viewBinding.btnWafer4.setOnClickListener(onSingleClickListener)
        viewBinding.btnWafer5.setOnClickListener(onSingleClickListener)

        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
    }

    private val onTouchListener = View.OnTouchListener { v, event ->
        targetSpinner = v.id
        v.performClick()
    }

    private val itemSelectListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerCurrentQty.id -> {
                        if (targetSpinner == viewBinding.spinnerCurrentQty.id) {
                            setGapQty()
                        }
                    }
                    viewBinding.spinnerLossCode.id -> {
                        if (targetSpinner == viewBinding.spinnerLossCode.id) {
                            if (!checkInUseLossCode(
                                    viewBinding.spinnerLossCode,
                                    viewBinding.spinnerQty,
                                    viewBinding.txtWafer
                                )
                            )
                                return
                        }
                    }
                    viewBinding.spinnerLossCode2.id -> {
                        if (targetSpinner == viewBinding.spinnerLossCode2.id) {
                            if (!checkInUseLossCode(
                                    viewBinding.spinnerLossCode2,
                                    viewBinding.spinnerQty2,
                                    viewBinding.txtWafer2
                                )
                            )
                                return
                        }
                    }
                    viewBinding.spinnerLossCode3.id -> {
                        if (targetSpinner == viewBinding.spinnerLossCode3.id) {
                            if (!checkInUseLossCode(
                                    viewBinding.spinnerLossCode3,
                                    viewBinding.spinnerQty3,
                                    viewBinding.txtWafer3
                                )
                            )
                                return
                        }
                    }
                    viewBinding.spinnerLossCode4.id -> {
                        if (targetSpinner == viewBinding.spinnerLossCode4.id) {
                            if (!checkInUseLossCode(
                                    viewBinding.spinnerLossCode4,
                                    viewBinding.spinnerQty4,
                                    viewBinding.txtWafer4
                                )
                            )
                                return
                        }
                    }
                    viewBinding.spinnerLossCode5.id -> {
                        if (targetSpinner == viewBinding.spinnerLossCode5.id) {
                            if (!checkInUseLossCode(
                                    viewBinding.spinnerLossCode5,
                                    viewBinding.spinnerQty5,
                                    viewBinding.txtWafer5
                                )
                            )
                                return
                        }
                    }
                    viewBinding.spinnerQty.id -> {
                        if (targetSpinner == viewBinding.spinnerQty.id) {
                            viewBinding.txtWafer.text = ""

                            if (!checkLossCode(viewBinding.spinnerLossCode, viewBinding.spinnerQty))
                                return

                            if (!checkQty(viewBinding.spinnerQty))
                                return
                        }
                    }
                    viewBinding.spinnerQty2.id -> {
                        if (targetSpinner == viewBinding.spinnerQty2.id) {
                            viewBinding.txtWafer2.text = ""

                            if (!checkLossCode(
                                    viewBinding.spinnerLossCode2,
                                    viewBinding.spinnerQty2
                                )
                            )
                                return

                            if (!checkQty(viewBinding.spinnerQty2))
                                return
                        }
                    }
                    viewBinding.spinnerQty3.id -> {
                        if (targetSpinner == viewBinding.spinnerQty3.id) {
                            viewBinding.txtWafer3.text = ""

                            if (!checkLossCode(
                                    viewBinding.spinnerLossCode3,
                                    viewBinding.spinnerQty3
                                )
                            )
                                return

                            if (!checkQty(viewBinding.spinnerQty3))
                                return
                        }
                    }
                    viewBinding.spinnerQty4.id -> {
                        if (targetSpinner == viewBinding.spinnerQty4.id) {
                            viewBinding.txtWafer4.text = ""

                            if (!checkLossCode(
                                    viewBinding.spinnerLossCode4,
                                    viewBinding.spinnerQty4
                                )
                            )
                                return

                            if (!checkQty(viewBinding.spinnerQty4))
                                return
                        }
                    }
                    viewBinding.spinnerQty5.id -> {
                        if (targetSpinner == viewBinding.spinnerQty5.id) {
                            viewBinding.txtWafer5.text = ""

                            if (!checkLossCode(
                                    viewBinding.spinnerLossCode5,
                                    viewBinding.spinnerQty5
                                )
                            )
                                return

                            if (!checkQty(viewBinding.spinnerQty5))
                                return
                        }
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {

        }
    }

    private fun checkInUseLossCode(lossCode: Spinner, qty: Spinner, wafer: TextView): Boolean {
        var count = 0

        val spinnerItem = lossCode.selectedItem as SpinnerItem

        if (spinnerItem.key != "NON") {
            if (viewBinding.spinnerLossCode.selectedItem.toString() == lossCode.selectedItem.toString())
                count++

            if (viewBinding.spinnerLossCode2.selectedItem.toString() == lossCode.selectedItem.toString())
                count++

            if (viewBinding.spinnerLossCode3.selectedItem.toString() == lossCode.selectedItem.toString())
                count++

            if (viewBinding.spinnerLossCode4.selectedItem.toString() == lossCode.selectedItem.toString())
                count++

            if (viewBinding.spinnerLossCode5.selectedItem.toString() == lossCode.selectedItem.toString())
                count++

            if (count > 1) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "같은 LOSS CODE가 이미 존재합니다.", GetString.BTNOKSTR
                )

                lossCode.setSelection(1, false)
                return false
            }
        } else {
            qty.setSelection(1, false)
            wafer.text = ""
        }

        return true
    }

    private fun initSpinnerData() {
        initSpinnerPosition["LOSSCODE"]?.let { viewBinding.spinnerLossCode.setSelection(it, false) }
        initSpinnerPosition["LOSSCODE2"]?.let {
            viewBinding.spinnerLossCode2.setSelection(it, false)
        }
        initSpinnerPosition["LOSSCODE3"]?.let {
            viewBinding.spinnerLossCode3.setSelection(it, false)
        }
        initSpinnerPosition["LOSSCODE4"]?.let {
            viewBinding.spinnerLossCode4.setSelection(it, false)
        }
        initSpinnerPosition["LOSSCODE5"]?.let {
            viewBinding.spinnerLossCode5.setSelection(it, false)
        }
        initSpinnerPosition["QTY"]?.let { viewBinding.spinnerQty.setSelection(it, false) }
        initSpinnerPosition["QTY2"]?.let { viewBinding.spinnerQty2.setSelection(it, false) }
        initSpinnerPosition["QTY3"]?.let { viewBinding.spinnerQty3.setSelection(it, false) }
        initSpinnerPosition["QTY4"]?.let { viewBinding.spinnerQty4.setSelection(it, false) }
        initSpinnerPosition["QTY5"]?.let { viewBinding.spinnerQty5.setSelection(it, false) }
    }

    private fun setGapQty() {
        val before = viewBinding.txtBeforeQty.text.toString().toInt()
        val current = viewBinding.spinnerCurrentQty.selectedItem.toString().toInt()

        viewBinding.txtGapQty.text = (before - current).toString()

        initSpinnerData()
    }

    private fun checkLossCode(lossCode: Spinner, qty: Spinner): Boolean {
        val spinnerItem = lossCode.selectedItem as SpinnerItem

        if (spinnerItem.key == "NON") {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "먼저 LOSS CODE를 선택하세요.", GetString.BTNOKSTR
            )

            qty.setSelection(1, false)

            return false
        }

        return true
    }

    private fun checkQty(qty: Spinner): Boolean {
        if (qty.selectedItem.toString() == "0") {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "수량을 0으로 지정할수 없습니다.", GetString.BTNOKSTR
            )

            return false
        }

        val total = viewBinding.spinnerQty.selectedItem.toString()
            .toInt() + viewBinding.spinnerQty2.selectedItem.toString().toInt()
        +viewBinding.spinnerQty3.selectedItem.toString()
            .toInt() + viewBinding.spinnerQty4.selectedItem.toString()
            .toInt() + viewBinding.spinnerQty5.selectedItem.toString().toInt()

        if (total > viewBinding.txtGapQty.text.toString().toInt()) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "지정한 수량이 현재수량을 초과하였습니다.", GetString.BTNOKSTR
            )

            qty.setSelection(1, false)
            targetSpinner = 0

            return false
        }

        return true
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnWafer.id -> {
                    val nextIntent = setNextIntent(
                        viewBinding.spinnerLossCode,
                        viewBinding.spinnerQty,
                        viewBinding.txtWafer,
                        "1"
                    )
                    if (nextIntent != null)
                        activityFactoryResultLauncher.launch(nextIntent)
                }
                viewBinding.btnWafer2.id -> {
                    val nextIntent = setNextIntent(
                        viewBinding.spinnerLossCode2,
                        viewBinding.spinnerQty2,
                        viewBinding.txtWafer2,
                        "2"
                    )
                    if (nextIntent != null)
                        activityFactoryResultLauncher.launch(nextIntent)
                }
                viewBinding.btnWafer3.id -> {
                    val nextIntent = setNextIntent(
                        viewBinding.spinnerLossCode3,
                        viewBinding.spinnerQty3,
                        viewBinding.txtWafer3,
                        "3"
                    )
                    if (nextIntent != null)
                        activityFactoryResultLauncher.launch(nextIntent)
                }
                viewBinding.btnWafer4.id -> {
                    val nextIntent = setNextIntent(
                        viewBinding.spinnerLossCode4,
                        viewBinding.spinnerQty4,
                        viewBinding.txtWafer4,
                        "4"
                    )
                    if (nextIntent != null)
                        activityFactoryResultLauncher.launch(nextIntent)
                }
                viewBinding.btnWafer5.id -> {
                    val nextIntent = setNextIntent(
                        viewBinding.spinnerLossCode5,
                        viewBinding.spinnerQty5,
                        viewBinding.txtWafer5,
                        "5"
                    )
                    if (nextIntent != null)
                        activityFactoryResultLauncher.launch(nextIntent)
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    private fun setNextIntent(
        lossCode: Spinner, selQty: Spinner, selWafer: TextView, sequence: String
    ): Intent? {
        val lossCodeValue = lossCode.selectedItem.toString()

        if (lossCodeValue == "" || lossCodeValue == "선택안함") {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "먼저 LOSS코드를 입력하세요.", GetString.BTNOKSTR
            )

            return null
        }

        if (viewBinding.spinnerQty.selectedItem.toString() == "0") {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "먼저 Wafer 수량을 입력하세요.", GetString.BTNOKSTR
            )

            return null
        }

        val activityWaferList = arrayListOf(
            viewBinding.txtWafer,
            viewBinding.txtWafer2,
            viewBinding.txtWafer3,
            viewBinding.txtWafer4,
            viewBinding.txtWafer5
        )
        var alreadySel = ""

        for (wafer in activityWaferList) {
            if (selWafer != wafer && wafer.text.isNotEmpty())
                alreadySel += "${wafer.text},"
        }

        if (alreadySel.isNotEmpty())
            alreadySel = alreadySel.substring(0, alreadySel.length - 1)

        val nextIntent = Intent(this, WaferSelectActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.editLotNo.text.toString())
        nextIntent.putExtra("EXISTWAFERLIST", waferList)
        nextIntent.putExtra("DISABLEWAFERLIST", alreadySel)
        nextIntent.putExtra("SELECTWAFERLIST", selWafer.text.toString())
        nextIntent.putExtra("FIXEDCOUNT", selQty.selectedItem.toString())
        nextIntent.putExtra("SEQUENCE", sequence)

        return nextIntent
    }

    private val activityFactoryResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                it.data?.let { intent ->
                    val seq = intent.getStringExtra("SEQUENCE").toString()
                    val selectedWaferList = intent.getStringExtra("SELECTEDWAFERLIST").toString()

                    when (seq) {
                        "1" -> {
                            viewBinding.txtWafer.text = ""
                            viewBinding.txtWafer.text = selectedWaferList
                        }
                        "2" -> {
                            viewBinding.txtWafer2.text = ""
                            viewBinding.txtWafer2.text = selectedWaferList
                        }
                        "3" -> {
                            viewBinding.txtWafer3.text = ""
                            viewBinding.txtWafer3.text = selectedWaferList
                        }
                        "4" -> {
                            viewBinding.txtWafer4.text = ""
                            viewBinding.txtWafer4.text = selectedWaferList
                        }
                        "5" -> {
                            viewBinding.txtWafer5.text = ""
                            viewBinding.txtWafer5.text = selectedWaferList
                        }
                    }
                }
            }
        }

    private fun clearInfo() {
        viewBinding.txtBeforeQty.text = ""
        viewBinding.txtGapQty.text = ""
        viewBinding.spinnerCurrentQty.adapter = null
        viewBinding.spinnerLossCode.adapter = null
        viewBinding.spinnerLossCode2.adapter = null
        viewBinding.spinnerLossCode3.adapter = null
        viewBinding.spinnerLossCode4.adapter = null
        viewBinding.spinnerLossCode5.adapter = null
        viewBinding.spinnerQty.adapter = null
        viewBinding.spinnerQty2.adapter = null
        viewBinding.spinnerQty3.adapter = null
        viewBinding.spinnerQty4.adapter = null
        viewBinding.spinnerQty5.adapter = null
        viewBinding.txtWafer.text = ""
        viewBinding.txtWafer2.text = ""
        viewBinding.txtWafer3.text = ""
        viewBinding.txtWafer4.text = ""
        viewBinding.txtWafer5.text = ""
        viewBinding.txtLossMachine.text = ""
    }

    private fun searchLossInfo(lotId: String, operation: String, subOperation: String) {
        mainScope.launch {
            clearInfo()

            val sendMessage =
                MessageFactoryUtil.lossInfo(lotId, DeviceInfo.FACILITY, operation, subOperation)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOSSINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val beforeQty = messageBody.optString("BEFOREQTY")
                val currentQty = messageBody.optString("CURRENTQTY")
                val lossCode1 = messageBody.optString("LOSSCODE1")
                var loss1 = messageBody.optString("LOSS1")
                if (loss1.isEmpty()) loss1 = "0"
                val waferList1 = messageBody.optString("LOSSWAFER1")
                val lossCode2 = messageBody.optString("LOSSCODE2")
                var loss2 = messageBody.optString("LOSS2")
                if (loss2.isEmpty()) loss2 = "0"
                val waferList2 = messageBody.optString("LOSSWAFER2")
                val lossCode3 = messageBody.optString("LOSSCODE3")
                var loss3 = messageBody.optString("LOSS3")
                if (loss3.isEmpty()) loss3 = "0"
                val waferList3 = messageBody.optString("LOSSWAFER3")
                val lossCode4 = messageBody.optString("LOSSCODE4")
                var loss4 = messageBody.optString("LOSS4")
                if (loss4.isEmpty()) loss4 = "0"
                val waferList4 = messageBody.optString("LOSSWAFER4")
                val lossCode5 = messageBody.optString("LOSSCODE5")
                var loss5 = messageBody.optString("LOSS5")
                if (loss5.isEmpty()) loss5 = "0"
                val waferList5 = messageBody.optString("LOSSWAFER5")
                val enabledWaferList = messageBody.optString("WAFERLIST")
                val jsonLossCodeList =
                    ResponseDataToJsonUtil.getMessageBodyList(result, "LOSSCODEITEMS")
                val currentEqpId = messageBody.optString("CURRENTEQPID")

                waferList = enabledWaferList


                viewBinding.txtBeforeQty.text = beforeQty
                val iBefore = beforeQty.toInt()
                viewBinding.txtGapQty.text = (iBefore - currentQty.toInt()).toString()

                val curQty = ArrayList<Int>()
                for (count in 0..iBefore) {
                    curQty.add(iBefore - count)
                }

                val curQtyAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, curQty)
                curQtyAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerCurrentQty.adapter = InitSpinnerAdapter(
                    curQtyAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                val position = curQtyAdapter.getPosition(currentQty.toInt()) + 1

                viewBinding.spinnerCurrentQty.setSelection(position, false)

                var lossCodePosition1 = 1
                var lossCodePosition2 = 1
                var lossCodePosition3 = 1
                var lossCodePosition4 = 1
                var lossCodePosition5 = 1

                val lossCodeList = arrayListOf(SpinnerItem("NON", "선택안함"))
                for (count in 0 until jsonLossCodeList.length()) {
                    val keyLossCode = jsonLossCodeList.getJSONObject(count).optString("LOSSCODE")
                    val valueLossDesc = jsonLossCodeList.getJSONObject(count).optString("LOSSDESC")

                    if (lossCode1 == keyLossCode)
                        lossCodePosition1 = count + 1

                    if (lossCode2 == keyLossCode)
                        lossCodePosition2 = count + 1

                    if (lossCode3 == keyLossCode)
                        lossCodePosition3 = count + 1

                    if (lossCode4 == keyLossCode)
                        lossCodePosition4 = count + 1

                    if (lossCode5 == keyLossCode)
                        lossCodePosition5 = count + 1

                    lossCodeList.add(SpinnerItem(keyLossCode, keyLossCode))
                }

                val lossCodeAdapter = ArrayAdapter(
                    applicationContext, R.layout.contact_spinner_row_init, lossCodeList
                )
                lossCodeAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerLossCode.adapter = InitSpinnerAdapter(
                    lossCodeAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                viewBinding.spinnerLossCode2.adapter = InitSpinnerAdapter(
                    lossCodeAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                viewBinding.spinnerLossCode3.adapter = InitSpinnerAdapter(
                    lossCodeAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                viewBinding.spinnerLossCode4.adapter = InitSpinnerAdapter(
                    lossCodeAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                viewBinding.spinnerLossCode5.adapter = InitSpinnerAdapter(
                    lossCodeAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                initSpinnerPosition["LOSSCODE"] = lossCodePosition1
                initSpinnerPosition["LOSSCODE2"] = lossCodePosition2
                initSpinnerPosition["LOSSCODE3"] = lossCodePosition3
                initSpinnerPosition["LOSSCODE4"] = lossCodePosition4
                initSpinnerPosition["LOSSCODE5"] = lossCodePosition5

                viewBinding.spinnerLossCode.setSelection(lossCodePosition1, false)
                viewBinding.spinnerLossCode2.setSelection(lossCodePosition2, false)
                viewBinding.spinnerLossCode3.setSelection(lossCodePosition3, false)
                viewBinding.spinnerLossCode4.setSelection(lossCodePosition4, false)
                viewBinding.spinnerLossCode5.setSelection(lossCodePosition5, false)

                val qtyList = ArrayList<Int>()
                for (count in 0..iBefore)
                    qtyList.add(count)

                val qtyAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, qtyList)
                qtyAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerQty.adapter = InitSpinnerAdapter(
                    qtyAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                viewBinding.spinnerQty2.adapter = InitSpinnerAdapter(
                    qtyAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                viewBinding.spinnerQty3.adapter = InitSpinnerAdapter(
                    qtyAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                viewBinding.spinnerQty4.adapter = InitSpinnerAdapter(
                    qtyAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                viewBinding.spinnerQty5.adapter = InitSpinnerAdapter(
                    qtyAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                initSpinnerPosition["QTY"] = (loss1.toInt()) + 1
                initSpinnerPosition["QTY2"] = (loss2.toInt()) + 1
                initSpinnerPosition["QTY3"] = (loss3.toInt()) + 1
                initSpinnerPosition["QTY4"] = (loss4.toInt()) + 1
                initSpinnerPosition["QTY5"] = (loss5.toInt()) + 1

                viewBinding.spinnerQty.setSelection(
                    qtyAdapter.getPosition(loss1.toInt()) + 1, false
                )
                viewBinding.spinnerQty2.setSelection(
                    qtyAdapter.getPosition(loss2.toInt()) + 1, false
                )
                viewBinding.spinnerQty3.setSelection(
                    qtyAdapter.getPosition(loss3.toInt()) + 1, false
                )
                viewBinding.spinnerQty4.setSelection(
                    qtyAdapter.getPosition(loss4.toInt()) + 1, false
                )
                viewBinding.spinnerQty5.setSelection(
                    qtyAdapter.getPosition(loss5.toInt()) + 1, false
                )

                viewBinding.txtWafer.text = waferList1
                viewBinding.txtWafer2.text = waferList2
                viewBinding.txtWafer3.text = waferList3
                viewBinding.txtWafer4.text = waferList4
                viewBinding.txtWafer5.text = waferList5

                viewBinding.txtLossMachine.text = currentEqpId

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }
}