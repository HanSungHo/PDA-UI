package com.keyfoundry.hifos.view.etchinspection

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Vibrator
import android.text.InputFilter
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityCommentViewBinding
import com.keyfoundry.hifos.databinding.ActivityEtchInspectionBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDailogAlram
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class EtchInspectionActivity :  HFActivity() {
     companion object {
         private const val TAG = "EtchInspection"
     }

    private lateinit var viewBinding: ActivityEtchInspectionBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityEtchInspectionBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotID = intent.getStringExtra("LOTID").toString()
            viewBinding.editLotNo.setText(lotID)
            searchData(lotID)
        }

        viewBinding.editLotNo.setOnEditorActionListener { v, actionId, event ->
            if(actionId == EditorInfo.IME_ACTION_DONE) {
                val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                if (check) {
                    searchData(viewBinding.editLotNo.text.toString())
                }
                else{
                    clearData()
                }
            }else if(event !=null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                    if (check)
                        searchData(viewBinding.editLotNo.text.toString())
                    else
                        clearData()
                }
            }
            true
        }

        viewBinding.btnSearchLotNo.setOnClickListener(onSingleClickListener)
        viewBinding.btnClose.setOnClickListener(onSingleClickListener)
        viewBinding.btnExecution.setOnClickListener(onSingleClickListener)

    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchLotNo.id -> {
                    searchData(viewBinding.editLotNo.text.toString())
                }
                viewBinding.btnExecution.id ->{
                    execution()
                }
                viewBinding.btnClose.id ->{
                    finish()
                }
            }
        }
    }

    private fun searchData(lotId: String) {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@EtchInspectionActivity,currentFocus)
            clearData()

            if (lotId.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT ID을 입력하세요", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.EtchInspectionInfo("S", lotId)

            val message = MessageSender.send( supportFragmentManager, sendMessage, MessageName.ETCHINSPINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                //val messageListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "ITEMS")
                //val messageBody = messageListJSON.getJSONObject(0)

                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val OldOperation = messageBody.optString("OLDPROCESSOPERATIONNAME")
                val OldOperationDesc = messageBody.optString("OLDOPERATIONDESCRIPTION")
                val oldMachine = messageBody.optString("OLDMACHINENAME")
                val NowOperation = messageBody.optString("NOWPROCESSOPERATIONNAME")
                val NowOperationDesc = messageBody.optString("NOWOPERATIONDESCRIPTION")
                val sInspDate = messageBody.optString("INSPDATE")
                val sproduct = messageBody.optString("PRODUCTSPECNAME")

                viewBinding.txtViewLotname.text = lotId
                viewBinding.txtViewBoperation.text = OldOperation
                viewBinding.txtViewBoperationdesc.text = OldOperationDesc
                viewBinding.txtViewBmoveinmachine.text = oldMachine
                viewBinding.txtViewNoperation.text = NowOperation
                viewBinding.txtViewNoperationdesc.text = NowOperationDesc
                viewBinding.txtInspectionDate.text = sInspDate
                viewBinding.txtViewProductspec.text = sproduct

                viewBinding.btnExecution.isEnabled = true

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
            }
        }
    }

    private fun execution() {
        mainScope.launch{

            if(viewBinding.txtViewLotname.text ==""){
                OkDailogAlram.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    "LotName이 확인되지 않습니다..",
                    GetString.POSITIVEBTNSTR,
                    applicationContext,
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                return@launch
            }

            if(viewBinding.txtInspectionDate.text != "")
            {
                val returnCode = OkCancelDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_INFORM,
                    "[${viewBinding.txtViewBoperation.text}] 공정의 검사 이력이 있습니다. 삭제 후 다시 입력 하시겠습니까?" ,
                    GetString.BTNYESSTR,
                    GetString.BTNNOSTR
                )
                if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                    return@launch
                }
            }

            val sendMessage = MessageFactoryUtil.EtchInspectionexecution(
                DeviceInfo.FACILITY,
                viewBinding.txtViewLotname.text.toString(),
                viewBinding.txtViewProductspec.text.toString(),
                viewBinding.txtViewBoperation.text.toString(),
                viewBinding.txtViewBoperationdesc.text.toString(),
                viewBinding.txtViewBmoveinmachine.text.toString(),
                DeviceInfo.OPERATOR_ID,
                viewBinding.txtInspectionComment.text.toString()
            )
        val message = MessageSender.send(supportFragmentManager, sendMessage, MessageName.ETCHINSPEXCUTION)
        val isSuccessFul = message.isSuccessFul
        val result = message.result

            if (isSuccessFul) {
                /*
                val sSmsg = "완성검사가 정상처리 되었습니다. "

                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
                    sSmsg, GetString.BTNOKSTR
                )
                 */
                clearData()
                viewBinding.editLotNo.selectAll()

            }else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }


    private fun clearData() {
        viewBinding.editLotNo.text = null
        //Etch Scope 검사정보
        viewBinding.txtViewLotname.text = null
        viewBinding.txtViewBoperation.text = null
        viewBinding.txtViewBoperationdesc.text = null
        viewBinding.txtViewBmoveinmachine.text = null
        viewBinding.txtViewNoperation.text = null
        viewBinding.txtViewNoperationdesc.text = null
        viewBinding.txtViewProductspec.text = null;
        //완성 검사 정보 입력
        viewBinding.txtInspectionDate.text = null
        viewBinding.txtInspectionComment.text = null
        viewBinding.btnExecution.isEnabled = false
    }
}