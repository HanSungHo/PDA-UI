package com.keyfoundry.hifos.view.cmm

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.BarcodeStyle
import com.keyfoundry.hifos.config.utils.CommonUtil
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityWaferSelectBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.cmm.wafer.SelectWafer
import com.keyfoundry.hifos.view.cmm.wafer.WaferAdapter
import com.keyfoundry.hifos.view.cmm.wafer.WaferInfo
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.DecimalFormat

class WaferSelectActivity : HFActivity() {
    init {
        this.update = false
    }

    companion object {
        private const val TAG = "LotStatusActivity"
    }

    private lateinit var viewBinding: ActivityWaferSelectBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var selectWafer: SelectWafer

    private var fixedCount = 0
    private var sequence = ""
    private var createCategoryDummy = ""
    private var selectedMachine = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityWaferSelectBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editMachineName.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.txtWaferList.movementMethod = ScrollingMovementMethod.getInstance()

        sequence = intent.getStringExtra("SEQUENCE").toString()

        if (intent.getStringExtra("FIXEDCOUNT")?.isNotEmpty() == true)
            fixedCount = intent.getStringExtra("FIXEDCOUNT")!!.toInt()

        selectWafer = SelectWafer(fixedCount)

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()
            viewBinding.editLotNo.setText(lotId)
        }

        var editable = true
        if (intent.getStringExtra("EDITABLE")?.isNotEmpty() == true) {
            val edit = intent.getStringExtra("EDITABLE").toString()

            if (edit == "N") {
                setInvisibleButton()
                editable = false
            }
        }

        if (intent.getStringExtra("CATEGORY")?.isNotEmpty() == true)
            createCategoryDummy = intent.getStringExtra("CATEGORY").toString()

        if (createCategoryDummy != "COUNT" && intent.getStringExtra("EXISTWAFERLIST")
                ?.isNotEmpty() == true
        ) {
            val existWaferList = intent.getStringExtra("EXISTWAFERLIST")
            val disableWaferList = intent.getStringExtra("DISABLEWAFERLIST")
            val selectWaferList = intent.getStringExtra("SELECTWAFERLIST")

            setWaferButtonList(existWaferList, editable, disableWaferList, selectWaferList)
        }

        setDisable()

        viewBinding.btnSelectAll.setOnClickListener(onSingleClickListener)
        viewBinding.btnModify.setOnClickListener(onSingleClickListener)
        viewBinding.editMachineName.setOnEditorActionListener(editorActionListener)
        viewBinding.btnMachine.setOnClickListener(onSingleClickListener)
        viewBinding.btnSave.setOnClickListener(onSingleClickListener)
        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
    }

    private val editorActionListener =
        TextView.OnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                val check = BarcodeStyle(this).eqpId(viewBinding.editMachineName)

                if (check)
                    getDummyCMachineInfo(viewBinding.editMachineName.text.toString())
            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).eqpId(viewBinding.editMachineName)

                    if (check)
                        getDummyCMachineInfo(viewBinding.editMachineName.text.toString())
                }
            }

            true
        }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSelectAll.id -> {
                    selectAll()
                }
                viewBinding.btnModify.id -> {
                    resetWafer()
                }
                viewBinding.btnMachine.id -> {
                    getDummyCMachineInfo(viewBinding.editMachineName.text.toString())
                }
                viewBinding.btnSave.id -> {
                    dummyEqpInput()
                }
                viewBinding.btnOk.id -> {
                    sendWaferList()
                }
                viewBinding.btnCancel.id -> {
                    cancel()
                }
            }
        }
    }

    private fun selectAll() {
        var realCount = fixedCount - selectWafer.currentCount

        if (realCount == 0) {
            for (count in 0 until viewBinding.rcWaferList.childCount) {
                val waferButton =
                    viewBinding.rcWaferList.layoutManager?.findViewByPosition(count) as Button

                if (waferButton.isEnabled && waferButton.isSelected) {
                    waferButton.performClick()
                    realCount++
                }
            }
        } else {
            for (count in 0 until viewBinding.rcWaferList.childCount) {
                val waferButton =
                    viewBinding.rcWaferList.layoutManager?.findViewByPosition(count) as Button

                if (waferButton.isEnabled && !waferButton.isSelected && realCount > 0) {
                    waferButton.performClick()
                    realCount--
                }
            }
        }
    }

    private fun resetWafer() {
        var realCount = selectWafer.currentCount

        for (count in 0 until viewBinding.rcWaferList.childCount) {
            val waferButton =
                viewBinding.rcWaferList.layoutManager?.findViewByPosition(count) as Button

            if (waferButton.isEnabled && waferButton.isSelected && realCount > 0) {
                waferButton.performClick()
                realCount--
            }
        }
    }

    private fun sendWaferList() {
        val returnIntent = Intent()
        returnIntent.putExtra("SEQUENCE", sequence)
        returnIntent.putExtra("SELECTEDWAFERLIST", viewBinding.txtWaferList.text.toString())
        returnIntent.putExtra("SELECTEDMACHINE", selectedMachine)

        setResult(Activity.RESULT_OK, returnIntent)

        finish()
    }

    private fun cancel() {
        val returnIntent = Intent()
        setResult(Activity.RESULT_CANCELED, returnIntent)

        finish()
    }

    private fun setDisable() {
        if (createCategoryDummy.isNotEmpty()) {
            if (createCategoryDummy == "COUNT") {
                viewBinding.editMachineName.isEnabled = false
                viewBinding.btnMachine.isEnabled = false
                viewBinding.btnSelectAll.isEnabled = false

                getLotLastEvent()
            } else if (createCategoryDummy == "SLOT") {
                viewBinding.editCountName.isEnabled = false

                if (DeviceInfo.AREA != "DIFF") {
                    viewBinding.editMachineName.isEnabled = false
                    viewBinding.btnMachine.isEnabled = false
                }

                getLotLastEvent()
            }
        } else {
            viewBinding.editMachineName.isEnabled = false
            viewBinding.btnMachine.isEnabled = false
            viewBinding.editCountName.isEnabled = false
            viewBinding.btnSave.isEnabled = false
        }
    }

    private fun setWaferButtonList(
        waferList: String?, editable: Boolean, disableList: String?, selectList: String?
    ) {
        if (waferList != null) {
            val slotMap = makeSlotMapList(waferList)
            viewBinding.rcWaferList.layoutManager =
                object : GridLayoutManager(this, 5, LinearLayoutManager.VERTICAL, false) {
                    override fun canScrollVertically(): Boolean {
                        return false
                    }
                }

            viewBinding.rcWaferList.adapter = WaferAdapter(
                this, slotMap, editable,
                disableList, selectList, selectWafer, supportFragmentManager
            )
        }
    }

    private fun setInvisibleButton() {
        viewBinding.btnSelectAll.visibility = View.INVISIBLE
        viewBinding.btnMachine.visibility = View.INVISIBLE
        viewBinding.btnSave.visibility = View.INVISIBLE
        viewBinding.btnModify.visibility = View.GONE
        viewBinding.btnOk.visibility = View.GONE

        viewBinding.editLotNo.isEnabled = false
    }

    private fun makeSlotMapList(waferString: String): MutableList<WaferInfo> {
        val waferList = waferString.split(",")
        val wafercount = waferList.count(); //요기서 수정을 해야함.
        var value = ""
        var key = ""
        val slotMapList = mutableListOf<WaferInfo>()
        var bresult = false

        var slotIndex = 0
        for (i in 1..25) {

            if(wafercount < i) {
                 value = ""
                 key = ""
            }
            else {
                 key = waferList[slotIndex]
                 value = key.substring(key.lastIndexOf(".") + 1, key.length)
            }

            //val key = waferList[slotIndex]
            //val value = key.substring(key.lastIndexOf(".") + 1, key.length)

            val df = DecimalFormat("00")
            val buttonIndex = df.format(i)

            bresult = false
            for(iw in 0..wafercount-1) {
                var tempkey = waferList[iw]
                var tempvalue =  tempkey.substring(tempkey.lastIndexOf(".") + 1, tempkey.length)

                if(buttonIndex == tempvalue) {
                    key = waferList[iw]
                    value = key.substring(key.lastIndexOf(".") + 1, key.length)
                    bresult = true
                }
            }

            if(!bresult)
            {
                value = ""
                key = ""
            }

/*
            if(wafercount < slotIndex) {
                 value = ""
                 key = ""
            }
            else {
                 key = waferList[slotIndex]
                 value = key.substring(key.lastIndexOf(".") + 1, key.length)
            }
*/
            //val key = waferList[slotIndex]
            //val value = key.substring(key.lastIndexOf(".") + 1, key.length)

            if(value == buttonIndex.toString()){
                val waferInfo = WaferInfo(key, buttonIndex.toString())
                waferInfo.machine = ""
                slotMapList.add(waferInfo)
                slotIndex++
            } else {
                val waferInfo = WaferInfo("empty", buttonIndex.toString())
                waferInfo.machine = ""
                slotMapList.add(waferInfo)
            }
        }

//        for (row in 0 until waferList.count()) {
//            val key = waferList[row]
//            val value = key.substring(key.lastIndexOf(".") + 1, key.length)
//
//            val waferInfo = WaferInfo(key, value)
//            waferInfo.machine = ""
//
//            slotMapList.add(waferInfo)
//        }

        return slotMapList
    }

    private fun getDummyCMachineInfo(searchEqpId: String) {
        if (searchEqpId.replace(" ", "").isEmpty()) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "장비 호기를 입력 하세요.", GetString.BTNOKSTR
            )
            return
        }
        mainScope.launch {
            CommonUtil.hideKeyboard(this@WaferSelectActivity, currentFocus)
            val sendMessage =
                MessageFactoryUtil.dummyEqpInfo(searchEqpId, viewBinding.editLotNo.text.toString())

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.DUMMYEQPINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {

                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val eqpId = messageBody.optString("EQPID")

                for (count in 0 until viewBinding.rcWaferList.childCount) {
                    val waferButton =
                        viewBinding.rcWaferList.layoutManager?.findViewByPosition(count) as Button
                    val waferInfo = waferButton.tag as WaferInfo

                    if (waferInfo.machine == "Empty") {
                        val newText = """
                                    |${waferButton.text}
                                    |[$eqpId]
                                """.trimMargin()

                        waferButton.text = newText
                        waferInfo.machine = eqpId
                    }
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun getLotLastEvent() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.lotLastEvent(
                viewBinding.editLotNo.text.toString(), DeviceInfo.AREA
            )
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTLSATEVENT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val category = messageBody.optString("CREATECATEGORY")
                var lastEvent = messageBody.optString("LASTEVENTCOMMENT")
                if (lastEvent.startsWith(" "))
                    lastEvent = lastEvent.substring(1, lastEvent.length)

                if (lastEvent.isEmpty())
                    return@launch

                if (category == "COUNT") {
                    viewBinding.editCountName.setText(lastEvent.substring(6, lastEvent.length))
                } else if (category == "SLOT") {
                    if (lastEvent.length < 7)
                        return@launch

                    val slotWafer = lastEvent.substring(7, lastEvent.length)
                    if (slotWafer.isNotEmpty()) {
                        val waferList = slotWafer.split(",")

                        for (count in 0 until viewBinding.rcWaferList.childCount) {
                            val waferButton =
                                viewBinding.rcWaferList.layoutManager?.findViewByPosition(count) as Button

                            for (wafer in waferList) {
                                val waferId = wafer.substring(0, 2)

                                var machineName = ""
                                if (wafer.length > 2)
                                    machineName = wafer.substring(3, wafer.length - 1)

                                if (waferButton.text.toString() == waferId) {
                                    waferButton.performClick()
                                    val waferInfo = waferButton.tag as WaferInfo

                                    if (DeviceInfo.AREA == "DIFF") {
                                        waferInfo.machine = machineName

                                        if (machineName.isNotEmpty() && machineName != "Empty") {
                                            val newText = """
                                                    |$waferId
                                                    |[$machineName]
                                                    """.trimMargin()
                                            waferButton.text = newText
                                        }
                                    }

                                    break
                                }
                            }
                        }
                    }
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun dummyEqpInput() {
        mainScope.launch {
            var comment = ""

            if (createCategoryDummy == "SLOT") {
                if (DeviceInfo.AREA == "DIFF") {
                    for (count in 0 until viewBinding.rcWaferList.childCount) {
                        val waferButton =
                            viewBinding.rcWaferList.layoutManager?.findViewByPosition(count) as Button

                        if (waferButton.isSelected) {
                            val waferInfo = waferButton.tag as WaferInfo

                            if (waferInfo.machine.isEmpty() || waferInfo.machine == "Empty") {
                                OkDialog.show(
                                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                                    "선택된 Wafer는 반드시 장비가 선택 되어야 합니다.", GetString.BTNOKSTR
                                )
                                return@launch
                            } else {
                                comment += if (comment.isEmpty()) {
                                    "${waferInfo.waferId}(${waferInfo.machine})"
                                } else {
                                    ",${waferInfo.waferId}(${waferInfo.machine})"
                                }
                            }
                        }
                    }
                } else {
                    for (count in 0 until viewBinding.rcWaferList.childCount) {
                        val waferButton =
                            viewBinding.rcWaferList.layoutManager?.findViewByPosition(count) as Button

                        if (waferButton.isSelected) {
                            val waferInfo = waferButton.tag as WaferInfo
                            comment += if (comment.isEmpty()) {
                                waferInfo.waferId
                            } else {
                                ",${waferInfo.waferId}"
                            }
                        }
                    }
                }
            } else if (createCategoryDummy == "COUNT") {
                if (viewBinding.editCountName.text.isEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "COUNT를 입력 하세요.", GetString.BTNOKSTR
                    )

                    return@launch
                }
                comment += viewBinding.editCountName.text.toString()
            }

            val sendMessage = MessageFactoryUtil.dummyEqpInput(
                viewBinding.editLotNo.text.toString(), comment, createCategoryDummy
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.DUMMYEQPINPUT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val lotComment = messageBody.optString("LOTCOMMENT")
                val msg = messageBody.optString("MSG")

                if (createCategoryDummy == "SLOT") {
                    selectedMachine = lotComment
                    OkDialog.show(
                        supportFragmentManager, "확인 COMMENT",
                        "정상 처리 되었습니다.", GetString.BTNOKSTR
                    )

                    return@launch
                } else if (createCategoryDummy == "COUNT") {
                    if (msg.isNullOrEmpty()) {
                        OkDialog.show(
                            supportFragmentManager, "확인 COMMENT",
                            "정상 처리 되었습니다.", GetString.BTNOKSTR
                        )

                        viewBinding.editCountName.setText(
                            lotComment.substring(6, lotComment.length)
                        )
                        selectedMachine = lotComment
                        return@launch
                    } else {
                        OkDialog.show(supportFragmentManager, "확인 COMMENT", msg, GetString.BTNOKSTR)
                        selectedMachine = ""
                        return@launch
                    }
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }
}