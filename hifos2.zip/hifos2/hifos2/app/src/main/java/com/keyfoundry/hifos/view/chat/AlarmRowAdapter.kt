package com.keyfoundry.hifos.view.chat

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.keyfoundry.hifos.R

class AlarmRowAdapter(private val items: List<AlarmRowItem>) :
    RecyclerView.Adapter<AlarmRowAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tvTitle)
        val tvValue: TextView = view.findViewById(R.id.tvValue)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_alarm_popup, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvTitle.text = item.title
        holder.tvValue.text = item.value

        // 👉 특정 값 강조 (예: SpcResult)
        if (item.title == "SpcResult") {
            holder.tvValue.setBackgroundColor(Color.YELLOW)
            holder.tvValue.setTextColor(Color.RED)
        }
    }

    override fun getItemCount() = items.size
}