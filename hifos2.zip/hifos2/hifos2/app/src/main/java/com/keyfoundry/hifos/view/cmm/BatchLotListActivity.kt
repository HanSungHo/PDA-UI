package com.keyfoundry.hifos.view.cmm

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.TextView
import androidx.core.view.children
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.utils.GridService
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityBatchLotListBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject

class BatchLotListActivity : HFActivity() {
    init {
        this.update = false
    }

    companion object {
        private const val TAG = "BatchLotListActivity"
    }

    private lateinit var viewBinding: ActivityBatchLotListBinding
    private lateinit var gridService: GridService
    private lateinit var gridList: CTMainLayout

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityBatchLotListBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        gridService = GridService(applicationContext)

        if (intent.getStringExtra("BATID")?.isNotEmpty() == true) {
            val batId = intent.getStringExtra("BATID").toString()
            viewBinding.txtBatId.setText(batId)
            getBatchLotList()
        }

        viewBinding.btnSearchBatId.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                getBatchLotList()
            }
        })

        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
            }
        })

        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                var selectedLot = ""
                if (::gridList.isInitialized) {
                    for (row in gridList.mainTable.children) {
                        if (row.isFocused) {
                            selectedLot =
                                ((row as CTRowLayout).getChildAt(1) as TextView).text.toString()
                        }
                    }
                }

                if (selectedLot.isEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "LOT을 선택하세요.", GetString.BTNOKSTR
                    )
                    return
                }

                val returnIntent = Intent()
                returnIntent.putExtra("LOTID", selectedLot)
                setResult(Activity.RESULT_OK, returnIntent)
                finish()
            }
        })
    }

    private fun getBatchLotList() {
        mainScope.launch {
            val batId = viewBinding.txtBatId.text.toString()
            val sendMessage = MessageFactoryUtil.batchList(batId, DeviceInfo.FACILITY)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.BATCHLIST)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val batchList =
                    ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "BATCHITEMS")

                for (i in 0 until batchList.length()) {
                    (batchList[i] as JSONObject).put("NO", (i + 1).toString())
                }

                val columnData = linkedMapOf(
                    "NO" to ColumnProperty("NO", Gravity.CENTER, false, 80),
                    "LOTID" to ColumnProperty("LOT NO", Gravity.START, false, 550),
                    "ISDCOL" to ColumnProperty("D", Gravity.CENTER, false, 80)
                )

                gridList = gridService.setGridPropData(columnData, batchList)
                viewBinding.baseLayout.addView(gridList)

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }

        }
    }

}