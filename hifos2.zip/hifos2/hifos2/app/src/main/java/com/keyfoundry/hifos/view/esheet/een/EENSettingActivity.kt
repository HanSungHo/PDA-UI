package com.keyfoundry.hifos.view.esheet.een

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.children
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.CTSubLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.spinner.SpinnerItem
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityEenSettingBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.lang.Exception
import java.util.ArrayList


/*
*   EEN 등록하기 기능 화면 (Addition by Sunggil Hwang, 2024.01.19)
    Requested by 제조팀 김택용 FL
* */
class EENSettingActivity :  HFActivity() {
     companion object {
         private const val TAG = "SettingEEN"
     }

    private lateinit var viewBinding: ActivityEenSettingBinding
    private lateinit var keyboardVisibilityUtils: KeyboardVisibilityUtils

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var gridData: CTMainLayout
    private lateinit var gridService: GridService

    lateinit var lotId: String
    lateinit var operation: String
    lateinit var processStep: String
    lateinit var operSeq: String
    lateinit var factoryname: String
    lateinit var product: String
    lateinit var route: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityEenSettingBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        lotId = intent.getStringExtra("LOTID").toString()
        factoryname = intent.getStringExtra("FACTORYNAME").toString()
        product = intent.getStringExtra("PRODUCT").toString()
        route = intent.getStringExtra("ROUTE").toString()
        operation = intent.getStringExtra("OPERATION").toString()
        processStep = intent.getStringExtra("PROCESSSTEP").toString()
        operSeq = intent.getStringExtra("OPERSEQUENCE").toString()

        viewBinding.txtLotNo.text = lotId
        viewBinding.txtCurrentProcess.text = operation
        viewBinding.txtProductName.text = product
        viewBinding.txtRoute.text = route
        viewBinding.txtProcessStep.text = processStep

        viewBinding.btnAdd.setOnClickListener(onSingleClickListener)
        viewBinding.btnModify.setOnClickListener(onSingleClickListener)
        viewBinding.btnDelete.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)


        gridService = GridService(applicationContext)

        getEENInfo()
    }



    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnAdd.id ->{
                    CommonUtil.hideKeyboard(this@EENSettingActivity, currentFocus)
                    addEEN()
                }
                viewBinding.btnModify.id ->{
                    CommonUtil.hideKeyboard(this@EENSettingActivity, currentFocus)
                    modifyEEN()
                }
                viewBinding.btnDelete.id ->{
                    CommonUtil.hideKeyboard(this@EENSettingActivity, currentFocus)
                    deleteEEN()
                }
                viewBinding.btnCancel.id ->{
                    CommonUtil.hideKeyboard(this@EENSettingActivity, currentFocus)
                    val returnIntent = Intent()
                    returnIntent.putExtra("LOTID", lotId)
                    setResult(Activity.RESULT_OK, returnIntent)
                    finish()
                }
            }
        }
    }

    private fun getEENInfo() {
        viewBinding.baseLayout.removeAllViews()

        mainScope.launch {

            val sendMessage = MessageFactoryUtil.getEenList(viewBinding.txtLotNo.text.toString(), DeviceInfo.FACILITY)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val eenList =
                    ResponseDataToJsonUtil.getMessageBodyList(result, "ITEMS")

                val columnData = linkedMapOf(
                    "EENID" to ColumnProperty("EENID", Gravity.START, false, 0),
                    "PROCESSOPERATIONNAMEDESC" to ColumnProperty("공정명", Gravity.START, false),
                    "TAGCOMMENT" to ColumnProperty("TAGCOMMENT", Gravity.START, false, 1000),
                    "ACTIONPOINT" to ColumnProperty("ACTIONPOINT", Gravity.START, false),
                    "FACTORYNAME" to ColumnProperty("FACTORYNAME", Gravity.START, false,0),
                    "PRODUCTSPECNAME" to ColumnProperty("PRODUCTSPECNAME", Gravity.START, false,0),
                    "PROCESSFLOWNAME" to ColumnProperty("PROCESSFLOWNAME", Gravity.START, false,0),
                    "PROCESSOPERATIONNAME" to ColumnProperty("PROCESSOPERATIONNAME", Gravity.START, false,0),
                    "TAGID" to ColumnProperty("TAGID", Gravity.START, false,0),
                    "CREATETIME" to ColumnProperty("CREATETIME", Gravity.START, false),
                    "CREATEUSER" to ColumnProperty("CREATEUSER", Gravity.START, false),
                    "CONFIRMUSER" to ColumnProperty("CONFIRMUSER", Gravity.START, false),
                    "CONFIRMTIME" to ColumnProperty("CONFIRMTIME", Gravity.START, false),
                    "DESCRIPTION" to ColumnProperty("DESCRIPTION", Gravity.START, false,0)
                )

                gridData = gridService.setGridPropData(columnData, eenList)
                viewBinding.baseLayout.addView(gridData)

                for (i in 0 until eenList.length()) {
                    val item = eenList.getJSONObject(i)
                    if (item.getString("PROCESSOPERATIONNAME") == operation) {
                        (gridData.mainTable.getChildAt(i) as CTRowLayout).requestFocus()
                        gridData.mainTable.currentRowIndex = i
                        break;
                    }
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)
            }
        }
    }

    private val activityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                getEENInfo()
            }

        }

    private fun addEEN() {
        val nextIntent = Intent(applicationContext, EENAddActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
        nextIntent.putExtra("FACTORYNAME", gridService.getCurrentRow(gridData).cellValue(4))
        nextIntent.putExtra("PRODUCT", gridService.getCurrentRow(gridData).cellValue(5))
        nextIntent.putExtra("ROUTE", viewBinding.txtRoute.text.toString())
        nextIntent.putExtra("OPERATION", viewBinding.txtCurrentProcess.text.toString())
        nextIntent.putExtra("PROCESSSTEP", "")
        activityResultLauncher.launch(nextIntent)
    }

    private fun modifyEEN() {
        val nextIntent = Intent(applicationContext, EENModifyActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
        nextIntent.putExtra("EENID", gridService.getCurrentRow(gridData).cellValue(0))
        nextIntent.putExtra("TAGCOMMENT", gridService.getCurrentRow(gridData).cellValue(2))
        nextIntent.putExtra("ACTIONPOINT", gridService.getCurrentRow(gridData).cellValue(3))
        nextIntent.putExtra("FACTORYNAME", gridService.getCurrentRow(gridData).cellValue(4))
        nextIntent.putExtra("PRODUCT", gridService.getCurrentRow(gridData).cellValue(5))
        nextIntent.putExtra("ROUTE", gridService.getCurrentRow(gridData).cellValue(6))
        nextIntent.putExtra("OPERATION", gridService.getCurrentRow(gridData).cellValue(7))
        nextIntent.putExtra("TAGID", gridService.getCurrentRow(gridData).cellValue(8))
        nextIntent.putExtra("PODESC", gridService.getCurrentRow(gridData).cellValue(13))
        activityResultLauncher.launch(nextIntent)

    }

    private fun deleteEEN() {
        val nextIntent = Intent(applicationContext, EENDeleteActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
        nextIntent.putExtra("EENID", gridService.getCurrentRow(gridData).cellValue(0))
        nextIntent.putExtra("TAGCOMMENT", gridService.getCurrentRow(gridData).cellValue(2))
        nextIntent.putExtra("ACTIONPOINT", gridService.getCurrentRow(gridData).cellValue(3))
        nextIntent.putExtra("FACTORYNAME", gridService.getCurrentRow(gridData).cellValue(4))
        nextIntent.putExtra("PRODUCT", gridService.getCurrentRow(gridData).cellValue(5))
        nextIntent.putExtra("ROUTE", gridService.getCurrentRow(gridData).cellValue(6))
        nextIntent.putExtra("OPERATION", gridService.getCurrentRow(gridData).cellValue(7))
        nextIntent.putExtra("TAGID", gridService.getCurrentRow(gridData).cellValue(8))
        nextIntent.putExtra("PODESC", gridService.getCurrentRow(gridData).cellValue(13))
        activityResultLauncher.launch(nextIntent)
        // lotid, facility, product, route, operation, actiontype, eenid,

    }
}