package com.keyfoundry.hifos.view.dialog

import android.os.Bundle
import android.view.View
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivityStepperIdleactivityBinding


    class StepperIDLEActivity : HFActivity() {
        init {
            this.update = false
        }

        private lateinit var viewBinding: ActivityStepperIdleactivityBinding

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_stepper_idleactivity)
            setFinishOnTouchOutside(false)

            viewBinding = ActivityStepperIdleactivityBinding.inflate(layoutInflater)
            setContentView(viewBinding.root)

            val receiverMessage = intent.getStringExtra(DeviceInfo.UDP_RECEIVER_MESSAGE)


            if (receiverMessage != null) if (receiverMessage.contains("INTERLOCKMANAGER")) {
                val new_receiverMessage = arrayOf(receiverMessage?.split("<Table diffgr:")) // receiverMessage 잘라서 배열에 담기

                for (data in 1 until new_receiverMessage[0].size) {
                    val arry_receiverMessage = arrayOf(new_receiverMessage[0][data]?.split("</")) // receiverMessage 잘라서 배열에 담기

                    val sTime = arry_receiverMessage[0]!![1].substring(arry_receiverMessage[0]!![1].lastIndexOf(">") + 1
                    )
                    if (sTime > 0.toString())
                        viewBinding.txtReceiverTimeResult.append(sTime)

                    val sEqpid = arry_receiverMessage[0]!![3].substring(arry_receiverMessage[0]!![3].lastIndexOf(">") + 1
                    )
                    if (sEqpid > 0.toString())
                        viewBinding.txtReceiverEqpidResult.append(sEqpid)

                    val sLotid = arry_receiverMessage[0]!![6].substring(arry_receiverMessage[0]!![6].lastIndexOf(">") + 1
                    )
                    if (sLotid > 0.toString())
                        viewBinding.txtReceiverLotidResult.append(sLotid)

                    val sWafer = arry_receiverMessage[0]!![10].substring(arry_receiverMessage[0]!![10].lastIndexOf(">") + 1
                    )
                    if (sWafer > 0.toString())
                        viewBinding.txtReceiverWaferResult.append(sWafer)
                }
            }

            viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
                override fun onSingleClick(it: View) {
                    finish()
                }
            })
        }

        //override fun onBackPressed() {
        //    finish()
        //}
    }
