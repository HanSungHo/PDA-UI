package com.keyfoundry.hifos.view.esheet.backupbay

import android.os.Bundle
import android.text.InputFilter
import android.view.KeyEvent
import android.view.View
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.widget.*
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityBackupBayDialogBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BackupBayDialogActivity : HFActivity() {
    companion object {
        private const val TAG = "BackupBayActivity"
    }

    private lateinit var viewBinding: ActivityBackupBayDialogBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setFinishOnTouchOutside(false)

        viewBinding = ActivityBackupBayDialogBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.editLotId.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editLotId2.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editLotId3.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editLotId4.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editLotId5.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editLotId6.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editLotId7.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        setLotIdAction()

        setFloorList()
        setFloorListAction()

        viewBinding.spinnerBay.onItemSelectedListener = selectListener
        viewBinding.btnExecute.setOnClickListener(onSingleClickListener)
        viewBinding.btnClose.setOnClickListener(onSingleClickListener)
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnExecute.id -> {
                    saveData()
                }
                viewBinding.btnClose.id -> {
                    finish()
                }
            }
        }
    }

    private fun setLotIdAction() {
        viewBinding.editLotId.setOnEditorActionListener(lotOnEditorListener)
        viewBinding.editLotId2.setOnEditorActionListener(lotOnEditorListener)
        viewBinding.editLotId3.setOnEditorActionListener(lotOnEditorListener)
        viewBinding.editLotId4.setOnEditorActionListener(lotOnEditorListener)
        viewBinding.editLotId5.setOnEditorActionListener(lotOnEditorListener)
        viewBinding.editLotId6.setOnEditorActionListener(lotOnEditorListener)
        viewBinding.editLotId7.setOnEditorActionListener(lotOnEditorListener)
    }

    private fun setFloorList() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.getFloorData()
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.GETFLOORDATA)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val fabs = messageBody.getJSONObject("FABS")
                val jsonFloorList = fabs.getJSONArray("ITEM")

                val floorList = arrayListOf<String>()

                for (count in 0 until jsonFloorList.length())
                    floorList.add(jsonFloorList.getJSONObject(count).optString("FLOOR"))

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, floorList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerFloor.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                viewBinding.spinnerFloor2.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                viewBinding.spinnerFloor3.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                viewBinding.spinnerFloor4.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                viewBinding.spinnerFloor5.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                viewBinding.spinnerFloor6.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                viewBinding.spinnerFloor7.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

            }
        }
    }

    private fun setFloorListAction() {
        viewBinding.spinnerFloor.onItemSelectedListener = selectListener
        viewBinding.spinnerFloor2.onItemSelectedListener = selectListener
        viewBinding.spinnerFloor3.onItemSelectedListener = selectListener
        viewBinding.spinnerFloor4.onItemSelectedListener = selectListener
        viewBinding.spinnerFloor5.onItemSelectedListener = selectListener
        viewBinding.spinnerFloor6.onItemSelectedListener = selectListener
        viewBinding.spinnerFloor7.onItemSelectedListener = selectListener
    }

    private val selectListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null && view != null) {
                val floor = (view as TextView).text.toString()

                if (floor.isNotEmpty()) {
                    when (parent.id) {
                        viewBinding.spinnerFloor.id -> {
                            viewBinding.spinnerFloor2.setSelection(position, false)
                            viewBinding.spinnerFloor3.setSelection(position, false)
                            viewBinding.spinnerFloor4.setSelection(position, false)
                            viewBinding.spinnerFloor5.setSelection(position, false)
                            viewBinding.spinnerFloor6.setSelection(position, false)
                            viewBinding.spinnerFloor7.setSelection(position, false)

                            setBay(floor, viewBinding.spinnerBay)
                        }
                        viewBinding.spinnerFloor2.id -> {
                            setBay(floor, viewBinding.spinnerBay2)
                        }
                        viewBinding.spinnerFloor3.id -> {
                            setBay(floor, viewBinding.spinnerBay3)
                        }
                        viewBinding.spinnerFloor4.id -> {
                            setBay(floor, viewBinding.spinnerBay4)
                        }
                        viewBinding.spinnerFloor5.id -> {
                            setBay(floor, viewBinding.spinnerBay5)
                        }
                        viewBinding.spinnerFloor6.id -> {
                            setBay(floor, viewBinding.spinnerBay6)
                        }
                        viewBinding.spinnerFloor7.id -> {
                            setBay(floor, viewBinding.spinnerBay7)
                        }
                        viewBinding.spinnerBay.id -> {
                            if (viewBinding.spinnerFloor.selectedItem == null)
                                return

                            val firstFloor = viewBinding.spinnerFloor.selectedItem.toString()

                            if (viewBinding.spinnerFloor2.selectedItem != null && firstFloor == viewBinding.spinnerFloor2.selectedItem.toString())
                                viewBinding.spinnerBay2.setSelection(position, false)

                            if (viewBinding.spinnerFloor3.selectedItem != null && firstFloor == viewBinding.spinnerFloor3.selectedItem.toString())
                                viewBinding.spinnerBay3.setSelection(position, false)

                            if (viewBinding.spinnerFloor4.selectedItem != null && firstFloor == viewBinding.spinnerFloor4.selectedItem.toString())
                                viewBinding.spinnerBay4.setSelection(position, false)

                            if (viewBinding.spinnerFloor5.selectedItem != null && firstFloor == viewBinding.spinnerFloor5.selectedItem.toString())
                                viewBinding.spinnerBay5.setSelection(position, false)

                            if (viewBinding.spinnerFloor6.selectedItem != null && firstFloor == viewBinding.spinnerFloor6.selectedItem.toString())
                                viewBinding.spinnerBay6.setSelection(position, false)

                            if (viewBinding.spinnerFloor7.selectedItem != null && firstFloor == viewBinding.spinnerFloor7.selectedItem.toString())
                                viewBinding.spinnerBay7.setSelection(position, false)
                        }
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private fun setBay(floor: String, targetSpinner: Spinner) {
        mainScope.launch {
            targetSpinner.adapter = null

            val sendMessage = MessageFactoryUtil.getBayData(floor)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.GETBAYDATA)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val fabs = messageBody.getJSONObject("FABS")
                val jsonAreaList = fabs.getJSONArray("ITEM")

                val floorList = arrayListOf<String>()

                for (count in 0 until jsonAreaList.length())
                    floorList.add(jsonAreaList.getJSONObject(count).optString("AREANAME"))

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, floorList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                targetSpinner.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private val lotOnEditorListener =
        TextView.OnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                val lotText = v as EditText
                getLotInfo(lotText)
            } else if (event != null) { // Barcode Event
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val lotText = v as EditText
                    getLotInfo(lotText)
                }
            }

            true
        }

    private fun clearAll() {
        viewBinding.editLotId.setText("")
        viewBinding.editLotId2.setText("")
        viewBinding.editLotId3.setText("")
        viewBinding.editLotId4.setText("")
        viewBinding.editLotId5.setText("")
        viewBinding.editLotId6.setText("")
        viewBinding.editLotId7.setText("")

//        viewBinding.spinnerBay.adapter = null
//        viewBinding.spinnerBay2.adapter = null
//        viewBinding.spinnerBay3.adapter = null
//        viewBinding.spinnerBay4.adapter = null
//        viewBinding.spinnerBay5.adapter = null
//        viewBinding.spinnerBay6.adapter = null
//        viewBinding.spinnerBay7.adapter = null

        clearLotInfo(viewBinding.editLotId)
        clearLotInfo(viewBinding.editLotId2)
        clearLotInfo(viewBinding.editLotId3)
        clearLotInfo(viewBinding.editLotId4)
        clearLotInfo(viewBinding.editLotId5)
        clearLotInfo(viewBinding.editLotId6)
        clearLotInfo(viewBinding.editLotId7)

    }

    private fun clearLotInfo(lotEditText: EditText) {
        when (lotEditText.id) {
            viewBinding.editLotId.id -> {
                viewBinding.txtJob.text = ""
                viewBinding.txtQty.text = ""
                viewBinding.txtProcessName.text = ""
            }
            viewBinding.editLotId2.id -> {
                viewBinding.txtJob2.text = ""
                viewBinding.txtQty2.text = ""
                viewBinding.txtProcessName2.text = ""
            }
            viewBinding.editLotId3.id -> {
                viewBinding.txtJob3.text = ""
                viewBinding.txtQty3.text = ""
                viewBinding.txtProcessName3.text = ""
            }
            viewBinding.editLotId4.id -> {
                viewBinding.txtJob4.text = ""
                viewBinding.txtQty4.text = ""
                viewBinding.txtProcessName4.text = ""
            }
            viewBinding.editLotId5.id -> {
                viewBinding.txtJob5.text = ""
                viewBinding.txtQty5.text = ""
                viewBinding.txtProcessName5.text = ""
            }
            viewBinding.editLotId6.id -> {
                viewBinding.txtJob6.text = ""
                viewBinding.txtQty6.text = ""
                viewBinding.txtProcessName6.text = ""
            }
            viewBinding.editLotId7.id -> {
                viewBinding.txtJob7.text = ""
                viewBinding.txtQty7.text = ""
                viewBinding.txtProcessName7.text = ""
            }
        }
    }

    private fun getLotInfo(lotEditText: EditText) {
        mainScope.launch {
            clearLotInfo(lotEditText)
            CommonUtil.hideKeyboard(this@BackupBayDialogActivity, currentFocus)

            if (lotEditText.text.toString().isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT NO를 입력하세요", GetString.BTNOKSTR
                )

                lotEditText.requestFocus()
                lotEditText.selectAll()
                return@launch
            }

            val check = BarcodeStyle(this@BackupBayDialogActivity).lotId(lotEditText)

            if (!check) {
                lotEditText.setText("")
                lotEditText.requestFocus()
                lotEditText.selectAll()
                return@launch
            }

            val lotId = lotEditText.text.toString()
            if (!checkSameLotId(lotId)) {
                lotEditText.setText("")
                lotEditText.requestFocus()
                lotEditText.selectAll()
                return@launch
            }
            val sendMessage = MessageFactoryUtil.getProcessFactoryLot(lotId)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.GETPROCESSFACTORYLOT
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val tempLotState = messageBody.optString("LOTSTATE")
                val tempLotHoldState = messageBody.optString("LOTHOLDSTATE")
                val tempProcessState = messageBody.optString("LOTPROCESSSTATE")

                if (tempProcessState == "RUN") {
                    val runMessage = """
                        Move In 된 Lot($lotId)은
                        BACKUP BAY를 변경할수 없습니다.
                    """.trimIndent()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        runMessage, GetString.BTNOKSTR
                    )

                    lotEditText.setText("")
                    lotEditText.requestFocus()
                    lotEditText.selectAll()

                    return@launch
                }

                if (tempLotHoldState == "OnHold") {
                    val holdMessage = """
                        Hold 된 Lot($lotId)은
                        BACKUP BAY를 변경할수 없습니다.
                    """.trimIndent()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        holdMessage, GetString.BTNOKSTR
                    )

                    lotEditText.setText("")
                    lotEditText.requestFocus()
                    lotEditText.selectAll()

                    return@launch
                }

                if (tempLotState != "Released") {
                    val stateMessage = """
                        Lot($lotId)이 Released 상태가 아니면
                        BACKUP BAY를 변경할수 없습니다.
                    """.trimIndent()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        stateMessage, GetString.BTNOKSTR
                    )

                    lotEditText.setText("")
                    lotEditText.requestFocus()
                    lotEditText.selectAll()

                    return@launch
                }

                val tempJobCode = messageBody.optString("JOBCODE")
                val tempQuantity = messageBody.optString("PRODUCTQUANTITY")
                val tempOperDesc = messageBody.optString("OPERATIONDESCRIPTION")

                when (lotEditText.id) {
                    viewBinding.editLotId.id -> {
                        viewBinding.txtJob.text = tempJobCode
                        viewBinding.txtQty.text = tempQuantity
                        viewBinding.txtProcessName.text = tempOperDesc

                        viewBinding.editLotId2.requestFocus()
                        viewBinding.editLotId2.selectAll()
                    }
                    viewBinding.editLotId2.id -> {
                        viewBinding.txtJob2.text = tempJobCode
                        viewBinding.txtQty2.text = tempQuantity
                        viewBinding.txtProcessName2.text = tempOperDesc

                        viewBinding.editLotId3.requestFocus()
                        viewBinding.editLotId3.selectAll()
                    }
                    viewBinding.editLotId3.id -> {
                        viewBinding.txtJob3.text = tempJobCode
                        viewBinding.txtQty3.text = tempQuantity
                        viewBinding.txtProcessName3.text = tempOperDesc

                        viewBinding.editLotId4.requestFocus()
                        viewBinding.editLotId4.selectAll()
                    }
                    viewBinding.editLotId4.id -> {
                        viewBinding.txtJob4.text = tempJobCode
                        viewBinding.txtQty4.text = tempQuantity
                        viewBinding.txtProcessName4.text = tempOperDesc

                        viewBinding.editLotId5.requestFocus()
                        viewBinding.editLotId5.selectAll()
                    }
                    viewBinding.editLotId5.id -> {
                        viewBinding.txtJob5.text = tempJobCode
                        viewBinding.txtQty5.text = tempQuantity
                        viewBinding.txtProcessName5.text = tempOperDesc

                        viewBinding.editLotId6.requestFocus()
                        viewBinding.editLotId6.selectAll()
                    }
                    viewBinding.editLotId6.id -> {
                        viewBinding.txtJob6.text = tempJobCode
                        viewBinding.txtQty6.text = tempQuantity
                        viewBinding.txtProcessName6.text = tempOperDesc

                        viewBinding.editLotId7.requestFocus()
                        viewBinding.editLotId7.selectAll()
                    }
                    viewBinding.editLotId7.id -> {
                        viewBinding.txtJob7.text = tempJobCode
                        viewBinding.txtQty7.text = tempQuantity
                        viewBinding.txtProcessName7.text = tempOperDesc

                        viewBinding.editLotId7.requestFocus()
                        viewBinding.editLotId7.selectAll()
                    }
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                lotEditText.requestFocus()
                lotEditText.selectAll()
            }
        }
    }

    private fun checkSameLotId(lotId: String): Boolean {
        var count = 0

        if (lotId == viewBinding.editLotId.text.toString())
            count++

        if (lotId == viewBinding.editLotId2.text.toString())
            count++

        if (lotId == viewBinding.editLotId3.text.toString())
            count++

        if (lotId == viewBinding.editLotId4.text.toString())
            count++

        if (lotId == viewBinding.editLotId5.text.toString())
            count++

        if (lotId == viewBinding.editLotId6.text.toString())
            count++

        if (lotId == viewBinding.editLotId7.text.toString())
            count++

        if (count > 1) {
            OkDialog.show(
                supportFragmentManager, "동일 LotId 확인",
                "동일한 LotId가 존재합니다.", GetString.BTNOKSTR
            )
            return false
        }

        return true
    }

    private fun saveData() {
        mainScope.launch {
            if (viewBinding.editLotId.text.isNullOrEmpty() && viewBinding.editLotId2.text.isNullOrEmpty() && viewBinding.editLotId3.text.isNullOrEmpty() && viewBinding.editLotId4.text.isNullOrEmpty()
                && viewBinding.editLotId5.text.isNullOrEmpty() && viewBinding.editLotId6.text.isNullOrEmpty() && viewBinding.editLotId7.text.isNullOrEmpty()
            ) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "입력된 정보가 없습니다.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.editLotId.text.isNotEmpty() && viewBinding.spinnerBay.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "첫번째 LOT의 BAY가 지정되지 않았습니다.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.editLotId2.text.isNotEmpty() && viewBinding.spinnerBay2.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "두번째 LOT의 BAY가 지정되지 않았습니다.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.editLotId3.text.isNotEmpty() && viewBinding.spinnerBay3.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "세번째 LOT의 BAY가 지정되지 않았습니다.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.editLotId4.text.isNotEmpty() && viewBinding.spinnerBay4.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "네번째 LOT의 BAY가 지정되지 않았습니다.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.editLotId5.text.isNotEmpty() && viewBinding.spinnerBay5.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "다섯번째 LOT의 BAY가 지정되지 않았습니다.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.editLotId6.text.isNotEmpty() && viewBinding.spinnerBay6.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "여섯번째 LOT의 BAY가 지정되지 않았습니다.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.editLotId7.text.isNotEmpty() && viewBinding.spinnerBay7.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "일곱번째 LOT의 BAY가 지정되지 않았습니다.", GetString.BTNOKSTR
                )
                return@launch
            }

            var cf0 = ""
            var cf1 = ""
            var cf2 = ""
            var cf3 = ""
            var cf4 = ""
            var cf5 = ""
            var cf6 = ""

            if (viewBinding.editLotId.text.isNotEmpty()) {
                cf0 =
                    "${viewBinding.editLotId.text}|${viewBinding.spinnerBay.selectedItem}|${DeviceInfo.OPERATOR_ID}"
            }
            if (viewBinding.editLotId2.text.isNotEmpty()) {
                cf1 =
                    "${viewBinding.editLotId2.text}|${viewBinding.spinnerBay2.selectedItem}|${DeviceInfo.OPERATOR_ID}"
            }
            if (viewBinding.editLotId3.text.isNotEmpty()) {
                cf2 =
                    "${viewBinding.editLotId3.text}|${viewBinding.spinnerBay3.selectedItem}|${DeviceInfo.OPERATOR_ID}"
            }
            if (viewBinding.editLotId4.text.isNotEmpty()) {
                cf3 =
                    "${viewBinding.editLotId4.text}|${viewBinding.spinnerBay4.selectedItem}|${DeviceInfo.OPERATOR_ID}"
            }
            if (viewBinding.editLotId5.text.isNotEmpty()) {
                cf4 =
                    "${viewBinding.editLotId5.text}|${viewBinding.spinnerBay5.selectedItem}|${DeviceInfo.OPERATOR_ID}"
            }
            if (viewBinding.editLotId6.text.isNotEmpty()) {
                cf5 =
                    "${viewBinding.editLotId6.text}|${viewBinding.spinnerBay6.selectedItem}|${DeviceInfo.OPERATOR_ID}"
            }
            if (viewBinding.editLotId7.text.isNotEmpty()) {
                cf6 =
                    "${viewBinding.editLotId7.text}|${viewBinding.spinnerBay7.selectedItem}|${DeviceInfo.OPERATOR_ID}"
            }

            val sendMessage = MessageFactoryUtil.inFactory(cf0, cf1, cf2, cf3, cf4, cf5, cf6)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.INFACTORY)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val successLot = messageBody.optString("SUCCESSLOT")

                OkDialog.show(
                    supportFragmentManager, "완료",
                    "$successLot 개의 LOT이 완료 되었습니다", GetString.BTNOKSTR
                )

                clearAll()
                viewBinding.editLotId.requestFocus()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

            }
        }
    }

    override fun onBackPressed() {
        return
    }
}