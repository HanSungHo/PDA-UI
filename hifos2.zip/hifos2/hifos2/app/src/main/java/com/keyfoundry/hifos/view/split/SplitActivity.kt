package com.keyfoundry.hifos.view.split

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.*
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.*
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivitySplitBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.cmm.WaferSelectActivity
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*
import kotlin.collections.ArrayList

class SplitActivity : HFActivity() {
    companion object {
        private const val TAG = "SplitActivity"
    }

    private lateinit var viewBinding: ActivitySplitBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var gridService: GridService
    private lateinit var currentSelectedRow: CTRowLayout
    private lateinit var columnMap: LinkedHashMap<String, ColumnProperty>

    private val maxSplitCount = 5
    private var currentRowCount = 0
    private var enableWafer = ""
    private var searchRootLotName = ""
    private var searchProcessStep = ""
    private var searchOperation = ""
    private var searchSubOperation = ""
    private var childlotseq = 0;

    inner class WaferGestureListener : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent?): Boolean {
            executeWaferSelect()

            return super.onDoubleTap(e)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivitySplitBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        gridService = GridService(this)
        currentSelectedRow = CTRowLayout(this)

        columnMap = linkedMapOf(
            "LOT NO" to ColumnProperty(
                "LOT NO", Gravity.START + Gravity.CENTER_VERTICAL, false, 250, true
            ),
            "N" to ColumnProperty("N", Gravity.START + Gravity.CENTER_VERTICAL, false, 100),
            "WAFER" to ColumnProperty("WAFER", Gravity.START + Gravity.CENTER_VERTICAL, false, 200),
            "제품명" to ColumnProperty("제품명", Gravity.START + Gravity.CENTER_VERTICAL, false, 350)
        )

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()
            viewBinding.editLotNo.setText(lotId)

            setLotInfo()//---[Modification] Apr 05, 2007. by I. H. Lee; 아래 RF 대신사용
            //	OnRfread((WPARAM)new CString(m_sLotID), RF_TYPE_LOT);
        } else {
            setHeaderRow()
        }

        viewBinding.editLotNo.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)
                if (check)
                    setLotInfo()
                else
                    clearInfo()
            } else if (event != null) { // Barcode Event
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)
                    if (check)
                        setLotInfo()
                    else
                        clearInfo()
                }
            }

            true
        }

        setChildSpinner()
        viewBinding.btnSplit.setOnClickListener(onSingleClickListener)
        viewBinding.btnWafer.setOnClickListener(onSingleClickListener)
        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
    }

    private fun clearInfo() {
        viewBinding.txtProductName.text = ""
        viewBinding.txtOriginalQty.text = ""
        viewBinding.txtRemainQty.text = ""
        viewBinding.txtCurrentOperation.text = ""
        viewBinding.editComment.setText("")

        clearGrid()

        viewBinding.spinnerChildCount.setSelection(0, false)

        viewBinding.spinnerChildCount.isEnabled = false
        viewBinding.btnSplit.isEnabled = false
        viewBinding.btnOk.isEnabled = false
        viewBinding.btnWafer.isEnabled = false

        enableWafer = ""
        searchRootLotName = ""
        searchProcessStep = ""
        searchOperation = ""
        searchSubOperation = ""
        currentRowCount = 0
        childlotseq = 0
    }

    private fun clearGrid() {
        viewBinding.mainbody.removeAllViews()
        currentSelectedRow = CTRowLayout(this)
        setHeaderRow()
    }

    private fun setLotInfo() {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@SplitActivity, currentFocus)

            clearInfo()

            val lotId = viewBinding.editLotNo.text.toString()
            val sendMessage = MessageFactoryUtil.slotInfo(lotId, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.SLOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val product = messageBody.optString("PRODUCT")
                val operation = messageBody.optString("OPERATION")
                val subOperation = messageBody.optString("SUBOPERATION")
                val processStep = messageBody.optString("PROCESSSTEP")
                val qty = messageBody.optString("QUANTITY")
                val state = messageBody.optString("STATE")
                val status = messageBody.optString("STATUS")
                val holdStatus = messageBody.optString("HOLDSTATUS")
                val batchID = messageBody.optString("BATCHID")
                val enabledWaferList = messageBody.optString("WAFERLIST")
                val sampleFlag = messageBody.optString("SAMPLEFLAG")
                //---[Addition] Dec 14, 2007. by I. H. Lee (Begin)
                val rootLotName = messageBody.optString("ROOTLOTNAME")
                val clotseq = messageBody.optString("CHILDLOTSEQUENCE")
                searchRootLotName = rootLotName
                //---[Addition] Dec 14, 2007. by I. H. Lee (End)
                searchProcessStep = processStep
                searchOperation = operation
                searchSubOperation = subOperation
                enableWafer = enabledWaferList
                if(clotseq.isEmpty() || clotseq == "0"){
                    childlotseq = 0 }
                else{
                    childlotseq = clotseq.toInt() }


                val currentStep = "$processStep($operation$subOperation)"
                viewBinding.txtProductName.text = product
                viewBinding.txtOriginalQty.text = qty
                viewBinding.txtRemainQty.text = qty
                viewBinding.txtCurrentOperation.text = currentStep

//                if(status == "RUN"){
//                    OkDialog.show(
//                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
//                        "현재 RUN중입니다. SPLIT할수 없습니다.", GetString.BTNOKSTR
//                    )
//                    return@launch
//                }

                if (state != "WIP") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "$state 상태 입니다. SPLIT할 수 없습니다.", GetString.BTNOKSTR
                    )
                    return@launch
                }

                if (holdStatus == "ONHOLD") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "HOLD된 LOT입니다. SPLIT할수 없습니다.", GetString.BTNOKSTR
                    )
                    return@launch
                }

                if (batchID.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "BATCH로 묶여 있는 LOT입니다. SPLIT할수 없습니다.", GetString.BTNOKSTR
                    )
                    return@launch
                }

                if (sampleFlag == "S") {
                    val sampleMsg = """
                            |${lotId}은(는) Sample Lot 입니다.
                            |모 Lot으로 합류 후 Split 하세요.
                        """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        sampleMsg, GetString.BTNOKSTR
                    )
                    return@launch
                }

                viewBinding.spinnerChildCount.isEnabled = true
                viewBinding.btnSplit.isEnabled = true
                viewBinding.btnOk.isEnabled = true

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
            }
        }
    }

    private fun setChildSpinner() {
        val countList = ArrayList<Int>()
        for (count in 1..maxSplitCount)
            countList.add(count)

        val spinnerAdapter =
            ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, countList)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerChildCount.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSplit.id -> {
                    setSplitGrid()
                }
                viewBinding.btnWafer.id -> {
                    executeWaferSelect()
                }
                viewBinding.btnOk.id -> {
                    executeSplit()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    private fun setSplitGrid() {
        if (viewBinding.spinnerChildCount.selectedItem == null) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "자 LOT의 개수를 입력하세요", GetString.BTNOKSTR
            )
            return
        }

        val count = viewBinding.spinnerChildCount.selectedItem.toString().toInt()

        if (count < 1) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "SPLIT개수는 1이상이어야 합니다.", GetString.BTNOKSTR
            )
            return
        }

        if (count > 5) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "최대 5개 까지 나눌수 있습니다.", GetString.BTNOKSTR
            )
            return
        }

        if (currentRowCount < count)
            addGridRow(count - currentRowCount)
        else
            removeGridRow(currentRowCount - count)

        val mainGrid = viewBinding.mainbody.getChildAt(0) as CTMainLayout
        val mainTable = mainGrid.mainTable
        val firstRow = mainTable.getChildAt(0) as CTRowLayout

        firstRow.requestFocus()
        currentSelectedRow = firstRow
        currentRowCount = count
        viewBinding.btnWafer.isEnabled = currentRowCount > 0
    }

    private fun setHeaderRow() {
        val bodyLayout = CTMainLayout(this)

        val columnHeaderList = CTSubLayout(this, GridType.COLUMN_GRID)
        val rowHeaderList = CTSubLayout(this, GridType.ROW_GRID)
        val mainBodyList = CTSubLayout(this, GridType.MAIN_GRID)
        val cornerHeaderList = CTSubLayout(this, GridType.CORNER_GRID)

        val columnValueList = mutableListOf<String>()

        val columnHeaderRow = CTRowLayout(this)
        columnHeaderRow.setBackgroundColor(Color.parseColor("#e9edef"))

        for (columnName in columnMap.keys) {
            val property = columnMap[columnName] as ColumnProperty
            val columnValue = property.columnVale
            var columnSize = property.columnSize

            if (columnSize == null)
                columnSize = ViewGroup.LayoutParams.WRAP_CONTENT

            val columnItem = TextView(this)
            columnItem.gravity = Gravity.CENTER
            columnItem.setPadding(10)
            columnItem.setBackgroundResource(R.drawable.cellsharp)
            columnValueList.add(columnName)
            columnItem.text = columnValue
            columnHeaderRow.addView(columnItem)

            val columnParameter = columnItem.layoutParams
            columnParameter.width = columnSize
            columnItem.layoutParams = columnParameter
        }

        columnHeaderRow.tag = columnValueList
        columnHeaderList.addView(columnHeaderRow)

        for (col in 0 until columnHeaderList.childCount) {
            val cornerHeaderRow = CTRowLayout(this)
            val cornerItem = TextView(this)
            cornerHeaderRow.addView(cornerItem)

            cornerHeaderList.addView(cornerHeaderRow)
        }

        bodyLayout.addViews(mainBodyList, columnHeaderList, rowHeaderList, cornerHeaderList)
        viewBinding.mainbody.addView(bodyLayout)
    }

    private fun addGridRow(count: Int) {
        val bodyLayout = viewBinding.mainbody.getChildAt(0) as CTMainLayout

        val rowHeaderList = bodyLayout.rowHeaderTable
        val mainBodyList = bodyLayout.mainTable
        var seqCLot = ""

        for (row in 0 until count) {
            val mainBodyRow = CTRowLayout(this)
            mainBodyRow.setBackgroundResource(R.drawable.rowcolor)
            mainBodyRow.isClickable = true
            mainBodyRow.isFocusableInTouchMode = true
            mainBodyRow.setOnTouchListener { v, event ->
                currentSelectedRow = mainBodyRow
                false
            }


            val columnHeaderRow = CTRowLayout(this)
            columnHeaderRow.setBackgroundColor(Color.parseColor("#e9edef"))

            val colDataMap = HashMap<String, Any>()

            for (columnName in columnMap.keys) {
                val property = columnMap[columnName] as ColumnProperty
                val columnGravity = property.gravity
                val editable = property.editable
                val columnSize = property.columnSize

                var bodyItem = TextView(this)
                if (editable) {
                    bodyItem = EditText(this)
                    //소문자 -> 대문자
                    bodyItem.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
                }

                var itemValue = ""

                when (columnName) {
                    "LOT NO" -> {
                        bodyItem.inputType = InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                        /// 추가
                        if(viewBinding.chkEtch.isChecked)
                        {
                            if ( childlotseq ==0) {
                                seqCLot = "SE1"
                            }
                            else if (childlotseq  == 99){
                                seqCLot = ""
                                OkDialog.show(
                                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                                    "Child Lot이 생성할수 있는 Sequence를 벗어났습니다.\n 4469로 문의하세요 ", GetString.BTNOKSTR
                                )
                            }
                            else{
                                seqCLot = "SE" + (childlotseq + 1).toString()
                            }
                        }
                        else
                        {
                            if(childlotseq > 8 ){
                                var iAlphabet = 0

                                //N9 다음은 NA로 강제 Setting
                                if (childlotseq == 9){
                                    seqCLot = "NA"
                                }
                                else{
                                    iAlphabet = 65 + (childlotseq -9)
                                    seqCLot = "N" + iAlphabet.toChar()
                                }
                            }
                            else {
                                seqCLot = "N" + (childlotseq + 1).toString()
                            }
                        }
                        // 여기 까지

                        if(viewBinding.editLotNo.text.length > 7)
                        {
                            //itemValue = searchRootLotName+seqCLot
                            itemValue = viewBinding.editLotNo.text.toString().substring(0,7)+seqCLot

                        }
                        else
                        {
                            itemValue = viewBinding.editLotNo.text.toString() + seqCLot
                        }

                        //itemValue = viewBinding.editLotNo.text.toString() + seqCLot
                        childlotseq = childlotseq +1  //추가
                    }
                    "N" -> {
                        itemValue = "0"
                    }
                    "WAFER" -> {
                        bodyItem.isClickable = true
                        bodyItem.imeOptions = EditorInfo.IME_ACTION_DONE;
                        val mDetector =
                            GestureDetectorCompat(applicationContext, WaferGestureListener())

                        bodyItem.setOnTouchListener { v, event ->
                            currentSelectedRow = v.parent as CTRowLayout
                            currentSelectedRow.onTouchEvent(event)

                            return@setOnTouchListener mDetector.onTouchEvent(event)
                        }
                    }
                    "제품명" -> {
                        itemValue = viewBinding.txtProductName.text.toString()
                    }
                }

                bodyItem.gravity = columnGravity
                bodyItem.setPadding(10)
                bodyItem.isSingleLine = true
                bodyItem.setBackgroundResource(R.drawable.cellsharp)
                bodyItem.text = itemValue
                colDataMap[columnName] = itemValue
                mainBodyRow.addView(bodyItem)

                val bodyParameter = bodyItem.layoutParams
                bodyParameter.width = columnSize
                bodyItem.layoutParams = bodyParameter
            }

            mainBodyRow.tag = GridService.RowData(colDataMap)
            mainBodyList.addView(mainBodyRow)

            val rowHeaderRow = CTRowLayout(this)
            val rowItem = TextView(this)
            rowHeaderRow.addView(rowItem)
            rowHeaderList.addView(rowHeaderRow)
        }
    }

    private fun removeGridRow(count: Int) {
        val bodyLayout = viewBinding.mainbody.getChildAt(0) as CTMainLayout

        val rowHeaderList = bodyLayout.rowHeaderTable
        val mainBodyList = bodyLayout.mainTable

        for (row in 0 until count) {
            mainBodyList.removeViewAt(mainBodyList.childCount - 1)
            rowHeaderList.removeViewAt(rowHeaderList.childCount - 1)
        }

        changeRemainQty(mainBodyList)
        childlotseq = childlotseq -count
    }

    private fun executeWaferSelect() {
        val grid = viewBinding.mainbody.getChildAt(0) as CTMainLayout

        if (currentSelectedRow.isEmpty()) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "Wafer를 지정할 LOT을 선택하세요.", GetString.BTNOKSTR
            )
            return
        }

        val disableWafer = getDisableWafer(grid.mainTable)
        val selectWafer = gridService.getCellValue(currentSelectedRow, "WAFER")

        var fixedCount = viewBinding.txtRemainQty.text.toString().toInt()
        if (selectWafer.isNotEmpty())
            fixedCount += selectWafer.split(",").count()

        val nextIntent = Intent(this, WaferSelectActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.editLotNo.text.toString())
        nextIntent.putExtra("FIXEDCOUNT", fixedCount.toString())
        nextIntent.putExtra("EXISTWAFERLIST", enableWafer)
        nextIntent.putExtra("DISABLEWAFERLIST", disableWafer)
        nextIntent.putExtra("SELECTWAFERLIST", selectWafer)

        activityFactoryResultLauncher.launch(nextIntent)
    }

    private fun getDisableWafer(mainTable: CTSubLayout): String {
        var disableList = ""

        for (row in 0 until mainTable.childCount) {
            val gridRow = mainTable.getChildAt(row) as CTRowLayout

            if (gridRow != currentSelectedRow) {
                val wafer = gridService.getCellValue(gridRow, "WAFER")

                if (wafer.isNotEmpty()) {
                    if (disableList.isEmpty())
                        disableList = wafer
                    else
                        disableList += ",$wafer"
                }
            }
        }

        return disableList
    }

    private fun changeRemainQty(mainTable: CTSubLayout) {
        var totalCount = 0

        for (row in 0 until mainTable.childCount) {
            val gridRow = mainTable.getChildAt(row) as CTRowLayout

            val wafer = gridService.getCellValue(gridRow, "WAFER")

            if (wafer.isNotEmpty()) {
                val waferCount = wafer.split(",").count()
                totalCount += waferCount
            }
        }

        val oriRemainQty = viewBinding.txtOriginalQty.text.toString().toInt()
        viewBinding.txtRemainQty.text = (oriRemainQty - totalCount).toString()
    }

    private val activityFactoryResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                it.data?.let { intent ->
                    val rowData = currentSelectedRow.tag as GridService.RowData

                    val gridBody = viewBinding.mainbody.getChildAt(0) as CTMainLayout

                    var columnIndex = gridService.getColumnIndex(gridBody, "WAFER")
                    var cellValue = currentSelectedRow.getChildAt(columnIndex) as TextView
                    val selectWaferList = intent.getStringExtra("SELECTEDWAFERLIST").toString()

                    rowData.rowDataList["WAFER"] = selectWaferList
                    cellValue.text = selectWaferList

                    columnIndex = gridService.getColumnIndex(gridBody, "N")
                    cellValue = currentSelectedRow.getChildAt(columnIndex) as TextView

                    var waferCount = 0
                    if (selectWaferList.isNotEmpty())
                        waferCount = selectWaferList.split(",").count()

                    rowData.rowDataList["N"] = waferCount
                    cellValue.text = waferCount.toString()

                    changeRemainQty(gridBody.mainTable)
                }
            }
        }

    private fun executeSplit() {
        mainScope.launch {
            val mainGrid = viewBinding.mainbody.getChildAt(0) as CTMainLayout

            if (mainGrid.mainTable.childCount <= 0) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "SPLIT할 자LOT을 입력하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            var beforeLotNo = ""
            // Convert to Uppercase String (Nov 25, 2003 I. H. Lee)
            for (mainRow in mainGrid.mainTable.children) {
                val childrenTextView = (mainRow as CTRowLayout).getChildAt(0) as EditText
                //---[Addition] Dec 14, 2007. by I. H. Lee (Begin)
                val childrenLotNo = childrenTextView.text.toString().trim()
                //---[Addition] Dec 14, 2007. by I. H. Lee (End)
                childrenTextView.setText(childrenLotNo.toUpperCase(Locale.ROOT))

                if (childrenLotNo.isEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "SPLIT할 자LOT을 입력하세요.", GetString.BTNOKSTR
                    )
                    return@launch
                }

                if (childrenLotNo.toUpperCase(Locale.ROOT) == beforeLotNo) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "중복된 LOT NO가 존재합니다.", GetString.BTNOKSTR
                    )
                    return@launch
                } else {
                    beforeLotNo = childrenLotNo.toUpperCase(Locale.ROOT)
                }

                val rowData = (mainRow.tag as GridService.RowData).rowDataList
                rowData["LOT NO"] = childrenLotNo.toUpperCase(Locale.ROOT)
            }

            var totalQty = 0
            for (mainRow in mainGrid.mainTable.children) {
                val lotNo = gridService.getCellValue(mainRow, "LOT NO")
                val selectWafer = gridService.getCellValue(mainRow, "WAFER")
                val qty = gridService.getCellValue(mainRow, "N").toInt()

                totalQty += qty

                if (selectWafer.isEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "자LOT의 WAFER를 입력하세요.", GetString.BTNOKSTR
                    )
                    return@launch
                }

                if (lotNo == viewBinding.editLotNo.text.toString()) {
                    val message = """
                        |자 LOT의 LOT NO가
                        |모 LOT의 LOT NO와 같습니다.
                    """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        message, GetString.BTNOKSTR
                    )
                    return@launch
                }

                //---[Addition] Dec 14, 2007. by I. H. Lee (Begin)
                // Requested by SC 기획팀, 2008/01/01부터 적용됨
                // Lot Naming Rule이 변경됨에 따라
                // 1. Lot Name 내부에 공백문자가 있을 경우 Error
                // 2. Root Lot Name의 자릿수가 7자리일 경우
                //    1) "-"은 금칙문자 처리
                //    2) 최대 Lot Name은 9자리
                //    3) Aplha + Numeric 이외에는 사용금지
                // 3. 기존과 동일하게 Root Lot Name이 6자리 이하일 경우
                //    Lot Naming Rule이 변경되기 전 Lot들이 WIP에 있을 경우를 감안하는 것으로
                //    아무것도 Check 하지 않음
                if (lotNo.contains(" ")) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "Lot Name 중간에 공백문자가 있습니다.", GetString.BTNOKSTR
                    )
                    return@launch
                }

                if (searchRootLotName.length == 7) {
                    if (lotNo.contains("-")) {
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            "Lot Name에 사용할 수 없는 문자(-)가 있습니다.", GetString.BTNOKSTR
                        )
                        return@launch
                    }

                    if (lotNo.length != 9) {
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            "Lot Name은 9자리여야 합니다.", GetString.BTNOKSTR
                        )
                        return@launch
                    }

                    for (element in lotNo.indices) {
                        val lotElement = lotNo.elementAt(element)
                        //--- 8번째 자리는 무조건 문자만 사용할 수 있다.
                        if (element == 7) {
                            if (lotElement.toInt() !in 64..91) {
                                val message = "Lot Name의 8번째 자리는 문자여야 합니다.[$lotElement]"
                                OkDialog.show(
                                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                                    message, GetString.BTNOKSTR
                                )
                                return@launch
                            }
                        } else {
                            if (lotElement.toInt() !in 65..91 && lotElement.toInt() !in 47..58) {
                                val message = "Lot Name에 사용할 수 없는 문자가 있습니다.[$lotElement]"
                                OkDialog.show(
                                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                                    message, GetString.BTNOKSTR
                                )
                                return@launch
                            }
                        }
                    }
                } else {//---[Addition] Jan 10, 2008. by I. H. Lee (Begin)
                    if (!lotNo.contains("-") && lotNo.length == 7) {
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            "이전 Lot Name은 최소 7자리 이상 및 '-'를 포함해야 합니다.", GetString.BTNOKSTR
                        )
                        return@launch
                    }
                }
            }
            //---[Addition] Jan 10, 2008. by I. H. Lee (End)

            //---[Addition] Dec 14, 2007. by I. H. Lee (End)
            if (totalQty > viewBinding.txtOriginalQty.text.toString().toInt()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "모 LOT의 Wafer수량을 넘었습니다.", GetString.BTNOKSTR
                )
                return@launch
            }

            //---특정 고객 Lot의 Split시, 작업자가 고객명을 인지할 수 있도록 메시지창 pop-up
            //---[Addition] 2016.03.02
            if (checkCustomerLot())
                return@launch
            //--[Addition] 2016.03.02

            val lotId = viewBinding.editLotNo.text.toString()
            val qty = viewBinding.txtRemainQty.text.toString()
            val product = viewBinding.txtProductName.text.toString()
            val splitLostList = getSplitLostList()
            val comment = viewBinding.editComment.text.toString()

            val sendMessage = MessageFactoryUtil.split(
                lotId, DeviceInfo.FACILITY, qty, searchOperation, searchSubOperation,
                product, "N", "", "", DeviceInfo.OPERATOR_ID, splitLostList, comment
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.SPLIT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                finish()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
            }
        }
    }

    private suspend fun checkCustomerLot(): Boolean {
        var check = false

        val sendMessage =
            MessageFactoryUtil.callCustomer(viewBinding.txtProductName.text.toString())
        val message =
            MessageSender.send(supportFragmentManager, sendMessage, MessageName.CALLCUSTOMER)
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val customer = messageBody.optString("CUSTOMER")

            if (customer.isNotEmpty()) {
                val customMsg = """
                        |[$customer] 고객 Lot 입니다.
                        |Scrap 대기 Lot으로 분리 시, 실물은 DIFF 반장에게 전달하세요
                    """.trimMargin()
                val returnCode = OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    customMsg, GetString.BTNOKSTR
                )
                if (returnCode == OkDialog.RETURN_CODE_OK) {
                    check = true
                }
            }
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )

            viewBinding.editLotNo.requestFocus()
            viewBinding.editLotNo.selectAll()
        }

        return check
    }

    private fun getSplitLostList(): String {
        val mainGrid = viewBinding.mainbody.getChildAt(0) as CTMainLayout

        var itemList = ""
        for (row in mainGrid.mainTable.children) {
            val splitLotNo = gridService.getCellValue(row, "LOT NO")
            val splitQty = gridService.getCellValue(row, "N")
            val splitProd = gridService.getCellValue(row, "WAFER")
            val waferId = gridService.getCellValue(row, "제품명")

            itemList += """
                        |<ITEM>
                        |<SPLITLOTID>$splitLotNo</SPLITLOTID>
                        |<SPLITQTY>$splitQty</SPLITQTY>
                        |<SPLITPROD>$waferId</SPLITPROD>
                        |<WAFERID>$splitProd</WAFERID>
                        |</ITEM>
                        """.trimMargin()
        }

        return itemList
    }
}