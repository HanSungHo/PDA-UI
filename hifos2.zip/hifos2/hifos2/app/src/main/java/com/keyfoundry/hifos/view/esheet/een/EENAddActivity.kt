package com.keyfoundry.hifos.view.esheet.een

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.spinner.SpinnerItem
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityEenAddBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.lang.Exception
import java.util.ArrayList


/*
*   EEN 등록하기 기능 화면 (Addition by Sunggil Hwang, 2024.01.19)
    Requested by 제조팀 김택용 FL
* */
class EENAddActivity :  HFActivity() {
     companion object {
         private const val TAG = "SettingEEN"
     }

    private lateinit var viewBinding: ActivityEenAddBinding
    private lateinit var keyboardVisibilityUtils: KeyboardVisibilityUtils

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    lateinit var lotId: String
    lateinit var operation: String
    lateinit var processStep: String
    lateinit var operSeq: String
    lateinit var factoryname: String
    lateinit var product: String
    lateinit var route: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityEenAddBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        keyboardVisibilityUtils = KeyboardVisibilityUtils(window,
            onShowKeyboard = { keyboardHeight ->
                viewBinding.svRoot.run {
                    smoothScrollTo(scrollX, scrollY + keyboardHeight)
                }
            })

        lotId = intent.getStringExtra("LOTID").toString()
        factoryname = intent.getStringExtra("FACTORYNAME").toString()
        product = intent.getStringExtra("PRODUCT").toString()
        route = intent.getStringExtra("ROUTE").toString()
        operation = intent.getStringExtra("OPERATION").toString()
        processStep = intent.getStringExtra("PROCESSSTEP").toString()
        operSeq = intent.getStringExtra("OPERSEQUENCE").toString()

        viewBinding.txtLotId.text = lotId
        viewBinding.txtFacility.text = factoryname
        viewBinding.txtProduct.text = product
        viewBinding.txtOperationDesc.text = processStep
        viewBinding.spinnerTagId.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerRoute.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerOperation.onItemSelectedListener = itemSelectListener
        viewBinding.btnConfirm.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
        viewBinding.btnWaferNo.setOnClickListener(onSingleClickListener)


        setSpinnerTag()
        setSpinnerRoute()
        spinnerActionPoint()

    }

    private fun setSpinnerRoute(){
        mainScope.launch {
            var sendMessage = MessageFactoryUtil.getProcessFlow(factoryname,product,operation)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            val spinnerRouteItems = arrayListOf<String>()

            try {
                if (isSuccessFul) {
                    val routeListJSON =
                        ResponseDataToJsonUtil.getMessageBodyList(result, GetString.ITEMS)

                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                    val selectedProcessFlow = messageBody.optString("PROCESSFLOWNAME")

                    for (i in 0 until routeListJSON.length()) {
                        val processFlow = routeListJSON.getJSONObject(i)
                        spinnerRouteItems.add(processFlow.optString("PROCESSFLOWNAME"))
                    }
                    spinnerRoute(spinnerRouteItems)

                    for(i in 1..spinnerRouteItems.size) {
                        if(viewBinding.spinnerRoute.getItemAtPosition(i)==selectedProcessFlow) {
                            viewBinding.spinnerRoute.setSelection(i)
                        }
                    }

                } else {
                    spinnerRouteItems.clear()
                }
            } catch (e: Exception){

            }
        }
    }

    private fun setSpinnerTag(){
        mainScope.launch {
            var sendMessage = MessageFactoryUtil.getTagId(factoryname)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.GETTAGID)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val tagListStr = messageBody.optString("TAGLIST")

                val dataList = ParseUtil.stringTo2D(tagListStr);

                setSpinnerTag(dataList)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR)
            }
        }
    }

    private fun setSpinnerTag(dataList : Array<Array<String>>?) {
        val itemList = arrayListOf<SpinnerItem>()

        dataList?.forEachIndexed { index, row ->
            itemList.add(SpinnerItem(row[1], row[0]))
        }

        val spinnerAdapter =
            ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerTagId.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
    }

    private val itemSelectListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {

                if (parent != null) {
                    when (parent.id) {
                        viewBinding.spinnerTagId.id -> {
                            viewBinding.editComment.setText((viewBinding.spinnerTagId.selectedItem as? SpinnerItem)?.key)
                        }
                        viewBinding.spinnerRoute.id -> {
                            spinnerProcessOperation(ArrayList<String>())
                            setSpinnerProcessOperation()
                        }
                        viewBinding.spinnerOperation.id -> {
                            if(viewBinding.spinnerOperation.selectedItem!=null) {
                                val index = viewBinding.spinnerOperation.selectedItem.toString()
                                    .indexOfFirst { it.isWhitespace() }
                                viewBinding.txtOperationDesc.text =
                                    viewBinding.spinnerOperation.selectedItem.toString()
                                        .substring(index + 1)
                            }
                        }
                    }
                }

        }

        override fun onNothingSelected(parent: AdapterView<*>?) {

        }
    }

    private fun setSpinnerProcessOperation(){
        if(viewBinding.spinnerRoute.selectedItem==null){
            return
        }
        mainScope.launch {
            var sendMessage = MessageFactoryUtil.getProcessOperation(factoryname,product,viewBinding.spinnerRoute.selectedItem.toString())
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            val spinnerOperationItems = arrayListOf<String>()

            try {
                if (isSuccessFul) {
                    val processOperListJSON =
                        ResponseDataToJsonUtil.getMessageBodyList(result, GetString.ITEMS)

                    for (i in 0 until processOperListJSON.length()) {
                        val operationName = processOperListJSON.getJSONObject(i)
                        spinnerOperationItems.add(operationName.optString("PROCESSOPERATIONNAME") + " " + operationName.optString("PODESC"))
                    }
                    spinnerProcessOperation(spinnerOperationItems)

                    if(operation != "") {
                        for (i in 1..spinnerOperationItems.size) {
                            if (viewBinding.spinnerOperation.getItemAtPosition(i).toString()
                                    .split(" ")[0] == operation
                            ) {
                                viewBinding.spinnerOperation.setSelection(i)
                                operation = "";
                            }
                        }
                    }


                } else {
                    spinnerOperationItems.clear()
                }
            } catch (e: Exception){

            }
        }
    }

    private fun spinnerRoute(itemList : ArrayList<String>){
        val spinnerAdapter =
            ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerRoute.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
    }

    private fun spinnerProcessOperation(itemList : ArrayList<String>){
        val spinnerAdapter =
            ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerOperation.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
    }

    private fun spinnerActionPoint(){
        val itemList = arrayListOf("MOVEIN", "MOVEOUT", "MOVEIN/OUT")

        val spinnerAdapter =
            ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerActionPoint.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
    }



    private fun addWaferNumber(){
        val sendMessage = MessageFactoryUtil.getTagPosition(lotId)
        mainScope.launch {
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.GETTAGPOSITION)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val positionList =
                    ResponseDataToJsonUtil.getMessageBodyList(result, GetString.ITEMS)

                var tagComment = "#"
                for (i in 0 until positionList.length()) {
                    tagComment += positionList.getJSONObject(i).optString("POSITION")

                    if (i != positionList.length() - 1) {
                        tagComment += ","
                    }
                }

                viewBinding.editComment.setText(tagComment + viewBinding.editComment.text);
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR)
            }

        }
    }

    private fun addEenMessage(){
        if (viewBinding.spinnerRoute.selectedItem == null)
        {
            OkDialog.show(
                supportFragmentManager, "Route 입력",
                "Route를 입력하세요.", GetString.BTNOKSTR)
            return;
        }
        if (viewBinding.spinnerOperation.selectedItem == null)
        {
            OkDialog.show(
                supportFragmentManager, "공정 입력",
                "공정을 입력하세요.", GetString.BTNOKSTR)
            return;
        }
        if (viewBinding.spinnerActionPoint.selectedItem == null)
        {
            OkDialog.show(
                supportFragmentManager, "Action Point 입력",
                "Action Point를 입력하세요.", GetString.BTNOKSTR)
            return;
        }
        if (viewBinding.editComment.text.toString() == "")
        {
            OkDialog.show(
                supportFragmentManager, "Tag Comment 입력",
                "Tag Comment를 입력하세요.", GetString.BTNOKSTR)
            return;
        }

        val returnCode = OkCancelDialog.show(
            supportFragmentManager,
            GetString.TXTDIALOGTITLE_OK,
            "입력하시겠습니까?",
            GetString.BTNYESSTR,
            GetString.BTNNOSTR
        )

        if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
            return
        }

        val sendMessage = MessageFactoryUtil.insertEen(
            viewBinding.txtLotId.text.toString(),
            DeviceInfo.OPERATOR_ID,
            viewBinding.txtFacility.text.toString().trim(),
            viewBinding.txtProduct.text.toString().trim(),
            viewBinding.spinnerOperation.selectedItem.toString().split(" ")[0],
            viewBinding.spinnerActionPoint.selectedItem.toString(),
            viewBinding.spinnerRoute.selectedItem.toString().trim(),
            viewBinding.editComment.text.toString(),
            viewBinding.spinnerTagId.selectedItem?.toString()
        )

        mainScope.launch {
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.INSERTEEN)
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_OK,
                    "EEN을 성공적으로 저장하였습니다.",
                    GetString.BTNOKSTR
                )

                val returnIntent = Intent()
                returnIntent.putExtra("LOTID", lotId)
                setResult(Activity.RESULT_OK, returnIntent)
                finish()

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )

            }
        }
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnConfirm.id -> {
                    addEenMessage()
                }
                viewBinding.btnCancel.id ->{
                    CommonUtil.hideKeyboard(this@EENAddActivity, currentFocus)
                    finish()
                }
                viewBinding.btnWaferNo.id -> {
                    addWaferNumber()
                }
            }
        }
    }
}