package com.keyfoundry.hifos.view.chat

data class CreateChatRoom(
    val roomType: String,
    val roomName: String,
    val creatorId: String,
    val ipAddrList: MutableList<String>
)