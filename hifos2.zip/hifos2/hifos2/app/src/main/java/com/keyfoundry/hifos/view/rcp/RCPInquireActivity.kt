package com.keyfoundry.hifos.view.rcp

import android.graphics.Color
import android.os.Bundle
import android.text.InputFilter
import android.view.*
import android.view.inputmethod.EditorInfo
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityRcpinquireBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RCPInquireActivity : HFActivity() {
    companion object {
        private const val TAG = "RCPInquireActivity"
    }

    lateinit var viewBinding: ActivityRcpinquireBinding
    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)
    lateinit var gridService: GridService
    private var baseWidth = 0
    private var sScopemsg = ""
    private var sMacromsg = ""
    private var sCDmsg = ""
    private var sOvmsg = ""

    private var sSampleVimsg = ""
    private var sSampleCDmsg = ""
    private var sSampleOvmsg = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityRcpinquireBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        val base = viewBinding.baseLayout
        val vto: ViewTreeObserver = base.viewTreeObserver
        vto.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                base.viewTreeObserver.removeOnGlobalLayoutListener(this)
                baseWidth = base.width
            }
        })

        gridService = GridService(applicationContext)

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID")

            viewBinding.editLotNo.setText(lotId)
            getData()
        }

        viewBinding.editLotNo.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { //KeyBoard Event0
                getData()
            } else if (event != null) { //barcode event
                if (event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                    if (check)
                        getData()
                    else
                        clearData()
                }
            }
            true
        }

        viewBinding.btnSearchLotNo.setOnClickListener(onSingleClickListener)
        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnInspection.setOnClickListener(onSingleClickListener)
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchLotNo.id -> {
                    getData()
                }
                viewBinding.btnOk.id -> {
                    finish()
                }
                viewBinding.btnInspection.id -> {
                    getInspection()
                }
            }
        }
    }

    private fun getInspection() {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@RCPInquireActivity, currentFocus)

            if (viewBinding.editLotNo.text.toString().replace(" ", "") == "") {  // 공백 CHECK
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT NO가 확인되지 않습니다.", GetString.BTNOKSTR
                )
                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
                return@launch
            } else {
                val lotId = viewBinding.editLotNo.text.toString()
                val operationName = viewBinding.txtProcessNum.text.toString()

                if(operationName == ""){
                    return@launch
                }

                val sMOper = operationName.substring(0, operationName.indexOf("-"))
                val sSOper = operationName.substring(operationName.indexOf("-") + 1)

                val sendMessage = MessageFactoryUtil.checkinspection(
                    lotId,
                    DeviceInfo.FACILITY,
                    "RCP",
                    sMOper,
                    sSOper
                )
                val message = MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.CHECKINSPACTION
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result

                if (isSuccessFul) {
                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                    sMacromsg = messageBody.optString("MACROMSG");
                    sScopemsg = messageBody.optString("SCOPEMSG");
                    sCDmsg = messageBody.optString("CDMSG");
                    sOvmsg = messageBody.optString("sOvMSG");

                    sSampleVimsg = messageBody.optString("sSampleViMSG");
                    sSampleCDmsg = messageBody.optString("sSampleCdMSG");
                    sSampleOvmsg = messageBody.optString("sSampleOvMSG");
                }

                if (sMacromsg != "") {
                    val returnCode = OkDialog.show(
                        supportFragmentManager,
                        "Macro 측정 정보",
                        "▶ Macro 측정 [ $sMacromsg ]",
                        GetString.BTNOKSTR
                    )
                }

                if (sScopemsg != "") {
                    val returnCode = OkDialog.show(
                        supportFragmentManager, "Scope 측정 정보", "$sScopemsg", GetString.BTNOKSTR
                    )
                }
                if (sCDmsg != "") {
                    val returnCode = OkDialog.show(
                        supportFragmentManager,
                        "CD 측정 POINT",
                        "[CD 측정]\n $sCDmsg",
                        GetString.BTNOKSTR
                    )
                }

                if (sOvmsg != "") {
                    val returnCode = OkDialog.show(
                        supportFragmentManager, "Overlay 측정 정보", "$sOvmsg", GetString.BTNOKSTR
                    )
                }

                if (sSampleVimsg != "") {
                    val returnCode = OkDialog.show(
                        supportFragmentManager,
                        "VI 측정 정보",
                        "▶ Macro 측정 [ $sSampleVimsg ]",
                        GetString.BTNOKSTR
                    )
                }

                if (sSampleCDmsg != "") {
                    val returnCode = OkDialog.show(
                        supportFragmentManager,
                        "CD 측정 POINT",
                        "[CD 측정]\n $sSampleCDmsg",
                        GetString.BTNOKSTR
                    )
                }

                if (sSampleOvmsg != "") {
                    val returnCode = OkDialog.show(
                        supportFragmentManager, "Overlay 측정 정보", sSampleOvmsg, GetString.BTNOKSTR
                    )
                }

            }
        }
    }

    private fun getData() {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@RCPInquireActivity, currentFocus)

            viewBinding.baseLayout.removeAllViews()

            if (viewBinding.editLotNo.text.toString().replace(" ", "") == "") {  // 공백 CHECK

                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT NO가 확인되지 않습니다.", GetString.BTNOKSTR
                )

                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
                return@launch
            } else {
                val sLot = viewBinding.editLotNo.text.toString()
                val sendMessage = MessageFactoryUtil.metRecipeSearch(sLot, DeviceInfo.FACILITY)
                val message = MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.METRECIPESEARCH
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result

                if (isSuccessFul) {
                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                    val sProd = messageBody.optString("PRODUCTSPECNAME")
                    val sOper = messageBody.optString("PROCESSOPERATIONNAME")
                    val sOperDesc = messageBody.optString("OPERATIONDESCRIPTION")
                    val sTempCategory = messageBody.optString("CATEGORY")

                    viewBinding.txtProductName.text = sProd
                    viewBinding.txtProcessNum.text = sOper
                    viewBinding.txtProcessName.text = sOperDesc

                    val firstCol = baseWidth / 5 * 4
                    val secondCol = baseWidth / 5

                    if (sTempCategory == "CDOVERAYVI") {
                        val itemListCD =
                            ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "RCPCDITEMS")
                        val itemListOV =
                            ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "RCPOVITEMS")
                        val itemListVI =
                            ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "RCPVIITEMS")
                        val itemMask =
                            ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "MASKITEMS")

                        //CD->OV->VI 순서를 OV->VI->CD로 변경함
                        if (itemListOV.length() != 0) {
                            val columnData = linkedMapOf(
                                "OVRCP" to ColumnProperty(
                                    "OVERLAY RECIPE", Gravity.CENTER, false, firstCol
                                ),
                                "OVMACHINE" to ColumnProperty(
                                    "MACHINE", Gravity.CENTER, false, secondCol
                                )
                            )

                            val gridListov = gridService.setGridPropData(
                                columnData, itemListOV, Color.GREEN, Color.BLACK
                            )
                            viewBinding.baseLayout.addView(gridListov)
                        }

                        if (itemListVI.length() != 0) {
                            val columnData = linkedMapOf(
                                "MACHINERECIPENAME" to ColumnProperty(
                                    "VI RECIPE", Gravity.CENTER, false, firstCol
                                ),
                                "MACHINENAME" to ColumnProperty(
                                    "MACHINE", Gravity.CENTER, false, secondCol
                                )
                            )

                            val gridListvi = gridService.setGridPropData(
                                columnData, itemListVI, Color.BLUE, Color.WHITE
                            )
                            viewBinding.baseLayout.addView(gridListvi)
                        }

                        if (itemListCD.length() != 0) {
                            val columnData = linkedMapOf(
                                "CDRCP" to ColumnProperty(
                                    "CD RECIPE", Gravity.CENTER, false, firstCol
                                ),
                                "CDMACHINE" to ColumnProperty(
                                    "MACHINE", Gravity.CENTER, false, secondCol
                                )
                            )

                            val gridListcd = gridService.setGridPropData(
                                columnData, itemListCD, Color.RED, Color.WHITE
                            )
                            viewBinding.baseLayout.addView(gridListcd)
                        }

                        if (itemMask.length() != 0) {
                            val columnData = linkedMapOf(
                                "RETICLENAME" to ColumnProperty(
                                    "진행 마스크", Gravity.CENTER, false, firstCol
                                ),
                                "MACHINENAME" to ColumnProperty(
                                    "MACHINE", Gravity.CENTER, false, secondCol
                                )
                            )

                            val gridListMask = gridService.setGridPropData(
                                columnData, itemMask
                                , Color.MAGENTA, Color.WHITE
                            )
                            viewBinding.baseLayout.addView(gridListMask)
                        }

                    } else if (sTempCategory == "PQC") {
                        val itemList =
                            ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "RCPITEMS")

                        if (itemList.length() != 0) {
                            val columnData = linkedMapOf(
                                "REVIEW_EQUIP" to ColumnProperty(
                                    "CD RECIPE", Gravity.CENTER, false, baseWidth
                                )
                            )

                            val gridList = gridService.setGridPropData(columnData, itemList)
                            viewBinding.baseLayout.addView(gridList)
                        }
                    } else if (sTempCategory == "THIK") {
                        val itemList =
                            ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "RCPITEMS")

                        if (itemList.length() != 0) {
                            val columnData = linkedMapOf(
                                "MACHINERECIPENAME" to ColumnProperty(
                                    "RECIPE", Gravity.CENTER, false, firstCol
                                ),
                                "MACHINENAME" to ColumnProperty(
                                    "MACHINE", Gravity.CENTER, false, secondCol
                                )
                            )

                            val gridList = gridService.setGridPropData(columnData, itemList)

                            viewBinding.baseLayout.addView(gridList)
                        }
                    }
                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR
                    )
                }
            }
        }
    }

    private fun clearData() {
        viewBinding.txtProductName.text = ""
        viewBinding.txtProcessNum.text = ""
        viewBinding.txtProcessName.text = ""
        viewBinding.editLotNo.requestFocus()
        viewBinding.editLotNo.selectAll()

    }
}