package com.keyfoundry.hifos.config.service.udp

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.view.chat.ChatRoom
import com.keyfoundry.hifos.view.chat.ChatRoomActivity
import com.keyfoundry.hifos.view.dialog.NotificationActivity
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket

class UDPService : Service() {

    private var udpThread: UDPThread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        if (udpThread == null) {
            udpThread = UDPThread(this)
            udpThread?.start()
        }

        // Foreground Service 최소 알림
        val fgNotification = NotificationCompat.Builder(this, DeviceInfo.UDP_SERVICE_CHANEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("")
            .setContentText("")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()

        startForeground(10, fgNotification)

        return START_STICKY
    }

    override fun onDestroy() {
        udpThread?.stopRunning()
        super.onDestroy()
    }

    /** UDP 메시지 Notification (클릭 시 Activity) */
    fun showChatNotification(roomId: String, roomName: String, level: String, message: String) {

        UDPMessageStore.addMessage(roomName, roomName, message)
        val messages = UDPMessageStore.getMessages(roomName)

        val person = Person.Builder().setName(level).build()
        val style = NotificationCompat.MessagingStyle(person)
            .setConversationTitle(level)
        messages.forEach { style.addMessage(it) }

        val intent = Intent(this, ChatRoomActivity::class.java).apply {
            putExtra("roomId", roomId)
            putExtra("roomName", roomName)
            putExtra("clearMessages", true) // 클릭 시 메시지 초기화 플래그
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            roomName.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if(level == "NORMAL") {
            val notification = NotificationCompat.Builder(this, "udp_chat_channel")
                .setSmallIcon(android.R.drawable.sym_action_chat)
                .setStyle(style)
                .setContentIntent(pendingIntent) // 클릭 시 이동
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setAutoCancel(true) // 클릭하면 알림 사라짐
                .setGroup("udp_chat_group")
                .build()

            NotificationManagerCompat.from(this)
                .notify(roomName.hashCode(), notification)
        }
    }

    /** Notification Channel 생성 */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val serviceChannel = NotificationChannel(
                DeviceInfo.UDP_SERVICE_CHANEL_ID,
                DeviceInfo.UDP_SERVICE_CHANEL_NAME,
                NotificationManager.IMPORTANCE_MIN
            ).apply { description = "UDP background service" }

            val messageChannel = NotificationChannel(
                "udp_chat_channel",
                "UDP Chat Messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "UDP Chat Messages" }

            manager.createNotificationChannel(serviceChannel)
            manager.createNotificationChannel(messageChannel)
        }
    }

    /** 안정형 UDP Thread */
    class UDPThread(private val service: UDPService) : Thread() {

        companion object { private const val TAG = "UDPThread" }

        @Volatile private var running = true
        private var socket: DatagramSocket? = null

        fun stopRunning() {
            running = false
            socket?.close()
        }

        override fun run() {
            val buffer = ByteArray(10000)

            while (running) {
                try {
                    if (socket == null || socket!!.isClosed) {
                        socket = DatagramSocket(DeviceInfo.UDP_SERVICE_PORT)
                        socket?.reuseAddress = true
                    }

                    val packet = DatagramPacket(buffer, buffer.size)
                    socket?.receive(packet)

                    val msg = String(packet.data, 0, packet.length)
                    val json = JSONObject(msg)
                    val level = json.optString(GetString.UDP_LEVEL)
                    val content = json.optString(GetString.UDP_MESSAGE)

                    val roomId = json.optString("ROOMID")
                    val roomName = json.optString("ROOMNAME")

                    Log.d(TAG, "IP: ${packet.address} Level: $level Message: $content")

                    // Notification 표시 (클릭 시만 Activity)
                    service.showChatNotification(roomId, roomName, level, content)

                    // Broadcast (앱 UI 업데이트)
                    sendBroadcast(service, level, content, roomName)

                } catch (e: Exception) {
                    Log.e(TAG, "UDP Error", e)
                    Thread.sleep(1000) // 잠깐 대기 후 재시도
                }
            }

            socket?.close()
        }

        private fun sendBroadcast(context: Context, level: String, message: String, roomName: String) {
            val intent = Intent(DeviceInfo.UDP_RECEIVER_FILTER)
            intent.putExtra(DeviceInfo.UDP_RECEIVER_LEVEL, level)
            intent.putExtra(DeviceInfo.UDP_RECEIVER_MESSAGE, message)
            intent.putExtra("ROOMNAME", roomName)
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent)
        }
    }
}

/** 메시지 누적 저장 */
object UDPMessageStore {
    private val messages = mutableMapOf<String, MutableList<NotificationCompat.MessagingStyle.Message>>()

    fun addMessage(room: String, sender: String, message: String) {
        val list = messages.getOrPut(room) { mutableListOf() }
        list.add(NotificationCompat.MessagingStyle.Message(message, System.currentTimeMillis(), sender))
        if (list.size > 10) list.removeAt(0)
    }

    fun getMessages(room: String): List<NotificationCompat.MessagingStyle.Message> = messages[room] ?: emptyList()

    // 🔹 메시지 초기화
    fun clearMessages(room: String) {
        messages.remove(room)
    }
}