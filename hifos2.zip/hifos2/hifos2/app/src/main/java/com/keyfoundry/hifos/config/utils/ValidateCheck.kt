package com.keyfoundry.hifos.config.utils

import androidx.fragment.app.FragmentActivity
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog

/*
* 기준장비에 대한 장비 유효성을 체크 하는 Class
* */
class ValidateCheck(val activity: FragmentActivity) {

    fun equipment(eqpListString: String, machineName: String): Boolean {
        if(!equipmentValidate(eqpListString, machineName)){
            OkDialog.show(
            activity.supportFragmentManager,
            GetString.TXTDIALOGTITLE_ERROR,
            "[$machineName]장비가 기준장비에 존재하지 않습니다.",
            GetString.BTNOKSTR
            )
            return false
        }
        return true
    }

    private fun equipmentValidate(eqpListString: String, machineName: String) : Boolean {
        if(machineName.isEmpty()){
            return false
        }

        if(eqpListString.isNotEmpty()&&!eqpListString.contains("-")){
            return true
        }

        val eqpGroups = eqpListString.split("|")

        val preMachineName = machineName.substring(0,machineName.lastIndexOf("-"))
        val machineNumber = machineName.substring(machineName.lastIndexOf("-")+1)

        // val machineNumber = machineName.substring(machineName.lastIndexOf("-")+1).replace("[^0-9]".toRegex(), "").toInt()
        //  val machineNumber = machineName.split("-")[1].replace("[^0-9]".toRegex(), "").toInt()

        var machineList = ""
        for(eqpGroup in eqpGroups) {
            if(eqpGroup.contains(preMachineName)) {
                var tmpMachineList = eqpGroup.substringAfter(preMachineName)
                tmpMachineList = tmpMachineList.substring(1)

                if(tmpMachineList.contains(preMachineName)) {
                    if(equipmentValidate(tmpMachineList, machineName)){
                        return true
                    }
                }

                if(tmpMachineList.contains("-")) {

                    tmpMachineList = tmpMachineList.substringBefore("-")
                    tmpMachineList = tmpMachineList.substring(0,tmpMachineList.lastIndexOf(","))
                }

                if(machineList != "") {
                    machineList += ","
                }
                machineList += tmpMachineList
            }
        }

        if(machineList==""){
            return false
        }

        val machineNumberGroupList = machineList.split(",")
        for(machineNumberGroup in machineNumberGroupList){
            if(machineNumberGroup.contains("~")){
                val tmp = machineNumberGroup.split("~")
                if(tmp[0].toIntOrNull()==null&&machineNumber.replace("[^0-9]".toRegex(), "").toIntOrNull()==null){
                    if (machineNumber.single().toInt() >= tmp[0].single().toInt() &&  machineNumber.single().toInt() <= tmp[1].single().toInt()) {
                        return true
                    }
                } else if(tmp[0].toIntOrNull()!=null && machineNumber.replace("[^0-9]".toRegex(), "").toIntOrNull()!=null){
                    if (machineNumber.replace("[^0-9]".toRegex(),"").toInt() >= tmp[0].toInt() &&  machineNumber.replace("[^0-9]".toRegex(),"").toInt() <= tmp[1].toInt()) {
                        return true
                    }
                }

            }

            else {
                if (machineNumber.replace("[^0-9]".toRegex(), "").toIntOrNull() == null && machineNumberGroup.replace("[^0-9]".toRegex(), "").toIntOrNull()==null) {
                    if(machineNumber.single().toInt()==machineNumberGroup.single().toInt()) {
                        return true
                    }
                } else if(machineNumber.replace("[^0-9]".toRegex(), "").toIntOrNull() != null && machineNumberGroup.replace("[^0-9]".toRegex(), "").toIntOrNull()!=null)
                    if (machineNumber.replace("[^0-9]".toRegex(), "").toInt() == machineNumberGroup.replace("[^0-9]".toRegex(), "").toIntOrNull()) {
                        return true
                    }
            }
        }

        return false
    }

}