package com.keyfoundry.hifos.config.service.room

import android.content.Context
import com.keyfoundry.hifos.config.dao.SettingInfoDao
import com.keyfoundry.hifos.config.domain.SettingInfo
import com.keyfoundry.hifos.config.service.HifosDBHelper

class SettingInfoService {
    lateinit var db : HifosDBHelper
    lateinit var settingInfoDao: SettingInfoDao

    constructor(context: Context){
        db = HifosDBHelper.getInstance(context)!!
        settingInfoDao = db.settingInfoDao()
    }

    fun insert(settingInfo: SettingInfo){
        //1. delete
        settingInfoDao.deleteAll()

        //2. insert
        settingInfoDao.insert(settingInfo)
    }

    fun selectAll(): List<SettingInfo> {
        return settingInfoDao.getAll()
    }

    fun selectSettingInfo(): SettingInfo {
        return settingInfoDao.getSettingInfo()
    }

}