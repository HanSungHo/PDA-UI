package com.keyfoundry.hifos.view.remote

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ShapeDrawable
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.view.View
import android.view.ViewTreeObserver
import android.view.Window
import android.widget.TextView
import androidx.core.view.children
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.customview.TitleLayout
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.utils.GridService
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityRemoteEtchCommRcpBinding
import com.keyfoundry.hifos.message.MessageSenderAuto
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RemoteEtchCommRcpActivity : HFActivity() {
    init {
        this.update = false
    }

    private lateinit var viewBinding: ActivityRemoteEtchCommRcpBinding
    private lateinit var gridService: GridService

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var receiveLotId = ""
    private var receiveRecipe = ""
    private var receiveEqpId = ""
    private var receiveOperDesc = ""
    private var receiveOperID = ""

    private var receiveEQP_TYPE = ""

    private var baseWidth = 0

    override fun onBackPressed() {
        return
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setFinishOnTouchOutside(false)

        viewBinding = ActivityRemoteEtchCommRcpBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        gridService = GridService(this)
        viewBinding.txtRecipe.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtMachine.movementMethod = ScrollingMovementMethod.getInstance()

        val base = viewBinding.mainbody

        val vto: ViewTreeObserver = base.viewTreeObserver
        vto.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                base.viewTreeObserver.removeOnGlobalLayoutListener(this)
                baseWidth = base.width
            }
        })

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true)
            receiveLotId = intent.getStringExtra("LOTID").toString()

        if (intent.getStringExtra("RECIPE")?.isNotEmpty() == true) {
            receiveRecipe = intent.getStringExtra("RECIPE").toString()
            viewBinding.txtRecipe.text = receiveRecipe
        }

        if (intent.getStringExtra("EQPID")?.isNotEmpty() == true) {
            receiveEqpId = intent.getStringExtra("EQPID").toString()
            viewBinding.txtMachine.text = receiveEqpId
        }

        if (intent.getStringExtra("OPERID")?.isNotEmpty() == true)
            receiveOperID = intent.getStringExtra("OPERID").toString()
        if (intent.getStringExtra("OPERDESC")?.isNotEmpty() == true)
            receiveOperDesc = intent.getStringExtra("OPERDESC").toString()

        setData()

        viewBinding.btnModify.setOnClickListener(onSingleClickListener)
        viewBinding.btnConfirm.setOnClickListener(onSingleClickListener)
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnModify.id -> {
                    mainScope.launch {
                        executeModify()
                    }
                }
                viewBinding.btnConfirm.id -> {
                    finish()
                }
            }
        }
    }

    private suspend fun executeModify() {
        //if(m_USERID == L"")
        //{
        //	MessageBox(L"사번을 입력하여 주세요",L"에러",MB_OK | MB_ICONEXCLAMATION);
        //	return;
        //}

        val continueValue = OkCancelDialog.show(
            supportFragmentManager, "Recipe 변경", "Recipe를 변경하시겠습니까?",
            GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
        )

        if (continueValue == OkCancelDialog.RETURN_CODE_CANCEL)
            return

        val mainGrid = viewBinding.mainbody.getChildAt(0) as CTMainLayout

        var rmsPara = ""
        var downValue = ""

        if(receiveEQP_TYPE == "TE8500")
        {
            downValue = viewBinding.txtOwner.text.toString().replace(" 초","")
            val sendMessage = MessageFactoryUtil.etchRcpDownload(
                receiveLotId, receiveRecipe, receiveEqpId, DeviceInfo.OPERATOR_ID,
                receiveEQP_TYPE, "TIME", downValue, "2"
            )

            val message = MessageSenderAuto.send(
                supportFragmentManager, sendMessage, MessageName.ETCHRCPDOWNLOAD
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val status = messageBody.optString("CHK")

                for (row in mainGrid.mainTable.children) {
                    val checkRow = row as CTRowLayout
                    val checkRowData = (checkRow.tag as GridService.RowData).rowDataList
                    val chkCOL = checkRowData["COL"].toString()
                    if(chkCOL == "진행 TIME")
                    {
                        val chkResultCell = checkRow.getChildAt(2) as TextView
                        chkResultCell.setTextColor(Color.parseColor("#FFFFFF"))
                        var color = 0

                        when (status) {
                            "OK" -> {
                                checkRowData["RESULT"] = "정상"
                                chkResultCell.text = "정상"
                                color = Color.parseColor("#b30000e1")
                            }
                            "D_FAIL" -> {
                                checkRowData["RESULT"] = "변경실패"
                                chkResultCell.text = "변경실패"
                                color = Color.parseColor("#b3ff0000")
                            }
                            "V_FAIL" -> {
                                checkRowData["RESULT"] = "검증실패"
                                chkResultCell.text = "검증실패"
                                color = Color.parseColor("#b3ff0000")
                            }
                        }

                        when (val background = chkResultCell.background) {
                            is ShapeDrawable -> background.paint.color = color
                            is GradientDrawable -> background.setColor(color)
                            is ColorDrawable -> background.color = color
                        }
                    }
                }
            }
            else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR)
            }
        }
        else
        {
            for (count in 0 until mainGrid.mainTable.childCount) {
                val currentRow = mainGrid.mainTable.getChildAt(count) as CTRowLayout
                val currentRowData = (currentRow.tag as GridService.RowData).rowDataList

                // Down Value가 없는 경우 Skip
                val tuneValue = currentRowData["TUNE_VALUE"].toString()
                if (tuneValue.isEmpty())
                    continue

                // 정상 처리된 경우 Skip
                val resultValue = currentRowData["RESULT"]
                if (resultValue.toString() == "정상")
                    continue

                // 동일 Step은 한번에 처리
                if (count != mainGrid.mainTable.childCount - 1) {
                    val nextRow = mainGrid.mainTable.getChildAt(count + 1) as CTRowLayout
                    val nextRowData = (nextRow.tag as GridService.RowData).rowDataList

                    val currentRowStep = currentRowData["STEP"].toString()
                    val nextRowStep = nextRowData["STEP"].toString()

                    val nextRowResult = nextRowData["RESULT"].toString()

                    if (currentRowStep == nextRowStep && nextRowResult != "정상") {
                        val currentRowRmsPara = currentRowData["RMS_PARANAME"].toString()
                        val currentRowDownValue = currentRowData["TUNE_VALUE"].toString()

                        rmsPara += "$currentRowRmsPara@"
                        downValue += "$currentRowDownValue@"
                        continue
                    }
                }

                val currentRowRmsPara = currentRowData["RMS_PARANAME"].toString()
                val currentRowDownValue = currentRowData["TUNE_VALUE"].toString()

                rmsPara += currentRowRmsPara
                downValue += currentRowDownValue

                val currentChm = currentRowData["CHAMBER"].toString()
                val currentStep = currentRowData["STEP"].toString()

                execute(mainGrid, currentChm, rmsPara, downValue, currentStep)

                rmsPara = ""
                downValue = ""
            }
        }
    }

    private suspend fun execute(
        mainGrid: CTMainLayout,
        currentChm: String, rmsPara: String,
        downValue: String, currentStep: String
    ) {
        //mainScope.launch {
            val sendMessage = MessageFactoryUtil.etchRcpDownload(
                receiveLotId, receiveRecipe, receiveEqpId, DeviceInfo.OPERATOR_ID,
                currentChm, rmsPara, downValue, currentStep
            )

            val message = MessageSenderAuto.send(
                supportFragmentManager, sendMessage, MessageName.ETCHRCPDOWNLOAD
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val status = messageBody.optString("CHK")

                for (row in mainGrid.mainTable.children) {
                    val checkRow = row as CTRowLayout
                    val checkRowData = (checkRow.tag as GridService.RowData).rowDataList

                    val chkChm = checkRowData["CHAMBER"].toString()
                    val chkStep = checkRowData["STEP"].toString()
                    val chkTuneValue = checkRowData["TUNE_VALUE"].toString()
                    val chkResult = checkRowData["RESULT"].toString()

                    if (currentChm == chkChm && currentStep == chkStep && chkTuneValue.isNotEmpty() && chkResult != "정상") {
                        val chkResultCell = checkRow.getChildAt(6) as TextView
                        var color = 0

                        when (status) {
                            "OK" -> {
                                checkRowData["RESULT"] = "정상"
                                chkResultCell.text = "정상"
                                color = Color.parseColor("#b30000e1")
                                //m_cGrid.SetItemBkColour(iChkRow, 0, RGB(135,206,250));
                                //m_cGrid.SetItemBkColour(iChkRow, 1, RGB(135,206,250));
                                //m_cGrid.SetItemBkColour(iChkRow, 2, RGB(135,206,250));
                            }
                            "D_FAIL" -> {
                                checkRowData["RESULT"] = "변경실패"
                                chkResultCell.text = "변경실패"
                                color = Color.parseColor("#b3ff0000")
                                //m_cGrid.SetItemBkColour(iChkRow, 0, RGB(255,215,0));
                                //m_cGrid.SetItemBkColour(iChkRow, 1, RGB(255,215,0));
                                //m_cGrid.SetItemBkColour(iChkRow, 2, RGB(255,215,0));
                            }
                            "V_FAIL" -> {
                                checkRowData["RESULT"] = "검증실패"
                                chkResultCell.text = "검증실패"
                                color = Color.parseColor("#b3ff0000")
                                //m_cGrid.SetItemBkColour(iChkRow, 0, RGB(255,105,180));
                                //m_cGrid.SetItemBkColour(iChkRow, 1, RGB(255,105,180));
                                //m_cGrid.SetItemBkColour(iChkRow, 2, RGB(255,105,180));
                            }
                        }

                        when (val background = chkResultCell.background) {
                            is ShapeDrawable -> background.paint.color = color
                            is GradientDrawable -> background.setColor(color)
                            is ColorDrawable -> background.color = color
                        }
                    }
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        //}
    }

    private fun setData() {
        mainScope.launch {
            viewBinding.mainbody.removeAllViews()

            val sendMessage =
                MessageFactoryUtil.etchCommRcp(receiveLotId, receiveRecipe, receiveEqpId,receiveOperID,receiveOperDesc)
            val message = MessageSenderAuto.send(
                supportFragmentManager, sendMessage, MessageName.ETCHCOMMRCP
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val downLoad = messageBody.optString("DOWNLOAD")
                val processType = messageBody.optString("PROCESS_TYPE")
                val sampleChk = messageBody.optString("SAMPLE_CHK")
                val ownerCode = messageBody.optString("OWNERCODE")
                val commRcp = ResponseDataToJsonUtil.getMessageBodyList(result, "COMMRCP")

                val s2NDPara = messageBody.optString("PARA2ND")
                val s2NDValue = messageBody.optString("VALUE2ND")
                val s2NDCOMM = messageBody.optString("COMM2ND")

                // 26.06.01 sti 경우 seq를 proc로 변환
                val sSTI_PROC_RCP  = messageBody.optString("STI_PROC_RCP")
                if(sSTI_PROC_RCP.isNotEmpty())
                    receiveRecipe = sSTI_PROC_RCP;

                receiveEQP_TYPE = messageBody.optString("EQP_TYPE")

                if( s2NDCOMM.isEmpty()) {
                    if (s2NDPara.isNotEmpty())
                        viewBinding.txtOwner.text = s2NDPara + " : " + s2NDValue + " 추가 반영"
                    //viewBinding.txtOwner.text = ownerCode
                }
                else
                    viewBinding.txtOwner.text= s2NDCOMM // TE8500의 경우는 몇 초인지

                val layoutTitle = viewBinding.layoutTitle
                val textViewTitle = layoutTitle.findViewById<TextView>(R.id.txt_title)
                textViewTitle.text = "RCP 조건 ( " + ownerCode + " )"

                if (downLoad == "N")
                    viewBinding.btnModify.isEnabled = false

                if (sampleChk.isNotEmpty())
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
                        sampleChk, GetString.BTNOKSTR
                    )

                if (processType == "eMAX CT" || processType == "DPS POLY") {

                    val columnData = linkedMapOf(
                        "CHAMBER" to ColumnProperty("CH", Gravity.CENTER, false, baseWidth / 6),
                        "ETCVALUE" to ColumnProperty("PARA", Gravity.CENTER, false, baseWidth / 6),
                        "BASE_VALUE" to ColumnProperty(
                            "BASE", Gravity.CENTER, false, baseWidth / 6
                        ),
                        "TUNE_VALUE" to ColumnProperty(
                            "변경", Gravity.CENTER, false, baseWidth / 6,
                            Color.parseColor("#b3ffe0de"), Color.BLACK
                        ),
                        "STEP" to ColumnProperty("STEP", Gravity.CENTER, false, baseWidth / 6),
                        "RMS_PARANAME" to ColumnProperty("RMS_NAME", Gravity.CENTER, false, 0),
                        "결과" to ColumnProperty("결과", Gravity.CENTER, false, (if (downLoad == "Y") baseWidth / 6 else 0 ))
                    )

                    val gridList = gridService.setGridPropData(columnData, commRcp)
                    viewBinding.mainbody.addView(gridList)
                } else if (processType == "TE8500") {
                    val columnData = linkedMapOf(
                        "COL" to ColumnProperty(
                            "COL", Gravity.CENTER, false, baseWidth / 3,
                            Color.parseColor("#b3ffe0de"), Color.BLACK
                        ),
                        "VALUE" to ColumnProperty(
                            "VALUE", Gravity.CENTER, false, baseWidth / 3
                        ),
                        "RESULT" to ColumnProperty(
                            "RESULT", Gravity.CENTER, false, baseWidth / 3
                        )
                    )

                    val gridList = gridService.setGridPropData(columnData, commRcp)

                    val valueIndex = gridService.getColumnIndex(gridList, "VALUE")
                    for (row in gridList.mainTable.children) {
                        val fixedRow = row as CTRowLayout
                        val cellItem = fixedRow.getChildAt(valueIndex) as TextView
                        if (cellItem.text.toString() == "-")
                            gridList.mainTable.removeView(row)
                    }
                    viewBinding.mainbody.addView(gridList)

                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
                viewBinding.btnModify.isEnabled = false
            }
        }
    }
}