package com.keyfoundry.hifos.view.remote

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.BarcodeStyle
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityRemoteMeasBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.cmm.WaferSelectActivity
import com.keyfoundry.hifos.view.dialog.RemoteRecipeDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.comment.CommentListActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RemoteMeasActivity : HFActivity() {
    companion object {
        private const val TAG = "RemoteMeasActivity"
    }



    lateinit var viewBinding: ActivityRemoteMeasBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var lsChangeRecipe = false
    private var exposure = false
    private var searchArea = ""
    private var searchOpType = ""
    private var mainEqpId = ""
    private var searchOperation = ""
    private var searchSubOperation = ""
    private var searchProcessStep = ""
    private var searchOperSeq = ""
    private var searchSuperEqpId = ""
    private var searchEqpArea = ""
    private var searchEqpType = ""
    private var searchReworkFlag = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityRemoteMeasBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.txtEngineer.movementMethod = ScrollingMovementMethod.getInstance()

        //소문자 -> 대문자
        viewBinding.editSelectMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editProductMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        setInitDisable()
        setFlagData()

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()
            //---[Modification] Mar 26, 2007. by I. H. Lee (Begin)
            viewBinding.txtLotNo.text = lotId
            getLotInfo(lotId)
            //---[Modification] Mar 26, 2007. by I. H. Lee (End)
            //if(m_sSelEquipID != "")
            //{
            //	GetMachineInfo();
            //}
        }

        viewBinding.spinnerPort.onItemSelectedListener = itemSelectedListener

        viewBinding.editSelectMachine.setOnEditorActionListener(editorActionLister)
        viewBinding.editProductMachine.setOnEditorActionListener(editorActionLister)

        viewBinding.btnClearPort.setOnClickListener(onSingleClickListener)
        viewBinding.btnSelectWafer.setOnClickListener(onSingleClickListener)
        viewBinding.btnReadComment.setOnClickListener(onSingleClickListener)
        viewBinding.btnStart.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
    }

    private val editorActionLister =
        TextView.OnEditorActionListener { v, actionId, event ->
            when (v.id) {
                viewBinding.editSelectMachine.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        val check = BarcodeStyle(this).eqpId(viewBinding.editSelectMachine)

                        if (check) {
                            mainScope.launch {
                                getMachineInfo(viewBinding.editSelectMachine.text.toString())
                            }
                        }
                    } else if (event != null) { // Barcode Event
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            val check = BarcodeStyle(this).eqpId(viewBinding.editSelectMachine)

                            if (check) {
                                mainScope.launch {
                                    getMachineInfo(viewBinding.editSelectMachine.text.toString())
                                }
                            }
                        }
                    }
                }
                viewBinding.editProductMachine.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        BarcodeStyle(this).eqpId(viewBinding.editProductMachine)
                    } else if (event != null) { // Barcode Event
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            BarcodeStyle(this).eqpId(viewBinding.editProductMachine)
                        }
                    }
                }
            }

            true
        }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnClearPort.id -> {
                    initPortState()
                }
                viewBinding.btnSelectWafer.id -> {
                    executeSelectWafer()
                }
                viewBinding.btnReadComment.id -> {
                    executeCommentList()
                }
                viewBinding.btnStart.id -> {
                    executeStart()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerPort.id -> {
                        setPortStatus()
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private fun setInitDisable() {
        viewBinding.btnReadComment.isEnabled = false
        viewBinding.btnClearPort.isEnabled = false
        viewBinding.btnStart.isEnabled = false
    }

    private fun initPortState() {
        mainScope.launch {
            val portName = viewBinding.spinnerPort.selectedItem.toString()
            val sendMessage = MessageFactoryUtil.machinePortClean(searchSuperEqpId, portName)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.SLOTINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager, "DOOR OPEN",
                    "해당 PORT 초기화 명령을 전송하였습니다.", GetString.BTNOKSTR
                )

                setPortStatus()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun executeSelectWafer() {
        mainScope.launch {
            val lotId = viewBinding.txtLotNo.text.toString()
            val sendMessage = MessageFactoryUtil.slotInfo(lotId, DeviceInfo.FACILITY)

            val message = MessageSender.send(
                supportFragmentManager,
                sendMessage,
                MessageName.SLOTINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val enableWaferList = messageBody.optString("WAFERLIST")

                if (enableWaferList.isNotEmpty()) {
                    val nextIntent =
                        Intent(applicationContext, WaferSelectActivity::class.java)
                    nextIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                    nextIntent.putExtra("EXISTWAFERLIST", enableWaferList)
                    nextIntent.putExtra("FIXEDCOUNT", enableWaferList.split(",").count())
                    nextIntent.putExtra("CATEGORY", "ETC")
                    //dlg.m_SelectedMachine = m_sComment;

                    activityWaferSelectLauncher.launch(nextIntent)
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private val activityWaferSelectLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                it.data?.let { intent ->
                    //SetDlgItemText(IDC_EDIT_COMMENT, L"");
                    //m_sComment = L"";
                    val selectedWaferList = intent.getStringExtra("SELECTEDWAFERLIST")

                    if (selectedWaferList != null) {
                        viewBinding.txtWafer.text = selectedWaferList
                        viewBinding.txtWaferCount.text =
                            selectedWaferList.split(",").count().toString()
                    }
                }
            }
        }

    private fun executeCommentList() {
        val nextIntent = Intent(applicationContext, CommentListActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
        nextIntent.putExtra("SUBOPERLIST", "")
        nextIntent.putExtra("OPERATION", searchOperation)
        nextIntent.putExtra("SUBOPERATION", searchSubOperation)
        nextIntent.putExtra("PROCESSSTEP", searchProcessStep)
        nextIntent.putExtra("OPERSEQUENCE", searchOperSeq)

        startActivity(nextIntent)
    }

    private fun setPortStatusColor(portStatus: String) {
        when (portStatus) {
            "RUN" -> {
                viewBinding.txtPortStatus.setBackgroundColor(Color.BLUE)
                viewBinding.txtPortStatus.setTextColor(Color.WHITE)
            }
            "PENDING" -> {
                viewBinding.txtPortStatus.setBackgroundColor(getColor(R.color.portPending))
                viewBinding.txtPortStatus.setTextColor(Color.BLACK)
            }
            "READY" -> {
                viewBinding.txtPortStatus.setBackgroundColor(Color.GREEN)
                viewBinding.txtPortStatus.setTextColor(Color.BLACK)
            }
            "RESERVED" -> {
                viewBinding.txtPortStatus.setBackgroundColor(Color.YELLOW)
                viewBinding.txtPortStatus.setTextColor(Color.BLACK)
            }
            "COMPLETE" -> {
                viewBinding.txtPortStatus.setBackgroundColor(getColor(R.color.portCompleted))
                viewBinding.txtPortStatus.setTextColor(Color.BLACK)
            }
            "IDLE" -> {
                viewBinding.txtPortStatus.setBackgroundColor(getColor(R.color.portIdle))
                viewBinding.txtPortStatus.setTextColor(Color.WHITE)
            }
        }
    }

    private fun setPortStatus() {
        mainScope.launch {
            if (viewBinding.spinnerPort.selectedItem == null)
                return@launch

            viewBinding.btnClearPort.isEnabled = false

            val portName = viewBinding.spinnerPort.selectedItem.toString()
            val sendMessage = MessageFactoryUtil.machinePortStatus(searchSuperEqpId, portName)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MACHINEPORTSTATUS
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val portState = messageBody.optString("PORTSTATENAME")
                val portLotName = messageBody.optString("PORTLOTNAME")
                val ackMsg = messageBody.optString("ACKMSG")

                viewBinding.txtPortStatus.text = portState
                setPortStatusColor(portState)

                if (portState == "RUN" || portState == "PENDING" || portState == "RESERVED") {
                    val portMsg = """
                        |해당 PORT가 진행중입니다.
                        |장비 및 진행할 LOT을 다시 확인 바랍니다.
                    """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, "장비 MASSAGE", portMsg, GetString.BTNOKSTR
                    )

                    viewBinding.btnClearPort.isEnabled = true
                    viewBinding.btnStart.isEnabled = false

                    if (viewBinding.txtLotNo.text.toString() == portLotName)
                        viewBinding.btnClearPort.isEnabled = true

                    if (ackMsg.isNotEmpty()) {
                        OkDialog.show(
                            supportFragmentManager, "PORT WORNING",
                            ackMsg, GetString.BTNOKSTR
                        )
                    }
                } else if (portState.isNullOrEmpty()) {
                    val portMsg = """
                        |PORT 정보를 가져올 수 없습니다.
                        |잠시후 다시 확인 바랍니다.
                    """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, "장비 MASSAGE", portMsg, GetString.BTNOKSTR
                    )

                    viewBinding.btnClearPort.isEnabled = false
                    viewBinding.btnStart.isEnabled = false
                } else {
                    viewBinding.btnClearPort.isEnabled = false
                    viewBinding.btnStart.isEnabled = true
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }

        }
    }

    private fun setFlagData() {
        val itemList = arrayListOf("P", "T", "E")
        val spinnerAdapter =
            ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerFlag.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
    }

    private fun clearLotInfo() {
        lsChangeRecipe = false
        searchArea = ""
        searchOpType = ""
        searchOperation = ""
        searchSubOperation = ""
        searchProcessStep = ""
        searchOperSeq = ""
        searchReworkFlag = ""

        viewBinding.editProductMachine.setText("")

        viewBinding.txtCommentCount.text = ""
        viewBinding.txtRecipe.text = ""
        viewBinding.txtJobCode.text = ""
        viewBinding.txtProduct.text = ""
        viewBinding.txtCurrentOperation.text = ""
        viewBinding.txtQty.text = ""
        viewBinding.txtFacility.text = ""
        viewBinding.txtCustomer.text = ""
        viewBinding.txtSaleType.text = ""
        viewBinding.txtEngineer.text = ""
        viewBinding.txtPacking.text = ""
        viewBinding.txtGoodChips.text = ""
    }

    private fun getLotInfo(lotId: String) {
        mainScope.launch {
            clearLotInfo()

            val sendMessage = MessageFactoryUtil.lotInfo("MVIN", lotId, DeviceInfo.FACILITY)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.LOTINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val product = messageBody.optString("PRODUCT")
                val facility = messageBody.optString("FACILITY")
                val operation = messageBody.optString("OPERATION")
                val customer = messageBody.optString("CUSTOMER")
                val category = messageBody.optString("CATEGORY")
                val engineer = messageBody.optString("ENGINEER")
                val packing = messageBody.optString("PACKING")
                val qty = messageBody.optString("QUANTITY")
                val goodChips = messageBody.optString("GOODCHIPS")
                val recipe = messageBody.optString("RECIPE")
                val changeRecipe = messageBody.optString("CHANGERECIPE")
                val eqpGroup = messageBody.optString("MEASEQPID")
                val changeEqpGroup = messageBody.optString("CHANGEEQPGROUP")
                val commentQty = messageBody.optString("COMMENTQTY")
                val nwCommentQty = messageBody.optString("NWCOMMENTQTY")
                val batchId = messageBody.optString("BATCHID")
                val area = messageBody.optString("AREA")
                val workedEqpId = messageBody.optString("WORKEDEQPID")
                val workedRecipe = messageBody.optString("WORKEDRECIPE")
                val workedReticle = messageBody.optString("WORKEDRETICLE")
                val jobCode = messageBody.optString("JOBCODE")
                val processStep = messageBody.optString("PROCESSSTEP")
                val subOperation = messageBody.optString("SUBOPERATION")
                val opType = messageBody.optString("OPTYPE")
                val status = messageBody.optString("STATUS")
                val state = messageBody.optString("STATE")
                val holdStatus = messageBody.optString("HOLDSTATUS")
                val operSeq = messageBody.optString("OPERSEQUENCE")
                val etcMsg = messageBody.optString("ETCMSG")
                val machineName = messageBody.optString("MACHINENAME")
                val portName = messageBody.optString("PORTNAME")
                val machineRecipeName = messageBody.optString("MACHINERECIPENAME")
                val lotResUser = messageBody.optString("LOTRESUSER")
                val reworkFlag = messageBody.optString("REWORKINFO")
                val oxCmpMachine = messageBody.optString("OXMACHINE")
                val skipAllowFlag =
                    messageBody.optString("SKIPALLOWFLAG")//---[Addition] Nov 22, 2007. by I. H. Lee

                if (status == "RUN") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 MOVE IN된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.isEnabled = false
                    return@launch
                }

                if (state != "WIP") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "$state 상태 입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.isEnabled = false
                    return@launch
                }

                if (holdStatus == "ONHOLD") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "HOLD된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.isEnabled = false
                    return@launch
                }

                if (area == "PHOTO") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "PHOTO 계측진행 LOT입니다. 계측 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.isEnabled = false
                    return@launch
                }

                if (area == "IMP") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "IMP 진행 LOT입니다. IMP 자동화기능을 이용해 주세요.", GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.isEnabled = false
                    return@launch
                }

                viewBinding.txtCommentCount.text = commentQty

                if (changeRecipe.isNotEmpty()) {
                    if (recipe == changeRecipe) {
                        viewBinding.txtRecipe.text = recipe
                        lsChangeRecipe = false
                    } else {
                        viewBinding.txtRecipe.text = changeRecipe
                        lsChangeRecipe = true
                    }
                } else {
                    viewBinding.txtRecipe.text = recipe
                    lsChangeRecipe = false
                }

                viewBinding.editProductMachine.setText(oxCmpMachine)

                searchArea = area
                searchOpType = opType
                searchOperation = operation
                searchSubOperation = subOperation
                searchProcessStep = processStep
                searchOperSeq = operSeq
                searchReworkFlag = reworkFlag

                val currentStep = "$processStep($operation$subOperation)"

                viewBinding.txtJobCode.text = jobCode
                viewBinding.txtProduct.text = product
                viewBinding.txtCurrentOperation.text = currentStep
                viewBinding.txtQty.text = qty
                viewBinding.txtFacility.text = facility
                viewBinding.txtCustomer.text = customer
                viewBinding.txtSaleType.text = category
                viewBinding.txtEngineer.text = engineer
                viewBinding.txtPacking.text = packing
                viewBinding.txtGoodChips.text = goodChips

                if (etcMsg.isNotEmpty())
                    OkDialog.show(supportFragmentManager, "정보", etcMsg, GetString.BTNOKSTR)

                viewBinding.btnReadComment.isEnabled = commentQty.toInt() > 0
                viewBinding.btnStart.isEnabled = true

                if (nwCommentQty.isNotEmpty() && nwCommentQty.toInt() > 0) {
                    val checkMessage = """
                        |읽지 않은 작업성 COMMENT가 [$nwCommentQty]가 있습니다.
                        |읽은후 진행하세요.
                    """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, "정보",
                        checkMessage, GetString.BTNOKSTR
                    )
                }

                if (lotResUser.isNotEmpty()) {
                    viewBinding.editSelectMachine.setText(machineName)
                    viewBinding.editSelectMachine.isEnabled = false
                    viewBinding.spinnerPort.isEnabled = false
                    viewBinding.btnStart.isEnabled = false

                    getMachineInfo(machineName)

                    if (portName.isNotEmpty()) {
                        val portAdapter = viewBinding.spinnerPort.adapter
                        for (count in 0 until portAdapter.count) {
                            if (portAdapter.getItem(count) == portName) {
                                viewBinding.spinnerPort.setSelection(count)
                                break
                            }
                        }
                    }
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearPortInfo() {
        viewBinding.spinnerPort.adapter = null
        viewBinding.txtPortStatus.text = ""
        viewBinding.txtPortStatus.background = null
    }

    private fun clearMachineInfo() {
        mainEqpId = ""
        searchSuperEqpId = ""
        searchEqpArea = ""
        searchEqpType = ""
        viewBinding.txtRecipe.text = ""

        clearPortInfo()
    }

    private suspend fun getMachineInfo(eqpId: String) {
        clearMachineInfo()

        if (searchArea == "PHOTO" && searchOpType == "P" && exposure) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "PHOTO진행 LOT입니다. PHOTO 자동화 기능을 이용해 주세요.", GetString.BTNOKSTR
            )
        }

        var isMachineName = eqpId
        mainEqpId = eqpId

        viewBinding.btnClearPort.isEnabled = false

        if (searchOpType == "M") {
            val lotId = viewBinding.txtLotNo.text.toString()
            val product = viewBinding.txtProduct.text.toString()

            val sendMessage = MessageFactoryUtil.remoteMeaseEqpInfo(
                lotId, searchOperation, searchSubOperation,
                product, isMachineName, searchOpType, DeviceInfo.FACILITY
            )

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.REMOTEMEASEQPINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val mainEQP = messageBody.optString("MAINEQPID")
                val procEQP = messageBody.optString("PROCEQPID")
                val eqpArea = messageBody.optString("EQPAREA")
                val eqpType = messageBody.optString("EQPTYPE")
                //2015.06.01 장비 PM 주기 체크 수정
                val pmMessage = messageBody.optString("PMMESSAGE")
                val portName = messageBody.optString("PORTNAME")
                val recipeName = messageBody.optString("RECIPENAME")

                if (pmMessage.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, "PM주기 경고", pmMessage, GetString.BTNOKSTR
                    )
                }

                mainEqpId = procEQP
                isMachineName = procEQP
                searchSuperEqpId = mainEQP
                searchEqpArea = eqpArea
                searchEqpType = eqpType
                viewBinding.txtRecipe.text = recipeName

                val itemList = portName.split(",")
                val spinnerAdapter = ArrayAdapter(
                    applicationContext, R.layout.contact_spinner_row_init, itemList
                )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerPort.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                val recipeRight = recipeName.substring(recipeName.length - 2)
                val flagAdapter = viewBinding.spinnerFlag.adapter

                if (recipeRight == "BF") {
                    for (count in 0 until flagAdapter.count) {
                        if (flagAdapter.getItem(count) == "P") {
                            viewBinding.spinnerFlag.setSelection(count)
                            break
                        }
                    }
                } else {
                    for (count in 0 until flagAdapter.count) {
                        if (flagAdapter.getItem(count) == "T") {
                            viewBinding.spinnerFlag.setSelection(count)
                            break
                        }
                    }
                }

                viewBinding.editSelectMachine.setText(isMachineName)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                //Add By wj.Kim
                searchSuperEqpId = ""
                searchEqpArea = ""
                searchEqpType = ""

                viewBinding.editSelectMachine.setText("")
                viewBinding.editSelectMachine.requestFocus()
            }
        }

        viewBinding.editSelectMachine.requestFocus()
        viewBinding.editSelectMachine.selectAll()
    }

    private fun executeStart() {
        mainScope.launch {
            if (viewBinding.editSelectMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행장비를 입력하세요.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.spinnerPort.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Port를 선택하세요.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.txtWafer.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 WF를 선택하세요.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.spinnerFlag.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "계측 FLAG를 선택하세요.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.editProductMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "생산 장비명을 입력하세요.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.txtRecipe.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행Rcp를 선택하세요.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (!checkComment())
                return@launch

            val recipeIntent = Intent(this@RemoteMeasActivity, RemoteRecipeDialog::class.java)
            recipeIntent.putExtra(
                RemoteRecipeDialog.RECIPE_LIST, viewBinding.txtRecipe.text.toString()
            )
            startLauncher.launch(recipeIntent)
        }
    }

    private suspend fun checkComment(): Boolean {
        val lotId = viewBinding.txtLotNo.text.toString()

        val sendMessage = MessageFactoryUtil.lotInfo("MVIN", lotId, DeviceInfo.FACILITY)
        val message = MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
        val isSuccessFul = message.isSuccessFul
        val result = message.result
        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val nwCommentQty = messageBody.optString("NWCOMMENTQTY")

            return if (nwCommentQty.isNotEmpty() && nwCommentQty.toInt() > 0) {
                val commentMsg = """
                            |읽지 않은 작업성 COMMENT가 [$nwCommentQty]가 있습니다.
                            |읽은후 진행하세요.
                        """.trimMargin()
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    commentMsg, GetString.BTNOKSTR
                )

                false
            } else {
                true
            }
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )

            return false
        }
    }

    private val startLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                execute()
            }
        }

    private fun execute() {
        mainScope.launch {
            if (searchSuperEqpId.isEmpty())
                searchSuperEqpId = viewBinding.editSelectMachine.text.toString()

            val machineName = searchSuperEqpId
            val machineType = searchEqpType
            val lotName = viewBinding.txtLotNo.text.toString()
            val portName = viewBinding.spinnerPort.selectedItem.toString()
            val recipeName = viewBinding.txtRecipe.text.toString()
            val procQty = viewBinding.txtWaferCount.text.toString()
            val measFlag = viewBinding.spinnerFlag.selectedItem.toString()
            val prodMachine = viewBinding.editProductMachine.text.toString()
            val reworkFlag = searchReworkFlag
            val eventUser = DeviceInfo.OPERATOR_NAME
            val wfList = viewBinding.txtWafer.text.toString()
            val product = viewBinding.txtProduct.text.toString()
            val operation = "$searchOperation-$searchSubOperation"

            val sendMessage = MessageFactoryUtil.measRemoteStart(
                machineName, machineType, lotName, portName, recipeName, procQty,
                measFlag, prodMachine, reworkFlag, eventUser, wfList, product, operation
            )

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MEASREMOTESTART
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                setResult(RESULT_OK)
                finish()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }

        }
    }
}