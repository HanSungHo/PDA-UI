package com.keyfoundry.hifos.config.service


import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.ServerType
import com.keyfoundry.hifos.config.service.update.VersionInfo
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

/*
* PDA 패치 관련 네트워크 설정
* */
interface RetrofitUpdateService {

    @GET("upload/output-metadata.json")
    fun getVersion(): Call<VersionInfo>

    @GET()
    @Streaming
    fun downloadFile(@Url downloadUrl: String): Call<ResponseBody?>?

    companion object { // static 처럼 공유객체로 사용가능함. 모든 인스턴스가 공유하는 객체로서 동작함.
        var BASE_URL = ServerType.UPDATE_SERVER_URL // 주소
        var API : RetrofitUpdateService

        init {
            val gson : Gson =   GsonBuilder().setLenient().create()

            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()

            API = retrofit.create(RetrofitUpdateService::class.java)
        }

        fun reInit(url : String) {
            BASE_URL = url
            val gson :Gson =   GsonBuilder().setLenient().create()

            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()
            API = retrofit.create(RetrofitUpdateService::class.java)
        }

    }

}