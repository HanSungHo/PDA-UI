package com.keyfoundry.hifos.config.domain

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/*
* 안드로이드 내부 DB 환경 설정 정보 Table
* */
@Entity(tableName = "setting_info")
class SettingInfo {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo
    var no: Long? = null

    @ColumnInfo
    var facility: String = ""

    @ColumnInfo
    var area: String = ""

    @ColumnInfo
    var bay: String = ""

    @ColumnInfo
    var historyCount: Int = 0

    @ColumnInfo
    var forwardCount: Int = 0

    @ColumnInfo(name = "date")
    var regTime: Long = 0

    constructor(facility : String, area : String, bay : String, historyCount : Int, forwardCount : Int
                , regTime: Long) {
        this.facility = facility
        this.area = area
        this.bay = bay
        this.historyCount = historyCount
        this.forwardCount = forwardCount
        this.regTime = regTime
    }
}