//package com.keyfoundry.hifos.view.chat
//
//import android.view.View
//import android.widget.TextView
//import androidx.recyclerview.widget.RecyclerView
//
//
//inner class AreaViewHolder(view: View) : RecyclerView.ViewHolder(view) {
//    val name = view.findViewById<TextView>(R.id.areaName)
//    val check = view.findViewById<CheckBox>(R.id.areaCheck)
//}
//
//inner class BayViewHolder(view: View) : RecyclerView.ViewHolder(view) {
//    val name = view.findViewById<TextView>(R.id.bayName)
//    val check = view.findViewById<CheckBox>(R.id.bayCheck)
//}
//
//inner class DeviceViewHolder(view: View) : RecyclerView.ViewHolder(view) {
//    val name = view.findViewById<TextView>(R.id.idText)
//    val check = view.findViewById<CheckBox>(R.id.checkBox)
//}