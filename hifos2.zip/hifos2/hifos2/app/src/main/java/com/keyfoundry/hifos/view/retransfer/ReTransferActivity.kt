package com.keyfoundry.hifos.view.retransfer

import android.os.Bundle
import android.text.InputFilter
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityReTransferBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReTransferActivity : HFActivity() {
    companion object {
        private const val TAG = "ReTransferActivity"
    }

    private lateinit var viewBinding: ActivityReTransferBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var initFabCheck = 0
    private var initBayCheck = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityReTransferBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()
            viewBinding.editLotNo.setText(lotId)

            if (lotId.isNotEmpty())
                getCarryInfo(lotId)
        }

        viewBinding.editLotNo.setOnEditorActionListener(editorActionListener)

        viewBinding.spinnerNextFab.onItemSelectedListener = itemSelectedListener
        viewBinding.spinnerNextBay.onItemSelectedListener = itemSelectedListener

        viewBinding.btnSearchLotNo.setOnClickListener(onSingleClickListener)
        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
    }

    private val editorActionListener = TextView.OnEditorActionListener { v, actionId, event ->
        when (v.id) {
            viewBinding.editLotNo.id -> {
                if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                    val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                    if (check)
                        getCarryInfo(viewBinding.editLotNo.text.toString())
                    else
                        clearInfo()

                    viewBinding.editLotNo.requestFocus()
                    viewBinding.editLotNo.selectAll()
                } else if (event != null) { // Barcode Event
                    if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                        val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                        if (check)
                            getCarryInfo(viewBinding.editLotNo.text.toString())
                        else
                            clearInfo()

                        viewBinding.editLotNo.requestFocus()
                        viewBinding.editLotNo.selectAll()
                    }
                }
            }
        }

        true
    }

    private fun clearInfo() {
        viewBinding.txtCurrentStk.text = ""
        viewBinding.spinnerNextFab.adapter = null
        viewBinding.spinnerNextBay.adapter = null
        viewBinding.spinnerNextStk.adapter = null
        viewBinding.spinnerOutPort.adapter = null
        viewBinding.spinnerNotiPda.adapter = null

        initFabCheck = 0
        initBayCheck = 0
    }

    private fun getCarryInfo(lotId: String) {
        mainScope.launch {
            clearInfo()
            CommonUtil.hideKeyboard(this@ReTransferActivity, currentFocus)

            if (lotId.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT NO를 입력해주세요", GetString.BTNOKSTR
                )

                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
                return@launch
            }

            val sendMessage = MessageFactoryUtil.carryInfo(lotId, DeviceInfo.FACILITY)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.CARRYINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val currentSTK = messageBody.optString("CURRENTSTK")

                val jsonFabs = messageBody.getJSONObject("FABS")
                val jsonFabList = jsonFabs.getJSONArray("ITEM")

                val fabList = arrayListOf<String>()
                for (count in 0 until jsonFabList.length()) {
                    val fab = jsonFabList.getJSONObject(count)
                    fabList.add(fab.optString("FAB"))
                }

                val jsonPorts = messageBody.getJSONObject("PORTS")
                val jsonPortList = jsonPorts.getJSONArray("ITEM")

                var outIndex = 0
                var outBoolean = false
                val portList = arrayListOf<String>()
                for (count in 0 until jsonPortList.length()) {
                    val fab = jsonPortList.getJSONObject(count)
                    val portId = fab.optString("PORT")
                    val portDesc = fab.optString("PORTDESC")

                    if (!outBoolean && portId == "OUT") {
                        outIndex = count
                        outBoolean = true
                    }

                    portList.add("$portId  $portDesc")
                }

                viewBinding.txtCurrentStk.text = currentSTK

                val fabListAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, fabList)
                fabListAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerNextFab.adapter = InitSpinnerAdapter(
                    fabListAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                val portListAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, portList)
                portListAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerOutPort.adapter = InitSpinnerAdapter(
                    portListAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                if (fabList.contains("FAB4"))
                    viewBinding.spinnerNextFab.setSelection(fabList.indexOf("FAB4") + 1, false)

                if (outBoolean) {
                    val position = portList.indexOf(portList[outIndex]) + 1
                    viewBinding.spinnerOutPort.setSelection(position, false)
                }

                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
            }
        }
    }

    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerNextFab.id -> {
                        if (++initFabCheck > 1)
                            setNextBay()
                    }
                    viewBinding.spinnerNextBay.id -> {
                        if (++initBayCheck > 1) {
                            setNextSTK()
                            setPDAList()
                        }
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchLotNo.id -> {
                    getCarryInfo(viewBinding.editLotNo.text.toString())
                }
                viewBinding.btnOk.id -> {
                    executeCarry()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    private fun setNextBay() {
        mainScope.launch {
            viewBinding.spinnerNextBay.adapter = null
            viewBinding.spinnerNextStk.adapter = null
            viewBinding.spinnerNotiPda.adapter = null
            initBayCheck = 0

            if (viewBinding.spinnerNextFab.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "다음 FAB을 선택해주세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage =
                MessageFactoryUtil.fabBayInfo(viewBinding.spinnerNextFab.selectedItem.toString())

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.FABBAYINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val jsonBayList = ResponseDataToJsonUtil.getMessageBodyList(result, "BAYS")

                val bayList = arrayListOf<String>()
                for (count in 0 until jsonBayList.length()) {
                    val bay = jsonBayList.getJSONObject(count)

                    bayList.add(bay.optString("BAY"))
                }

                val bayListAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, bayList)
                bayListAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerNextBay.adapter = InitSpinnerAdapter(
                    bayListAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

            }
        }
    }

    private fun setNextSTK() {
        mainScope.launch {
            viewBinding.spinnerNextStk.adapter = null

            if (viewBinding.spinnerNextFab.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "다음 FAB을 선택해주세요", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.spinnerNextBay.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "다음 BAY를 선택해주세요", GetString.BTNOKSTR
                )
                return@launch
            }

            val bay = viewBinding.spinnerNextBay.selectedItem.toString()
            val fab = viewBinding.spinnerNextFab.selectedItem.toString()
            val sendMessage = MessageFactoryUtil.bayStockerInfo(bay, fab)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.BAYSTOCKERINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val jsonSTKList = ResponseDataToJsonUtil.getMessageBodyList(result, "STOCKERS")

                val stkList = arrayListOf<String>()
                for (count in 0 until jsonSTKList.length()) {
                    val stk = jsonSTKList.getJSONObject(count)

                    stkList.add(stk.optString("STOCKER"))
                }

                val stkListAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, stkList)
                stkListAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerNextStk.adapter = InitSpinnerAdapter(
                    stkListAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setPDAList() {
        mainScope.launch {
            viewBinding.spinnerNotiPda.adapter = null

            if (viewBinding.spinnerNextBay.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "다음 BAY를 선택해주세요", GetString.BTNOKSTR
                )
                return@launch
            }

            val bay = viewBinding.spinnerNextBay.selectedItem.toString()
            val sendMessage = MessageFactoryUtil.pdaList(bay, DeviceInfo.FACILITY)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.PDALIST)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val jsonPDAList = ResponseDataToJsonUtil.getMessageBodyList(result, "PDAS")

                val pdaList = arrayListOf<String>()
                pdaList.add("지정안함")
                for (count in 0 until jsonPDAList.length()) {
                    val pda = jsonPDAList.getJSONObject(count)
                    val pdaCode = pda.optString("PDACODE")
                    val userName = pda.optString("USERNAME")
                    val userId = pda.optString("USERID")

                    pdaList.add("$pdaCode  $userName($userId)")
                }

                val pdaListAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, pdaList)
                pdaListAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerNotiPda.adapter = InitSpinnerAdapter(
                    pdaListAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                viewBinding.spinnerNotiPda.setSelection(1, false)

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun executeCarry() {
        mainScope.launch {
            if (viewBinding.editLotNo.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT NO를 입력하세요.", GetString.BTNOKSTR
                )
                return@launch
            }
            if (viewBinding.txtCurrentStk.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT이 STOCKER내에 없습니다.", GetString.BTNOKSTR
                )
                return@launch
            }
            if (viewBinding.spinnerNextFab.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "반송할 FAB을 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }
            if (viewBinding.spinnerNextBay.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "반송할 BAY를 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }
            if (viewBinding.spinnerNextStk.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "반송할 STOCKER를 선택하세요.", GetString.BTNOKSTR
                )
                return@launch

            }
            if (viewBinding.spinnerOutPort.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "출고할 PORT를 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }
            if (viewBinding.spinnerNotiPda.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "반송여부를 알려줄 PDA를 선택하세요.", GetString.BTNOKSTR
                )
                return@launch

            }

            val lotId = viewBinding.editLotNo.text.toString()
            val nextFab = viewBinding.spinnerNextFab.selectedItem.toString()
            val nextBay = viewBinding.spinnerNextBay.selectedItem.toString()
            val nextStocker = viewBinding.spinnerNextStk.selectedItem.toString()
            val port = viewBinding.spinnerOutPort.selectedItem.toString()
            val pda = viewBinding.spinnerNotiPda.selectedItem.toString()
            var currentSTK = viewBinding.txtCurrentStk.text.toString()

            if (currentSTK == "지정안함")
                currentSTK = ""

            val sendMessage = MessageFactoryUtil.carry(
                lotId, DeviceInfo.FACILITY, nextFab, nextBay, nextStocker, port, pda, currentSTK
            )

            val message = MessageSender.send(supportFragmentManager, sendMessage, MessageName.CARRY)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                getCarryInfo(lotId)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }
}