package com.keyfoundry.hifos.view.remote

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputFilter
import android.view.ContextMenu
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.BarcodeStyle
import com.keyfoundry.hifos.config.utils.GridService
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityRemoteAegisBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.cmm.wafer.WaferselectAEGIS_Activity
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.comment.CommentListActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class RemoteAegisActivity : HFActivity() {
    companion object {
        private const val TAG = "RemoteAegisActivity"
    }

    lateinit var viewBinding: ActivityRemoteAegisBinding
    private lateinit var gridService: GridService

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var mainEqpId = "";
    private var mainModel = "";
    private lateinit var slotlist: CTMainLayout
    private lateinit var SlotlistJSON: JSONArray
    private var selectSlot = ""

    private var startEqp = ""
    private var startEqpType = "AEGIS"
    private var startPort = ""
    private var startSlot = ""
    private var startRecipe = ""
    private var startProdeqp = ""
    private var startMid = ""
    private var startLot = ""
    private var startPara = ""
    private var startThick = ""
    private var startTable = ""
    private var startFolder = ""


    private var wfOwnercode = ""
    private var wfProduct = ""
    private var wfOpercode = ""

    private var searchOperation = ""
    private var searchSubOperation = ""
    private var searchProcessStep = ""
    private var searchOperSequence = ""

    private var CopyRowData = JSONObject()

    private val noticeItems = mutableListOf<String>()
    private lateinit var noticeAdapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityRemoteAegisBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        gridService = GridService(applicationContext)

        viewBinding.titleLayout.findViewById<TextView>(R.id.txt_title).text = "AEGIS Remote Start (${DeviceInfo.OPERATOR_NAME})"
        viewBinding.btnStart.isEnabled = false;
        //소문자 -> 대문자
        viewBinding.txtMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.txtMachine.setOnEditorActionListener(editorActionListener)



        viewBinding.txtLOTID.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.txtLOTID.setOnEditorActionListener(editorActionListener)


        viewBinding.spinnerPort.onItemSelectedListener = itemSelectedListener


        viewBinding.btnClearPort.setOnClickListener(onSingleClickListener)
        viewBinding.btnStart.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
        viewBinding.btnSearchIngMachine.setOnClickListener(onSingleClickListener)
        viewBinding.btnSearchIngLOTID.setOnClickListener(onSingleClickListener)
        viewBinding.btnSelectWafer.setOnClickListener(onSingleClickListener)
        viewBinding.btnModeRemote.setOnClickListener(onSingleClickListener)
        viewBinding.btnModeLocal.setOnClickListener(onSingleClickListener)
        viewBinding.btnMoveOut.setOnClickListener(onSingleClickListener)

        noticeAdapter = ArrayAdapter(applicationContext, R.layout.item_lot_notice, noticeItems)
        viewBinding.lvLotNotice.adapter = noticeAdapter


        if(intent.getStringExtra("Eqpid").toString() != "NULL")
            mainEqpId = intent.getStringExtra("Eqpid").toString()

        viewBinding.txtMachine.setText(mainEqpId)

        setEqpInfo()
    }

    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        val inflater = menuInflater
        inflater.inflate(R.menu.xrf_remote_context, menu)
        //super.onCreateContextMenu(menu, v, menuInfo)
    }

    private val editorActionListener =
        TextView.OnEditorActionListener { v, actionId, event ->
            when (v.id) {
                viewBinding.txtMachine.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        val check = BarcodeStyle(this).eqpId(viewBinding.txtMachine)

                        if (check)
                            setEqpInfo()
                    } else if (event != null) {
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            val check = BarcodeStyle(this).eqpId(viewBinding.txtMachine)

                            if (check)
                                setEqpInfo()
                        }
                    }
                }

                viewBinding.txtLOTID.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        val check = BarcodeStyle(this).lotId(viewBinding.txtLOTID)
                        if (check)
                            setLotInfo()
                    } else if (event != null) {
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            val check = BarcodeStyle(this).lotId(viewBinding.txtLOTID)
                            if (check)
                                setLotInfo()
                        }
                    }
                }
            }

            true
        }

    private fun setEqpInfo() {
        mainScope.launch {
            clearEqpInfo()

            if (viewBinding.txtMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "장비명을 입력하여 주세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage =
                MessageFactoryUtil.remoteEqpInfo(viewBinding.txtMachine.text.toString())

            val message =
                MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.REMOTEEQPINFO
                )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val pCount = messageBody.optString("PCOUNT")
                val portname = messageBody.optString("PORTNAME")
                val pmMessage = messageBody.optString("PMMESSAGE")
                mainEqpId = messageBody.optString("MAINEQPID")

                if (pmMessage.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, "PM주기 경고", pmMessage, GetString.BTNOKSTR
                    )
                }
                if (pCount == "N") {
                    OkDialog.show(
                        supportFragmentManager, GetString.ERRMSG,
                        "진행중인 LOT이 있어 진행이 불가합니다.", GetString.BTNOKSTR
                    )
                    return@launch
                }

                val portList = portname.split(",")
                val spinnerAdapter =
                    ArrayAdapter(
                        applicationContext,
                        R.layout.contact_spinner_row_init,
                        portList
                    )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerPort.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
                viewBinding.spinnerPort.setSelection(1)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun executeSelectWafer() {
        mainScope.launch {
            val lotId = viewBinding.txtLOTID.text.toString()
            val sendMessage = MessageFactoryUtil.slotInfo(lotId, DeviceInfo.FACILITY)

            val message = MessageSender.send(
                supportFragmentManager,
                sendMessage,
                MessageName.SLOTINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val enableWaferList = messageBody.optString("WAFERLIST")

                if (enableWaferList.isNotEmpty()) {
                    var nextIntent =
                        Intent(applicationContext, WaferselectAEGIS_Activity::class.java)
                    val cnt = enableWaferList.split(",").count().toString()

                    nextIntent.putExtra("LOTID", viewBinding.txtLOTID.text.toString())
                    nextIntent.putExtra("EXISTWAFERLIST", enableWaferList)
                    nextIntent.putExtra("FIXEDCOUNT", cnt)
                    nextIntent.putExtra("CATEGORY", "ETC")
                    nextIntent.putExtra("FACTORY", "FABCJ4")
                    nextIntent.putExtra("PRODUCT", wfProduct)
                    nextIntent.putExtra("OWNERCODE", wfOwnercode)
                    nextIntent.putExtra("OPERCODE", wfOpercode)
                    //dlg.m_SelectedMachine = m_sComment;

                    activityWaferSelectLauncher.launch(nextIntent)
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }



    private val activityWaferSelectLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                it.data?.let { intent ->
                    var selectedWaferList = intent.getStringExtra("SELECTEDWAFERLIST")

                    if (selectedWaferList != null) {
                        viewBinding.txtWafer.setText(selectedWaferList)
                        viewBinding.txtWaferCount.setText(
                            selectedWaferList.split(",").count().toString())
                    }
                }
            }
        }



    private fun setLotInfo() {
        mainScope.launch {

            // 기존 안내 목록 초기화 (새 LOT 조회마다 리셋)
            noticeItems.clear()
            noticeAdapter.notifyDataSetChanged()

            if (viewBinding.txtMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOTID를 입력하여 주세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage =
                MessageFactoryUtil.AEGISLotInfo(viewBinding.txtLOTID.text.toString(),viewBinding.txtMachine.text.toString())

            val message =
                MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.AEGISLOTINFO
                )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                try {
                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                    val ItemList =
                        ResponseDataToJsonUtil.getMessageBodyList(result, "ITEMS")
                    val tempLotHoldState = ItemList.getJSONObject(0).optString("LOTHOLDSTATE")
                    val tempProcessState = ItemList.getJSONObject(0).optString("LOTPROCESSSTATE")

                    //한영미직장님 요청 : RUN / HOLD 시에도 리모트 진행하도록
                    if (tempProcessState == "RUN") {
                        val runMessage = """
                        현재 RUN 중인 LOT 입니다. REMOTE를 진행하겠습니까?
                    """.trimIndent()

//                        OkDialog.show(
//                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
//                            runMessage, GetString.BTNOKSTR
//                        )

                        val checkCode = OkCancelDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                            runMessage,
                            GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
                        )

                        if (checkCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                            viewBinding.txtLOTID.setText("")
                            viewBinding.txtLOTID.requestFocus()
                            viewBinding.txtLOTID.selectAll()
                            viewBinding.editRecipe.setText("")
                            viewBinding.editProductMachine.setText("")
                            return@launch
                        }
                    }

                    if (tempLotHoldState == "OnHold") {
                        val holdMessage = """
                        현재 HOLD 중인 LOT입니다. REMOTE를 진행하겠습니까?
                    """.trimIndent()

//                        OkDialog.show(
//                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
//                            runMessage, GetString.BTNOKSTR
//                        )

                        val checkCode = OkCancelDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                            holdMessage,
                            GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
                        )

                        if (checkCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                            viewBinding.txtLOTID.setText("")
                            viewBinding.txtLOTID.requestFocus()
                            viewBinding.txtLOTID.selectAll()
                            viewBinding.editRecipe.setText("")
                            viewBinding.editProductMachine.setText("")
                            return@launch
                        }
                    }


                    val tempJobCode = ItemList.getJSONObject(0).optString("JOBCODE")
                    val tempQuantity = ItemList.getJSONObject(0).optString("PRODUCTQUANTITY")
                    val tempOperDesc = ItemList.getJSONObject(0).optString("OPERDESC")
                    val tempOperCode = ItemList.getJSONObject(0).optString("OPERCODE")
                    val tempProduct = ItemList.getJSONObject(0).optString("PRODUCTSPECNAME")
                    val temprcp = ItemList.getJSONObject(0).optString("RECIPE")
                    val tempeqp = ItemList.getJSONObject(0).optString("MACHINENAME")
                    val tempfab = ItemList.getJSONObject(0).optString("FAB")
                    val tempeng = ItemList.getJSONObject(0).optString("ENGINEERNAME")
                    val tempOwnercode = ItemList.getJSONObject(0).optString("OWNERCODE")

                    val codeParts = tempOperCode.split("-")
                    searchOperation = codeParts.getOrNull(0).orEmpty()
                    searchSubOperation = codeParts.getOrNull(1).orEmpty()
                    searchProcessStep = tempOperDesc
                    searchOperSequence = ""

                    // Safe Launch / Inline Sampling 안내 목록 채우기 (공정 종류 무관)
                    val safeLaunch = ItemList.getJSONObject(0).optString("SAFELAUNCHLOT")
                    val inlineSampleMsg = ItemList.getJSONObject(0).optString("INLINESAMPLEMESSGE")
                    if (safeLaunch == "Y")
                        noticeItems.add("Automotive Safe Launch 대상 Lot!")
                    if (inlineSampleMsg.isNotEmpty())
                        noticeItems.add(inlineSampleMsg)
                    noticeAdapter.notifyDataSetChanged()



                    //TEST CODE
//                    viewBinding.btnStart.isEnabled = true
//                    viewBinding.editProductMachine.setText(tempeqp)
//                    viewBinding.editRecipe.setText(temprcp)
//
//                    wfOwnercode = tempOwnercode
//                    wfProduct = tempProduct
//                    wfOpercode = tempOperCode


// REAL CODE
                    if (tempOperDesc.contains("PARTICLE") || tempOperDesc.contains("PQC") ) {
                        viewBinding.editProductMachine.setText(tempeqp)
                        viewBinding.editRecipe.setText(temprcp)

                        wfOwnercode = tempOwnercode
                        wfProduct = tempProduct
                        wfOpercode = tempOperCode

                        viewBinding.btnStart.isEnabled = true
                    }
                    else{
                        val operMessage = """
                        LOT이 PARTICLE/PQC 공정이 아닙니다.
                    """.trimIndent()

                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            operMessage, GetString.BTNOKSTR
                        )

                        return@launch
                    }

                    // 미확인 EEN 체크 (ACTIONPOINT=MOVEIN 인 것만 대상)
                    val commentListMessage = MessageFactoryUtil.commentList(
                        viewBinding.txtLOTID.text.toString(), DeviceInfo.FACILITY,
                        searchOperation, searchSubOperation, searchOperSequence
                    )
                    val commentListResult = MessageSender.send(
                        supportFragmentManager, commentListMessage, MessageName.COMMENTLIST
                    )
                    if (commentListResult.isSuccessFul) {
                        val items = ResponseDataToJsonUtil.getMessageBodyList(
                            commentListResult.result, "COMMENTITEMS"
                        )
                        var uncheckedCount = 0
                        for (i in 0 until items.length()) {
                            val item = items.getJSONObject(i)
                            if (item.optString("ISCHECK") == "N"
                                && item.optString("TRACKTYPE") == "MOVEIN")
                                uncheckedCount++
                        }
                        if (uncheckedCount > 0) {
                            val returnCode = OkCancelDialog.show(
                                supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                                "미확인 MOVE IN EEN이 ${uncheckedCount}건 있습니다.\nEEN 확인 후 진행해주세요.",
                                GetString.BTNYESSTR, GetString.BTNNOSTR
                            )
                            if (returnCode == OkCancelDialog.RETURN_CODE_OK) {
                                val nextIntent = Intent(this@RemoteAegisActivity, CommentListActivity::class.java)
                                nextIntent.putExtra("LOTID", viewBinding.txtLOTID.text.toString())
                                nextIntent.putExtra("OPERATION", searchOperation)
                                nextIntent.putExtra("SUBOPERATION", searchSubOperation)
                                nextIntent.putExtra("PROCESSSTEP", searchProcessStep)
                                nextIntent.putExtra("OPERSEQUENCE", searchOperSequence)
                                startActivity(nextIntent)
                            }
                            return@launch
                        }
                    }
                }
                finally {
                    return@launch
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearEqpInfo() {
        viewBinding.spinnerPort.adapter = null
        mainEqpId = ""
        mainModel = ""
    }

    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerPort.id -> {
                        setPortState()
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {

                viewBinding.btnSearchIngMachine.id -> {
                    setEqpInfo()
                }
                viewBinding.btnSearchIngLOTID.id -> {
                    setLotInfo()
                }
                viewBinding.btnSelectWafer.id -> {
                    executeSelectWafer()
                }
                viewBinding.btnClearPort.id -> {
                    executeClearPort()
                }
                viewBinding.btnStart.id -> {
                    executeStart()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
                viewBinding.btnModeLocal.id -> {
                    modeChangeLocal()
                }
                viewBinding.btnMoveOut.id -> {
                    executeMoveOut()
                }
                viewBinding.btnModeRemote.id -> {
                    modeChangeRemote()
                }
            }
        }
    }

    private fun modeChangeLocal() {
        mainScope.launch {
            val checkCode = OkCancelDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                "장비를 LOCAL 모드로 바꾸시겠습니까?",
                GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
            )

            if (checkCode == OkCancelDialog.RETURN_CODE_CANCEL)
                return@launch

            val sendMessage = MessageFactoryUtil.AegisModeChange(viewBinding.txtMachine.text.toString(), "LOCAL", DeviceInfo.OPERATOR_ID, DeviceInfo.OPERATOR_NAME)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.AEGISMODECHANGE
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager, "모드 전환",
                    "모드 전환 명령을 전송하였습니다.", GetString.BTNOKSTR
                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }


    private fun modeChangeRemote() {
        mainScope.launch {
            val checkCode = OkCancelDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                "장비를 REMOTE 모드로 바꾸시겠습니까?",
                GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
            )

            if (checkCode == OkCancelDialog.RETURN_CODE_CANCEL)
                return@launch

            val sendMessage = MessageFactoryUtil.AegisModeChange(viewBinding.txtMachine.text.toString(), "REMOTE", DeviceInfo.OPERATOR_ID, DeviceInfo.OPERATOR_NAME)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.AEGISMODECHANGE
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager, "모드 전환",
                    "모드 전환 명령을 전송하였습니다.", GetString.BTNOKSTR
                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun executeMoveOut() {
        //eSheet 화면으로 넘김
        val intent = Intent(this, com.keyfoundry.hifos.view.esheet.ESheetActivity::class.java)
        startActivity(intent)
    }

    // PORT EVENT ST
    private fun executeClearPort() {
        mainScope.launch {
            if (viewBinding.spinnerPort.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Port를 먼저 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val portName = viewBinding.spinnerPort.selectedItem.toString()

            val checkCode = OkCancelDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                "PORT [$portName]을(를) 초기화 하고 [IDLE]상태로 바꾸시겠습니까?",
                GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
            )

            if (checkCode == OkCancelDialog.RETURN_CODE_CANCEL)
                return@launch

            val sendMessage = MessageFactoryUtil.machinePortClean(mainEqpId, portName)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MACHINEPORTCLEAR
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager, "PORT 초기화",
                    "해당 PORT 초기화 명령을 전송하였습니다.", GetString.BTNOKSTR
                )

                setPortState()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearPortState() {
        viewBinding.txtPortState.text = ""
        viewBinding.txtPortState.background = null
    }

    private fun setPortColor(portState: String) {
        when (portState) {
            "INIT" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.RED)
                viewBinding.txtPortState.setTextColor(Color.WHITE)
            }
            "RUN" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.BLUE)
                viewBinding.txtPortState.setTextColor(Color.WHITE)
            }
            "PENDING" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portPending))
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "READY" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.GREEN)
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "RESERVED" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.YELLOW)
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "COMPLETE" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portCompleted))
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "IDLE" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portIdle))
                viewBinding.txtPortState.setTextColor(Color.WHITE)
            }
        }
    }

    private fun setPortState() {
        mainScope.launch {
            clearPortState()

            if (viewBinding.spinnerPort.selectedItem == null)
                return@launch

            viewBinding.btnClearPort.isEnabled = false

            val portId = viewBinding.spinnerPort.selectedItem.toString()

            val sendMessage =
                MessageFactoryUtil.machinePortStatus(viewBinding.txtMachine.text.toString(), portId)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MACHINEPORTSTATUS
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val portState = messageBody.optString("PORTSTATENAME")
                val ackMsg = messageBody.optString("ACKMSG")

                viewBinding.txtPortState.text = portState

                setPortColor(portState)

                if (portState == "RUN" || portState == "PENDING" || portState == "RESERVED") {
                    val portMsg = """
                    |해당 PORT가 진행중입니다.
                    |장비 및 진행할 LOT을 다시 확인 바랍니다.
                    |""".trimMargin()
                    OkDialog.show(
                        supportFragmentManager,
                        "장비 MASSAGE",
                        portMsg,
                        GetString.BTNOKSTR
                    )
                    viewBinding.btnClearPort.isEnabled = true
                    viewBinding.btnStart.isEnabled = false

                    if (ackMsg.isNotEmpty()) {
                        OkDialog.show(
                            supportFragmentManager, "PORT WORNING", ackMsg, GetString.BTNOKSTR
                        )
                    }
                } else if (portState.isEmpty()) {
                    val portMsg = """
                    |PORT 정보를 가져올 수 없습니다.
                    |잠시후 다시 확인 바랍니다.
                    |""".trimMargin()
                    OkDialog.show(
                        supportFragmentManager,
                        "장비 MASSAGE",
                        portMsg,
                        GetString.BTNOKSTR
                    )
                    viewBinding.btnStart.isEnabled = false
                    viewBinding.btnClearPort.isEnabled = false
                } else if (portState == "READY") {
                    viewBinding.btnStart.isEnabled = true
                    viewBinding.btnClearPort.isEnabled = true

                    //getLotinfo()
                } else
                    viewBinding.btnStart.isEnabled = false
                viewBinding.btnClearPort.isEnabled = true
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }
    // PORT EVENT END
    /* *
    * Start Event 처리
    * */

    fun concat(s1: String, s2: String): String {
        if(s1 != "")
            return "$s1$$s2"
        else
            return "$s2"
    }

    private fun executeStart()    {
        mainScope.launch {

            startSlot = ""
            startProdeqp = ""
            startMid = ""
            startRecipe = ""
            startLot= ""
            startPara= ""
            startThick = ""
            startTable = ""

            startEqp = viewBinding.txtMachine.text.toString()
            startPort = viewBinding.spinnerPort.selectedItem.toString()
            startRecipe = viewBinding.editRecipe.text.toString()
            startLot = viewBinding.txtLOTID.text.toString()
            startMid = viewBinding.editProductMachine.text.toString()
            startSlot = viewBinding.txtWafer.text.toString()

            // 미확인 EEN 재확인 (ACTIONPOINT=MOVEIN 인 것만 대상, EEN 화면에서 처리하지 않고 돌아온 경우 방어)
            val commentListMessage = MessageFactoryUtil.commentList(
                startLot, DeviceInfo.FACILITY,
                searchOperation, searchSubOperation, searchOperSequence
            )
            val commentListResult = MessageSender.send(
                supportFragmentManager, commentListMessage, MessageName.COMMENTLIST
            )
            if (commentListResult.isSuccessFul) {
                val items = ResponseDataToJsonUtil.getMessageBodyList(
                    commentListResult.result, "COMMENTITEMS"
                )
                var uncheckedCount = 0
                for (i in 0 until items.length()) {
                    val item = items.getJSONObject(i)
                    if (item.optString("ISCHECK") == "N"
                        && item.optString("TRACKTYPE") == "MOVEIN")
                        uncheckedCount++
                }
                if (uncheckedCount > 0) {
                    val returnCode = OkCancelDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                        "미확인 MOVE IN EEN이 ${uncheckedCount}건 있습니다.\nEEN 확인 후 진행해주세요.",
                        GetString.BTNYESSTR, GetString.BTNNOSTR
                    )
                    if (returnCode == OkCancelDialog.RETURN_CODE_OK) {
                        val nextIntent = Intent(this@RemoteAegisActivity, CommentListActivity::class.java)
                        nextIntent.putExtra("LOTID", startLot)
                        nextIntent.putExtra("OPERATION", searchOperation)
                        nextIntent.putExtra("SUBOPERATION", searchSubOperation)
                        nextIntent.putExtra("PROCESSSTEP", searchProcessStep)
                        nextIntent.putExtra("OPERSEQUENCE", searchOperSequence)
                        startActivity(nextIntent)
                    }
                    return@launch
                }
            }

            val sendMessage =
                MessageFactoryUtil.AEGISRemoteStart(
                    startEqp,
                    startRecipe,
                    startLot,
                    startPort,
                    startMid,
                    startSlot,
                    DeviceInfo.OPERATOR_ID,
                    DeviceInfo.OPERATOR_NAME
                )
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.AEGISREMOTESTART
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul){
                OkDialog.show(
                    supportFragmentManager, "전송 성공",
                    "성공적으로 START 명령을 전송하였습니다.", GetString.BTNOKSTR
                )
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portPending))
                viewBinding.txtPortState.setText("PENDING")
                viewBinding.txtPortState.setTextColor(Color.BLACK)
                viewBinding.txtLOTID.setText("")
            }
            else{
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }


        }

    }
}