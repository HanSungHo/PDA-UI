package com.keyfoundry.hifos.view.cmm.wafer

class WaferInfo(val waferName: String, val waferId: String) {
    var machine = ""
}