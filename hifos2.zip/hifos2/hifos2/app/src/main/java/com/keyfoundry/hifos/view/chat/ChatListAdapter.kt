package com.keyfoundry.hifos.view.chat

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.keyfoundry.hifos.R

class ChatListAdapter(
    private val rooms: List<ChatRoom>,
    private val onClick: (ChatRoom) -> Unit
) : RecyclerView.Adapter<ChatListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chat_room, parent, false)

        return ViewHolder(view)
    }

    override fun getItemCount() = rooms.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val room = rooms[position]

        holder.lastMessage.text = room.lastMessage

        holder.roomName.text = room.roomName
        holder.time.text = room.time

        if (room.unReadCount != "0") {
            holder.unreadCount.text = room.unReadCount
            holder.unreadCount.visibility = View.VISIBLE
        } else {
            holder.unreadCount.visibility = View.GONE
        }

        holder.itemView.setOnClickListener {
            onClick(room)
        }
    }

    class ViewHolder(v: View) : RecyclerView.ViewHolder(v) {

        val lastMessage: TextView = v.findViewById(R.id.lastMessage)
        val roomName: TextView = v.findViewById(R.id.roomName)
       // val roomId: TextView = v.findViewById(R.id.roomId)
        val time: TextView = v.findViewById(R.id.time)

        val unreadCount: TextView = v.findViewById(R.id.unreadCount)

    }
}