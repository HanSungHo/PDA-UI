package com.keyfoundry.hifos.view.udpsend

import android.os.Bundle
import android.os.StrictMode
import android.view.*
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.core.view.GestureDetectorCompat
import androidx.core.view.children
import androidx.core.view.isGone
import androidx.core.view.size
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.*
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.CommonUtil
import com.keyfoundry.hifos.config.utils.GridService
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityUdpsendBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.*
import kotlin.collections.ArrayList


class UDPSendActivity : HFActivity() {
    private lateinit var viewBinding: ActivityUdpsendBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var gridService: GridService

    lateinit var selectedRow: CTRowLayout

    private var selectAll = false
    private var selectedRowList = arrayListOf<Int>()

    private var baseWidth = 0

    inner class RowGestureListener : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(event: MotionEvent): Boolean {
            selectedRow.isSelected = !selectedRow.isSelected

            val rowIndex = ((selectedRow.parent) as CTSubLayout).indexOfChild(selectedRow)

            if (selectedRow.isSelected)
                selectedRowList.add(rowIndex)
            else
                selectedRowList.remove(rowIndex)

            countPda(selectedRowList.count())

            return true
        }
    }

    inner class SortGestureListener(
        private val gridList: CTMainLayout,
        private val columnName: String?
    ) :
        GestureDetector.SimpleOnGestureListener() {
        private var asc = true

        override fun onDoubleTap(e: MotionEvent?): Boolean {
            val sortList = mutableListOf<Pair<String, CTRowLayout>>()

            for (row in gridList.mainTable.children) {
                val mainRow = row as CTRowLayout

                var cellValue = mainRow.cellValue(columnName)
                if (!columnName.isNullOrEmpty()) {
                    if (columnName == "IPADDRESS") {
                        val lastIdx = cellValue.lastIndexOf(".")
                        var lastValue = cellValue.substring(lastIdx + 1, cellValue.length)
                        if (lastValue.length < 3) {
                            for (i in 0..2 - lastValue.length) {
                                lastValue = "0$lastValue"
                            }
                        }

                        cellValue = "${cellValue.substring(0, lastIdx + 1)}$lastValue"
                    }
                }
                sortList.add(cellValue.replace(".", "") to mainRow)
            }

            gridList.mainTable.removeAllViews()
            selectedRowList.clear()

            val sortedList = if (asc)
                sortList.sortedWith(compareBy { it.first })
            else
                sortList.sortedByDescending { it.first }

            for (row in sortedList) {
                gridList.mainTable.addView(row.second)

                if (row.second.isSelected)
                    selectedRowList.add(sortedList.indexOf(row))
            }

            asc = !asc

            countPda(selectedRowList.count())

            return super.onDoubleTap(e)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityUdpsendBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        val base = viewBinding.baseLayout

        gridService = GridService(applicationContext)
        val vto: ViewTreeObserver = base.viewTreeObserver
        vto.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                base.viewTreeObserver.removeOnGlobalLayoutListener(this)
                baseWidth = base.width / 5
            }
        })

        viewBinding.spinnerArea.onItemSelectedListener = selectListener
        viewBinding.spinnerBay.onItemSelectedListener = selectListener

        viewBinding.btnAllSelect.setOnClickListener(onClickListener)
        viewBinding.btnSend.setOnClickListener(onClickListener)
        viewBinding.btnCancel.setOnClickListener(onClickListener)

        initAreaSpinner()
        countPda(selectedRowList.count())
    }

    private val onClickListener = View.OnClickListener {
        when (it.id) {
            viewBinding.btnAllSelect.id -> selectAllRow()
            viewBinding.btnSend.id -> sendUDP()
            viewBinding.btnCancel.id -> finish()
        }
    }

    private val selectListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerArea.id -> initBaySpinner()
                    viewBinding.spinnerBay.id -> getPdaList()
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private fun clearData() {
        viewBinding.baseLayout.removeAllViews()
        selectedRowList.clear()
        selectAll = false
        countPda(selectedRowList.count())
    }

    private fun getPdaList() {
        mainScope.launch {
            clearData()

            var area = ""
            if (viewBinding.spinnerArea.selectedItem != null && viewBinding.spinnerArea.selectedItem.toString() != "ALL")
                area = viewBinding.spinnerArea.selectedItem.toString()

            var bay = ""
            if (viewBinding.spinnerBay.selectedItem != null && viewBinding.spinnerBay.selectedItem.toString() != "ALL")
                bay = viewBinding.spinnerBay.selectedItem.toString()

            val sendMessage = MessageFactoryUtil.newPdaList(DeviceInfo.FACILITY, area, bay, "")

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.NEWPDALIST)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val pdaList = ResponseDataToJsonUtil.getMessageBodyList(result, "PDAS")

                val columnData = linkedMapOf(
                    "PDAID" to ColumnProperty("PDA", Gravity.CENTER, false, baseWidth),
                    "IPADDRESS" to ColumnProperty("ADDRESS", Gravity.CENTER, false, baseWidth * 2),
                    "AREA" to ColumnProperty("AREA", Gravity.CENTER, false, baseWidth),
                    "BAY" to ColumnProperty("BAY", Gravity.CENTER, false, baseWidth),
                    "USERNAME" to ColumnProperty("USER", Gravity.CENTER, false)
                )

                val gridList = gridService.setGridPropData(columnData, pdaList)
                setSortAction(gridList)

                viewBinding.baseLayout.addView(gridList)

                selectPDAList(gridList)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setSortAction(gridList: CTMainLayout) {
        val columnRow = (gridList.columnHeaderTable).getChildAt(0) as CTRowLayout
        val columnValueList = (columnRow.tag) as MutableList<*>

        for (cell in columnRow.children) {
            val columnCell = cell as TextView
            val columnValue = columnValueList[columnRow.indexOfChild(columnCell)] as String

            val mDetector = GestureDetectorCompat(this, SortGestureListener(gridList, columnValue))

            columnCell.setOnTouchListener { v, event ->
                mDetector.onTouchEvent(event)

                true
            }
        }
    }

    private fun selectPDAList(gridData: CTMainLayout) {
        val mainTable = gridData.mainTable

        for (row in 0 until mainTable.size) {
            val tableRow = mainTable.getChildAt(row) as CTRowLayout
            tableRow.setBackgroundResource(R.drawable.selected_grid_row)

            val mDetector = GestureDetectorCompat(this, RowGestureListener())

            tableRow.setOnTouchListener { v, event ->
                selectedRow = v as CTRowLayout

                return@setOnTouchListener (mDetector.onTouchEvent(event))
            }
        }
    }

    private fun sendUDP() {
        CommonUtil.hideKeyboard(this, currentFocus)

        if (viewBinding.baseLayout.childCount < 1)
            return

        if (selectedRowList.count() < 1) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "선택된 PDA가 없습니다.", GetString.BTNOKSTR
            )
            return
        }

        var level = GetString.MESSAGE_LOW_LEVEL
        if (viewBinding.chkPush.isChecked)
            level = GetString.MESSAGE_HIGH_LEVEL

        for (i in 0 until selectedRowList.count()) {
            val gridList = viewBinding.baseLayout.getChildAt(0) as CTMainLayout
            val rowData = gridList.mainTable.getChildAt(selectedRowList[i]) as CTRowLayout
            val remoteHost = gridService.getCellValue(rowData, "IPADDRESS")

            //      var RemoteHost: String = "192.168.132.241"
            val remotePort = 9999
            val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
            StrictMode.setThreadPolicy(policy)

            val socket = DatagramSocket()
            //      socket.broadcast = true

            val data = setData(level, viewBinding.editSendMessage.text.toString())
            val sendData = data.toByteArray()
            val sendPacket = DatagramPacket(
                sendData, sendData.size, InetAddress.getByName(remoteHost), remotePort
            )
            socket.send(sendPacket)
        }

        OkDialog.show(
            supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
            "메시지를 전송 하였습니다.", GetString.BTNOKSTR
        )
    }

    private fun setData(level: String, message: String): String {
        return """
            {
                "${GetString.UDP_LEVEL}": "$level",
                "${GetString.UDP_MESSAGE}": "$message"
            }
        """.trimIndent()
    }

    private fun selectAllRow() {
        if (viewBinding.baseLayout.childCount < 1)
            return

        val gridList = viewBinding.baseLayout.getChildAt(0) as CTMainLayout

        selectAll = !selectAll

        for (i in 0 until gridList.mainTable.childCount) {
            val rowData = gridList.mainTable.getChildAt(i) as CTRowLayout

            if (!rowData.isGone) {
                if (selectAll) {
                    rowData.isSelected = true
                    selectAll = true
                    selectedRowList.add(i)
                } else {
                    rowData.isSelected = false
                    selectAll = false
                    selectedRowList.remove(i)
                }
            }
        }

        if (selectedRowList.isNotEmpty())
            selectedRowList = selectedRowList.distinct().toCollection(ArrayList())

        countPda(selectedRowList.count())
    }

    private fun initAreaSpinner() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.area(DeviceInfo.FACILITY)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.CONFINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val areaListJSON =
                    ResponseDataToJsonUtil.getMessageBodyList(result, GetString.ITEMS)

                val spinnerAreaItems = arrayListOf("ALL")
                for (i in 0 until areaListJSON.length()) {
                    val area = areaListJSON.getJSONObject(i)
                    spinnerAreaItems.add(area.getString(GetString.VALUE))
                }

                val spinnerAdapter = ArrayAdapter(
                    this@UDPSendActivity, R.layout.contact_spinner_row_init, spinnerAreaItems
                )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerArea.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, this@UDPSendActivity
                )

                if (spinnerAreaItems.contains(DeviceInfo.AREA)) {
                    val position = spinnerAreaItems.indexOf(DeviceInfo.AREA)
                    viewBinding.spinnerArea.setSelection(position + 1, false)
                } else {
                    viewBinding.spinnerArea.setSelection(1, false)
                }
            }
        }
    }

    private fun initBaySpinner() {
        mainScope.launch {
            viewBinding.spinnerBay.adapter = null

            var area = ""
            if (viewBinding.spinnerArea.selectedItem != null && viewBinding.spinnerArea.selectedItem.toString() != "ALL")
                area = viewBinding.spinnerArea.selectedItem.toString()

            val sendMessage = MessageFactoryUtil.areaBayInfo(area, DeviceInfo.FACILITY)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.AREABAYINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            val spinnerBayItems = arrayListOf("ALL")
            if (isSuccessFul) {
                val checkString =
                    ResponseDataToJsonUtil.checkMessageBodyList(result, GetString.BAYS)

                if (checkString == GetString.JSONOBJECT) {
                    val bayObjectJSON =
                        ResponseDataToJsonUtil.getMessageBodyObject(result, GetString.BAYS)
                    val bay = bayObjectJSON.getString(GetString.BAY)
                    spinnerBayItems.add(bay)
                } else {
                    val bayListJSON =
                        ResponseDataToJsonUtil.getMessageBodyList(result, GetString.BAYS)

                    for (i in 0 until bayListJSON.length()) {
                        val bay = bayListJSON.getJSONObject(i)
                        spinnerBayItems.add(bay.getString(GetString.BAY))
                    }
                }
            }

            val spinnerAdapter = ArrayAdapter(
                this@UDPSendActivity, R.layout.contact_spinner_row_init, spinnerBayItems
            )
            spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
            viewBinding.spinnerBay.adapter = InitSpinnerAdapter(
                spinnerAdapter, R.layout.contact_spinner_row_init, this@UDPSendActivity
            )
            viewBinding.spinnerBay.setSelection(1, false)
        }
    }

    private fun countPda(count: Int) {
        val sendList = "선택된 PDA 수량 - ${count}대"
        viewBinding.txtSendList.text = sendList
    }
}