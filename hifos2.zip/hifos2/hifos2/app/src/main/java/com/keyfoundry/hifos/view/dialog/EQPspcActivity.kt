package com.keyfoundry.hifos.view.dialog

import android.os.Bundle
import android.view.View
import android.view.Window
import androidx.lifecycle.lifecycleScope
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.CommonUtil
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivityEqpspc2Binding
import com.keyfoundry.hifos.message.MessageSender
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter


class EQPspcActivity : HFActivity() {
    init {
        this.update = false
    }

    private lateinit var viewBinding: ActivityEqpspc2Binding

    fun concat(s1: String, s2: String): String {
        if (s1 != "")
            return "$s1$$s2"
        else
            return "$s2"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setFinishOnTouchOutside(false)

        viewBinding = ActivityEqpspc2Binding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        val receiverMessage = intent.getStringExtra(DeviceInfo.UDP_RECEIVER_MESSAGE)

        if (receiverMessage != null) if (receiverMessage.contains("INTERLOCKMANAGER")) {

            val new_receiverMessage =arrayOf(receiverMessage?.split("<Table diffgr:")) // receiverMessage 잘라서 배열에 담기

            for (data in 1 until new_receiverMessage[0].size) {
                val arry_receiverMessage =
                    arrayOf(new_receiverMessage[0][data]?.split("</")) // receiverMessage 잘라서 배열에 담기

                //viewBinding.titlereceivermessage.text = "#EQPSPC INTERLOCK#";

                val Lotid = arry_receiverMessage[0]!![1].substring(arry_receiverMessage[0]!![1].lastIndexOf(">")+1)
                if(Lotid > 0.toString())
                    viewBinding.txtReceiverLotIDResult.append(Lotid)

                val Recipe = arry_receiverMessage[0]!![5].substring(arry_receiverMessage[0]!![5].lastIndexOf(">")+1)
                if(Recipe > 0.toString())
                    viewBinding.txtReceiverRecipeResult.append(Recipe)

                val Slot = arry_receiverMessage[0]!![11].substring(arry_receiverMessage[0]!![11].lastIndexOf(">")+1)
                if(Slot > 0.toString())
                    viewBinding.txtReceiverSlotResult.append(Slot)

                val Runtype = arry_receiverMessage[0]!![12].substring(arry_receiverMessage[0]!![12].lastIndexOf(">")+1)
                if(Runtype > 0.toString())
                    viewBinding.txtReceiverRunTypeResult.append(Runtype)

                val Spcaction = arry_receiverMessage[0]!![10].substring(arry_receiverMessage[0]!![10].lastIndexOf(">")+1)
                if(Spcaction > 0.toString())
                    viewBinding.txtReceiverSpcRuleResult.append(Spcaction)

                val Ocapsheet = arry_receiverMessage[0]!![13].substring(arry_receiverMessage[0]!![13].lastIndexOf(">")+1)
                if(Ocapsheet > 0.toString())
                    viewBinding.txtReceiverOCAPSheetResult.append(Ocapsheet)

                val Equipid = arry_receiverMessage[0]!![6].substring(arry_receiverMessage[0]!![6].lastIndexOf(">")+1)
                if(Equipid > 0.toString())
                    viewBinding.txtReceiverMesMachineResult.append(Equipid)

                val Chamber = arry_receiverMessage[0]!![7].substring(arry_receiverMessage[0]!![7].lastIndexOf(">")+1)
                if(Chamber > 0.toString())
                    viewBinding.txtReceiverChamberResult.append(Chamber)

                val Measeqpid = arry_receiverMessage[0]!![8].substring(arry_receiverMessage[0]!![8].lastIndexOf(">")+1)
                if(Measeqpid > 0.toString())
                    viewBinding.txtReceiverMeasMachineResult.append(Measeqpid)

                val Parameter = arry_receiverMessage[0]!![17].substring(arry_receiverMessage[0]!![17].lastIndexOf(">")+1)
                if(Parameter > 0.toString())
                    viewBinding.txtReceiverParameterResult.append(Parameter)

                val Min = arry_receiverMessage[0]!![20].substring(arry_receiverMessage[0]!![20].lastIndexOf(">")+1)
                if(Min > 0.toString())
                    viewBinding.txtReceiverMINResult.append(Min)

                val Max = arry_receiverMessage[0]!![21].substring(arry_receiverMessage[0]!![21].lastIndexOf(">")+1)
                if(Max > 0.toString())
                    viewBinding.txtReceiverMAXResult.append(Max)

                val AVG = arry_receiverMessage[0]!![19].substring(arry_receiverMessage[0]!![19].lastIndexOf(">")+1)
                if(AVG > 0.toString())
                    viewBinding.txtReceiverAVGResult.append(AVG)

                val Time = arry_receiverMessage[0]!![24].substring(arry_receiverMessage[0]!![24].lastIndexOf(">") + 1)
                if(Time > 0.toString())
                    viewBinding.txtReceiverTimeResult.append(Time)


                val SPCResult = arry_receiverMessage[0]!![9].substring(arry_receiverMessage[0]!![9].lastIndexOf(">") + 1
                )
                if (SPCResult > 0.toString()) {
                    var ruleCnt = 0

                    var str = ""
                    val list_spc = arrayListOf<String>()
                    var tempStr = "";
                    for (i in 1 until SPCResult.length) {
                        //list_spc.add("TT");
                        if (SPCResult.toString().substring(ruleCnt until ruleCnt + 1) == "F") {
                            //tempStr = SPCResult.toString().substring(ruleCnt until  ruleCnt+1).toString()
                            tempStr = (ruleCnt + 1).toString()
                            list_spc.add(tempStr)
                        }

                        ruleCnt++
                    }
                    viewBinding.txtReceiverSpcResultResult.append(list_spc.toString())
                }
            }
        }
        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                setData()
            }
        })
    }

    private fun setData(){
        lifecycleScope.launch {
            //CommonUtil.hideKeyboard(this@ESDMasterActivity, currentFocus)
            CommonUtil.hideKeyboard(this@EQPspcActivity, currentFocus)

            val sDeviceName = DeviceInfo.DEVICE_NAME; //PDA ID
            val sMasterTime = viewBinding.txtReceiverTimeResult.text.toString()
            val sEqpid = viewBinding.txtReceiverMesMachineResult.text.toString()
            val sRecipe = viewBinding.txtReceiverRecipeResult.text.toString()
            val sLotID = viewBinding.txtReceiverLotIDResult.text.toString()
            val sSlot = viewBinding.txtReceiverSlotResult.text.toString()
            val sUsers = DeviceInfo.OPERATOR_ID

            val current = LocalDateTime.now()
            val formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd_HH:mm:ss")
            val sCurrentTime = current.format(formatter)
            //내꺼에 맞게 수정
            val sendMessage = MessageFactoryUtil.intlkpopupcheck(sMasterTime,"EQPSPC","POP-UP",sDeviceName,"PDA",sDeviceName,"http://::1:62011/InterlockClient.soap"
                ,"Y",sUsers,sCurrentTime,sEqpid,sRecipe,sLotID,sSlot)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.SETGASUSAGE
            )
        }
        finish()
    }
}