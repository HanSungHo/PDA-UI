package com.keyfoundry.hifos.view.mask

import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.core.view.children
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.CommonUtil
import com.keyfoundry.hifos.config.utils.GridService
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityMultiMaskLocationBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class MultiMaskLocationActivity : HFActivity() {


    private lateinit var viewBinding: ActivityMultiMaskLocationBinding
    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var reticleId = ""
    private var currentSpinnerId = 0
    private lateinit var gridService: GridService
    private lateinit var slotlist: CTMainLayout
    private lateinit var SlotlistJSON: JSONArray


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityMultiMaskLocationBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editMaskTag.setOnEditorActionListener(editorActionListener)

        viewBinding.spinnerFloor.setOnTouchListener(onTouchListener)
        viewBinding.spinnerStatus.setOnTouchListener(onTouchListener)
        viewBinding.spinnerCurrentLocation.setOnTouchListener(onTouchListener)
        viewBinding.spinnerDetailLocation.setOnTouchListener(onTouchListener)

        viewBinding.spinnerFloor.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerStatus.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerCurrentLocation.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerDetailLocation.onItemSelectedListener = itemSelectListener


        setFloorSpinner()
        setStatusSpinner()
        setUseableSpinner()

        gridService = GridService(applicationContext)
        SlotlistJSON = JSONArray()


        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
        viewBinding.btnClear.setOnClickListener(onSingleClickListener)
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnOk.id -> {
                    changeMaskLocCheck()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
                viewBinding.btnClear.id -> {
                    clearList()
                    clearData()
                }
            }
        }
    }


    private val onTouchListener = View.OnTouchListener { v, event ->
        currentSpinnerId = v.id
        v.performClick()
    }

    private val itemSelectListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerFloor.id -> {
                        if (currentSpinnerId == parent.id) {
                            viewBinding.spinnerStatus.adapter = null
                            viewBinding.spinnerCurrentLocation.adapter = null
                            viewBinding.spinnerDetailLocation.adapter = null

                            setStatusSpinner()
                        }
                    }
                    viewBinding.spinnerStatus.id -> {
                        if (currentSpinnerId == parent.id) {
                            viewBinding.spinnerCurrentLocation.adapter = null
                            viewBinding.spinnerDetailLocation.adapter = null

                            setCurrentLocSpinner()
                        }
                    }
                    viewBinding.spinnerCurrentLocation.id -> {
                        if (currentSpinnerId == parent.id) {
                            viewBinding.spinnerDetailLocation.adapter = null
                            setDetailLocation()
                        }
                    }
//                    viewBinding.spinnerDetailLocation.id -> {
//                        if (currentSpinnerId == parent.id) {
//                            if (viewBinding.spinnerDetailLocation.selectedItem != null)
//                                checkPMSShelf(viewBinding.spinnerDetailLocation.selectedItem.toString())
//                        }
//                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private fun clearInfo() {
        reticleId = ""
        viewBinding.editMaskTag.setText("")
    }

    private fun clearList(){
        viewBinding.MaskInfo.removeAllViews()
    }


    private fun clearData() {
        SlotlistJSON = JSONArray()
    }


    private fun setFloorSpinner() {
        val itemList = arrayListOf("2F", "4F", "6F")
        val spinnerAdapter =
            ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerFloor.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
    }

    private fun setStatusSpinner() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.maskStatusInfo(DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MASKSTATUSINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val statusList = ResponseDataToJsonUtil.getMessageBodyList(result, "STATUSES")

                val itemList = arrayListOf<String>()
                for (count in 0 until statusList.length()) {
                    val status = statusList.getJSONObject(count).optString("STATUS")
                    itemList.add(status)
                }

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerStatus.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setDetailLocation() {
        mainScope.launch {
            if (viewBinding.spinnerStatus.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "상태를 선택해주세요", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.spinnerCurrentLocation.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "현재위치를 선택해주세요", GetString.BTNOKSTR
                )

                return@launch
            }
            val status = viewBinding.spinnerStatus.selectedItem.toString()
            val floor = if (viewBinding.spinnerFloor.selectedItem != null)
                viewBinding.spinnerFloor.selectedItem.toString()
            else
                ""

            val sendMessage = MessageFactoryUtil.maskLocationInfo(
                status, viewBinding.spinnerCurrentLocation.selectedItem.toString(),
                floor, DeviceInfo.FACILITY
            )
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MASKLOCGROUPINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val locationList = ResponseDataToJsonUtil.getMessageBodyList(result, "LOCATIONS")

                val itemList = arrayListOf<String>()
                for (count in 0 until locationList.length()) {
                    val location = locationList.getJSONObject(count).optString("LOCATION")
                    itemList.add(location)
                }

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerDetailLocation.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setCurrentLocSpinner() {
        mainScope.launch {
            if (viewBinding.spinnerStatus.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "상태를 선택해주세요", GetString.BTNOKSTR
                )

                return@launch
            }

            val status = viewBinding.spinnerStatus.selectedItem.toString()
            val floor = if (viewBinding.spinnerFloor.selectedItem != null)
                viewBinding.spinnerFloor.selectedItem.toString()
            else
                ""

            val sendMessage =
                MessageFactoryUtil.maskLocGroupInfo(status, floor, DeviceInfo.FACILITY)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MASKLOCGROUPINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val locGroupList = ResponseDataToJsonUtil.getMessageBodyList(result, "LOCGROUPS")

                val itemList = arrayListOf<String>()
                for (count in 0 until locGroupList.length()) {
                    val locGroup = locGroupList.getJSONObject(count).optString("LOCGROUP")
                    itemList.add(locGroup)
                }

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerCurrentLocation.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setUseableSpinner() {
        val itemList = arrayListOf("사용가능", "사용불가")
        val spinnerAdapter =
            ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerUseable.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
    }

    private fun changeMaskLocCheck(){
        val rows = slotlist.mainTable.children.toList()
        var pending = rows.size
        var anyFail = false
        for (mainRow in slotlist.mainTable.children){

            var reticleSeq = gridService.getCellValue(mainRow, "MASKID")
            changeMaskLoc(reticleSeq) { rc ->
                if (rc != 0) anyFail = true
                pending -= 1
                if (pending == 0) {
                    // 모든 처리 완료 시점에 한 번만 알림
                    if (!anyFail) {
                        OkDialog.show(
                            supportFragmentManager, GetString.BTNOKSTR,
                            "위치가 변경되었습니다.", GetString.BTNOKSTR
                        )
                        clearList()
                        clearData()
                    } else {
                        OkDialog.show(
                            supportFragmentManager, GetString.BTNOKSTR,
                            "위치 변경에 실패한 MASK가 있습니다.", GetString.BTNOKSTR
                        )
                    }
                }
            }
        }
    }

    private fun changeMaskLoc(seq: String, callback: (Int) -> Unit) {

        mainScope.launch {
            var resultCode = 1
            var locType = ""
            var location = ""
            var etcStatus = ""
            var etcLocation = ""
            var etcDetailLocation = ""
            var floor = ""

            if (viewBinding.spinnerStatus.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "변경할 STATUS를 입력하세요.", GetString.BTNOKSTR
                )
                return@launch
            } else {
                etcStatus = viewBinding.spinnerStatus.selectedItem.toString()
            }


            if (viewBinding.spinnerCurrentLocation.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "변경할 위치를 입력하세요.", GetString.BTNOKSTR
                )
                return@launch
            } else {
                etcLocation = viewBinding.spinnerCurrentLocation.selectedItem.toString()
            }

            if (viewBinding.spinnerDetailLocation.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "변경할 상세위치를 입력하세요.", GetString.BTNOKSTR
                )
                return@launch
            } else {
                etcDetailLocation = viewBinding.spinnerDetailLocation.selectedItem.toString()
            }

            if (viewBinding.spinnerFloor.selectedItem != null)
                floor = viewBinding.spinnerFloor.selectedItem.toString()


            locType = "MULTI"

            val sendMessage = MessageFactoryUtil.changeMaskLocation(
                seq, DeviceInfo.FACILITY, locType, location, etcStatus,
                etcLocation, etcDetailLocation, "",
                DeviceInfo.OPERATOR_ID, floor
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.CHECKPELLICLE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result




            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val reticles = messageBody.optString("RETCILES")
                val count = messageBody.optString("SCOUNT")

                if (count.isNotEmpty()) {
                    if (count.toInt() == 1) {
//                        OkDialog.show(
//                            supportFragmentManager, GetString.BTNOKSTR,
//                            "$reticles 위치가 변경되었습니다.", GetString.BTNOKSTR
//                        )
                    } else if (count.toInt() > 1) {
//                        val countMsg = """
//                            |동일한 Serial/위치인 MASK가 변경되었습니다.
//                            |[$reticles]
//                        """.trimMargin()
//                        OkDialog.show(
//                            supportFragmentManager, GetString.BTNOKSTR,
//                            countMsg, GetString.BTNOKSTR
//                        )
                    }
                }

                viewBinding.editMaskTag.setText("")
                viewBinding.editMaskTag.requestFocus()
                clearData()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }


            if (isSuccessFul)
                resultCode = 0
            else
                resultCode = 1

            callback(resultCode)
        }
    }

    private fun setMaskInfo() {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@MultiMaskLocationActivity, currentFocus)


            if (viewBinding.editMaskTag.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "위치 변경할 Mask를 읽어주세요.", GetString.BTNOKSTR
                )

                viewBinding.editMaskTag.requestFocus()
                viewBinding.editMaskTag.selectAll()
                return@launch
            }

            val currentText = viewBinding.editMaskTag.text.toString()
            val maskId = currentText.substring(0, currentText.length - 1)
            val reticleseq = maskId
            reticleId = maskId
            viewBinding.editMaskTag.setText(maskId)
            clearInfo()


            val sendMessage = MessageFactoryUtil.maskInfo(maskId, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MASKINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                clearList()
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val reticleTag = messageBody.optString("RETICLETAG")
                val product = messageBody.optString("PRODUCT")
                val status = messageBody.optString("STATUS")
                val isUse = messageBody.optString("ISUSE")
                val currLoc = messageBody.optString("CURRLOC")

                val newRowData = JSONObject()
                newRowData.put("MASKID", reticleseq)
                newRowData.put("MASKTAG", reticleTag)
                newRowData.put("ISUSE", isUse)
                newRowData.put("STATUS", status)
                newRowData.put("CURRLOC", currLoc)
                newRowData.put("PRODUCT", product)

                SlotlistJSON.put(newRowData)
                val slotcol = linkedMapOf(
                    "MASKTAG" to ColumnProperty("MASK TAG", Gravity.CENTER, false),
                    "ISUSE" to ColumnProperty("사용여부", Gravity.CENTER, false),
                    "STATUS" to ColumnProperty("상태", Gravity.CENTER, false),
                    "CURRLOC" to ColumnProperty("현재위치", Gravity.CENTER, false),
                    "PRODUCT" to ColumnProperty("PRODUCT", Gravity.CENTER, false),
                    "MASKID" to ColumnProperty("MASKID", Gravity.CENTER, false),
                )
                slotlist = gridService.setGridPropData(slotcol, SlotlistJSON)

                viewBinding.MaskInfo.addView(slotlist)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }



    private val editorActionListener = TextView.OnEditorActionListener { v, actionId, event ->
        when (v.id) {
            viewBinding.editMaskTag.id -> {
                if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                    setMaskInfo()
                } else if (event != null) { // Barcode Event
                    if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                        setMaskInfo()
                    }
                }
            }
        }
        true
    }




}

