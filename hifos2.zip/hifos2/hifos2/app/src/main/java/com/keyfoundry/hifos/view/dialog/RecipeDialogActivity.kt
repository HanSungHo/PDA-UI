package com.keyfoundry.hifos.view.dialog

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.View
import android.view.Window
import androidx.core.view.isGone
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivityRecipeDialogBinding
import com.keyfoundry.hifos.view.esheet.movein.MoveInActivity


class RecipeDialogActivity : HFActivity() {
    companion object {
        private const val TAG = "RecipeDialogActivity"
    }

    init {
        this.update = false
    }

    private lateinit var viewBinding: ActivityRecipeDialogBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setFinishOnTouchOutside(false)

        viewBinding = ActivityRecipeDialogBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.txtRecipe.movementMethod = ScrollingMovementMethod()
        viewBinding.txtLotNo.movementMethod = ScrollingMovementMethod()

        // set Param
        if (intent.getStringExtra("RECIPE")?.isNotEmpty() == true) {
            val recipe = intent.getStringExtra("RECIPE").toString()
            val lotId = intent.getStringExtra("LOTID").toString()
            viewBinding.txtRecipe.text = recipe
            viewBinding.txtLotNo.text = lotId
        }

        if (intent.getStringExtra("SKIP")?.isNotEmpty() == true) {
            viewBinding.txtSelectRcp.text = ""
            viewBinding.txtSelectLot.text = ""
            viewBinding.txtInformMessage.text = ""
        }

        val edgefarFlag = intent.getStringExtra("EDGEFAR")

        if (edgefarFlag=="Y") {
            viewBinding.txtEdgefar.isGone = false
        }

        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val returnIntent = Intent(applicationContext, MoveInActivity::class.java)
                setResult(Activity.RESULT_OK, returnIntent)
                finish()
            }
        })

        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
            }
        })
    }

    override fun onBackPressed() {
        viewBinding.btnOk.performClick()
    }
}