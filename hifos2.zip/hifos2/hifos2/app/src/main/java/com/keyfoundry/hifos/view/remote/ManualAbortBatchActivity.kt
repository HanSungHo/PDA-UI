package com.keyfoundry.hifos.view.remote

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ShapeDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputFilter
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewTreeObserver
import android.view.inputmethod.EditorInfo
import androidx.core.view.children
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityManualAbortBatchBinding
import com.keyfoundry.hifos.databinding.ActivityRemoteFurnaceInitBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class ManualAbortBatchActivity : HFActivity() {

    companion object {
        private const val TAG = "ManualAbortBatchActivity"
    }

    private lateinit var viewBinding: ActivityManualAbortBatchBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var gridService: GridService
    private lateinit var selectedRow: CTRowLayout
    private lateinit var gridList: CTMainLayout
    private var baseWidth = 3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityManualAbortBatchBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        val base = viewBinding.baseLayout
        val vto: ViewTreeObserver = base.viewTreeObserver

        vto.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                base.viewTreeObserver.removeOnGlobalLayoutListener(this)
                baseWidth = base.width
            }
        })
        gridService = GridService(this)

        //setContentView(R.layout.activity_manual_abort_batch)

        viewBinding.txtEqp.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.txtLot.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.txtRecipe.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        viewBinding.btnReManul.isEnabled = false;
        viewBinding.txtLot.requestFocus()

        viewBinding.txtLot.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE)
            {
                val check = BarcodeStyle(this).lotId(viewBinding.txtLot)
                if (check) {
                    mainScope.launch {
                        getBatchLOTInfo(viewBinding.txtLot.text.toString())
                    }
                }
            }
            else if (event != null)
            {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER)
                {
                    val check = BarcodeStyle(this).lotId(viewBinding.txtLot)
                    if (check) {
                        mainScope.launch {
                            getBatchLOTInfo(viewBinding.txtLot.text.toString())
                        }
                    }
                }
            }
            true
        }

        viewBinding.txtEqp.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                val check = BarcodeStyle(this).eqpId(viewBinding.txtEqp)
                if (check) {
                    viewBinding.txtRecipe.requestFocus()
                }
            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).eqpId(viewBinding.txtEqp)
                    if (check) {
                        viewBinding.txtRecipe.requestFocus()
                    }
                }
            }
            true
        }

        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
        viewBinding.btnReManul.setOnClickListener(onSingleClickListener)

    }

    private suspend fun getBatchLOTInfo(lotID: String) {
        if (lotID.isEmpty())
            return
        viewBinding.baseLayout.removeAllViews()

        val sendMessage = MessageFactoryUtil.remoteRemanualLOT(lotID)

        val message = MessageSender.send(
            supportFragmentManager, sendMessage, MessageName.FURNACEREMANUALLOT
        )
        val isSuccessFul = message.isSuccessFul
        val result = message.result
        if (isSuccessFul) {
            val itemList = ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "ITEMS")

            val columnList = linkedMapOf(
                "BATCHINFO" to ColumnProperty("구분", Gravity.CENTER, false, baseWidth / 3),
                "ZONE" to ColumnProperty("ZONE", Gravity.CENTER, false, baseWidth / 3),
                "LOT" to ColumnProperty("LOT", Gravity.CENTER, false, baseWidth / 3)
            )

            gridList = gridService.setGridPropData(columnList, itemList)
            viewBinding.baseLayout.addView(gridList)
            for (row in gridList.mainTable.children) {
                val checkRow = row as CTRowLayout
                val checkRowData = (checkRow.tag as GridService.RowData).rowDataList
                if(checkRowData["BATCHINFO"].toString() == "자") {
                    var color = Color.parseColor("#ffebcd")
                     checkRow.setBackgroundColor(color)
                }
            }
            viewBinding.btnReManul.isEnabled = true
            viewBinding.txtEqp.requestFocus()
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )
        }
    }


    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {

                viewBinding.btnCancel.id -> {
                    finish()
                }

                viewBinding.btnReManul.id -> {
                    rebatchManualSave();
                }
            }
        }
    }

    private fun rebatchManualSave() {
        mainScope.launch {
            if(viewBinding.txtLot.text.isEmpty())
            {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT을 입력하세요.", GetString.BTNOKSTR
                )
                viewBinding.txtLot.requestFocus()
                return@launch;
            }
            if(viewBinding.txtEqp.text.isEmpty())
            {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "장비를 입력하세요.", GetString.BTNOKSTR
                )
                viewBinding.txtEqp.requestFocus()
                return@launch;
            }
            if(viewBinding.txtRecipe.text.isEmpty())
            {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "Recipe를 입력하세요.", GetString.BTNOKSTR
                )
                viewBinding.txtRecipe.requestFocus()
                return@launch;
            }

            val lotid = viewBinding.txtLot.text.toString();
            val eqpid = viewBinding.txtEqp.text.toString();
            val rcpid = viewBinding.txtRecipe.text.toString();
            val eventUser = DeviceInfo.OPERATOR_ID;

            val sendMessage = MessageFactoryUtil.remoteRemanualSave(lotid, eqpid, rcpid, eventUser)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.FURNACEREMANUALSAVE
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                setResult(RESULT_OK)
                finish()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }
}