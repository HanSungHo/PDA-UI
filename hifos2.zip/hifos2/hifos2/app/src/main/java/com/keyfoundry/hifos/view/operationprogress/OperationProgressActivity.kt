package com.keyfoundry.hifos.view.operationprogress

import android.content.Context
import android.os.Bundle
import android.os.Vibrator
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import androidx.core.view.isGone
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.BarcodeStyle
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityOperationAddBinding
import com.keyfoundry.hifos.databinding.ActivityPrChangeBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.batch.BatchActivity
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDailogAlram
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class OperationProgressActivity : HFActivity() {
    companion object {
        private const val TAG = "OperationAddActivity"
    }

    private lateinit var viewBinding: ActivityOperationAddBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityOperationAddBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        viewBinding.editLotId.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editMachineId.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        viewBinding.editLotId.requestFocus()

        viewBinding.btnChange.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                getOperationProcessCount()
            }
        })

        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
            }
        })

        viewBinding.btnSearchLotId.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                getLotInfo(viewBinding.editLotId.text.toString())
            }
        })

        viewBinding.btnSearchMachineId.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                getMachineInfo(viewBinding.editMachineId.text.toString())
            }
        })

        viewBinding.editLotId.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                val check = BarcodeStyle(this).lotId(viewBinding.editLotId)

                if (check) {
                    getLotInfo(viewBinding.editLotId.text.toString())
                } else {
                    clearData()
                }
            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).lotId(viewBinding.editLotId)

                    if (check) {
                        getLotInfo(viewBinding.editLotId.text.toString())
                    } else {
                        clearData()
                    }
                }
            }

            true
        }

        viewBinding.editMachineId.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                val check = BarcodeStyle(this).eqpId(viewBinding.editMachineId)
                if(check){
                    getMachineInfo(viewBinding.editMachineId.text.toString())
                }

            } else if (event != null) { // Barcode Event
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).eqpId(viewBinding.editMachineId)
                    if(check){
                        getMachineInfo(viewBinding.editMachineId.text.toString())
                    }
                }
            }

            true
        }

    }

    private fun clearData() {

    }


    private fun getLotInfo(sLot : String){
        mainScope.launch {

            val sendMessage =
                MessageFactoryUtil.lotInfo(sLot, DeviceInfo.FACILITY, "", DeviceInfo.OPERATOR_ID)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sProduct = messageBody.optString("PRODUCT")
                val sOperation = messageBody.optString("OPERATION")
                val sSubOperation = messageBody.optString("SUBOPERATION")
                val sCustomer = messageBody.optString("CUSTOMER")
                val sQuantity = messageBody.optString("QUANTITY")
                val sProcessStep = messageBody.optString("PROCESSSTEP")

                viewBinding.txtProduct.text = sProduct
                viewBinding.txtProcessOperation.text = "$sOperation-$sSubOperation"
                viewBinding.txtQty.text = sQuantity
                viewBinding.txtProcessOperationDesc.text = sProcessStep

                viewBinding.editMachineId.requestFocus()

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR
                )
            }
        }
    }

    private fun getMachineInfo(sMachine: String){
        mainScope.launch {

            val sendMessage =
                MessageFactoryUtil.getMachineInfo(DeviceInfo.FACILITY, sMachine)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sStatus = messageBody.optString("MESSTATE")
                val sArea = messageBody.optString("AREANAME")
                viewBinding.txtMachineState.text = sStatus
                viewBinding.txtAreaName.text = sArea



            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR
                )
            }
        }
    }

    private fun getOperationProcessCount(){

        if(viewBinding.txtProcessOperation.text !in listOf("50265-00", "50745-00", "51216-00", "51572-00", "51928-00", "52300-00")){
            insertOperationHistory()
        } else {

            mainScope.launch {

                val sendMessage =
                    MessageFactoryUtil.getOperationProcessCount(
                        DeviceInfo.FACILITY,
                        viewBinding.editLotId.text.toString(),
                        viewBinding.editMachineId.text.toString(),
                        viewBinding.txtProcessOperation.text.toString(),
                        viewBinding.txtProcessOperationDesc.text.toString(),
                        DeviceInfo.OPERATOR_ID,
                        viewBinding.txtProduct.text.toString(),
                        viewBinding.txtAreaName.text.toString()
                    )

                val message =
                    MessageSender.send(supportFragmentManager, sendMessage, MessageName.MESSAGE)
                val isSuccessFul = message.isSuccessFul
                val result = message.result

                if (isSuccessFul) {
                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                    val sCount = messageBody.optString("COUNT")
                    val sEventTime = messageBody.optString("EVENTTIME")

                    if (sCount == "0") {
                        insertOperationHistory()
                    } else {
                        val returnCode = OkCancelDialog.show(
                            supportFragmentManager,
                            GetString.BTNOKSTR,
                            "$sEventTime 진행이력 있음. Eng'r Confirm 후 적용바랍니다. 계속 진행 하시겠습니까?",
                            GetString.POSITIVEBTNSTR,
                            GetString.NEGATIVEBTNSTR
                        )

                        if (returnCode == OkCancelDialog.RETURN_CODE_OK)
                            insertOperationHistory()// [ uk 20180514 ] Photo Inline Remote Code Copy
                    }


                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    val returnCode = OkDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage,
                        GetString.BTNOKSTR
                    )
                }
            }
        }

    }
    private fun insertOperationHistory(){
        mainScope.launch {

            val sendMessage =
                MessageFactoryUtil.insertOperationHistory(DeviceInfo.FACILITY, viewBinding.editLotId.text.toString(),
                    viewBinding.editMachineId.text.toString(),
                    viewBinding.txtProcessOperation.text.toString(), viewBinding.txtProcessOperationDesc.text.toString(),
                    DeviceInfo.OPERATOR_ID,viewBinding.txtProduct.text.toString(), viewBinding.txtAreaName.text.toString())

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_INFORM
                    , "저장하였습니다."
                    , GetString.BTNOKSTR)


            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR
                )
            }
        }
    }
}