package com.keyfoundry.hifos.view.dispatching

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputFilter
import android.util.Log
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import androidx.core.view.*
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.CTSubLayout
import com.keyfoundry.hifos.config.grid.GridType
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityDispatchingBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.ESheetActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.*
import kotlin.collections.HashMap

class DispatchingActivity : HFActivity() {

    companion object {
        private const val TAG = "DisPatchingActivity"
    }

    private lateinit var viewBinding : ActivityDispatchingBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    lateinit var gridService: GridService
    lateinit var tableList: CTMainLayout

    var selectedRowCount = 0
    lateinit var selectedRow: CTRowLayout
    val selectedRowList = arrayListOf<Int>()

    var reserveFlag : String ="F"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityDispatchingBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        viewBinding.editDispatchingNo.requestFocus()
        viewBinding.editDispatchingNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        gridService = GridService(applicationContext)

        viewBinding.btnClose.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
            }
        })

        viewBinding.btnSearchDispatching.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                getDispatch()
            }
        })

        viewBinding.editDispatchingNo.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                val check = BarcodeStyle(this).eqpId(viewBinding.editDispatchingNo)
                if(check){
                    getDispatch()
                }

            } else if (event != null) { // Barcode Event
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).eqpId(viewBinding.editDispatchingNo)
                    if(check){
                        getDispatch()
                    }
                }
            }

            true
        }

        viewBinding.btnReservedReg.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                if(selectedRowList.count()>0) {
                    setDispatch(true)
                }
            }
        })

        viewBinding.btnReservedCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                if(selectedRowList.count()>0) {
                    setDispatch(false)
                }
            }
        })

        viewBinding.checkBoxReserved.setOnCheckedChangeListener{compoundButton, b ->
            reserveFlag = if (b) "T" else "F"
        }
    }

    private fun getDispatch(){
        selectedRowList.clear()
        viewBinding.baseLayout.removeAllViews()
        val wet = viewBinding.editWetLimitLank.text.toString()
        val machineName = viewBinding.editDispatchingNo.text.toString()

        if (machineName.isEmpty()) {
            val returnCode = OkDialog.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_ERROR,
                "Machine을 입력해주세요",
                GetString.BTNOKSTR
            )
            return
        }

        val sendMessage = MessageFactoryUtil.getDisPatch(reserveFlag, machineName, wet)
        mainScope.launch {
            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.GETDISPATCH)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {

                // reservelot, displot 을 합쳐서 list에 뿌려줘야기 때문에 합칠 jsonarray
                var concatJsonArray = JSONArray()
                val reserveLotList = ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "RESERVELOT")
                val disparcherLotList = ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "DISPLOT")

                for(i in 0 until reserveLotList.length()){
                    (reserveLotList[i] as JSONObject).put("OPREATIONDESC",(reserveLotList[i] as JSONObject).optString("PODESC"))
                    (reserveLotList[i] as JSONObject).put("OPREATIONNAME",(reserveLotList[i] as JSONObject).optString("PROCESSOPERATIONNAME"))
                    concatJsonArray.put(reserveLotList[i])
                }

                for(i in 0 until disparcherLotList.length()){
                        if((disparcherLotList[i] as JSONObject).optString("BOXSTATUS")=="INBAY"){
                            (disparcherLotList[i] as JSONObject).put("TRANSPORTLOCATION",(disparcherLotList[i] as JSONObject).optString("BAYNAME"))
                        } else {
                            (disparcherLotList[i] as JSONObject).put("TRANSPORTLOCATION",(disparcherLotList[i] as JSONObject).optString("TRANSPORT"))
                        }
                    concatJsonArray.put(disparcherLotList[i])
                }

                val hideList = ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "HIDE")

                var hideColumnIndex = arrayListOf<Int>()

                // 숨길 컬럼 추출
                for(i in 8 until hideList.length()){
                    if(hideList.optJSONObject(i).optString("HIDEFLAG")=="Y")
                        hideColumnIndex.add(i)
                }

                val columnData = linkedMapOf(
                    "NUMBER" to "NUM", "RESERVE" to "R", "JOBCODE" to "JOB", "LOTNAME" to "LOT", "OPREATIONNAME" to "공정번호",
                    "OPREATIONDESC" to "공정명", "QTY" to "QTY", "DOPANT" to "GAS",  "RECIPE" to "RECIPE", "BOXSTATUS" to "BOXSTATUS",
                    "TRANSPORTLOCATION" to "반송위치", "HOLDCODE" to "H-CODE", "HOLDCOMMENT" to "HOLD COMMENTS","QTIME" to "QT", "LOTCLASS" to "LOTCLASS",
                    "SDD" to "SDD", "PRODUCTSPECNAME" to "제품명", "CUSTOMERNAME" to "고객명", "PROCESSINTIME" to "공정 도착시각", "REWORKSTATUS" to "RW", //if(inRework==Y) else ""
                    "MAVEINMACHINE1" to "MOVEIN장비", "RETILCEKEY" to "RETICLE KEY", "MASKLOCATION" to "MASK 위치", "PRNAME" to "PRNAME", "BATCHID" to "BATCHID",
                    "SUBSTN_REPLY" to "가능 HEAD", "RUNINGMODE" to "진행 MODE",  "LOTPROCESSSTATE" to "LOT 상태",  "STARTPOTIME" to "시작 가능 시간", "BATCHLOT" to "BATCHLOT",
                    "NEXTMACHINE" to "다음 진행장비", "OPTIMALSTARTTIME" to "최적 START 시간", "PSTARTTIME" to "예상 시작 시각",
                    "MAINTITEM" to "MAINTITEM",
                )

                val gridData = setGridData(columnData, concatJsonArray, hideColumnIndex)
                viewBinding.baseLayout.addView(gridData)

                selectDispatch(gridData)

            }
            else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

                // viewBinding.editDispatchingNo.setText("")
            }
        }
    }

    private fun setDispatch(brev: Boolean){
        val sendMessage = makeSetDispatchSendMessage(brev)
        if(sendMessage==""){
            return
        }
        mainScope.launch {
            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.SETDISPATCH)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                getDispatch()
            }
            else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)
            }
        }
    }

    private fun makeSetDispatchSendMessage(brev: Boolean) :String {
        if (viewBinding.editDispatchingNo.text.isEmpty()) {
            val returnCode = OkDialog.show(supportFragmentManager
                , GetString.TXTDIALOGTITLE_ERROR
                ,"장비명이 확인 되지 않습니다."
                , GetString.BTNOKSTR)

            return ""
        }

        val rv = if (brev) "Y" else "N"

        val gridBody = viewBinding.baseLayout.getChildAt(0) as CTMainLayout

        var itemList = ""

        // 선택한 row 서버로 보낼 메시지 만드는 부분
        for (i in 0 until selectedRowList.count()) {
            val rowData = gridBody.mainTable.getChildAt(selectedRowList[i]) as CTRowLayout

            val reserve = gridService.getCellValue(rowData, "RESERVE")
            val lotName = gridService.getCellValue(rowData, "LOTNAME")
            val processOper = gridService.getCellValue(rowData, "OPREATIONNAME")
            val processOperDesc = gridService.getCellValue(rowData, "OPREATIONDESC")
            val product = gridService.getCellValue(rowData, "PRODUCTSPECNAME")

            if (brev && reserve == "N") {
                itemList += """
                        |
                        |<ITEM>
                        |<LOTNAME>$lotName</LOTNAME>
                        |<PROECSSOPER>$processOper</PROECSSOPER>
                        |<PROECSSOPERDESC>$processOperDesc</PROECSSOPERDESC>
                        |<PRODUCT>$product</PRODUCT>
                        |</ITEM>
                        """.trimMargin()
            }

            if (!brev && reserve == "Y") {
                itemList += """
                        |
                        |<ITEM>
                        |<LOTNAME>$lotName</LOTNAME>
                        |<PROECSSOPER>$processOper</PROECSSOPER>
                        |</ITEM>
                        """.trimMargin()
            }
        }

        if (itemList == "") {
            val returnCode = OkDialog.show(supportFragmentManager
                , GetString.TXTDIALOGTITLE_ERROR
                ,"선택된 예약 해제 LOT이 없습니다."
                , GetString.BTNOKSTR)
            return ""
        }

        return MessageFactoryUtil.setDisPatch(viewBinding.editDispatchingNo.text.toString(), DeviceInfo.OPERATOR_ID, DeviceInfo.OPERATOR_NAME, rv, itemList)

    }

    fun setGridData(columnData: LinkedHashMap<String, String>, dataTable: JSONArray, hideColumnIndex: ArrayList<Int>): CTMainLayout {
        val bodyLayout = CTMainLayout(this)

        val columnNameList = gridService.getColumnNameList(dataTable)

        val columnHeaderList = CTSubLayout(this, GridType.COLUMN_GRID)
        val rowHeaderList =CTSubLayout(this, GridType.ROW_GRID)
        val mainBodyList = CTSubLayout(this, GridType.MAIN_GRID)
        val cornerHeaderList = CTSubLayout(this, GridType.CORNER_GRID)

        for (row in 0 until dataTable.length()) {
            val mainBodyRow = CTRowLayout(this)
            val rowHeaderRow = CTRowLayout(this)
            val columnHeaderRow =
                CTRowLayout(this)
            columnHeaderRow.setBackgroundColor(Color.parseColor("#e9edef"))

            val colDataMap = HashMap<String, Any>()
            val columnValueList = mutableListOf<String>()

            for (columnName in columnNameList)
                colDataMap[columnName.toUpperCase(Locale.ROOT)] = dataTable.getJSONObject(row).optString(columnName)

            mainBodyRow.tag = GridService.RowData(colDataMap)
            rowHeaderRow.tag = GridService.RowData(colDataMap)

//            val mainDataTag = mainBodyRow.tag as GridService.RowData

//            val reworkStatus = mainDataTag.rowDataList["REWORKSTATUS"].toString()
//
//
//            if(reworkStatus=="InRework"){
//                mainDataTag.rowDataList["REWORKSTATUS"] = "Y"
//            } else {
//                mainDataTag.rowDataList["REWORKSTATUS"] = "N"
//            }

            val textColor = Color.BLACK


            setGridRowColor(mainBodyRow, rowHeaderRow)

            var startIndex = 0
            for (columnName in columnData.keys) {
                startIndex++
                // 컬럼헤더 데이터 등록=============================================
                if (columnHeaderList.childCount == 0) {
                    val columnItem = TextView(this)
                    columnItem.gravity = Gravity.CENTER
                    columnItem.setPadding(10)
                    columnItem.setBackgroundResource(R.drawable.cellsharp)
                    columnItem.text = columnData[columnName]
                    columnValueList.add(columnName.toUpperCase(Locale.ROOT))

                    if (columnName == "MAINTITEM") {
                        columnItem.isInvisible = true
                        columnItem.width=0
                        columnItem.height=0
                    }

                    // hideflag true 인 컬럼 숨김
                    if(hideColumnIndex.contains(startIndex)){
                        columnItem.isInvisible = true
                        columnItem.width=0
                        columnItem.height=0
                    }

                    columnHeaderRow.addView(columnItem)
                }

                var itemValue = dataTable.getJSONObject(row).optString(columnName)

                var bodyItem = TextView(this)

                // lotname row 더블 클릭 이벤트 등록
                if (columnName == "LOTNAME") {
                    callActivity(bodyItem, itemValue)
                }

                if (columnName == "REWORKSTATUS" && itemValue == "InRework") {
                    itemValue ="Y"
                } else if (columnName == "REWORKSTATUS" && itemValue != "") {
                    itemValue ="N"
                }

                bodyItem.setPadding(10)
                bodyItem.setBackgroundResource(R.drawable.cellsharp)
                bodyItem.text = itemValue
                bodyItem.isSingleLine = true

                if (columnName == "MAINTITEM" ) {
                    bodyItem.isInvisible = true
                    bodyItem.width=0
                }

                if(hideColumnIndex.contains(startIndex)){
                    bodyItem.isInvisible = true
                    bodyItem.width=0
                }
                bodyItem.gravity = Gravity.CENTER

                bodyItem.setTextColor(textColor)

                mainBodyRow.addView(bodyItem)
            }

            // MainTable의 Row데이터 등록====================================
            mainBodyRow.isFocusableInTouchMode = true
            mainBodyList.addView(mainBodyRow)

            // ColumnHeader 데이터 등록
            if (columnHeaderList.childCount == 0) {
                columnHeaderRow.tag = columnValueList
                columnHeaderList.addView(columnHeaderRow)
            }

            // RowHeader의 Row데이터 등록====================================
            rowHeaderRow.isFocusableInTouchMode = true
            rowHeaderList.addView(rowHeaderRow)
        }

        bodyLayout.addViews(mainBodyList, columnHeaderList, rowHeaderList, cornerHeaderList)

        return bodyLayout
    }

    // mainitem 항목이 긴급 또는 매출일 경우 row 색깔 변경
    fun setGridRowColor(mainBodyRow: CTRowLayout, rowHeaderRow: CTRowLayout) {
        val rowData = (rowHeaderRow.tag as GridService.RowData).rowDataList
        when {
            rowData["MAINTITEM"] == "긴급" -> {
                mainBodyRow.setBackgroundColor(Color.rgb(242,150,97))
            }
            rowData["MAINTITEM"] == "매출" -> {
                mainBodyRow.setBackgroundColor(Color.rgb(134,229,127))
            }
        }
    }

    // 선택된 row를 selectedRowList index 에 담기
    inner class MyGestureListener : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent?): Boolean {
            return true
        }

        override fun onSingleTapUp(event: MotionEvent): Boolean {
            selectedRow.isSelected = !selectedRow.isSelected

            val rowIndex = ((selectedRow.parent) as CTSubLayout).indexOfChild(selectedRow)

            if (selectedRow.isSelected) {
                selectedRowCount++
                selectedRowList.add(rowIndex)
            } else {
                selectedRowCount--
                selectedRowList.remove(rowIndex)
            }
            return true
        }
    }

    private fun selectDispatch(gridData: CTMainLayout) {
        val mainTable = gridData.mainTable
        selectedRowCount = 0

        for (row in 0 until mainTable.size) {
            val tableRow = mainTable.getChildAt(row) as CTRowLayout
            tableRow.setBackgroundResource(R.drawable.selected_grid_row)

            val mDetector = GestureDetectorCompat(this, MyGestureListener())

            tableRow.setOnTouchListener { v, event ->
                selectedRow = v as CTRowLayout

                return@setOnTouchListener (mDetector.onTouchEvent(event))
            }
        }
    }


    private fun callActivity(item: TextView, itemValue: String){
        val mDetector = GestureDetectorCompat(this, LotGestureListener(itemValue))

        if(itemValue.isNotEmpty()) {
            item.isClickable = true
            item.setOnTouchListener { v, event ->
                val row = v.parent as CTRowLayout
                val gridTable = viewBinding.baseLayout.getChildAt(0) as CTMainLayout

                setRowColor(row, event, gridTable)

                mDetector.onTouchEvent(event)

                true
            }
        }
    }

    // lot 더블클릭 시 해당 lot으로 esheet 조회
    inner class LotGestureListener(
        private val lotName: String,
    ) : GestureDetector.SimpleOnGestureListener() {

        override fun onDoubleTap(e: MotionEvent?): Boolean {
            val esheetIntent = Intent(applicationContext, ESheetActivity::class.java)
            esheetIntent.putExtra("LOTID", lotName)
            startActivity(esheetIntent)
            return super.onDoubleTap(e)
        }
    }

    private fun setRowColor(v: View, event: MotionEvent?, gridData: CTMainLayout){
        val parentLayout = v.parent as CTSubLayout
        parentLayout.currentRowIndex = parentLayout.indexOfChild(v)

        if(event?.action == MotionEvent.ACTION_UP) {

            val selectedRow = gridData.mainTable.getChildAt(parentLayout.currentRowIndex) as CTRowLayout
            selectedRow.isSelected = !selectedRow.isSelected

            val rowIndex = ((selectedRow.parent) as CTSubLayout).indexOfChild(selectedRow)

            if (selectedRow.isSelected) {
                selectedRowCount++
                selectedRowList.add(rowIndex)
            } else {
                selectedRowCount--
                selectedRowList.remove(rowIndex)
            }
        }
    }
}