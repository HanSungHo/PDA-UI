package com.keyfoundry.hifos.view.remote

import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.os.Bundle
import android.view.View
import android.view.Window
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityRemoteBatchCancelBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RemoteBatchCancelActivity : HFActivity() {
    init {
        this.update = false
    }

    private lateinit var viewBinding: ActivityRemoteBatchCancelBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var searchJob1 = ""
    private var searchJob2 = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setFinishOnTouchOutside(false)

        viewBinding = ActivityRemoteBatchCancelBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        if (intent.getStringExtra("EQPID")?.isNotEmpty() == true) {
            val eqpId = intent.getStringExtra("EQPID")
            if (eqpId != null) {
                getJobList(eqpId)
            }
        }

        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnOk.id -> {
                    val returnIntent = Intent()
                    var job1 = ""
                    if (viewBinding.chkJob1.isChecked)
                        job1 = searchJob1

                    var job2 = ""
                    if (viewBinding.chkJob2.isChecked)
                        job2 = searchJob2

                    returnIntent.putExtra("JOB1", job1)
                    returnIntent.putExtra("JOB2", job2)

                    setResult(RESULT_OK, returnIntent)
                    finish()
                }
                viewBinding.btnCancel.id -> {
                    setResult(RESULT_CANCELED)
                    finish()
                }
            }
        }
    }

    private fun clearJobList() {
        viewBinding.txtState1.text = ""
        viewBinding.txtJ1Rcp.text = ""
        viewBinding.txtJ1Lot1.text = ""
        viewBinding.txtJ1Lot2.text = ""

        viewBinding.txtState2.text = ""
        viewBinding.txtJ2Rcp.text = ""
        viewBinding.txtJ2Lot1.text = ""
        viewBinding.txtJ2Lot2.text = ""
    }

    private fun getJobList(eqpId: String) {
        mainScope.launch {
            clearJobList()

            val sendMessage = MessageFactoryUtil.wetJobList(eqpId)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.ETCHRCPDOWNLOAD
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val job1 = messageBody.optString("JOB1")
                val job2 = messageBody.optString("JOB2")
                val j1Rcp = messageBody.optString("RCP1")
                val j2Rcp = messageBody.optString("RCP2")
                val j1Sta = messageBody.optString("J1STA")
                val j2Sta = messageBody.optString("J2STA")
                val j1Lot1 = messageBody.optString("J1LOT1")
                val j1Lot2 = messageBody.optString("J1LOT2")
                val j2Lot1 = messageBody.optString("J2LOT1")
                val j2Lot2 = messageBody.optString("J2LOT2")

                viewBinding.txtState1.text = j1Sta
                viewBinding.txtJ1Rcp.text = j1Rcp
                viewBinding.txtJ1Lot1.text = j1Lot1
                viewBinding.txtJ1Lot2.text = j1Lot2

                viewBinding.txtState2.text = j2Sta
                viewBinding.txtJ2Rcp.text = j2Rcp
                viewBinding.txtJ2Lot1.text = j2Lot1
                viewBinding.txtJ2Lot2.text = j2Lot2

                if (job1.isEmpty()) {
                    viewBinding.chkJob1.isEnabled = false
                    viewBinding.txtState1.visibility = View.GONE
                }else{
                    searchJob1 = job1
                }

                if (job2.isEmpty()) {
                    viewBinding.chkJob2.isEnabled = false
                    viewBinding.txtState2.visibility = View.GONE
                } else {
                    searchJob2 = job2

                    viewBinding.txtState2.setBackgroundColor(Color.BLUE)
                    viewBinding.txtState2.setTextColor(Color.WHITE)

                    val drawablePadding = Rect()
                    val top = viewBinding.txtJ2Lot2.paddingTop + drawablePadding.top
                    val left = viewBinding.txtJ2Lot2.paddingLeft + drawablePadding.left
                    val right = viewBinding.txtJ2Lot2.paddingRight + drawablePadding.right
                    val bottom = viewBinding.txtJ2Lot2.paddingBottom + drawablePadding.bottom

                    viewBinding.txtJ2Lot2.setBackgroundResource(R.drawable.textview_batch_cancel)
                    viewBinding.txtJ2Lot2.setPadding(left, top, right, bottom)
                    viewBinding.txtJ2Lot2.setTextColor(Color.BLUE)
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }
}