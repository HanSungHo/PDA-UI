package com.keyfoundry.hifos.view

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.TextView
import com.keyfoundry.hifos.BuildConfig
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.domain.SettingInfo
import com.keyfoundry.hifos.config.domain.UserInfo
import com.keyfoundry.hifos.config.service.room.SettingInfoService
import com.keyfoundry.hifos.config.service.room.UserInfoService
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.CommonUtil
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivitySettingBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialogFragment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SettingActivity : HFActivity() {
    companion object {
        private const val TAG = "SettingActivity"
    }

    private lateinit var viewBinding: ActivitySettingBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var settingInfoService: SettingInfoService
    private lateinit var userInfoService: UserInfoService

    private lateinit var okDialogFragment: OkDialogFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        val newTitle = "환경설정 v${BuildConfig.VERSION_NAME}"
        val layoutTitle = viewBinding.layoutTitle
        val textViewTitle = layoutTitle.findViewById<TextView>(R.id.txt_title)
        textViewTitle.text = newTitle

        settingInfoService = SettingInfoService(applicationContext)
        userInfoService = UserInfoService(applicationContext)

        checkHistorySetting()
        setEventSpinner()

        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnOk.id -> {
                    executeSetting()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    // -- private --
    enum class SpinnerType { FACILITY, AREA, BAY }

    private fun executeSetting() {
        mainScope.launch {
            if (viewBinding.spinnerFacility.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_WARNING,
                    "FACILITY를 선택해주세요", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.spinnerArea.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_WARNING,
                    "AREA를 선택해주세요", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.spinnerBay.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_WARNING,
                    "BAY를 선택해주세요", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.editHistoryCount.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_WARNING,
                    "History Count를 입력해주세요", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.editForwardCount.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_WARNING,
                    "Forward Count를 입력해주세요", GetString.BTNOKSTR
                )

                return@launch
            }

            val facility = viewBinding.spinnerFacility.selectedItem.toString()
            val area = viewBinding.spinnerArea.selectedItem.toString()
            val bay = viewBinding.spinnerBay.selectedItem.toString()

            val historyCount = viewBinding.editHistoryCount.text.toString()
            val forwardCount = viewBinding.editForwardCount.text.toString()

            val iHistCount: Int
            val iForwardCount: Int

            if (historyCount.toInt() > 2000) {
                iHistCount = 2000
                viewBinding.editHistoryCount.setText(iHistCount.toString())
            } else {
                iHistCount = historyCount.toInt()
            }

            if (forwardCount.toInt() > 2000) {
                iForwardCount = 2000
                viewBinding.editForwardCount.setText(iForwardCount.toString())
            } else {
                iForwardCount = forwardCount.toInt()
            }

            ioScope.launch {
                settingInfoService.insert(
                    SettingInfo(
                        facility, area, bay, iHistCount,
                        iForwardCount, System.currentTimeMillis()
                    )
                )

                if (userInfoService.checkLoginState()) {
                    val userInfo = userInfoService.selectUserInfo()

                    if (userInfo != null) {
                        userInfoService.insert(
                            UserInfo(
                                userInfo.operId, userInfo.operName, facility,
                                area, bay, userInfo.permission, true, System.currentTimeMillis()
                            )
                        )
                    }
                }
            }

            // set DeviceInfo
            DeviceInfo.FACILITY = facility
            DeviceInfo.AREA = area
            DeviceInfo.BAY = bay
            DeviceInfo.HISTORY_COUNT = historyCount
            DeviceInfo.FORWARD_COUNT = forwardCount

            Log.d("settingOK is save : ", "[$facility ,$area, $bay ,$historyCount ,$forwardCount]")

            val resultIntent = Intent()
            setResult(RESULT_OK, resultIntent)

            val returnCode = OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_SETTING,
                "환경설정 정보가 저장 되었습니다", GetString.BTNOKSTR
            )

            if (returnCode == OkDialog.RETURN_CODE_OK) {
                val wifiIp = CommonUtil.wifiIpAddress(this@SettingActivity)
                if (wifiIp != null)
                    sendConfig(wifiIp)

                finish()
            }
        }
    }

    private suspend fun sendConfig(wifiIp: String) {
        val sendMessage = MessageFactoryUtil.config(
            DeviceInfo.FACILITY, DeviceInfo.AREA, DeviceInfo.BAY,
            DeviceInfo.DEVICE_NAME, wifiIp, DeviceInfo.OPERATOR_ID
        )

        val message =
            MessageSender.send(supportFragmentManager, sendMessage, MessageName.CONFIG)
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {

        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)

            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )
        }
    }

    private fun setEventSpinner() {
        viewBinding.spinnerFacility.setOnTouchListener(SpinnerTouchEvent(GetString.FACILITY))
        viewBinding.spinnerArea.setOnTouchListener(SpinnerTouchEvent(GetString.AREA))
        viewBinding.spinnerBay.setOnTouchListener(SpinnerTouchEvent(GetString.BAY))
    }

    // =========================================================================
    // ▼▼▼ 수정된 부분: onTouch가 true를 반환하여 시스템의 즉시-오픈 동작을 막음 ▼▼▼
    // =========================================================================
    private inner class SpinnerTouchEvent(var eventName: String) : View.OnTouchListener {

        override fun onTouch(v: View?, event: MotionEvent?): Boolean {
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    // [변경 전] 데이터 로드가 비동기로 진행되는 동안
                    //           시스템이 return false 때문에 드롭다운을 즉시 열어버려
                    //           옛 데이터(또는 빈 목록)가 먼저 보이는 문제가 있었음.

                    when (eventName) {
                        GetString.FACILITY -> {
                            initSpinner(SpinnerType.FACILITY)
                            initFacilitySpinner()
                        }
                        GetString.AREA -> {
                            if (viewBinding.spinnerFacility.selectedItem == null) {
                                okDialogFragment = OkDialogFragment(
                                    GetString.TXTDIALOGTITLE_WARNING,
                                    "PLEASE FACILITY", GetString.BTNOKSTR
                                )
                                okDialogFragment.show(supportFragmentManager, "DIALOG_CHECK_TAG")
                            } else {
                                initSpinner(SpinnerType.AREA)
                                initAreaSpinner(viewBinding.spinnerFacility.selectedItem.toString())
                            }
                        }
                        GetString.BAY -> {
                            if (viewBinding.spinnerFacility.selectedItem == null || viewBinding.spinnerArea.selectedItem == null) {
                                okDialogFragment = OkDialogFragment(
                                    GetString.TXTDIALOGTITLE_WARNING,
                                    "PLEASE AREA", GetString.BTNOKSTR
                                )
                                okDialogFragment.show(supportFragmentManager, "DIALOG_CHECK_TAG")
                            } else {
                                initSpinner(SpinnerType.BAY)
                                initBaySpinner(
                                    viewBinding.spinnerArea.selectedItem.toString(),
                                    viewBinding.spinnerFacility.selectedItem.toString()
                                )
                            }
                        }
                    }
                }
            }
            // [변경 후] true를 반환해서 "이 이벤트는 내가 직접 처리한다"고 시스템에 알림.
            //          -> 시스템의 즉시-드롭다운-오픈 동작이 발생하지 않음.
            //          -> 데이터가 준비된 뒤 performClick()으로 직접 열어줌.
            return true
        }
    }
    // =========================================================================
    // ▲▲▲ 수정 끝 ▲▲▲
    // =========================================================================

    private fun initFacilitySpinner() {
        // [변경] 중복 클릭 방지를 위해 로딩 중 비활성화
        viewBinding.spinnerFacility.isEnabled = false

        mainScope.launch {
            val sendMessage = MessageFactoryUtil.facility()

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.CONFINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val facilityListJSON =
                    ResponseDataToJsonUtil.getMessageBodyList(result, GetString.ITEMS)
                val spinnerFacilityItems = arrayListOf<String>()
                for (i in 0 until facilityListJSON.length()) {
                    val facility = facilityListJSON.getJSONObject(i)
                    spinnerFacilityItems.add(facility.getString(GetString.VALUE))
                }

                setFacilitySpinner(spinnerFacilityItems)
            } else {
                Log.d(TAG, "FACTORY DATA Empty!")
            }

            // [변경] 어댑터 세팅이 끝난 "이후"에 직접 드롭다운을 오픈
            viewBinding.spinnerFacility.isEnabled = true
            viewBinding.spinnerFacility.performClick()
        }
    }

    private fun setFacilitySpinner(items: ArrayList<String>) {
        //1. set spinner
        val spinnerAdapter =
            ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, items)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerFacility.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
    }

    private fun initAreaSpinner(facility: String) {
        // [변경] 로딩 중 중복 클릭 방지
        viewBinding.spinnerArea.isEnabled = false

        mainScope.launch {
            val sendMessage = MessageFactoryUtil.area(facility)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.CONFINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            val spinnerAreaItems = arrayListOf<String>()

            if (isSuccessFul) {
                val areaListJSON =
                    ResponseDataToJsonUtil.getMessageBodyList(result, GetString.ITEMS)

                for (i in 0 until areaListJSON.length()) {
                    val area = areaListJSON.getJSONObject(i)
                    spinnerAreaItems.add(area.getString(GetString.VALUE))
                }

            } else {
                Log.d(TAG, "AREA DATA Empty!")
                spinnerAreaItems.clear()
            }

            setAreaSpinner(spinnerAreaItems)

            // [변경] 데이터 세팅 후 직접 드롭다운 오픈 -> 한 번 클릭으로 최신 데이터 확인 가능
            viewBinding.spinnerArea.isEnabled = true
            viewBinding.spinnerArea.performClick()
        }
    }

    private fun setAreaSpinner(items: ArrayList<String>) {
        val spinnerAdapter =
            ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, items)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerArea.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
    }

    private fun initBaySpinner(area: String, facility: String) {
        // [변경] 로딩 중 중복 클릭 방지
        viewBinding.spinnerBay.isEnabled = false

        mainScope.launch {
            val sendMessage = MessageFactoryUtil.areaBayInfo(area, facility)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.AREABAYINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            val spinnerBayItems = arrayListOf<String>()
            if (isSuccessFul) {
                val checkString =
                    ResponseDataToJsonUtil.checkMessageBodyList(result, GetString.BAYS)

                if (checkString == GetString.JSONOBJECT) {
                    val bayObjectJSON =
                        ResponseDataToJsonUtil.getMessageBodyObject(result, GetString.BAYS)
                    val bay = bayObjectJSON.getString(GetString.BAY)
                    spinnerBayItems.add(bay)

                } else {
                    val bayListJSON =
                        ResponseDataToJsonUtil.getMessageBodyList(result, GetString.BAYS)

                    for (i in 0 until bayListJSON.length()) {
                        val bay = bayListJSON.getJSONObject(i)
                        spinnerBayItems.add(bay.getString(GetString.BAY))
                    }
                }
            } else {
                Log.d(TAG, "BAY DATA Empty!")
                spinnerBayItems.clear()
            }

            setBaySpinner(spinnerBayItems)

            // [변경] 데이터 세팅 후 직접 드롭다운 오픈
            viewBinding.spinnerBay.isEnabled = true
            viewBinding.spinnerBay.performClick()
        }
    }

    private fun setBaySpinner(items: ArrayList<String>) {
        val spinnerAdapter =
            ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, items)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerBay.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
    }

    // check SettingInfo DB
    private fun checkHistorySetting() {
        ioScope.launch {
            val settingInfo = settingInfoService.selectSettingInfo()
            if (settingInfo != null) {
                val facility = settingInfo.facility
                val area = settingInfo.area
                val bay = settingInfo.bay
                val historyCount = settingInfo.historyCount
                val forwardCount = settingInfo.forwardCount

                if (facility.isNotEmpty() && area.isNotEmpty() && bay.isNotEmpty()) {
                    mainScope.launch {
                        val spinnerFacilityItems = arrayListOf<String>()
                        val spinnerAreaItems = arrayListOf<String>()
                        val spinnerBayItems = arrayListOf<String>()

                        spinnerFacilityItems.add(facility)
                        spinnerAreaItems.add(area)
                        spinnerBayItems.add(bay)

                        val facilityAdapter = ArrayAdapter(
                            applicationContext,
                            R.layout.contact_spinner_row_init,
                            spinnerFacilityItems
                        )
                        facilityAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                        viewBinding.spinnerFacility.adapter = InitSpinnerAdapter(
                            facilityAdapter, R.layout.contact_spinner_row_init, applicationContext
                        )

                        val areaAdapter = ArrayAdapter(
                            applicationContext, R.layout.contact_spinner_row_init, spinnerAreaItems
                        )
                        areaAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                        viewBinding.spinnerArea.adapter = InitSpinnerAdapter(
                            areaAdapter, R.layout.contact_spinner_row_init, applicationContext
                        )

                        val bayAdapter = ArrayAdapter(
                            applicationContext, R.layout.contact_spinner_row_init, spinnerBayItems
                        )
                        bayAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                        viewBinding.spinnerBay.adapter = InitSpinnerAdapter(
                            bayAdapter, R.layout.contact_spinner_row_init, applicationContext
                        )

                        viewBinding.spinnerFacility.setSelection(1, false)
                        viewBinding.spinnerArea.setSelection(1, false)
                        viewBinding.spinnerBay.setSelection(1, false)

                        viewBinding.editHistoryCount.setText(historyCount.toString())
                        viewBinding.editForwardCount.setText(forwardCount.toString())

                        Log.d(TAG, "checkHistorySetting : $facility , $area , $bay")
                    }
                }

            }
        }

    }

    private fun initSpinner(type: SpinnerType) {
        when (type) {
            SpinnerType.FACILITY -> {
                viewBinding.spinnerArea.adapter = null
                viewBinding.spinnerBay.adapter = null
            }
            SpinnerType.AREA -> {
                viewBinding.spinnerBay.adapter = null
            }
            SpinnerType.BAY -> {
            }
        }
    }
}