package com.keyfoundry.hifos.view.shelf

import android.os.Bundle
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.TextView
import androidx.core.view.GestureDetectorCompat
import androidx.core.view.children
import androidx.core.view.setPadding
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.CTSubLayout
import com.keyfoundry.hifos.config.grid.GridType
import com.keyfoundry.hifos.config.service.RetrofitSyncService
import com.keyfoundry.hifos.config.service.dto.RequestData
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityShelfIncomingBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ShelfIncomingActivity : HFActivity() {
    companion object {
        private const val TAG = "ShelfIncomingActivity"
    }

    private lateinit var viewBinding: ActivityShelfIncomingBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var category = ""
    private var searchShelf = ""
    private val maxRowCount = 8
    private val maxColCount = 3
    private var baseWidth = 0

    inner class GestureListener(private val v: View) : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(e: MotionEvent?): Boolean {
            v.isSelected = !v.isSelected

            return super.onSingleTapUp(e)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityShelfIncomingBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editShelf.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editLotId.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        viewBinding.txtProductSpecName.movementMethod = ScrollingMovementMethod()
        viewBinding.txtOperationName.movementMethod = ScrollingMovementMethod()
        viewBinding.txtOperationDesc.movementMethod = ScrollingMovementMethod()

        val base = viewBinding.mainBody
        val vto: ViewTreeObserver = base.viewTreeObserver
        vto.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                base.viewTreeObserver.removeOnGlobalLayoutListener(this)
                baseWidth = base.width
            }
        })

        viewBinding.editShelf.setOnEditorActionListener(onEditorActionListener)
        viewBinding.editLotId.setOnEditorActionListener(onEditorActionListener)

        viewBinding.btnSearchShelf.setOnClickListener(onSingleClickListener)
        viewBinding.btnSearchLotNo.setOnClickListener(onSingleClickListener)
        viewBinding.btnDelete.setOnClickListener(onSingleClickListener)
        viewBinding.btnClose.setOnClickListener(onSingleClickListener)
        viewBinding.btnShelfIn.setOnClickListener(onSingleClickListener)
        viewBinding.btnShelfOut.setOnClickListener(onSingleClickListener)
        viewBinding.btnCartIn.setOnClickListener(onSingleClickListener)
        viewBinding.btnCartOut.setOnClickListener(onSingleClickListener)

        setShelfGrid()
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchShelf.id -> {
                    searchShelfInfo(viewBinding.editShelf.text.toString())
                }
                viewBinding.btnSearchLotNo.id -> {
                    setLotInfo(viewBinding.editLotId.text.toString())
                }
                viewBinding.btnDelete.id -> {
                    deleteLotId()
                }
                viewBinding.btnClose.id -> {
                    finish()
                }
                viewBinding.btnShelfIn.id -> {
                    executeIN()
                }
                viewBinding.btnShelfOut.id -> {
                    executeOUT("SHELF OUT")
                }
                viewBinding.btnCartIn.id -> {
                    executeIN()
                }
                viewBinding.btnCartOut.id -> {
                    executeOUT("CART OUT")
                }
            }
        }
    }

    private val onEditorActionListener = TextView.OnEditorActionListener { v, actionId, event ->
        if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
            when (v.id) {
                viewBinding.editShelf.id -> {
                    searchData(viewBinding.editShelf)
                }
                viewBinding.editLotId.id -> {
                    searchData(viewBinding.editLotId)
                }
            }
        } else if (event != null) { // Barcode Event
            if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                when (v.id) {
                    viewBinding.editShelf.id -> {
                        searchData(viewBinding.editShelf)
                    }
                    viewBinding.editLotId.id -> {
                        searchData(viewBinding.editLotId)
                    }
                }
            }
        }

        true
    }

    private fun clearShelfGrid() {
        viewBinding.mainBody.removeAllViews()
        setShelfGrid()
    }

    private fun searchData(focusEditText: EditText) {
        CommonUtil.hideKeyboard(this, currentFocus)

        if (focusEditText.text.isEmpty()) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "조회할 정보가 없습니다.", GetString.BTNOKSTR
            )

            viewBinding.editShelf.requestFocus()
            viewBinding.editShelf.selectAll()
            return
        }

        val focusText = focusEditText.text.toString()
        val searchId = focusText.substring(0, focusText.length - 1)

        if (searchId.startsWith("EQP-$") || searchId.startsWith("eqp-$")) {
            clearShelfGrid()

            val shelfId = searchId.substring(4, searchId.length)
            viewBinding.editShelf.setText(shelfId)
            viewBinding.editLotId.setText("")
            searchShelfInfo(shelfId)

            viewBinding.editLotId.requestFocus()
            viewBinding.editLotId.selectAll()
        } else if (searchId == "SHELF IN" || searchId == "CART IN" || searchId == "SHELF OUT" || searchId == "CART OUT") {
            if (category.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "Shelf No가 확인되지 않았습니다!", GetString.BTNOKSTR
                )

                viewBinding.editShelf.requestFocus()
                viewBinding.editShelf.selectAll()
                return
            }

            if (category == "S" && searchId.contains("CART")) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "SHELF를 선택 후 CART 기능을 시도하셨습니다.", GetString.BTNOKSTR
                )

                return
            } else if (category == "C" && searchId.contains("SHELF")) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "CART를 선택 후 SHELF 기능을 시도하셨습니다.", GetString.BTNOKSTR
                )

                return
            }

            if (searchId == "SHELF IN" || searchId == "CART IN")
                executeIN()
            else if (searchId == "SHELF OUT" || searchId == "CART OUT")
                executeOUT(searchId)

            if (focusEditText == viewBinding.editShelf)
                viewBinding.editShelf.setText(
                    viewBinding.editShelf.text.toString().replace(focusText, "")
                )
            else if (focusEditText == viewBinding.editLotId)
                viewBinding.editLotId.setText("")
        } else if (searchId.startsWith(" ")) {
            val lotId = searchId.substring(1, searchId.length)

            if (category.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "Shelf No가 확인되지 않았습니다!", GetString.BTNOKSTR
                )

                viewBinding.editShelf.setText("")
                viewBinding.editLotId.setText("")
                viewBinding.editShelf.requestFocus()
                viewBinding.editShelf.selectAll()
                return
            }

            viewBinding.editShelf.setText(searchShelf)
            viewBinding.editLotId.setText(lotId)
            setLotInfo(lotId)

            viewBinding.editLotId.requestFocus()
            viewBinding.editLotId.selectAll()
        } else {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "입력된 정보를 확인하세요", GetString.BTNOKSTR
            )

            viewBinding.editShelf.requestFocus()
            viewBinding.editShelf.selectAll()
        }
    }

    private fun clearShelfInfo() {
        category = ""
        searchShelf = ""

        viewBinding.btnShelfIn.isEnabled = false
        viewBinding.btnShelfOut.isEnabled = false
        viewBinding.btnCartIn.isEnabled = false
        viewBinding.btnCartOut.isEnabled = false
    }

    private fun clearLotInfo() {
        viewBinding.txtProductSpecName.text = ""
        viewBinding.txtOperationName.text = ""
        viewBinding.txtOperationDesc.text = ""
        clearSelectedCell()
    }

    private fun clearAll() {
        viewBinding.editShelf.setText("")
        viewBinding.editLotId.setText("")
        clearShelfInfo()
        clearLotInfo()
        clearShelfGrid()
        viewBinding.editShelf.requestFocus()
    }

    private fun clearSelectedCell() {
        if (viewBinding.mainBody.childCount > 0) {
            val mainLayout = viewBinding.mainBody.getChildAt(0) as CTMainLayout
            val mainTable = mainLayout.mainTable

            for (row in mainTable.children) {
                val tableRow = row as CTRowLayout

                for (cell in tableRow.children) {
                    val cellView = cell as TextView
                    cellView.isSelected = false
                }
            }
        }
    }

    private fun searchShelfInfo(shelfId: String) {
        mainScope.launch {
            clearShelfInfo()

            if (shelfId.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "SHELF NO 를 입력하세요.", GetString.BTNOKSTR
                )

                viewBinding.editShelf.requestFocus()
                viewBinding.editShelf.selectAll()
                return@launch
            }

            val sendMessage = MessageFactoryUtil.shelfCall(shelfId)
            val result = RetrofitSyncService.API.hifosProcess(RequestData(sendMessage))

            val isSuccessFul = ResponseDataToJsonUtil.isSuccessFul(result)
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                category = messageBody.optString("CATEGORY")
                searchShelf = shelfId
                //CString tempstr= FIND_VALUE_STRING(pBodyList,L"MAXPOSITION") ;
                //m_MaxPosition =  _wtoi(tempstr);

                if (category == "S") {
                    viewBinding.btnShelfIn.isEnabled = true
                    viewBinding.btnShelfOut.isEnabled = true
                } else if (category == "C") {
                    viewBinding.btnCartIn.isEnabled = true
                    viewBinding.btnCartOut.isEnabled = true
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editShelf.requestFocus()
                viewBinding.editShelf.selectAll()
            }
        }
    }

    private fun setLotInfo(lotId: String) {
        mainScope.launch {
            clearLotInfo()

            if (lotId.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT NO를 입력하세요", GetString.BTNOKSTR
                )

                viewBinding.editLotId.requestFocus()
                viewBinding.editLotId.selectAll()
                return@launch
            }

            var emptyCheck = false
            val mainLayout = viewBinding.mainBody.getChildAt(0) as CTMainLayout
            val mainTable = mainLayout.mainTable

            for (row in mainTable.children) {
                val tableRow = row as CTRowLayout

                for (cell in tableRow.children) {
                    val cellView = cell as TextView
                    if (cellView.text == lotId) {
                        OkDialog.show(
                            supportFragmentManager, "중 복",
                            "이미 같은  Lot이 선택 되었습니다.", GetString.BTNOKSTR
                        )

                        viewBinding.editLotId.requestFocus()
                        viewBinding.editLotId.selectAll()
                        return@launch
                    }

                    if (cellView.text.isEmpty())
                        emptyCheck = true
                }
            }

            if (!emptyCheck) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT 수량을 초과했습니다.", GetString.BTNOKSTR
                )

                viewBinding.editLotId.requestFocus()
                viewBinding.editLotId.selectAll()
                return@launch
            }

            val sendMessage = MessageFactoryUtil.checkShelfLot(lotId, DeviceInfo.FACILITY)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.CHECKINSHELFLOT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val productSpecName = messageBody.optString("PRODUCTSPECNAME")
                val processOperationName = messageBody.optString("PROCESSOPERATIONNAME")
                val operationDesc = messageBody.optString("OPERATIONDESCRIPTION")
                val machine = messageBody.optString("MACHINENAME")
                val lotResUser = messageBody.optString("LOTRESUSER")
                val bayName = messageBody.optString("BAYNAME")

                if (machine != "" && lotResUser != "") {
                    val msg = """
                        |$lotId 은(는) $machine 호기에 자동화 예약중인 LOT 입니다.
                        |$bayName BAY로 이동 및 진행 상태 확인 하세요.
                    """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
                        msg, GetString.BTNOKSTR
                    )

                    viewBinding.editLotId.requestFocus()
                    viewBinding.editLotId.selectAll()
                }

                viewBinding.txtProductSpecName.text = productSpecName
                viewBinding.txtOperationName.text = processOperationName
                viewBinding.txtOperationDesc.text = operationDesc

                setLotIdInGrid(lotId)

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "입고가 불가능한 LOT 입니다.", GetString.BTNOKSTR
                )

                viewBinding.editLotId.requestFocus()
                viewBinding.editLotId.selectAll()

            }
        }
    }

    private fun setLotIdInGrid(lotId: String) {
        val mainGrid = viewBinding.mainBody.getChildAt(0) as CTMainLayout
        val mainTable = mainGrid.mainTable

        for (col in 0 until maxColCount) {
            for (row in 0 until maxRowCount) {
                val dataRow = mainTable.getChildAt(row) as CTRowLayout
                val dataCell = dataRow.getChildAt(col) as TextView

                if (dataCell.text.isEmpty()) {
                    dataCell.text = lotId
                    return
                }
            }
        }
    }

    private fun setShelfGrid() {
        mainScope.launch {
            val width = baseWidth.div(maxColCount)

            val bodyLayout = CTMainLayout(this@ShelfIncomingActivity)

            val columnHeaderList = CTSubLayout(this@ShelfIncomingActivity, GridType.COLUMN_GRID)
            val rowHeaderList = CTSubLayout(this@ShelfIncomingActivity, GridType.ROW_GRID)
            val mainBodyList = CTSubLayout(this@ShelfIncomingActivity, GridType.MAIN_GRID)
            val cornerHeaderList = CTSubLayout(this@ShelfIncomingActivity, GridType.CORNER_GRID)

            for (row in 0 until maxRowCount) {
                val mainBodyRow = CTRowLayout(this@ShelfIncomingActivity)
                val rowHeaderRow = CTRowLayout(this@ShelfIncomingActivity)
                val columnHeaderRow = CTRowLayout(this@ShelfIncomingActivity)

                for (col in 0 until maxColCount) {
                    if (columnHeaderList.childCount < 1) {
                        val colHeaderItem = TextView(this@ShelfIncomingActivity)
                        colHeaderItem.height = 0
                        columnHeaderRow.addView(colHeaderItem)
                    }

                    val mainBodyItem = TextView(this@ShelfIncomingActivity)
                    mainBodyItem.gravity = Gravity.CENTER
                    mainBodyItem.setPadding(10)
                    mainBodyItem.setBackgroundResource(R.drawable.shelf_lot_selected)
                    mainBodyItem.isClickable = true
                    mainBodyItem.isFocusableInTouchMode = true

                    val mDetector = GestureDetectorCompat(
                        this@ShelfIncomingActivity,
                        GestureListener(mainBodyItem)
                    )

                    mainBodyItem.setOnTouchListener { v, event ->
                        mDetector.onTouchEvent(event)

                        if (event.action == MotionEvent.ACTION_UP) {
                            viewBinding.editLotId.requestFocus()
                            viewBinding.editLotId.selectAll()
                        }

                        true
                    }

                    mainBodyItem.width = width

                    mainBodyRow.addView(mainBodyItem)
                }
                mainBodyList.addView(mainBodyRow)

                val rowHeaderItem = TextView(this@ShelfIncomingActivity)
                rowHeaderRow.addView(rowHeaderItem)
                rowHeaderList.addView(rowHeaderRow)

                if (columnHeaderList.childCount < 1) {
                    columnHeaderList.addView(columnHeaderRow)
                }
            }

            for (col in 0 until columnHeaderList.childCount) {
                val cornerHeaderRow =
                    CTRowLayout(this@ShelfIncomingActivity)

                for (row in 0 until rowHeaderList.childCount) {
                    val cornerItem = TextView(this@ShelfIncomingActivity)
                    cornerItem.height = 0
                    cornerHeaderRow.addView(cornerItem)
                }

                cornerHeaderList.addView(cornerHeaderRow)
            }

            bodyLayout.addViews(mainBodyList, columnHeaderList, rowHeaderList, cornerHeaderList)

            viewBinding.mainBody.addView(bodyLayout)
        }
    }

    private fun deleteLotId() {
        val mainLayout = viewBinding.mainBody.getChildAt(0) as CTMainLayout
        val mainTable = mainLayout.mainTable

        for (row in mainTable.children) {
            val tableRow = row as CTRowLayout

            for (cell in tableRow.children) {
                val cellView = cell as TextView
                if (cellView.isSelected && cellView.text.isNotEmpty()) {
                    cellView.text = ""
                    cellView.isSelected = false
                }
            }
        }

        viewBinding.editLotId.requestFocus()
        viewBinding.editLotId.selectAll()
    }

    private fun executeIN() {
        mainScope.launch {
            var insertLot = ""

            val mainGrid = viewBinding.mainBody.getChildAt(0) as CTMainLayout
            val mainTable = mainGrid.mainTable

            for (col in 0 until maxColCount) {
                for (row in 0 until maxRowCount) {
                    val dataRow = mainTable.getChildAt(row) as CTRowLayout
                    val dataCell = dataRow.getChildAt(col) as TextView

                    if (dataCell.text.isNotEmpty()) {
                        if (insertLot.isEmpty())
                            insertLot = dataCell.text.toString()
                        else
                            insertLot += "|${dataCell.text}"
                    }
                }
            }

            if (insertLot.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT을 입력하여 주세요.", GetString.BTNOKSTR
                )

                viewBinding.editLotId.requestFocus()
                viewBinding.editLotId.selectAll()
                return@launch
            }

            val sendMessage = MessageFactoryUtil.lotInShelf(
                insertLot, viewBinding.editShelf.text.toString(), DeviceInfo.OPERATOR_ID
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINSHELF)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val errorLot = messageBody.optString("ERRORLOT")

                //if(ErrorLot.Find( _T("MASK02") ) > 1 )
                //	MessageBox( L"TEST02" ,L"완료.",MB_OK | MB_ICONEXCLAMATION);

                if (errorLot.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorLot, GetString.BTNOKSTR
                    )
                }
                //else
                //	MessageBox( L"처리 완료.",L"완료.",MB_OK | MB_ICONEXCLAMATION);

                clearAll()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun executeOUT(commandType: String) {
        mainScope.launch {
            var insertLot = ""

            val mainGrid = viewBinding.mainBody.getChildAt(0) as CTMainLayout
            val mainTable = mainGrid.mainTable

            for (col in 0 until maxColCount) {
                for (row in 0 until maxRowCount) {
                    val dataRow = mainTable.getChildAt(row) as CTRowLayout
                    val dataCell = dataRow.getChildAt(col) as TextView

                    if (dataCell.text.isNotEmpty()) {
                        if (insertLot.isEmpty())
                            insertLot = dataCell.text.toString()
                        else
                            insertLot += "|${dataCell.text}"
                    }
                }
            }

            if (insertLot.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT을 입력하여 주세요.", GetString.BTNOKSTR
                )

                viewBinding.editLotId.requestFocus()
                viewBinding.editLotId.selectAll()
                return@launch
            }

            val sendMessage = MessageFactoryUtil.lotOutShelf(
                insertLot,
                commandType,
                viewBinding.editShelf.text.toString(),
                DeviceInfo.OPERATOR_ID
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTOUTSHELF)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val errorLot = messageBody.optString("ERRORLOT")

                if (errorLot.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorLot, GetString.BTNOKSTR
                    )
                }
                //	else
                //		MessageBox( L"처리 완료.",L"완료.",MB_OK | MB_ICONEXCLAMATION);

                clearAll()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editLotId.requestFocus()
                viewBinding.editLotId.selectAll()
            }
        }
    }
}