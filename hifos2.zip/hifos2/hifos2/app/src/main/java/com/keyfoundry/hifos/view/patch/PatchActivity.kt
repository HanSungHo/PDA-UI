package com.keyfoundry.hifos.view.patch

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.Window
import androidx.appcompat.app.AppCompatActivity
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.keyfoundry.hifos.config.service.update.DownloadProgress
import com.keyfoundry.hifos.config.service.update.DownloadService
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivityPatchBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers

class PatchActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "PatchActivity"
    }

    lateinit var viewBinding: ActivityPatchBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val io = CoroutineScope(Dispatchers.IO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setFinishOnTouchOutside(false)

        viewBinding = ActivityPatchBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        registerReceiver()

        val patchText = """
            |새로운 HiFOS 버전이 있습니다.
            |다운로드 후 진행 하세요.
        """.trimMargin()

        viewBinding.txtPatchText.text = patchText
        viewBinding.btnDownload.setOnClickListener(singleClickListener)
    }


    private val singleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it) {
                viewBinding.btnDownload -> executeDownLoad()
            }
        }
    }

    private fun executeDownLoad() {
        viewBinding.btnDownload.isEnabled = false
        val intent = Intent(applicationContext, DownloadService::class.java)
        startService(intent)
    }

    private fun registerReceiver() {
        Log.e(TAG, "registerReceiver")
        val bManager = LocalBroadcastManager.getInstance(this)
        val intentFilter = IntentFilter()
        intentFilter.addAction("message_progress")
        bManager.registerReceiver(broadcastReceiver, intentFilter)
    }

    private val broadcastReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == "message_progress") {
                val downloadProgress: DownloadProgress? = intent.getParcelableExtra("download")

                if (downloadProgress != null) {
                    viewBinding.progressBar.incrementProgressBy(downloadProgress.progress.toInt())

//                    if (!viewBinding.btnDownload.isEnabled && downloadProgress.progress == 100.0)
//                        viewBinding.btnDownload.isEnabled = true
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()

        if (!viewBinding.btnDownload.isEnabled ) {
            viewBinding.progressBar.progress = 100
            viewBinding.btnDownload.text = "INSTALL"
            viewBinding.btnDownload.isEnabled = true
        }
    }

    override fun onBackPressed() {
        return
    }
}