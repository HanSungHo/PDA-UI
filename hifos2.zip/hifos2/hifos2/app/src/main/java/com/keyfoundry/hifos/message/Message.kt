package com.keyfoundry.hifos.message

import com.keyfoundry.hifos.config.service.dto.ResponseData

/*
* 모바일 서버로부터 받은 메시지를 Status에 따라 사용하기 위한 Class
* */
data class Message(
    var result: ResponseData,
    var isSuccessFul: Boolean
)