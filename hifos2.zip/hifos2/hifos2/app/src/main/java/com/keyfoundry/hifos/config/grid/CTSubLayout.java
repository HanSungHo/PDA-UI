package com.keyfoundry.hifos.config.grid;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;

import androidx.annotation.Nullable;

public class CTSubLayout extends TableLayout {

    private int currentRowIndex = 0;
    private String tableType = "";

    public int getCurrentRowIndex() {
        return currentRowIndex;
    }

    public void setCurrentRowIndex(int value) {
        currentRowIndex = value;
    }

    public CTSubLayout(Context context, String tableType) {
        super(context);
        this.tableType = tableType;
    }

    public CTSubLayout(Context context, @Nullable AttributeSet attrs, String tableType) {
        super(context, attrs);
        this.tableType = tableType;
    }

    @Override
    public void addView(View child, int index, ViewGroup.LayoutParams params) {
        if (child instanceof CTRowLayout) {
            super.addView(child, index, params);

            try {
                if (this.getParent() != null && this.tableType.equals("MAIN")) {
                    CTRowLayout rowChild = (CTRowLayout) child;
                    int measureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);
                    rowChild.measure(measureSpec, measureSpec);

                    CTMainLayout parentLayout = (CTMainLayout) this.getParent();
                    LayoutBound parentBound = parentLayout.getBound();

//                    parentBound.setRightBound(parentBound.getRightBound() + rowChild.getMeasuredWidth());
                    parentBound.setBottomBound(parentBound.getBottomBound() + rowChild.getMeasuredHeight());
                }
            } catch (Exception e) {

            }

        } else {
            throw new UnsupportedOperationException("Adding non TestFixedHeaderRow children is not supported");
        }
    }

    @Override
    public void removeAllViews() {
        super.removeAllViews();

        try {
            if (this.getParent() != null && this.tableType.equals("MAIN")) {
                CTMainLayout parentLayout = (CTMainLayout) this.getParent();
                CTSubLayout columnLayout = parentLayout.getColumnHeaderTable();

                LayoutBound parentBound = parentLayout.getBound();

                parentBound.setBottomBound(columnLayout.getMeasuredHeight());
            }
        } catch (Exception e) {

        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        // Always measure the tables to full size so pan and Scale works
        int measureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);
        super.onMeasure(measureSpec, measureSpec);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        try {
            if (this.getParent() != null) {
                CTMainLayout parentLayout = (CTMainLayout) this.getParent();
                parentLayout.setCurrentTable(this.tableType);
            }
        } catch (Exception e) {

        }

        return super.dispatchTouchEvent(ev);
    }
}

