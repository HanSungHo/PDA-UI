package com.keyfoundry.hifos.view.esheet.moveout

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivityWaferSkipBinding
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import org.json.JSONArray

class WaferSkipActivity : HFActivity() {
    init {
        this.update = false
    }

    companion object {
        private const val TAG = "WaferSkipActivity"
    }

    private lateinit var viewBinding : ActivityWaferSkipBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityWaferSkipBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        var spinnerReasonItems = arrayListOf<String>()

        val waferQty = intent.getStringExtra("WAFERQTY").toString()
        val machineQty = intent.getStringExtra("MACHINEQTY").toString()
        val reason = intent.getStringExtra("REASONLIST").toString()

        val reasonList = JSONArray(reason)

        viewBinding.txtLotQty.setText(waferQty)
        viewBinding.txtMachineQty.setText(machineQty)

        for (i in 0 until reasonList.length()) {
            if(i>10){
                break
            }
            val area = reasonList.getJSONObject(i)
            spinnerReasonItems.add(area.optString("TYPEVALUE"))
        }
        setReasonSpinner(spinnerReasonItems)

        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
            }
        })

        viewBinding.btnQtyCorrect.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                if(conditionCheck()) {
                    val sMinus = if (viewBinding.checkboxMinus.isChecked) "MINUS" else ""
                    val reason = viewBinding.spinnerReason.selectedItem?.toString()
                    val returnIntent = Intent(applicationContext, MoveOutActivity::class.java)
                    returnIntent.putExtra("SKIPWAFER", viewBinding.editAddedQty.text.toString())
                    returnIntent.putExtra("SMINUS", sMinus)
                    returnIntent.putExtra("REASON", reason)
                    setResult(Activity.RESULT_OK, returnIntent)
                    finish()
                }
            }
        })
    }

    private fun conditionCheck() : Boolean {
        if(viewBinding.spinnerReason.selectedItem?.toString().isNullOrBlank())
        {
            val returnCode = OkDialog.show(supportFragmentManager
                , "필수 입력"
                , "수량 보정 사유를 선택 하세요 "
                , GetString.BTNOKSTR)

            return false
        }

        if(viewBinding.editAddedQty.text?.toString().isNullOrEmpty())
        {
            val returnCode = OkDialog.show(supportFragmentManager
                , "필수 입력"
                , "추가 진행 QTY를 입력 하세요."
                , GetString.BTNOKSTR)

            return false
        }

        var iProductQty = 0.0
        var iAutoQty = 0.0
        var iWaferQty = 0.0


         iProductQty = viewBinding.txtLotQty.text?.toString()!!.toDouble()
         iAutoQty = viewBinding.txtMachineQty.text?.toString()!!.toDouble()
         iWaferQty = viewBinding.editAddedQty.text?.toString()!!.toDouble()

       // val ss = Integer.getInteger(viewBinding.txtLotQty.text?.toString())
        //Integer.parseInt

        if(viewBinding.checkboxMinus.isChecked)
        {
            if( iAutoQty - iWaferQty != iProductQty)
            {
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , "입력한 추가진행 수량이 올바르지 않습니다. \n 추가 진행 QTY를 다시 입력 하세요."
                    , GetString.BTNOKSTR)

                viewBinding.editAddedQty.setText("")
                return false
            }
        }
        else
        {
            if(iWaferQty + iAutoQty != iProductQty)
            {
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , "입력한 추가진행 수량이 올바르지 않습니다. \n 추가 진행 QTY를 다시 입력 하세요."
                    , GetString.BTNOKSTR)

                viewBinding.editAddedQty.setText("")
                return false
            }
        }

        return true
    }


    private fun setReasonSpinner(items : ArrayList<String>){
        //1. set spinner
        val myAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        viewBinding.spinnerReason.adapter = myAdapter
        viewBinding.spinnerReason.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }
    }
}