package com.keyfoundry.hifos.config.domain

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/*
* 안드로이드 내부 DB 로그인 사용자 정보 Table
* */
@Entity(tableName = "user_info")
class UserInfo {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo
    var no: Long? = null

    @ColumnInfo
    var operId: String = ""

    @ColumnInfo
    var operName: String = ""

    @ColumnInfo
    var facility: String = ""

    @ColumnInfo
    var area: String = ""

    @ColumnInfo
    var bay: String = ""

    @ColumnInfo
    var permission : String = ""

    @ColumnInfo
    var loginState : Boolean = false

    @ColumnInfo(name = "date")
    var regTime: Long = 0

    constructor(operId : String,operName : String
                , facility : String, area : String
                , bay : String, permission: String, loginState:Boolean, regTime: Long) {
        this.operId = operId
        this.operName = operName
        this.facility = facility
        this.area = area
        this.bay = bay
        this.permission = permission
        this.loginState = loginState
        this.regTime = regTime
    }
}