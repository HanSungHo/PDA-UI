package com.keyfoundry.hifos.view.chat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.utils.CommonUtil

class MessageAdapter(
    private val messages: List<Message>,
    private val myId: String
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val VIEW_MY = 1
    private val VIEW_OTHER = 2

    override fun getItemViewType(position: Int): Int {
        return if (messages[position].senderIp == CommonUtil.getLocalIpAddress())
            VIEW_MY
        else
            VIEW_OTHER
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        return if (viewType == VIEW_MY) {

            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_message_my, parent, false)

            MyHolder(view)

        } else {

            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_message_others, parent, false)

            OtherHolder(view)
        }
    }

    override fun getItemCount() = messages.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        val msg = messages[position]

        if (holder is MyHolder) {
            holder.text.text = msg.text
            holder.time.text = msg.time

            // 🔥 복사 기능 추가
            holder.text.setOnLongClickListener { view ->
                showCopyPopup(view, msg.text)
                true
            }
        }

        if (holder is OtherHolder) {
            holder.text.text = msg.text
            holder.time.text = msg.time

            if (msg.type == "HIGH") {
                holder.text.setTextColor(Color.RED)
            } else {
                holder.text.setTextColor(Color.BLACK)
            }

            // 🔥 복사 기능 추가
            holder.text.setOnLongClickListener { view ->
                showCopyPopup(view, msg.text)
                true
            }
        }


    }

    class MyHolder(v: View) : RecyclerView.ViewHolder(v) {
        val text: TextView = v.findViewById(R.id.myMessage)
        val time: TextView = v.findViewById(R.id.myTime)
    }

    class OtherHolder(v: View) : RecyclerView.ViewHolder(v) {
        val text: TextView = v.findViewById(R.id.otherMessage)
        val time: TextView = v.findViewById(R.id.otherTime)
    }

    private fun showCopyPopup(view: View, text: String) {
        val context = view.context

        val popup = PopupMenu(context, view)
        popup.menu.add("복사")

        popup.setOnMenuItemClickListener {

            val clipboard =
                context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

            val clip = ClipData.newPlainText("message", text)
            clipboard.setPrimaryClip(clip)

            Toast.makeText(context, "복사되었습니다", Toast.LENGTH_SHORT).show()
            true
        }

        popup.show()
    }
}