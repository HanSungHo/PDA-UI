package com.keyfoundry.hifos.config.service.udp

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import androidx.core.app.NotificationCompat
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.view.chat.AlarmCommonActivity
import com.keyfoundry.hifos.view.dialog.*


class UDPReceiver : BroadcastReceiver() {
    companion object {
        private const val TAG = "UDPReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        // This method is called when the BroadcastReceiver is receiving an Intent broadcast.
        val receiverLevel = intent.getStringExtra(DeviceInfo.UDP_RECEIVER_LEVEL)
        val receiverMessage = intent.getStringExtra(DeviceInfo.UDP_RECEIVER_MESSAGE)
        val roomName = intent.getStringExtra("ROOMNAME")


        Log.d(TAG, "receiver Level : $receiverLevel")
        Log.d(TAG, "receiver message : $receiverMessage")

        if (receiverLevel == GetString.MESSAGE_HIGH_LEVEL) {
            if (receiverMessage != null) if (receiverMessage.contains("<EVENT_TYPE>MDSSPC</EVENT_TYPE>")) {
                val notificationIntent = Intent(context, MDSspcActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                notificationIntent.action = "Message Receive : " + System.currentTimeMillis()
                notificationIntent.putExtra(DeviceInfo.UDP_RECEIVER_MESSAGE, receiverMessage)
                context.startActivity(notificationIntent)
            } else if (receiverMessage != null) if (receiverMessage.contains("<EVENT_TYPE>EQPSPC</EVENT_TYPE>")) {
                val notificationIntent = Intent(context, EQPspcActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                notificationIntent.action = "Message Receive : " + System.currentTimeMillis()
                notificationIntent.putExtra(DeviceInfo.UDP_RECEIVER_MESSAGE, receiverMessage)
                context.startActivity(notificationIntent)

            } else if (receiverMessage != null) if (receiverMessage.contains("<EVENT_TYPE>RECIPE</EVENT_TYPE>")) {
                val notificationIntent =
                    Intent(context, RecipeInterlockActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                notificationIntent.action = "Message Receive : " + System.currentTimeMillis()
                notificationIntent.putExtra(DeviceInfo.UDP_RECEIVER_MESSAGE, receiverMessage)
                context.startActivity(notificationIntent)
            } else if (receiverMessage != null) if (receiverMessage.contains("<EVENT_TYPE>STEPPERIDLE</EVENT_TYPE>")) {
                val notificationIntent = Intent(context, StepperIDLEActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                notificationIntent.action = "Message Receive : " + System.currentTimeMillis()
                notificationIntent.putExtra(DeviceInfo.UDP_RECEIVER_MESSAGE, receiverMessage)
                context.startActivity(notificationIntent)

            } else if (receiverMessage != null) if (receiverMessage.contains("<EVENT_TYPE>PR_EMPTY</EVENT_TYPE>")) {
                val notificationIntent = Intent(context, PREmptyActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                notificationIntent.action = "Message Receive : " + System.currentTimeMillis()
                notificationIntent.putExtra(DeviceInfo.UDP_RECEIVER_MESSAGE, receiverMessage)
                context.startActivity(notificationIntent)
            } else if (receiverMessage != null) if (receiverMessage.contains("<EVENT_TYPE>FDC</EVENT_TYPE>")) {
                if (receiverMessage.contains("<FDC_PROCESS_TYPE>ETCH_EMAX_LL_FDC</FDC_PROCESS_TYPE>")
                    && receiverMessage.contains("<PARAMETER>LOT_END</PARAMETER>")
                ) {
                    val notificationIntent = Intent(context, EMax_Activity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    notificationIntent.action = "Message Receive : " + System.currentTimeMillis()
                    notificationIntent.putExtra(DeviceInfo.UDP_RECEIVER_MESSAGE, receiverMessage)
                    context.startActivity(notificationIntent)
                } else {
                    //Log.d("UDP", "Receiver message does not match conditions: $receiverMessage")
                    return
                }
            }
            else
            {
                if(roomName == null || roomName == "") {
                    val notificationIntent = Intent(context, NotificationActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    notificationIntent.action = "Message Receive : " + System.currentTimeMillis()
                    notificationIntent.putExtra(DeviceInfo.UDP_RECEIVER_MESSAGE, receiverMessage)

                    context.startActivity(notificationIntent)
                }
                else {
                    val notificationIntent =
                        Intent(context, AlarmCommonActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                    notificationIntent.action = "Message Receive : " + System.currentTimeMillis()
                    notificationIntent.putExtra(DeviceInfo.UDP_RECEIVER_MESSAGE, receiverMessage)
                    notificationIntent.putExtra("ROOMNAME", roomName)

                    context.startActivity(notificationIntent)
                }
            }

            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            val vibratorTime = longArrayOf(200, 400, 200, 400)
            vibrator.vibrate(
                VibrationEffect.createWaveform(vibratorTime, VibrationEffect.DEFAULT_AMPLITUDE)
            )
        } else {
        //    sendNotification(context, receiverMessage.toString())
        }
    }



    private fun sendNotification(context: Context, receiverMessage: String) {
        try {
            val intent = Intent(context, NotificationActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            }
            intent.action = "Message Receive : " + System.currentTimeMillis()
            intent.putExtra(DeviceInfo.UDP_RECEIVER_MESSAGE, receiverMessage)

            val pendingIntent: PendingIntent =
                PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)

            val builder =
                getNotificationBuilder(
                    DeviceInfo.UDP_NOTI_CHANEL_ID, DeviceInfo.UDP_NOTI_CHANEL_NAME, context
                )
                    .setSmallIcon(R.drawable.ic_baseline_message_24)
                    .setContentTitle(DeviceInfo.UDP_NOTI_CONTENT_TITLE)
                    .setContentText(receiverMessage)
                    .setGroupSummary(true)
                    .setAutoCancel(true)
                    .setContentIntent(pendingIntent)

            val manager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(System.currentTimeMillis().toInt(), builder.build())
        } catch (e: Exception) {
            Log.e(UDPReceiver.TAG, "${e.message}")
        }
    }

    // 안드로이드 8.0 이상과 미만 버전에 대응하기 위해 채널을 설정하는 메서드
    private fun getNotificationBuilder(id: String, name: String, context: Context)
            : NotificationCompat.Builder {
        // os 버전별로 분기
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {         // 안드로이드 8.0 이상이라면
            val channel = NotificationChannel(id, name, NotificationManager.IMPORTANCE_HIGH)
            channel.enableLights(true)
            channel.lightColor = Color.RED
            channel.enableVibration(true)

            val manager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)

            return NotificationCompat.Builder(context, id)

        } else {
            return NotificationCompat.Builder(context)

        }
    }

}