package com.keyfoundry.hifos.config.service.room

import android.content.Context
import com.keyfoundry.hifos.config.dao.UserInfoDao
import com.keyfoundry.hifos.config.domain.UserInfo
import com.keyfoundry.hifos.config.service.HifosDBHelper

class UserInfoService {
    lateinit var db : HifosDBHelper
    lateinit var userInfoDao: UserInfoDao

    constructor(context: Context){
        db = HifosDBHelper.getInstance(context)!!
        userInfoDao = db.userInfoDao()
    }

    suspend fun insert(userInfo: UserInfo){
        //1. delete
        userInfoDao.deleteAll()

        //2. insert
        userInfoDao.insert(userInfo)
    }

    fun selectAll(): List<UserInfo> {
        return userInfoDao.getAll()
    }

    suspend fun selectUserInfo(): UserInfo? {
        return userInfoDao.getUserInfo()
    }

    fun checkLoginState(): Boolean {
        return userInfoDao.checkLoginState()
    }

    fun logOut() {
        userInfoDao.logOut()
    }


}