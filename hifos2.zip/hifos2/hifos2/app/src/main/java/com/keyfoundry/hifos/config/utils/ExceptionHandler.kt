package com.keyfoundry.hifos.config.utils

import android.util.Log
import com.keyfoundry.hifos.BuildConfig
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.service.RetrofitSyncService
import com.keyfoundry.hifos.config.service.dto.ErrorData
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.ESheetActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.system.exitProcess

/*
* Exception이 발생할 경우 모바일 서버로 Error 내용을 전송
* */
class ExceptionHandler(val currentActivity:String) : Thread.UncaughtExceptionHandler {
    override fun uncaughtException(t: Thread, e: Throwable) {

        var sendMessage =""
        sendMessage += "Activity  : $currentActivity\n"
        sendMessage += "PDA 명     : ${DeviceInfo.DEVICE_NAME}\n"
        sendMessage += "HiFOS Version   : ${BuildConfig.VERSION_NAME}\n"
        sendMessage += "사용자 ID  : ${DeviceInfo.OPERATOR_ID}\n"
        sendMessage += "FACILITY  : ${DeviceInfo.FACILITY}\n"
        sendMessage += "AREA      : ${DeviceInfo.AREA}\n"
        sendMessage += "BAY       : ${DeviceInfo.BAY}\n"
        sendMessage += "=================================================================================================\n"
        sendMessage += e.stackTraceToString()
        sendMessage += "=================================================================================================\n\n"

        CoroutineScope(Dispatchers.IO).launch {
            try {
                RetrofitSyncService.API.pdaError(ErrorData(DeviceInfo.DEVICE_NAME, sendMessage))
                    .execute()
            } catch (e:Exception) {

            }

            e.printStackTrace()
            android.os.Process.killProcess(android.os.Process.myPid())
            exitProcess(10)
        }
    }
}