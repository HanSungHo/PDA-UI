package com.keyfoundry.hifos.view.dialog

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.Window
import androidx.core.text.HtmlCompat
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivityNotificationBinding
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter


class NotificationActivity : HFActivity() {
    init {
        this.update = false
    }

    private lateinit var viewBinding: ActivityNotificationBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setFinishOnTouchOutside(false)

        viewBinding = ActivityNotificationBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        val receiverMessage = intent.getStringExtra(DeviceInfo.UDP_RECEIVER_MESSAGE)
        var ASMLError : Boolean = false;

        if (receiverMessage != null) if(receiverMessage.contains("INTERLOCKMANAGER"))
        {
            if(receiverMessage.contains("ALARM_ID    : 1414725736"))
            {
                //ALARM_ID    : 1414725736
                ASMLError = true   // <- 선언 없이 값만 변경
            }

            val new_receiverMessage = arrayOf(receiverMessage?.split("<Table diffgr:")) // receiverMessage 잘라서 배열에 담기

            for(data in 1 until new_receiverMessage[0].size)
            {
                val arry_receiverMessage = arrayOf(new_receiverMessage[0][data]?.split("</")) // receiverMessage 잘라서 배열에 담기

                val Time = arry_receiverMessage[0]!![0].substring(arry_receiverMessage[0]!![0].lastIndexOf(">")+1)
                val parsed = OffsetDateTime.parse(Time)
                val formatted = parsed.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))

                val Eqpid = arry_receiverMessage[0]!![2].substring(arry_receiverMessage[0]!![2].lastIndexOf(">")+1)
                val Lotid = arry_receiverMessage[0]!![3].substring(arry_receiverMessage[0]!![3].lastIndexOf(">")+1)
                var desc = arry_receiverMessage[0]!![7].substring(arry_receiverMessage[0]!![7].lastIndexOf(">")+1)
                //desc = desc.replace("&lt;BR&gt;&amp;nbsp;&amp;nbsp;&amp;","")
                desc = HtmlCompat.fromHtml(desc, HtmlCompat.FROM_HTML_MODE_LEGACY).toString()

                if(ASMLError)
                {
                    //&lt;BR&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;
                    //#5P01-15 ALARM_WARNING#&lt;BR&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;ALARM_ID    : 1414725736&lt;BR&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;ALARM_CODE    : 10100001&lt;BR&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;DESCRIPTION    : * Reticles for next batch are not pr
                    viewBinding.txtReceiverMessage.append("\n"+"["+Eqpid+"] Mask 없음 \n")
                    viewBinding.txtReceiverMessage.append("\nTIME: "+formatted)
                }
                else
                {
                    viewBinding.titleReceiverMessage.text = "#ALARM#";
                    if(!Eqpid.isNullOrEmpty())
                        viewBinding.txtReceiverMessage.append("\nEQPID: "+Eqpid)
                    if(!Time.isNullOrEmpty())
                        viewBinding.txtReceiverMessage.append("\n\nTIME: "+formatted)
                    if(!Lotid.isNullOrEmpty())
                        viewBinding.txtReceiverMessage.append("\n\nLOTID: "+Lotid)

                    if(!arry_receiverMessage[0]!![6].substring(arry_receiverMessage[0]!![6].lastIndexOf(">")+1).isEmpty())
                    {
                        val Level = arry_receiverMessage[0]!![6].substring(arry_receiverMessage[0]!![6].lastIndexOf(">")+1)
                        if(Level.equals("1"))
                            viewBinding.titleReceiverMessage.setTextColor(Color.rgb(239,181,81))
                        else if(Level.equals("2"))
                            viewBinding.titleReceiverMessage.setTextColor(Color.BLUE)
                        else if(Level.equals("3"))
                            viewBinding.titleReceiverMessage.setTextColor(Color.RED)
                    }

                    if(!desc.isNullOrEmpty())
                    {
                        // 1. 세미콜론(;)으로 split
                        val parts = desc.split(";")

                        // 2. 마지막 요소 가져오기 (trim으로 앞뒤 공백 제거)
                        val lastPart = parts.last().trim()

                        // 3. 콜론(:) 기준 split 후 마지막 값 가져오기
                        val value = lastPart.substringAfter(":").trim()

                        viewBinding.txtReceiverMessage.append("\n\n DESC: "+value + "\n\n" + "------------------------")
                    }
                    //viewBinding.txtReceiverMessage.gravity = Gravity.LEFT
                }
            }
        }
        else
        {
            viewBinding.txtReceiverMessage.text = receiverMessage.toString()
        }
        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
            }
        })
    }

    override fun onBackPressed() {
        finish()
    }
}

