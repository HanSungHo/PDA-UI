package com.keyfoundry.hifos.config.grid;

import android.content.Context;
import android.graphics.Matrix;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.GestureDetectorCompat;

import java.util.ArrayList;

public class CTMainLayout extends FrameLayout implements View.OnTouchListener, ScaleGestureDetector.OnScaleGestureListener, GestureDetector.OnGestureListener {
    private GestureDetectorCompat detector;

    private ScaleGestureDetector gestureScale;
    private float scaleFactor = 1;
    private float minScale = 0.5f;
    private float maxScale = 2.0f;

    private CTSubLayout mainTable;
    private CTSubLayout columnHeaderTable;
    private CTSubLayout rowHeaderTable;
    private CTSubLayout cornerTable;

    private final Matrix cornerMatrix = new Matrix();
    private final Matrix columnHeaderMatrix = new Matrix();
    private final Matrix rowHeaderMatrix = new Matrix();
    private final Matrix mainMatrix = new Matrix();

    private float panX = 0;
    private float panY = 0;

    //    private int rightBound;
//    private int bottomBound;
    private float scaledRightBound;
    private float scaledBottomBound;

    private final LayoutBound bound = new LayoutBound();

    private Boolean rowExist = true;

    private String currentTable = "";

    public CTMainLayout(Context context) {
        super(context);
        init(context);
    }

    public CTMainLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public CTMainLayout(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    public CTSubLayout getMainTable() {
        return mainTable;
    }

    public CTSubLayout getColumnHeaderTable() {
        return columnHeaderTable;
    }

    public CTSubLayout getRowHeaderTable() {
        return rowHeaderTable;
    }

    public CTSubLayout getCornerTable() {
        return cornerTable;
    }

    public LayoutBound getBound() {
        return bound;
    }

    public float getPanX() {
        return panX;
    }

    public float getPanY() {
        return panY;
    }

    public void setCurrentTable(String currentTable) {
        this.currentTable = currentTable;
    }

    private void init(Context context) {
        // As we extend a ViewGroup these won't draw anything by default
        // enable ViewGroup drawing so the scrollbars show
        setWillNotDraw(false);
        gestureScale = new ScaleGestureDetector(context, this);
        detector = new GestureDetectorCompat(context, this);
    }

    @SuppressWarnings({"UnusedDeclaration"})
    public void setMinScale(float minScale) {
        this.minScale = minScale;
    }

    @SuppressWarnings({"UnusedDeclaration"})
    public float getMinScale() {
        return minScale;
    }

    @SuppressWarnings({"UnusedDeclaration"})
    public void setMaxScale(float maxScale) {
        this.maxScale = maxScale;
    }

    @SuppressWarnings({"UnusedDeclaration"})
    public float getMaxScale() {
        return maxScale;
    }

    @SuppressWarnings({"UnusedDeclaration"})
    public void addViews(CTSubLayout mainTable, CTSubLayout columnHeaderTable,
                         CTSubLayout rowHeaderTable, CTSubLayout cornerTable) {

        // Store instances for later comparison;
        this.mainTable = mainTable;
        this.columnHeaderTable = columnHeaderTable;
        this.rowHeaderTable = rowHeaderTable;
        this.cornerTable = cornerTable;

        // Need to measure all Tables to full (UNSPECIFIED) size
        int measureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);
        mainTable.measure(measureSpec, measureSpec);
        columnHeaderTable.measure(measureSpec, measureSpec);
        rowHeaderTable.measure(measureSpec, measureSpec);
        cornerTable.measure(measureSpec, measureSpec);

        // Merge of the widths and height to align all the table rows
        // Get the max column width in mainTable and columnHeaderTable
        ArrayList<Integer> overallRightSideMaxColumnWidth = new ArrayList<>();
        calculateMaxColumnWidth(overallRightSideMaxColumnWidth, mainTable);
        calculateMaxColumnWidth(overallRightSideMaxColumnWidth, columnHeaderTable);
        // Set the new max column width in mainTable and columnHeaderTable
        setMaxColumnWidth(overallRightSideMaxColumnWidth, mainTable);
        setMaxColumnWidth(overallRightSideMaxColumnWidth, columnHeaderTable);
        // Get the max column width in cornerTable and rowHeaderTable
        ArrayList<Integer> overallLeftSideMaxColumnWidth = new ArrayList<>();
        calculateMaxColumnWidth(overallLeftSideMaxColumnWidth, rowHeaderTable);
        calculateMaxColumnWidth(overallLeftSideMaxColumnWidth, cornerTable);
        // Set the new max column width in mainTable and columnHeaderTable
        setMaxColumnWidth(overallLeftSideMaxColumnWidth, rowHeaderTable);
        setMaxColumnWidth(overallLeftSideMaxColumnWidth, cornerTable);

        // Get the max row height in mainTable and rowHeaderTable
        ArrayList<Integer> overallBottomSideMaxRowHeights = new ArrayList<>();
        calculateMaxRowHeight(overallBottomSideMaxRowHeights, mainTable);
        calculateMaxRowHeight(overallBottomSideMaxRowHeights, rowHeaderTable);
        // Set the max row height in mainTable and rowHeaderTable
        setMaxRowHeight(overallBottomSideMaxRowHeights, mainTable);
        setMaxRowHeight(overallBottomSideMaxRowHeights, rowHeaderTable);

        // Get the max row height in columnHeaderTable and cornerTable
        ArrayList<Integer> overallTopSideMaxRowHeights = new ArrayList<>();
        calculateMaxRowHeight(overallTopSideMaxRowHeights, columnHeaderTable);
        calculateMaxRowHeight(overallTopSideMaxRowHeights, cornerTable);
        // Set the max row height in mainTable and rowHeaderTable
        setMaxRowHeight(overallTopSideMaxRowHeights, columnHeaderTable);
        setMaxRowHeight(overallTopSideMaxRowHeights, cornerTable);


        // Remeasure Tables using the new set of aligned Heights and widths
        mainTable.measure(measureSpec, measureSpec);
        columnHeaderTable.measure(measureSpec, measureSpec);
        rowHeaderTable.measure(measureSpec, measureSpec);
        cornerTable.measure(measureSpec, measureSpec);

        // mainTable margin is on the Top and Left to make space for the over views
        LayoutParams mainTableLayoutParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        mainTableLayoutParams.leftMargin = rowHeaderTable.getMeasuredWidth();
        mainTableLayoutParams.topMargin = columnHeaderTable.getMeasuredHeight();
        mainTable.setLayoutParams(mainTableLayoutParams);

        // columnHeaderTable margin is on the Left to make space for the over views
        LayoutParams columnHeaderTableLayoutParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        columnHeaderTableLayoutParams.leftMargin = cornerTable.getMeasuredWidth();
        columnHeaderTable.setLayoutParams(columnHeaderTableLayoutParams);

        // rowHeaderTable margin is on the Top to make space for the over views
        LayoutParams rowHeaderTableLayoutParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        rowHeaderTableLayoutParams.topMargin = cornerTable.getMeasuredHeight();
        rowHeaderTable.setLayoutParams(rowHeaderTableLayoutParams);

        // Add the views
        addView(mainTable);
        addView(columnHeaderTable);
        addView(rowHeaderTable);
        addView(cornerTable);

        // Set Boundaries
        bound.setRightBound(cornerTable.getMeasuredWidth() + columnHeaderTable.getMeasuredWidth());
        bound.setBottomBound(cornerTable.getMeasuredHeight() + rowHeaderTable.getMeasuredHeight());
        scaledRightBound = bound.getRightBound() * scaleFactor;
        scaledBottomBound = bound.getBottomBound() * scaleFactor;
    }

    public void addViews(CTSubLayout mainTable, CTSubLayout columnHeaderTable) {

        // Store instances for later comparison;
        this.mainTable = mainTable;
        this.columnHeaderTable = columnHeaderTable;

        // Need to measure all Tables to full (UNSPECIFIED) size
        int measureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);
        mainTable.measure(measureSpec, measureSpec);
        columnHeaderTable.measure(measureSpec, measureSpec);

        // Merge of the widths and height to align all the table rows
        // Get the max column width in mainTable and columnHeaderTable
        ArrayList<Integer> overallRightSideMaxColumnWidth = new ArrayList<>();
        calculateMaxColumnWidth(overallRightSideMaxColumnWidth, mainTable);
        calculateMaxColumnWidth(overallRightSideMaxColumnWidth, columnHeaderTable);
        // Set the new max column width in mainTable and columnHeaderTable
        setMaxColumnWidth(overallRightSideMaxColumnWidth, mainTable);
        setMaxColumnWidth(overallRightSideMaxColumnWidth, columnHeaderTable);

        // Get the max row height in mainTable and rowHeaderTable
        ArrayList<Integer> overallBottomSideMaxRowHeights = new ArrayList<>();
        calculateMaxRowHeight(overallBottomSideMaxRowHeights, mainTable);
        // Set the max row height in mainTable and rowHeaderTable
        setMaxRowHeight(overallBottomSideMaxRowHeights, mainTable);

        // Get the max row height in columnHeaderTable and cornerTable
        ArrayList<Integer> overallTopSideMaxRowHeights = new ArrayList<>();
        calculateMaxRowHeight(overallTopSideMaxRowHeights, columnHeaderTable);
        // Set the max row height in mainTable and rowHeaderTable
        setMaxRowHeight(overallTopSideMaxRowHeights, columnHeaderTable);


        // Remeasure Tables using the new set of aligned Heights and widths
        mainTable.measure(measureSpec, measureSpec);
        columnHeaderTable.measure(measureSpec, measureSpec);

        // mainTable margin is on the Top and Left to make space for the over views
        LayoutParams mainTableLayoutParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        mainTableLayoutParams.topMargin = columnHeaderTable.getMeasuredHeight();
        mainTable.setLayoutParams(mainTableLayoutParams);

        // columnHeaderTable margin is on the Left to make space for the over views
        LayoutParams columnHeaderTableLayoutParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);

        columnHeaderTable.setLayoutParams(columnHeaderTableLayoutParams);

        // Add the views
        addView(mainTable);
        addView(columnHeaderTable);

        // Set Boundaries
        bound.setRightBound(mainTable.getMeasuredWidth());
        bound.setBottomBound(mainTable.getMeasuredHeight() + columnHeaderTable.getMeasuredHeight());
        scaledRightBound = bound.getRightBound() * scaleFactor;
        scaledBottomBound = bound.getBottomBound() * scaleFactor;

        rowExist = false;
    }

    private ArrayList<Integer> calculateMaxRowHeight(ArrayList<Integer> existHeights, CTSubLayout table) {
        for (int row = 0; row < table.getChildCount(); row++) {
            CTRowLayout tableRow = (CTRowLayout) table.getChildAt(row);
            if (existHeights.size() <= row) {
                // Not seen this row number before so add
                existHeights.add(tableRow.getMaxChildHeight());
            } else {
                // Take the max of existing value and new value
                existHeights.set(row, Math.max(existHeights.get(row), tableRow.getMaxChildHeight()));
            }
        }
        return existHeights;
    }

    private void setMaxRowHeight(ArrayList<Integer> newHeights, CTSubLayout table) {
        for (int row = 0; row < table.getChildCount(); row++) {
            CTRowLayout tableRow = (CTRowLayout) table.getChildAt(row);
            tableRow.setMaxChildHeight(newHeights.get(row));
        }
    }

    private ArrayList<Integer> calculateMaxColumnWidth(ArrayList<Integer> existWidths, CTSubLayout table) {
        for (int row = 0; row < table.getChildCount(); row++) {
            CTRowLayout tableRow = (CTRowLayout) table.getChildAt(row);
            ArrayList<Integer> rowColumnWidth = tableRow.getColumnWidths();
            for (int column = 0; column < rowColumnWidth.size(); column++) {
                if (existWidths.size() <= column) {
                    // Not seen this column number before so add
                    existWidths.add(rowColumnWidth.get(column));
                } else {
                    // Take the max of existing value and new value
                    existWidths.set(column, Math.max(existWidths.get(column), rowColumnWidth.get(column)));
                }
            }
        }
        return existWidths;
    }

    private void setMaxColumnWidth(ArrayList<Integer> newWidths, CTSubLayout table) {
        for (int row = 0; row < table.getChildCount(); row++) {
            CTRowLayout tableRow = (CTRowLayout) table.getChildAt(row);
            tableRow.setColumnWidths(newWidths);
        }
    }

    public void calculatePanScale(float distanceX, float distanceY, float newScaleFactor) {
        int width = getWidth();
        int height = getHeight();

        scaleFactor *= newScaleFactor;
        // Don't let the object get too small or too large.
        scaleFactor = Math.max(minScale, Math.min(scaleFactor, maxScale));

//        scaledRightBound = rightBound * scaleFactor;
//        scaledBottomBound = bottomBound * scaleFactor;

        scaledRightBound = bound.getRightBound();
        scaledBottomBound = bound.getBottomBound();

        float maxPanX = -(scaledRightBound - width);
        float maxPanY = -(scaledBottomBound - height);

        panX = Math.min(0, Math.max(maxPanX, (panX - distanceX)));
        panY = Math.min(0, Math.max(maxPanY, (panY - distanceY)));

//        mainMatrix.setScale(scaleFactor, scaleFactor);
//        mainMatrix.postTranslate(panX, panY);
//        columnHeaderMatrix.setScale(scaleFactor, scaleFactor);
//        columnHeaderMatrix.postTranslate(panX, 0);
//        rowHeaderMatrix.setScale(scaleFactor, scaleFactor);
//        rowHeaderMatrix.postTranslate(0, panY);
//        cornerMatrix.setScale(scaleFactor, scaleFactor);

        mainTable.setTranslationX(panX);
        mainTable.setTranslationY(panY);

        columnHeaderTable.setTranslationX(panX);
        columnHeaderTable.setTranslationY(0);

        if (rowExist) {
            rowHeaderTable.setTranslationX(0);
            rowHeaderTable.setTranslationY(panY);
        }
        invalidate();
    }

    // We don't allow adding Views directly use addViews instead
    // So unless we have stored the instance in addViews method don't allow add.
//    @Override
//    public void addView(View child, int index, ViewGroup.LayoutParams params) {
//        if (child == mainTable || child == columnHeaderTable || child == rowHeaderTable || child == cornerTable) {
//            super.addView(child, index, params);
//        } else {
//            throw new UnsupportedOperationException("Adding children directly is not supported, use addViews method");
//        }
//    }

//    @Override
//    protected boolean drawChild(Canvas canvas, View child, long drawingTime) {
//        boolean result;
//        int save = canvas.save();
//        result = super.drawChild(canvas, child, drawingTime);
//        canvas.restoreToCount(save);
//        return result;
//    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        gestureScale.onTouchEvent(ev);
        detector.onTouchEvent(ev);

        return super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean onTouch(View view, MotionEvent event) {
        gestureScale.onTouchEvent(event);
        detector.onTouchEvent(event);
        return true;
    }

    @Override
    public boolean onScale(ScaleGestureDetector detector) {
        // Don't change the pan just scale
        calculatePanScale(0, 0, detector.getScaleFactor());

        return true;
    }

    @Override
    public boolean onScaleBegin(ScaleGestureDetector detector) {
        return true;
    }

    @Override
    public void onScaleEnd(ScaleGestureDetector detector) {
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        // Don't change the scale just Pan
        if (!currentTable.equals(GridType.CORNER_GRID) && !currentTable.equals(GridType.COLUMN_GRID)) {
            if (Math.abs(distanceX) > Math.abs(distanceY))
                calculatePanScale(distanceX, 0F, 1);
            else
                calculatePanScale(0F, distanceY, 1);
        }

        return true;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return false;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    // Length of scrollbar track
    @Override
    protected int computeHorizontalScrollRange() {
        return (int) scaledRightBound;
    }

    // Position from thumb from the left of view
    @Override
    protected int computeHorizontalScrollOffset() {
        return (int) -panX;
    }

    @Override
    protected int computeVerticalScrollRange() {
        return (int) scaledBottomBound;
    }

    @Override
    protected int computeVerticalScrollOffset() {
        return (int) -panY;
    }
}
