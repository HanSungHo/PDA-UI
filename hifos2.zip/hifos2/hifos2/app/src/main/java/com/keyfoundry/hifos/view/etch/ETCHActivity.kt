package com.keyfoundry.hifos.view.etch

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ShapeDrawable
import android.os.Bundle
import android.text.InputFilter
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewTreeObserver
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.core.view.children
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityEtchactivityBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ETCHActivity : HFActivity() {
    companion object {
        private const val TAG = "ETCHActivity"
    }

    private lateinit var viewBinding: ActivityEtchactivityBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    lateinit var gridService: GridService
    private var baseWidth = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityEtchactivityBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        val base = viewBinding.mainBody
        val vto: ViewTreeObserver = base.viewTreeObserver

        vto.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                base.viewTreeObserver.removeOnGlobalLayoutListener(this)
                baseWidth = base.width
            }
        })

        gridService = GridService(this)

        viewBinding.editLotNo.setOnEditorActionListener(editorActionListener)
        viewBinding.btnSearch.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)

        viewBinding.spinnerEqp.adapter = null
        val spinnerAdapter = ArrayAdapter(
            applicationContext, R.layout.contact_spinner_row_init,
            ";4E03-21;4E03-22;4E03-23;4E03-24;5E03-21;5E03-22;5E03-23;5E03-24;5E03-25".split(";")
        )
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerEqp.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
        viewBinding.spinnerEqp.setSelection(1, false)

    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearch.id -> {
                    getLotInfo()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    private val editorActionListener =
        TextView.OnEditorActionListener { v, actionId, event ->
            when (v.id) {
                viewBinding.editLotNo.id -> {
                    clearInfo()
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                        if (check)
                            getLotInfo()
                        else
                            clearInfo()
                    } else if (event != null) {
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                            if (check)
                                getLotInfo()
                            else
                                clearInfo()
                        }
                    }
                }
            }

            true
        }

    private fun clearInfo() {
        viewBinding.mainBody.removeAllViews()
        viewBinding.txtOperRecipe.text = ""
        viewBinding.txtCOMMT.text = ""
    }

    private fun getLotInfo() {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@ETCHActivity, currentFocus)
            clearInfo()

            if (viewBinding.editLotNo.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, "ERROR",
                    "LOT을 입력하여 주세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            var sendMessage =  MessageFactoryUtil.etchCommRcpFrombType2(viewBinding.editLotNo.text.toString(), viewBinding.spinnerEqp.selectedItem.toString())

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.ETCHCOMMRCPFROMB
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val processType = messageBody.optString("PROCESS_TYPE")
                val oper = messageBody.optString("OPERDESC")

                val commRCP = ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "COMMRCP")

                val s2NDPara = messageBody.optString("PARA2ND")
                val s2NDValue = messageBody.optString("VALUE2ND")
                val s2NDCOMM = messageBody.optString("COMM2ND")
                val sHMEEN =  messageBody.optString("HMEEN")

                if( !sHMEEN.isEmpty() )
                {
                    OkDialog.show(
                        supportFragmentManager, "EEN",
                        sHMEEN, GetString.BTNOKSTR)
                }
                viewBinding.txtOperRecipe.text = oper

                if( s2NDCOMM.isEmpty()) {
                    if (s2NDPara.isNotEmpty())
                        viewBinding.txtCOMMT.text = s2NDPara + " : " + s2NDValue + " 추가 반영"
                    //viewBinding.txtOwner.text = ownerCode
                }
                else
                    viewBinding.txtCOMMT.text= s2NDCOMM

                if (commRCP.length() < 1)
                    return@launch

                if (processType == "eMAX CT" || processType == "DPS POLY") {

                    val columnList = linkedMapOf(
                        "CHAMBER" to ColumnProperty("CH", Gravity.CENTER, false, baseWidth / 7),
                        "ETCVALUE" to ColumnProperty("PARA", Gravity.CENTER, false, baseWidth / 7 * 2),
                        "BASE_VALUE" to ColumnProperty("BASE", Gravity.CENTER, false, baseWidth / 7),
                        "TUNE_VALUE" to ColumnProperty(
                            "변경", Gravity.CENTER, false, baseWidth / 7 ,
                            Color.parseColor("#b3ffe0de"), Color.BLACK
                        ),
                        "CURR_VALUE" to ColumnProperty("현재값", Gravity.CENTER, false, baseWidth / 7),
                        "CHKCHK" to ColumnProperty("연속", Gravity.CENTER, false, baseWidth / 7,
                        Color.WHITE, Color.BLACK)
                    )

                    val mainGrid = gridService.setGridPropData(columnList, commRCP)
                    viewBinding.mainBody.addView(mainGrid)
                    for (row in mainGrid.mainTable.children) {
                        val checkRow = row as CTRowLayout
                        val checkRowData = (checkRow.tag as GridService.RowData).rowDataList

                        val chkResultCell = checkRow.getChildAt(5) as TextView
                        var color = 0
                        if(checkRowData["CHKCHK"].toString() == "가능")
                            color = Color.parseColor("#8be04e")
                        else if(checkRowData["CHKCHK"].toString() == "불가")
                            color = Color.parseColor("#b3ff0000")
                        else if( checkRowData["CHKCHK"].toString() == "")
                            continue;
                        else
                            continue;

                        when (val background = chkResultCell.background) {
                            is ShapeDrawable -> background.paint.color = color
                            is GradientDrawable -> background.setColor(color)
                            is ColorDrawable -> background.color = color
                        }
                    }
                } else if (processType == "TE8500") {
                    var rowCount = 0

                    val columnData = linkedMapOf(
                        "COL" to ColumnProperty(
                            "COL", Gravity.CENTER, false, baseWidth / 2,
                            Color.parseColor("#b3ffe0de"), Color.BLACK
                        ),
                        "VALUE" to ColumnProperty(
                            "VALUE", Gravity.CENTER, false, baseWidth / 2
                        )
                    )

                    val mainGrid = gridService.setGridPropData(columnData, commRCP)
                    viewBinding.mainBody.addView(mainGrid)

                    for (count in 0 until commRCP.length()) {
                        val col = commRCP.getJSONObject(count).optString("COL")
                        val value = commRCP.getJSONObject(count).optString("VALUE")

                        if (col == "진행 TIME") {
                            viewBinding.txtCOMMT.text = "진행 TIME [ $value 초 ]";

                            //OkDialog.show(
                            //    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            //    "진행 TIME [ $value ]", GetString.BTNOKSTR
                            //)

                            viewBinding.editLotNo.requestFocus()
                            viewBinding.editLotNo.selectAll()
                            return@launch
                        } else {
                            rowCount++
                        }
                    }
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
                return@launch
            }

        }
    }
}