package com.keyfoundry.hifos.view.merge

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import androidx.core.view.*
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityAutoMergeBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.lot.LotStatusActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject


class AutoMergeActivity : HFActivity() {

    companion object {
        private const val TAG = "AutoMergeViewActivity"
    }

    private lateinit var viewBinding: ActivityAutoMergeBinding

    private lateinit var gridService: GridService
    private lateinit var gridList: CTMainLayout
    private lateinit var gridList2: CTMainLayout
    private lateinit var columnData : LinkedHashMap<String, ColumnProperty>
    private lateinit var columnData2 : LinkedHashMap<String, ColumnProperty>

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    lateinit var gMainLotId: String

    lateinit var selectedRow: CTRowLayout
    private var selectAll = false

    var gLotList = ""

    var mergeFlag = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityAutoMergeBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        viewBinding.txtProduct.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtRoute.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtProcessNum.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtProcessStep.movementMethod = ScrollingMovementMethod.getInstance()

        viewBinding.editLotNo.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                if (check)
                    getMergeLotInfo()
                else
                    clearData()
            } else if (event != null) { // Barcode Event
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                    if (check)
                        getMergeLotInfo()
                    else
                        clearData()
                }
            }

            true
        }

        gridService = GridService(applicationContext)
        setGrid()
        setGrid2()
        viewBinding.btnExecute.setOnClickListener(onClickListener)
        viewBinding.btnClose.setOnClickListener(onClickListener)
        viewBinding.btnSearchLotNo.setOnClickListener(onClickListener)
        viewBinding.btnLotInfo.setOnClickListener(onClickListener)


    }

    private val onClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnExecute.id -> executeMerge()
                viewBinding.btnClose.id -> finish()
                viewBinding.btnSearchLotNo.id -> getMergeLotInfo()
                viewBinding.btnLotInfo.id -> inquireLotInfo(viewBinding.editLotNo.text.toString())
            }
        }
    }

    private fun setGrid(){
        columnData = linkedMapOf(
            "LOTNAME" to ColumnProperty("LOT ID", Gravity.LEFT, false),
       //     "CHILDFLAG" to ColumnProperty("CHILD FLAG", Gravity.LEFT, false),
            "MAINLOTNAME" to ColumnProperty("MAIN LOT ID", Gravity.LEFT, false),
            "PRODUCTSPECNAME" to ColumnProperty("제품", Gravity.LEFT, false),
            "PROCESSFLOWNAME" to ColumnProperty("MERGE ROUTE", Gravity.LEFT, false),
            "PROCESSOPERATIONNAME" to ColumnProperty("MERGE 공정", Gravity.LEFT, false),
            "DESCRIPTION" to ColumnProperty("공정 DESC", Gravity.LEFT, false)
        )

        var setGridList = JSONArray()
        val emptyObject = JSONObject()
        emptyObject.put("NUM", 0)
        setGridList.put(emptyObject)

        gridList = gridService.setGridPropData(columnData, setGridList)

        viewBinding.baseLayout.addView(gridList)

    }

    private fun setGrid2(){
        columnData2 = linkedMapOf(
            "LOTNAME" to ColumnProperty("LOT ID", Gravity.LEFT, false),
        //    "CHILDFLAG" to ColumnProperty("CHILD FLAG", Gravity.LEFT, false),
            "PRODUCTQUANTITY" to ColumnProperty("QTY", Gravity.LEFT, false),
            "PRODUCTSPECNAME" to ColumnProperty("제품", Gravity.LEFT, false),
            "PROCESSFLOWNAME" to ColumnProperty("ROUTE", Gravity.LEFT, false),
            "PROCESSOPERATIONNAME" to ColumnProperty("공정", Gravity.LEFT, false),
            "OPERATIONDESCRIPTION" to ColumnProperty("공정 DESC", Gravity.LEFT, false),
            "LOTSTATE" to ColumnProperty("STATUS", Gravity.LEFT, false)
        )

        var setGridList = JSONArray()
        val emptyObject = JSONObject()
        emptyObject.put("NUM", 0)
        setGridList.put(emptyObject)

        gridList2 = gridService.setGridPropData(columnData2, setGridList)

        viewBinding.baseLayout2.addView(gridList2)

    }

    private fun getMergeLotInfo(){
        clearData()

        mainScope.launch {
            CommonUtil.hideKeyboard(this@AutoMergeActivity, currentFocus)

            val lotId = viewBinding.editLotNo.text.toString()

            if (lotId.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT ID을 입력하세요", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.getAutoMergeLot(DeviceInfo.FACILITY,lotId)

            val message = MessageSender.send( supportFragmentManager, sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val messageListJSON = ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "ITEMS")

                gMainLotId = viewBinding.editLotNo.text.toString()

                gridList = gridService.setGridPropData(columnData, messageListJSON)
                viewBinding.baseLayout.addView(gridList)

                selectLotList(gridList)

                for (i in 0 until messageListJSON.length()) {
                    val jsonObject = messageListJSON.getJSONObject(i)
                    val lotName = jsonObject.getString("LOTNAME")

                    if(gLotList==""){
                        gLotList=lotName
                    } else {
                        gLotList+= ",$lotName"
                    }
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
                gMainLotId = ""
                viewBinding.editLotNo.setText("")
                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
            }
        }
    }

    private fun executeMerge(){
        if(!mergeFlag){
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "선택된 LOT이 모두 AUTO MERGE와 같은 ROUTE, 공정이어야 작업진행이 가능합니다.", GetString.BTNOKSTR
            )
            return;
        }

        var arrMergeLot = ""

        val mainTable = gridList2.mainTable

        for (row in 0 until mainTable.size) {
            val tableRow = mainTable.getChildAt(row) as CTRowLayout

            val lotIdIndex = gridService.getColumnIndex(gridList2, "LOTNAME")
            val qtyIndex = gridService.getColumnIndex(gridList2, "PRODUCTQUANTITY")

            val lotId = (tableRow.getChildAt(lotIdIndex) as TextView).text
            val qty = (tableRow.getChildAt(qtyIndex) as TextView).text

            if(arrMergeLot == ""){
                arrMergeLot = "$lotId $qty"
            } else {
                arrMergeLot += ",$lotId $qty"
            }
        }

        if(arrMergeLot.trim()==""|| viewBinding.txtSelectedLot.text=="" || viewBinding.txtParentLot.text == ""){
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "Merge할 Lot이 없습니다.", GetString.BTNOKSTR
            )
            return;
        }


        mainScope.launch {
            CommonUtil.hideKeyboard(this@AutoMergeActivity, currentFocus)

            val lotId = viewBinding.editLotNo.text.toString()

            if (lotId.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT ID을 입력하세요", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.executeAutoMergeLot(DeviceInfo.FACILITY,
                gMainLotId,
                viewBinding.txtParentLot.text.toString(),
                viewBinding.txtProduct.text.toString(),
                viewBinding.txtRoute.text.toString(),
                viewBinding.txtProcessNum.text.toString(),
                viewBinding.txtQty.text.toString(),
                DeviceInfo.OPERATOR_ID,
                viewBinding.editComment.text.toString(),
                arrMergeLot
            )

            val message = MessageSender.send( supportFragmentManager, sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                if(messageBody.optString("FAILLOTNAME")!=""){
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        messageBody.optString("FAILLOTNAME"), GetString.BTNOKSTR
                    )
                }

                if(messageBody.optString("SUCCESS") == "Y"){
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                        "작업을 수행하였습니다.", GetString.BTNOKSTR
                    )
                    clearData()
                    viewBinding.editLotNo.setText("")
                    viewBinding.editLotNo.requestFocus()
                }


            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
            }
        }
    }

    inner class RowGestureListener(private val lotId: String,
                                   private val parentLotId: String,
                                   private val product: String,
                                   private val route: String,
                                   private val oper: String,
                                   private val operDesc: String)
        : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(event: MotionEvent): Boolean {

            viewBinding.txtSelectedLot.text = lotId
            viewBinding.txtProduct.text = product
            viewBinding.txtRoute.text = route
            viewBinding.txtProcessNum.text = oper
            viewBinding.txtProcessStep.text = operDesc

            getLotInfo(lotId, parentLotId)

            return true
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun getLotInfo(sLotId:String, sParentLotId:String){

        mergeFlag = true
        viewBinding.baseLayout2.removeAllViews()

        mainScope.launch {

            val sendMessage = MessageFactoryUtil.getAutoMergeLot2(sLotId, sParentLotId, gLotList)

            val message = MessageSender.send( supportFragmentManager, sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val messageListJSON = ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "ITEMS")

                viewBinding.txtParentLot.text = messageBody.optString("PARENTLOTNAME")
                viewBinding.txtQty.text = messageBody.optString("PARENTQTY")
                viewBinding.txtProduct2.text = messageBody.optString("PARENTPRODUCTSPECNAME")
                viewBinding.txtRoute2.text = messageBody.optString("PARENTPROCESSFLOWNAME")
                viewBinding.txtProcessNum2.text = messageBody.optString("PARENTOPERATION")
                viewBinding.txtProcessStep2.text = messageBody.optString("PARENTDESCRIPTION")

                gridList2 = gridService.setGridPropData(columnData2, messageListJSON)

                for (mainRow in gridList2.mainTable.children) {

                    val route = gridService.getCellValue(mainRow, "PROCESSFLOWNAME")
                    val oper = gridService.getCellValue(mainRow, "PROCESSOPERATIONNAME")

                    if(route != viewBinding.txtRoute.text.toString() || oper != viewBinding.txtProcessNum.text.toString() || oper != viewBinding.txtProcessNum2.text.toString()) {
                        mainRow.setBackgroundColor(Color.parseColor("#BC8F8F"))
                        mergeFlag = false
                    }

                    mainRow.setOnTouchListener { v, event -> true }
                }

                viewBinding.baseLayout2.addView(gridList2)

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

            }
        }
    }
    private fun selectLotList(gridData: CTMainLayout) {

        for (mainRow in gridData.mainTable.children) {
            val lotId = gridService.getCellValue(mainRow, "LOTNAME")
            val parentLotId = gridService.getCellValue(mainRow, "MAINLOTNAME")

            val product = gridService.getCellValue(mainRow, "PRODUCTSPECNAME")
            val route = gridService.getCellValue(mainRow, "PROCESSFLOWNAME")
            val oper = gridService.getCellValue(mainRow, "PROCESSOPERATIONNAME")
            val operDesc = gridService.getCellValue(mainRow, "DESCRIPTION")

            val mDetector =
                GestureDetectorCompat(this, RowGestureListener(lotId, parentLotId,product,route,oper,operDesc))
            mainRow.setOnTouchListener { v, event ->
                mDetector.onTouchEvent(event)
                v.performClick()
            }
        }

    }

    private fun inquireLotInfo(sLot: String){
        val nextIntent = Intent(applicationContext, LotStatusActivity::class.java)
        nextIntent.putExtra("LOTID", sLot)
        startActivity(nextIntent)
    }

    private fun clearData(){
        viewBinding.txtRoute.text = ""
        viewBinding.txtProcessNum.text = ""
        viewBinding.txtProcessStep.text = ""
        viewBinding.txtProduct.text = ""
        viewBinding.txtQty.text = ""
        viewBinding.editComment.setText("")
        viewBinding.baseLayout.removeAllViews()
        viewBinding.baseLayout2.removeAllViews()

        viewBinding.txtRoute2.text = ""
        viewBinding.txtParentLot.text = ""
        viewBinding.txtProcessNum2.text = ""
        viewBinding.txtProduct2.text = ""
        viewBinding.txtProcessStep2.text = ""
        viewBinding.txtSelectedLot.text = ""

        gMainLotId = ""
        gLotList = ""
    }

}