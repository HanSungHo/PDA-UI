package com.keyfoundry.hifos.view.esd

import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.utils.CommonUtil
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivityEsdmasterBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialogFragment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ESDMasterActivity : AppCompatActivity() {

    private lateinit var okDialogFragment: OkDialogFragment
    //    companion object {
    //        private const val TAG = "ESDMasterActivity"
    //    }
    private lateinit var viewBinding: ActivityEsdmasterBinding
    private val mainScope = CoroutineScope(Dispatchers.Main)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityEsdmasterBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        val spinner: Spinner = findViewById(R.id.spinner_ESD_Action)
        val items = arrayOf("","하단 고무 받침대", "접지선 장착 안됨 ", "손잡이 훼손"
                                ,"Tube 훼손","우레탄 바퀴 불량","Shelf단 나사 설치 불량")

        // ArrayAdapter를 사용하여 Spinner에 아이템 추가
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        viewBinding.txtId.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.txtId.setOnEditorActionListener(editorActionListener)
        viewBinding.txtFloor.setOnEditorActionListener(editorActionListener)
        viewBinding.txtArea.setOnEditorActionListener(editorActionListener)
        viewBinding.txtBay.setOnEditorActionListener(editorActionListener)
        viewBinding.txtESDValue1.setOnEditorActionListener(editorActionListener)
        viewBinding.txtESDValue2.setOnEditorActionListener(editorActionListener)
        viewBinding.txtESDValue3.setOnEditorActionListener(editorActionListener)
        viewBinding.txtESDValue4.setOnEditorActionListener(editorActionListener)
        viewBinding.txtSpec.setOnEditorActionListener(editorActionListener)
        viewBinding.txtRValue1.setOnEditorActionListener(editorActionListener)
        viewBinding.txtRValue2.setOnEditorActionListener(editorActionListener)
        viewBinding.txtRValue3.setOnEditorActionListener(editorActionListener)
        viewBinding.txtRValue4.setOnEditorActionListener(editorActionListener)
        viewBinding.txtSpec.setOnEditorActionListener(editorActionListener)
        viewBinding.btnSearchBCR.setOnEditorActionListener(editorActionListener)
        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)

        // Spinner 아이템 선택 이벤트 처리
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                // 선택된 아이템 처리
                val selectedItem = parent?.getItemAtPosition(position).toString()
                //Toast.makeText(this@ESDMasterActivity, "선택된 아이템: $selectedItem", Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // 아무것도 선택되지 않은 경우 처리
            }
        }

        //val editText: EditText = findViewById(R.id.txt_R_Value1)
        val editText = listOf(R.id.txt_R_Value1, R.id.txt_R_Value2, R.id.txt_R_Value3, R.id.txt_R_Value4)
        val inputFilter = InputFilter { source, start, end, dest, dstart, dend ->
            val inputText = dest.toString() + source.toString()
            when {
                inputText == "." -> return@InputFilter "0."
                inputText == "0" && source != "." -> return@InputFilter ""
                inputText == "0." -> return@InputFilter ""
                !inputText.matches("^\\d{0,1}\\.?\\d{0,2}\$".toRegex()) -> return@InputFilter ""
            }
            null // 입력 허용
        }
        // 모든 EditText에 동일한 필터 적용
        editText.forEach { id ->
            findViewById<EditText>(id).filters = arrayOf(inputFilter)
        }


        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
            }
        })


        val editTexts = arrayOf(
            viewBinding.txtESDValue1,
            viewBinding.txtESDValue2,
            viewBinding.txtESDValue3,
            viewBinding.txtESDValue4
        )

        val TextWatcher = object : TextWatcher {
        //viewBinding.txtESDValue1.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // 입력 전에 수행할 작업
            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // 텍스트가 변경될 때마다 수행할 작업
                var isAllInSpec = true
                var hasValue = false

                for (editText in editTexts) {
                    val text = editText.text.toString().trim()
                    val value = text.toIntOrNull()

                    if (!text.isNullOrEmpty()) {
                        hasValue = true
                        if (value == null || value < 4 || value > 8) {
                            isAllInSpec = false
                            break
                        }
                    }
                }

                if (!hasValue) {
                    viewBinding.txtSpec.text = ""
                    viewBinding.txtSpec.setBackgroundColor(ContextCompat.getColor(applicationContext, R.color.transparent))
                } else if (isAllInSpec) {
                    viewBinding.txtSpec.text = "IN"
                    viewBinding.txtSpec.setBackgroundColor(ContextCompat.getColor(applicationContext, R.color.green))
                    spinner.isEnabled = false
                    spinner.setSelection(0)
                } else {
                    viewBinding.txtSpec.text = "OUT"
                    viewBinding.txtSpec.setBackgroundColor(ContextCompat.getColor(applicationContext, R.color.yellow))
                    spinner.isEnabled = true
                }
            }
            override fun afterTextChanged(s: Editable?) {}
        }
        editTexts.forEach { it.addTextChangedListener(TextWatcher) }
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                //viewBinding.btnSearchGas.id ->{
                //    getData()
                //}
                viewBinding.btnOk.id ->{
                    setData()
                }
                viewBinding.btnCancel.id ->{
                    finish()
                }
            }
        }
    }

    private val editorActionListener =
        TextView.OnEditorActionListener { v, actionId, event ->
            when (v.id) {
                viewBinding.txtId.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {

                    } else if (event != null) {
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {

                            val Id = viewBinding.txtId.text.toString()
                            val returnLotId: String

                            val replaceLotId = Id
                            returnLotId = if (replaceLotId.isNotEmpty())
                                replaceLotId
                            else
                                ""
                            returnLotId
                            viewBinding.txtId.setText("");
                            viewBinding.txtId.setText(returnLotId)
                            viewBinding.txtLotID2.setText("");
                            viewBinding.txtArea.setText("");
                            viewBinding.txtFloor.setText("");
                            viewBinding.txtBay.setText("");
                            viewBinding.txtItem.setText("");
                            viewBinding.txtESDValue1.setText("");
                            viewBinding.txtESDValue2.setText("");
                            viewBinding.txtESDValue3.setText("");
                            viewBinding.txtESDValue4.setText("");
                            viewBinding.txtSpec.setText("");
                            viewBinding.txtRValue1.setText("");
                            viewBinding.txtRValue2.setText("");
                            viewBinding.txtRValue3.setText("");
                            viewBinding.txtRValue4.setText("");

                            if(viewBinding.txtId.length() > 0)
                            {
                                viewBinding.txtLotID2.setText(viewBinding.txtId.text)
                                val item = viewBinding.txtLotID2.text.substring(0,2);// item
                                if(item.equals("WT"))
                                {
                                    viewBinding.txtItem.setText("Work Table");
                                }else if (item.equals("SH"))
                                {
                                    viewBinding.txtItem.setText("Shelf");
                                }
                                else if (item.equals("CA"))
                                {
                                    viewBinding.txtItem.setText("밀차");
                                }
                                else if (item.equals("CH"))
                                {
                                    viewBinding.txtItem.setText("의자");
                                }
                                else if (item.equals("TW"))
                                {
                                    viewBinding.txtItem.setText("Tweezer");
                                }
                                val floor = viewBinding.txtLotID2.text.substring(2,3)+"F";// floor
                                viewBinding.txtFloor.setText(floor);
                                val area = viewBinding.txtLotID2.text.substring(3,4);// area
                                if(area.equals("P"))
                                {
                                    viewBinding.txtArea.setText("Photo");
                                }else if (area.equals("E"))
                                {
                                    viewBinding.txtArea.setText("Etch");
                                }else if (area.equals("D"))
                                {
                                    viewBinding.txtArea.setText("Diff");
                                }else if (area.equals("C"))
                                {
                                    viewBinding.txtArea.setText("Cvd");
                                }else if (area.equals("W"))
                                {
                                    viewBinding.txtArea.setText("End.Packing");
                                }else if (area.equals("O"))
                                {
                                    viewBinding.txtArea.setText("Ogi");
                                }else if (area.equals("S"))
                                {
                                    viewBinding.txtArea.setText("SAMKOO");
                                }

                                val bay = viewBinding.txtId.text.substring(4,viewBinding.txtLotID2.text.length - 5);// bay
                                viewBinding.txtBay.setText(bay);
                            }
                            viewBinding.txtId.setText("");
                        }
                    }
                }
            }

            true
        }

    private fun setData(){
        mainScope.launch {
            CommonUtil.hideKeyboard(this@ESDMasterActivity, currentFocus)

            val ESD_Value1 = viewBinding.txtESDValue1.text.toString().toIntOrNull()
            val ESD_Value2 = viewBinding.txtESDValue2.text.toString().toIntOrNull()
            val ESD_Value3 = viewBinding.txtESDValue3.text.toString().toIntOrNull()
            val ESD_Value4 = viewBinding.txtESDValue4.text.toString().toIntOrNull()

            if (ESD_Value1 == null )
            {
                OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "E(1) 값을 입력 해야합니다.", GetString.BTNOKSTR
                )
                return@launch
            }

            val sESDID = viewBinding.txtLotID2.text.toString()
            val sItem = viewBinding.txtLotID2.text.substring(0,2)
            val sFloor = viewBinding.txtLotID2.text.substring(2,3)
            val sArea = viewBinding.txtLotID2.text.substring(3,4)
            val sBay = viewBinding.txtLotID2.text.substring(4,viewBinding.txtLotID2.text.length - 5)
            val sESD1 = viewBinding.txtESDValue1.text.toString() //ESD Value_1
            val sESD2 = viewBinding.txtESDValue2.text.toString() //ESD Value_2
            val sESD3 = viewBinding.txtESDValue3.text.toString() //ESD Value_3
            val sESD4 = viewBinding.txtESDValue4.text.toString() //ESD Value_4
            val sResist1 = viewBinding.txtRValue1.text.toString()    //Resistance_1
            val sResist2 = viewBinding.txtRValue2.text.toString()    //Resistance_2
            val sResist3 = viewBinding.txtRValue3.text.toString()    //Resistance_3
            val sResist4 = viewBinding.txtRValue4.text.toString()    //Resistance_4
            val sReasons = viewBinding.spinnerESDAction.selectedItem.toString()
            val sUsers = DeviceInfo.OPERATOR_ID
            //내꺼에 맞게 수정
            //val sendMessage = MessageFactoryUtil.esdinsert(sESDID,sItem,sFloor,sArea,sBay,sInput,sDesc,sReasons, sUsers)
            val sendMessage = MessageFactoryUtil.esdinsert(sESDID,sItem,sFloor,sArea,sBay,sESD1,sESD2,sESD3,sESD4,sResist1,sResist2,sResist3,sResist4,sReasons,sUsers)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.SETGASUSAGE
            )
        }
        OkDialog.show(
            supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
            "Data가 입력되었습니다.", GetString.BTNOKSTR
        )
        clearData()
    }

    private fun clearData() {

        viewBinding.txtId.setText("")
        viewBinding.txtArea.text = ""
        viewBinding.txtFloor.text = ""
        viewBinding.txtESDValue1.setText("")
        viewBinding.txtESDValue2.setText("")
        viewBinding.txtESDValue3.setText("")
        viewBinding.txtESDValue4.setText("")
        viewBinding.txtBay.setText("")
        viewBinding.txtSpec.setText("")
        viewBinding.txtItem.setText("")
        viewBinding.txtRValue1.setText("");
        viewBinding.txtRValue2.setText("");
        viewBinding.txtRValue3.setText("");
        viewBinding.txtRValue4.setText("");
        viewBinding.spinnerESDAction.setSelection(0);
        viewBinding.txtSpec.setBackgroundColor(ContextCompat.getColor( viewBinding.txtESDValue1.context,R.color.white))
        viewBinding.txtSpec.setBackgroundColor(ContextCompat.getColor( viewBinding.txtESDValue2.context,R.color.white))
        viewBinding.txtSpec.setBackgroundColor(ContextCompat.getColor( viewBinding.txtESDValue3.context,R.color.white))
        viewBinding.txtSpec.setBackgroundColor(ContextCompat.getColor( viewBinding.txtESDValue4.context,R.color.white))
        viewBinding.txtId.requestFocus();

    }
}