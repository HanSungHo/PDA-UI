package com.keyfoundry.hifos.view.gas

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputFilter
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityGasBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class GasActivity : HFActivity() {
    companion object {
        private const val TAG = "GasActivity"
    }
    lateinit var viewBinding: ActivityGasBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityGasBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)
        viewBinding.editCabinetNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        viewBinding.editCabinetNo.setOnEditorActionListener { v, actionId, event ->
            if(actionId == EditorInfo.IME_ACTION_DONE){
                val check = BarcodeStyle(this).lotId(viewBinding.editCabinetNo)
                if(check) {
                    getData()
                }
            }else if (event != null) {
                if (event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).lotId(viewBinding.editCabinetNo)  // 바코드 스타일을 변경 해야함.
                    if(check)
                        getData()
                    else
                        clearData()
                }
            }
            true
        }

        viewBinding.btnSearchGas.setOnClickListener(onSingleClickListener)
        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
        viewBinding.editCabinetNo.requestFocus()
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchGas.id ->{
                    getData()
                }
                viewBinding.btnOk.id ->{
                    setData()
                }
                viewBinding.btnCancel.id ->{
                    finish()
                }
            }
        }
    }

    private fun getData() {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@GasActivity, currentFocus)

            if (viewBinding.editCabinetNo.text.toString().replace(" ", "") == "") {  // 공백 CHECK
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "CABINET NO가 확인되지 않습니다.", GetString.BTNOKSTR
                )

                viewBinding.editCabinetNo.requestFocus()
                viewBinding.editCabinetNo.selectAll()
                return@launch
            }else {
                val sCabinet = viewBinding.editCabinetNo.text.toString()
                val sendMessage = MessageFactoryUtil.GetCabinetInfo(sCabinet)

                val message = MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.GETCABINETINFO
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result

                if (isSuccessFul) {
                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                    val ItemList =
                        ResponseDataToJsonUtil.getMessageBodyList(result, "ITEMS")

                    val usages =
                        ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "USAGES")

                    val sCabinet =  ItemList.getJSONObject(0).optString("CABINET")
                    val sGas = ItemList.getJSONObject(0).optString("GAS")
                    val sType = ItemList.getJSONObject(0).optString("TYPE")

                    var sPressure = messageBody.optString("PRESSURE")
                    var sWeight = messageBody.optString("WEIGHT")

                    viewBinding.txtCabinet.text = sCabinet
                    viewBinding.txtGas.text = sGas

                    viewBinding.txtPressure.text = sPressure
                    viewBinding.txtWeight.text = sWeight

                    if(sType !="Y"){
                        viewBinding.editWeight.isEnabled = false
                        viewBinding.editWeight.visibility = View.GONE
                        viewBinding.lblWeight.visibility = View.GONE
                        viewBinding.txtWeight.visibility = View.GONE
                    }
                    else {
                        viewBinding.editWeight.isEnabled = true
                        viewBinding.editWeight.visibility = View.VISIBLE
                        viewBinding.lblWeight.visibility = View.VISIBLE
                        viewBinding.txtWeight.visibility = View.VISIBLE
                    }

                    viewBinding.editPressure.setText("")
                    viewBinding.editWeight.setText("")
                }
            }
        }
        viewBinding.editPressure.requestFocus()
        viewBinding.editPressure.selectAll()
    }

    private fun setData(){
        mainScope.launch {
            CommonUtil.hideKeyboard(this@GasActivity, currentFocus)

            if (viewBinding.txtCabinet.text.toString().replace(" ", "") == "") {  // 공백 CHECK
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "CABINET NO가 확인되지 않습니다.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.txtGas.text.toString().replace(" ", "") == "") {  // 공백 CHECK
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "GAS가 확인되지 않습니다.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.editPressure.text.toString().replace(" ", "") == "") {  // 공백 CHECK
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "압력값을 입력 해야합니다.", GetString.BTNOKSTR
                )
                return@launch
            }

            if(viewBinding.editWeight.isEnabled)
            {
                if (viewBinding.editWeight.text.toString().replace(" ", "") == "") {  // 공백 CHECK
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "무게를 입력 해야합니다.", GetString.BTNOKSTR
                    )
                    return@launch
                }
            }

            val sCabinet = viewBinding.txtCabinet.text.toString()
            val sGas = viewBinding.txtGas.text.toString()
            val sPressure = viewBinding.editPressure.text.toString()
            val sWeight = viewBinding.editWeight.text.toString()
            val sComment = viewBinding.editComment.text.toString()

            val sendMessage = MessageFactoryUtil.SetGasusage(sCabinet,DeviceInfo.OPERATOR_ID,sPressure,sWeight,sComment)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.SETGASUSAGE
            )
            val isSuccessFul = message.isSuccessFul

            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
                    "Data가 입력되었습니다.", GetString.BTNOKSTR
                )

                getData()

                viewBinding.editCabinetNo.requestFocus()
                viewBinding.editCabinetNo.selectAll()

              //  clearData()
            }
        }
    }

    private fun clearData() {
        viewBinding.txtCabinet.text = ""
        viewBinding.txtGas.text = ""
        viewBinding.editPressure.setText("")
        viewBinding.editWeight.setText("")
        viewBinding.editCabinetNo.requestFocus()
        viewBinding.editCabinetNo.selectAll()
        viewBinding.editComment.setText("")
    }
}
