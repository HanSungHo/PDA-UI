package com.keyfoundry.hifos.config.customview

import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.view.Gravity
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.content.ContextCompat
import com.keyfoundry.hifos.R

/*
* Bullet 디자인 관련 Class
* */
class BulletTextView : AppCompatTextView {
    init {
        this.foreground = ContextCompat.getDrawable(context, R.drawable.bullet)
        this.foregroundGravity = Gravity.START
        this.setTextColor(Color.WHITE)
        this.setPaddingRelative(20, 0, 0, 0)
        this.gravity = Gravity.CENTER_VERTICAL
        this.isSingleLine = true
    }

    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        val typeArray = context.obtainStyledAttributes(attrs, R.styleable.BulletTextView)
        this.setTextColor(typeArray.getColor(R.styleable.BulletTextView_textColor, Color.WHITE))
        this.text = typeArray.getString(R.styleable.BulletTextView_text)

        typeArray.recycle()
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int)
            : super(context, attrs, defStyleAttr) {
        val typeArray = context.obtainStyledAttributes(attrs, R.styleable.BulletTextView)
        this.setTextColor(typeArray.getColor(R.styleable.BulletTextView_textColor, Color.WHITE))
        this.text = typeArray.getString(R.styleable.BulletTextView_text)

        typeArray.recycle()
    }
}