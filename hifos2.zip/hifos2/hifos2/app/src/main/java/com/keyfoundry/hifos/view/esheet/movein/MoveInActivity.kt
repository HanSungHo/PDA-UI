package com.keyfoundry.hifos.view.esheet.movein

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Vibrator
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.view.GestureDetector
import android.view.KeyEvent.ACTION_UP
import android.view.KeyEvent.KEYCODE_ENTER
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.GestureDetectorCompat
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.BarcodeStyle
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.config.utils.ValidateCheck
import com.keyfoundry.hifos.databinding.ActivityMoveInBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.cmm.BatchLotListActivity
import com.keyfoundry.hifos.view.cmm.WaferSelectActivity
import com.keyfoundry.hifos.view.dialog.RecipeDialogActivity
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDailogAlram
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.comment.CommentListActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MoveInActivity : HFActivity() {

    companion object {
        private const val TAG = "MoveInActivity"
        private const val MVIN_ERROR_TYPE_TRANSACTION = "-1"
    }

    private lateinit var viewBinding : ActivityMoveInBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var spinnerRecipeItems = arrayListOf<String>()

    private var m_ReworkSkip = false

    private var m_oExposure = false

    //recipeinfo 에서 받은 정보를 movein 이 성공 했을대 다이얼로그로 띄우기 위하여
    private var sFICDChamber = ""
    private var sCumCycle = ""
    private var sCDmsg = ""
    private var sMultiMoveMSG = ""
    private var sCumCycleQty = ""
    private var sMacromsg = ""
    private var sScopemsg = ""
    private var sOvmsg = "";
    private var sEtchReworkmsg = ""

    private var m_sOverlayMessage = "" //[Addition] 2017.02.23 jy.Lim

    private var m_sNRWCmtCount = 0

    private var m_sArea = ""
    private var m_sOpType = ""
    private var m_sProduct = ""

    private var m_sProcessStep = ""
    private var m_sOperation = ""
    private var m_sSubOperation = ""

    // Comment Read에 넘길 파라미터
    private var m_sOperSeq = ""

    // wafer select에 사용
    private var m_CreateCategory = ""

    private var m_mainEqpId = ""

    // Inline에서 받아와서 Move In에 Set
    private var m_sMaskTag = ""
    private var m_sIdentCodeList = ""
    private var m_ProbecardID = ""
    private var m_processType = "";
    private var m_product = "";

    private var m_edgeFar = ""

    private var m_scopeSub = ""

    private var m_autoMotiveFlag = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityMoveInBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editIngMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editProbeCard.filters  = arrayOf<InputFilter>(InputFilter.AllCaps())

        viewBinding.txtRecipe.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtStandardMachine.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtProduct.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtCurrentOperation.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtEngineer.movementMethod = ScrollingMovementMethod.getInstance()

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()
            viewBinding.txtLotNo.text = lotId
            viewBinding.txtStandardMachine.setTextColor(Color.BLACK)
            getLotInfo()
        }

        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
            }
        })

        viewBinding.btnWH.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                mainScope.launch {
                    val sWaferList = selectWafer()

                    val waferIntent = Intent(applicationContext, WaferSelectActivity::class.java)
                    val lotId = viewBinding.txtLotNo.text.toString()

                    waferIntent.putExtra("LOTID", lotId)
                    waferIntent.putExtra("EXISTWAFERLIST", sWaferList)
                    waferIntent.putExtra("FIXEDCOUNT", sWaferList.split(",").count().toString())
                    waferIntent.putExtra("CATEGORY", m_CreateCategory)
                    //         waferIntent.putExtra("SELECTEDMACHINE", m_sComment)

                    waferSelectActivityResultLauncher.launch(waferIntent)
                }
            }
        })

//        viewBinding.btnModify.setOnClickListener(object : OnSingleClickListener() {
//            override fun onSingleClick(it: View) {
//                viewBinding.editIngMachine.setText("")
//                viewBinding.editIngMachine.requestFocus()
//                viewBinding.btnModify.isEnabled = false
//            }
//        })

        viewBinding.editIngMachine.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                val check = BarcodeStyle(this).eqpId(viewBinding.editIngMachine)
                if (check) {
                    getMCFDCMachineinfo()

                    if(m_processType == "WT" || m_processType == "PCM")
                    {
                        viewBinding.editProbeCard.requestFocus()
                    }
                } else {
                    viewBinding.txtRecipe.text = ""
                    spinnerRecipeItems.clear()
                    setRecipeSpinner(spinnerRecipeItems)
                }
            } else if (event != null) {
                if (actionId == 0 && event.action == ACTION_UP && event.keyCode == KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).eqpId(viewBinding.editIngMachine)
                    if (check) {
                        getMCFDCMachineinfo()
                        if(m_processType == "WT" || m_processType == "PCM")
                        {
                            viewBinding.editProbeCard.requestFocus()
                        }
                    } else {
                        viewBinding.txtRecipe.text = ""
                        spinnerRecipeItems.clear()
                        setRecipeSpinner(spinnerRecipeItems)
                    }
                }
            }
            true
        }

        viewBinding.editProbeCard.setOnEditorActionListener { v, actionId, event ->
            if(actionId == EditorInfo.IME_ACTION_DONE){
                val Check = BarcodeStyle(this).ProbeCardId(viewBinding.editProbeCard)
                if(Check){
                    getProbeCardInfo()
                }
                else {
                    viewBinding.editProbeCard.setText("")
                    viewBinding.editProbeCard.requestFocus()
                }
            }else if (event != null) {
                if (actionId == 0 && event.action == ACTION_UP && event.keyCode == KEYCODE_ENTER) {
                    val Check = BarcodeStyle(this).ProbeCardId(viewBinding.editProbeCard)
                    if(Check){
                        getProbeCardInfo()
                    }
                    else {
                        viewBinding.editProbeCard.setText("")
                        viewBinding.editProbeCard.requestFocus()
                    }
                }
            }

            true
        }

        viewBinding.btnBatId.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val batchLotListIntent =
                    Intent(applicationContext, BatchLotListActivity::class.java)

                Log.d("BATID", viewBinding.txtBatId.text.toString())
                batchLotListIntent.putExtra("BATID", viewBinding.txtBatId.text.toString())
                //        batchLotListIntent.putExtra("SLOTID", "slotId?")
                batchActivityResultLauncher.launch(batchLotListIntent)
            }
        })

        viewBinding.btnRead.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val commentListIntent = Intent(applicationContext, CommentListActivity::class.java)

//                dlg.m_sLotNo = m_sLotID;
//                dlg.m_sSubOperList = m_sSubOperList;
//                dlg.m_sStepNo = m_sOperation + m_sSubOperation;
//                dlg.m_sStepDesc = m_sProcessStep;
//                dlg.m_sOperSeq = m_sOperSeq;

                commentListIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                commentListIntent.putExtra("OPERATION", m_sOperation)
                commentListIntent.putExtra("SUBOPERATION", m_sSubOperation)
                commentListIntent.putExtra("PROCESSSTEP", m_sProcessStep)
                commentListIntent.putExtra("OPERSEQUENCE", m_sOperSeq)

                commentListActivityResultLauncher.launch(commentListIntent)
            }
        })

        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                onOk()
            }
        })
    }

    inner class eqpGroupGestureListener(
    ) : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent?): Boolean {
            if(viewBinding.txtStandardMachine.text.toString().isNotEmpty()) {
                OkDialog.show(
                    supportFragmentManager,
                    "기준장비",
                    viewBinding.txtStandardMachine.text.toString(),
                    GetString.BTNOKSTR,
                )
            }
            return super.onDoubleTap(e)
        }
    }

    private val waferSelectActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->
                    val selectedWaferList = intent.getStringExtra("SELECTEDWAFERLIST").toString().replace(viewBinding.txtLotNo.text.toString()+"." , "")
                    val selectedMachine = intent.getStringExtra("SELECTEDMACHINE").toString()
                    if(m_CreateCategory.isEmpty()) {
                        viewBinding.editComment.setText("; W/H:#$selectedWaferList")
                    } else {
                        viewBinding.editComment.setText(selectedMachine)
                    }
                }
            }
        }

    private val moveInInlineActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->
                    val eqpGroup = intent.getStringExtra("EQPGROUP").toString()
                    val eqpId = intent.getStringExtra("EQPID").toString()
                    val recipe = intent.getStringExtra("RECIPE").toString()
                    if(intent.getStringExtra("NRWCMTCOUNT")?.isNotEmpty() == true) {
                        m_sNRWCmtCount = intent.getStringExtra("NRWCMTCOUNT").toString().toIntOrNull() ?: 0
                    }
                    val nest = intent.getStringExtra("NEST").toString()
                    m_sIdentCodeList = intent.getStringExtra("ITDENTCODE").toString()
                    m_sMaskTag = intent.getStringExtra("MASKTAG").toString()

                    setInlineInfo(eqpGroup, eqpId, recipe,nest)
                    getLotInfoReminder()
                }
            } else {
                finish()
            }
        }

    private val processInquireActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->

                    val finishedMoveIn = intent.getStringExtra("FINISH")?.toString()
                    if(finishedMoveIn == "Y"){
                        val returnIntent = Intent()
                        returnIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                        setResult(Activity.RESULT_OK, returnIntent)
                        finish()
                    } else {
                        val changeEqpGroup = intent.getStringExtra("CHANGEEQPGROUP").toString()
                        val commentQty = intent.getStringExtra("COMMENTQTY").toString()
                        val processOperation = intent.getStringExtra("CURRENTSTEP").toString()
                        m_sSubOperation = intent.getStringExtra("SUBOPERATION").toString()
                        if (intent.getStringExtra("NRWCMTCOUNT")?.isNotEmpty() == true) {
                            m_sNRWCmtCount =
                                intent.getStringExtra("NRWCMTCOUNT").toString().toIntOrNull() ?: 0
                        }
                        if (intent.getStringExtra("SCOPESUB")?.isNotEmpty() == true) {
                            m_scopeSub =
                                intent.getStringExtra("SCOPESUB").toString()
                        }

                        viewBinding.txtCurrentOperation.text = processOperation
                        viewBinding.txtCommentSize.text = commentQty
                        if (viewBinding.txtStandardMachine.text.toString() != changeEqpGroup) {
                            viewBinding.txtStandardMachine.text = changeEqpGroup
                            viewBinding.txtStandardMachine.setTextColor(Color.RED)
                        }
                        getLotInfoReminder()
                        getInspection()
                    }
                }
            } else {
                finish()
            }
        }

    private val batchMoveInActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->
                    val returnIntent = Intent()
                    returnIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                    setResult(Activity.RESULT_OK, returnIntent)
                    finish()
                }
            }
        }

    private val recipeConfirmActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->
                    moveIn()
                }
            }
        }

    private val batchActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->
                    val lotId = intent.getStringExtra("LOTID").toString()
                    viewBinding.txtLotNo.text = lotId
                    getLotInfo()
                }
            }
        }

    private val commentListActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->

                }
            }
        }

    private fun setInlineInfo(eqpGroup:String, eqpId:String, recipe:String, nest:String){
        viewBinding.txtStandardMachine.text = eqpGroup
        viewBinding.editIngMachine.setText(eqpId)
        viewBinding.txtRecipe.text = recipe
        viewBinding.editComment.setText("NEST : $nest")
        viewBinding.editIngMachine.requestFocus()

        spinnerRecipeItems.clear()
        spinnerRecipeItems.add(recipe)
        setRecipeSpinner(spinnerRecipeItems)
        if(recipe != "") {
            viewBinding.spinnerIngRcp.setSelection(1)
        }
    }

    private fun getLotInfo() {
        mainScope.launch {
            val lotId = viewBinding.txtLotNo.text.toString()

            val sendMessage = MessageFactoryUtil.lotInfo(lotId, DeviceInfo.FACILITY, "MVIN", DeviceInfo.OPERATOR_ID)

            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.LOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sProduct = messageBody.optString("PRODUCT")
                val sFacility = messageBody.optString("FACILITY")
                val sOperation = messageBody.optString("OPERATION")
                val sCustomer = messageBody.optString("CUSTOMER")
                val sCategory = messageBody.optString("CATEGORY")
                val sEngineer = messageBody.optString("ENGINEER")
                val sPacking = messageBody.optString("PACKING")
                val sQty = messageBody.optString("QUANTITY")
                val sGoodChips = messageBody.optString("GOODCHIPS")
                val sRecipe = messageBody.optString("RECIPE")
                val sChangeRecipe = messageBody.optString("CHANGERECIPE")
                val sEqpGroup = messageBody.optString("EQPGROUP")
                val sChangeEqpGroup = messageBody.optString("CHANGEEQPGROUP")
                val sCommentQty = messageBody.optString("COMMENTQTY")
                val sBatchId = messageBody.optString("BATCHID")
                val sArea = messageBody.optString("AREA")
                val sWorkedEqpId = messageBody.optString("WORKEDEQPID")
                val sWorkedRecipe = messageBody.optString("WORKEDRECIPE")
                val sWorkedReticle = messageBody.optString("WORKEDRETICLE")
                val sJobCode = messageBody.optString("JOBCODE")
                val sProcessStep = messageBody.optString("PROCESSSTEP")
                val sSubOperation = messageBody.optString("SUBOPERATION")
                val sOpType = messageBody.optString("OPTYPE")
                val sStatus = messageBody.optString("STATUS")
                val sState = messageBody.optString("STATE")
                val sHoldStatus = messageBody.optString("HOLDSTATUS")
                val sOperSeq = messageBody.optString("OPERSEQUENCE")
                val sEtcMsg = messageBody.optString("ETCMSG")

                val sSkipAllowFlag =
                    messageBody.optString("SKIPALLOWFLAG")    //---[Addition] Nov 22, 2007. by I. H. Lee
                val sAutoSkip =
                    messageBody.optString("AUTOSKIP")            //---[Addition] 2011.09.09. by kck
                val sMeasOper =
                    messageBody.optString("MEASOPERATIONNAME")    //---[Addition] 2011.09.09. by kck
                val sFqcLot =
                    messageBody.optString("FQCLOTNAME")            //---[Addition] 2011.09.09. by kck
                val sReworkSkipFlag =
                    messageBody.optString("REWORKSKIPFLAG") //2013.11.13 Rework Skip Flag 추가 jy.Lim
                val sReworkScrubberSkipFlag =
                    messageBody.optString("REWORKSCRUBBERSKIPFLAG") //2024.03.29 Rework  scrubber Skip Flag 추가 sunggil hwang
                val sPhotoType =
                    messageBody.optString("PHOTOTYPE")    //2015.02.10 HV Asher공정 Photo 진행 관련 PhotoType 추가 wjKim
                val sPqcSkip =
                    messageBody.optString("PQCSKIPUSER") // 2015.03.03 PQCSKIP가능 판단 유무
                val sMeasSkip =
                    messageBody.optString("MEASSKIPCHECK") // 2026.01.21 PQCSKIP가능 판단 유무
                val sInlineSample =
                    messageBody.optString("INLINESAMPLEMESSGE") //---[Addition] 2015.03.18 Inline Sampling Messge 추가 메세지가 있다면  POP_up  jy.Lim
                val sCreateCategory =
                    messageBody.optString("CREATECATEGORY") //---[Addition] 2015.05.13 Dummay Count category 구분 jy.Lim
                val sLasteventcomment =
                    messageBody.optString("LASTEVENTCOMMENT") //---[Addition] 2015.05.13 Dummay Count category 구분 jy.Lim
                val sProcessName =
                    messageBody.optString("PROCESSNAME")//---[Addition] 2015.06.22 Dummay Wafer의 bach Movein못하도록 interlock
                val sOXcmpMachine =
                    messageBody.optString("OXMACHINE")        // 2016.04.06 사전 장비 확인 관련 하여
                val sFICDLot =
                    messageBody.optString("FICDLOT") // 2017.01.09 FICD SamplingLot jy.Lim
                val sMeastype =
                    messageBody.optString("MEASTYPE") // 2018.02.26 SamplingLot jy.Lim
                val sSortingSkipFlag =
                    messageBody.optString("SORTINGSKIP") // 2020.03.19 이미 Sorting 장비로 진행한 경우, default로 Skip에 Check가 되어야 하는 상태 jy.Lim
                val sMeastypeSampling =
                    messageBody.optString("SAMPLINGREASON") // 2021.04.12 UV CHECK를 위해
                val sSamplingMsg =
                    messageBody.optString("SAMPLINGMSG") // 2021.04.12 BATCH SAMPLINGMSG 확인을 위해 추가
                val sProcessType = messageBody.optString("PROCESSTYPE") // 2022.07.12 ProbeCard 사용 공정을 확인하기 위해 추가
                val sBakeCheck = messageBody.optString("BAKECHECK") // 2023.06.21   PIQ Bake Rework을 다녀온 Lot은 MP Add Etch 진행 후에만 Move In이 가능하도록 추가
                val sMacroMainMsg = messageBody.optString("MACROMSG")
                val AutomotiveFlag = messageBody.optString("AUTOMOTIVEFLAG")// [Addition] 2023.09.22 jy.Lim
                val ChamberSlotList = messageBody.optString("CHAMBERSLOTLIST")// [Addition] 2023.09.25 jy.Lim

                val sGoxPopup = messageBody.optString("GOXIDEPOPUP")

                m_autoMotiveFlag = AutomotiveFlag

                if(AutomotiveFlag == "Y")
                    viewBinding.imageCar.visibility = View.VISIBLE
                else
                    viewBinding.imageCar.visibility = View.INVISIBLE

                m_processType = sProcessType  //진행 장비 선택하고 다음 위치를 정하기 위해서. 2022.07.15

                m_sNRWCmtCount = messageBody.optString("NWCOMMENTQTY").toIntOrNull() ?: 0

                viewBinding.txtBatId.setText(sBatchId.replace(" ", ""))

                if (sCreateCategory == "COUNT") {
                    viewBinding.btnWH.setText("COUNT")
                    m_CreateCategory = "COUNT"
                    viewBinding.editComment.setText(sLasteventcomment)
                } else if (sCreateCategory == "SLOT") {
                    viewBinding.btnWH.setText("SLOT")
                    m_CreateCategory = "SLOT"
                    viewBinding.editComment.setText(sLasteventcomment)
                } else {
                    viewBinding.btnWH.setText("W/H")
                }

                if (sChangeRecipe != "" && sRecipe != sChangeRecipe) {
                    viewBinding.txtRecipe.setTextColor(Color.RED)
                }

                if (sChangeEqpGroup != "" && sChangeEqpGroup!=viewBinding.txtStandardMachine.text.toString()) {
                    viewBinding.txtStandardMachine.text = sChangeEqpGroup
                    viewBinding.txtStandardMachine.setTextColor(Color.RED)
                }
                else {
                    viewBinding.txtStandardMachine.text = sEqpGroup
                }

                m_sOperation = sOperation
                m_sSubOperation = sSubOperation
                m_sProduct = sProduct
                m_sProcessStep = sProcessStep
                m_sOperSeq = sOperSeq;
                m_sArea = sArea;
                m_sOpType = sOpType;
                viewBinding.txtBatId.text = sBatchId
                viewBinding.txtProduct.text = "$sProduct($sJobCode)"
                m_product = sProduct
                viewBinding.txtCurrentOperation.text = "$sProcessStep($sOperation$sSubOperation)"
                viewBinding.txtEngineer.text = sEngineer
                viewBinding.txtCustomer.text = sCustomer
                viewBinding.txtQty.text = sQty
                //viewBinding.txtPacking.text = sPacking    삭제 2022.07.08
                viewBinding.txtGoodChips.text = sGoodChips
                // viewBinding.txtSaleType.text = sCategory  삭제 2022.07.08
                viewBinding.txtCommentSize.text = sCommentQty
                viewBinding.txtExMachine.text = sOXcmpMachine
                viewBinding.checkCurrentOperationSkip.isEnabled = false

                if (sSkipAllowFlag == "Y"){
                    viewBinding.checkCurrentOperationSkip.isEnabled = true
                    //---[Modification] 2011.09.09. by kck (Begin)
                    if (sAutoSkip == "Y") {
                        //현공정 Skip 자동 Check
                        viewBinding.checkCurrentOperationSkip.isChecked = true
                        viewBinding.checkCurrentOperationSkip.isEnabled = sPqcSkip == "Y"
                    } else if(sAutoSkip == "N") {
                        viewBinding.checkCurrentOperationSkip.isEnabled = sPqcSkip == "Y"
                    }
                    //---[Addition] 2015.03.03 jy.Lim (End)
                    //---[Modification] 2011.09.09. by kck (End)

                    //--[Addition] 2015.10.29   jy.Lim(Begion)
                    if (sPhotoType == "DI") {
                        viewBinding.checkCurrentOperationSkip.isEnabled = true
                    }
                    //--[Addition] 2015.10.29   jy.Lim(End)
                } else if (sSkipAllowFlag == "N") {
                    viewBinding.checkCurrentOperationSkip.isEnabled = sPqcSkip == "Y"
                }

                /*if(sMacroMainMsg!=""){
                    val returnCode = OkDailogAlram.show(supportFragmentManager
                        , "Macro 측정 정보"
                        , "▶ Macro 측정 [ $sMacroMainMsg ]"
                        , GetString.BTNOKSTR
                        ,applicationContext
                        ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                }*/

                if (sMeastype != "") {
                    if (sSamplingMsg == "") {
                        if (sMeastypeSampling == "Y") {  //sMeastypeSampling uv 검사대상유무
                            OkDailogAlram.show(
                                supportFragmentManager,
                                "검사대상",
                                "UV검사 대상 Lot 입니다.",
                                GetString.POSITIVEBTNSTR,
                                applicationContext,
                                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                            )
                        } else {
                            if(sMeastype == "LAMU")  //LAMU 구분 추가
                            {
                                if(sMeastypeSampling != "EPI_SAMPLING")
                                {
                                    OkDailogAlram.show(
                                        supportFragmentManager,
                                        "검사대상",
                                        "$sMeastype 검사 대상 Lot 입니다.",
                                        GetString.POSITIVEBTNSTR,
                                        applicationContext,
                                        getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                                    )
                                }
                            }
                            else {
                                OkDailogAlram.show(
                                    supportFragmentManager,
                                    "검사대상",
                                    "$sMeastype 검사 대상 Lot 입니다.",
                                    GetString.POSITIVEBTNSTR,
                                    applicationContext,
                                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                                )
                            }
                        }
                    } else {
                        OkDailogAlram.show(
                            supportFragmentManager,
                            "검사대상",
                            "동일한 Batch에 검사대상 Lot이 있습니다.\n$sSamplingMsg",
                            GetString.POSITIVEBTNSTR,
                            applicationContext,
                            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                        )
                    }
                }
                if (ChamberSlotList != "") {  //sMeastypeSampling uv 검사대상유무
                    OkDailogAlram.show(
                        supportFragmentManager,
                        "Chamber 호기별 진행 Slot 정보",
                        ChamberSlotList,
                        GetString.POSITIVEBTNSTR,
                        applicationContext,
                        getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    )
                }

                if (sReworkSkipFlag == "Y" || sSortingSkipFlag == "Y") {
                    viewBinding.checkCurrentOperationSkip.isEnabled = true
                    viewBinding.checkCurrentOperationSkip.isChecked = true
                    m_ReworkSkip = true;
                }

                if(sReworkScrubberSkipFlag=="N"){
                    viewBinding.checkCurrentOperationSkip.isEnabled = false
                    viewBinding.checkCurrentOperationSkip.isChecked = false
                    m_ReworkSkip = false;
                }

                //2024.05.22 PQC면서 직반장 권한이 없을 경우 Skip 불가
                if(sPqcSkip=="N" && sArea =="PQC") {
                    viewBinding.checkCurrentOperationSkip.isChecked = false
                    viewBinding.checkCurrentOperationSkip.isEnabled = false
                }

                if(sMeasSkip=="N" ) {
                    viewBinding.checkCurrentOperationSkip.isChecked = false
                    viewBinding.checkCurrentOperationSkip.isEnabled = false
                }

                if (sMeasOper != "" && sFqcLot != "") {
                    OkDailogAlram.show(supportFragmentManager, "검사대상", "$sFqcLot 은 공정이물 검사 대상 Lot 입니다.",  GetString.POSITIVEBTNSTR,applicationContext,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                }

                if (sMeasOper != "" && sFICDLot != "") {
                    OkDailogAlram.show(supportFragmentManager, "검사대상", "$sFICDLot 은 FICD검사 대상 Lot 입니다.",  GetString.POSITIVEBTNSTR,applicationContext,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                }

                viewBinding.btnBatId.isEnabled = sBatchId != ""
                //  viewBinding.btnModify.isEnabled = viewBinding.editIngMachine.text.toString() != ""

                if (sEtcMsg != "") {
                    OkDailogAlram.show(supportFragmentManager, "정보", sEtcMsg,  GetString.POSITIVEBTNSTR,applicationContext,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                }

                if (sStatus == "RUN") {
                    OkDailogAlram.show(supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR, "이미 MOVE IN된 LOT입니다.", GetString.POSITIVEBTNSTR,applicationContext,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                    viewBinding.btnOk.isEnabled = false
                    return@launch
                }

                if (sState != "WIP") {
                    OkDailogAlram.show(supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR, "$sState 상태 입니다. MOVE IN할수 없습니다.", GetString.POSITIVEBTNSTR,applicationContext,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                    viewBinding.btnOk.isEnabled = false
                    return@launch
                }

                if (sHoldStatus == "ONHOLD") {
                    OkDailogAlram.show(supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR, "HOLD된 LOT입니다. MOVE IN할수 없습니다.", GetString.POSITIVEBTNSTR,applicationContext,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                    viewBinding.btnOk.isEnabled = false
                    return@launch
                }

                if(sInlineSample.isNotEmpty()){
                    OkDailogAlram.show(supportFragmentManager, GetString.TXTDIALOGTITLE_OK, sInlineSample, GetString.POSITIVEBTNSTR,applicationContext,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                }

                if ( sProcessName == "MW_TEST" && sBatchId !="")
                {
                    OkDailogAlram.show(supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR, "BATCH로 묶인 Dummy/Test LOT으로 \n" +
                            "MOVE_IN 할수 없습니다.", GetString.POSITIVEBTNSTR,applicationContext,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                    viewBinding.btnOk.isEnabled = false
                    return@launch
                }

                if ( sGoxPopup !="")
                {
                    OkDailogAlram.show(supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM, sGoxPopup, GetString.POSITIVEBTNSTR,applicationContext,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                }

                //2022.07.12 ProbeCard 사용을 위한 컨트롤 추가
                viewBinding.editProbeCard.setText("")
                viewBinding.editProbeOD.setText("")
                viewBinding.editProbeZ.setText("")
                if (sProcessType == "WT" || sProcessType == "PCM") {
                    viewBinding.editProbeCard.isEnabled = true
                    viewBinding.editProbeOD.isEnabled = true
                    viewBinding.editProbeZ.isEnabled = true
                }
                else {
                    viewBinding.editProbeCard.isEnabled = false
                    viewBinding.editProbeOD.isEnabled = false
                    viewBinding.editProbeZ.isEnabled = false
                }

                //2015.02.10 HV Asher공정 Photo 진행 관련 PhotoType 확인 로직 추가 wjKim
                if(sArea == "PHOTO") {
                    if(sOpType == "P" && sPhotoType != "NN")
                    {
                        openInlineActivity()
                    }
                    else if(sOpType != "P")
                    {
                        openProcessInquire()
                    }
                } else {
                    getLotInfoReminder()
                    if (m_sNRWCmtCount > 0) {
                        val errorMessage =
                            "읽지 않은 작업성 COMMENT가 [$m_sNRWCmtCount]가 있습니다.\n읽은 후 진행 하세요."
                        val returnCode = OkDailogAlram.show(
                            supportFragmentManager,
                            GetString.TXTDIALOGTITLE_OK,
                            errorMessage,
                            GetString.BTNOKSTR
                            ,applicationContext,
                            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                        )
                    }
                }

                if(sBakeCheck == "Y"){
                    OkDailogAlram.show(supportFragmentManager, "MOVE IN INTERLOCK", "$lotId 은(는) PIQ Bake Rework 진행 Lot으로, \n" +
                            "MP Add Etch Rework 진행이 필요합니다.", GetString.POSITIVEBTNSTR,applicationContext,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                    viewBinding.btnOk.isEnabled = false
                    return@launch
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDailogAlram.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR
                    ,applicationContext,
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)

                viewBinding.btnOk.isEnabled = false
            }
        }
    }

    private fun getLotInfoReminder(){
        if (viewBinding.txtCommentSize.text.toString().toInt() <= 0) {
            viewBinding.btnRead.isEnabled = false
            viewBinding.btnRead.setBackgroundColor(Color.GRAY)
        } else {
            viewBinding.btnRead.isEnabled = true
            viewBinding.btnRead.setBackgroundColor(Color.rgb(19, 0, 103))
        }

//        if ( m_sNRWCmtCount > 0){
//            val errorMessage = "읽지 않은 작업성 COMMENT가 [$m_sNRWCmtCount]가 있습니다.\n읽은 후 진행 하세요."
//            val returnCode = OkDialog.show(supportFragmentManager
//                , GetString.TXTDIALOGTITLE_OK
//                , errorMessage
//                , GetString.BTNOKSTR)
//        }

        val machineDetector = GestureDetectorCompat(
            this,
            eqpGroupGestureListener()
        )
        viewBinding.txtStandardMachine.setOnTouchListener { v, event ->
            machineDetector.onTouchEvent(event)
            false
        }

        viewBinding.editIngMachine.requestFocus()
    }

    private fun loginUserCheck() {
        mainScope.launch {
            if (viewBinding.editIngMachine.text.isNullOrEmpty()) {
                val returnCode = OkDailogAlram.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , "진행장비를 입력하세요."
                    , GetString.BTNOKSTR
                    ,applicationContext
                    ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                )

                viewBinding.editIngMachine.requestFocus()
                return@launch
            }

            val sendMessage =
                MessageFactoryUtil.loginUserCheck(DeviceInfo.OPERATOR_ID, viewBinding.editIngMachine.text.toString(),m_autoMotiveFlag)

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.LOGINUSERCHECK)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                Log.d("recieve recipeinfo", messageBody.toString())

                val sUserAreaFlag = messageBody.optString("AREACHECK");

                if (sUserAreaFlag == "N" || sUserAreaFlag == "") {
                    val returnCode = OkDailogAlram.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_OK
                        , "로그인한 사용자가 진행할 수 없는 장비 입니다."
                        , GetString.BTNOKSTR
                        ,applicationContext
                        ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    )

                    viewBinding.btnOk.isEnabled = false
                    return@launch
                }

                getLotInfoOk()

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDailogAlram.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR
                    ,applicationContext
                    ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
            }
        }
    }

    private fun onOk() {
        // 사용자 & 장비의 Area Check 2019.03.22 jy.Lim (Begin)
        if (!viewBinding.checkCurrentOperationSkip.isChecked) {
            if(viewBinding.editIngMachine.text.toString().isEmpty())
            {
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , "진행장비를 입력하세요."
                    , GetString.BTNOKSTR)

                viewBinding.editIngMachine.requestFocus()
                return
            }
            loginUserCheck()
        }
        else {
            if(viewBinding.editComment.text.toString().length<10 && m_sArea == "PQC")
            {
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , "PQC공정 SKIP시 Comment를 10자 이상 입력해야 합니다."
                    , GetString.BTNOKSTR)

                viewBinding.editIngMachine.requestFocus()
                return
            }

            checkDiCycle()
        }

    }

    private fun getLotInfoOk() {
        mainScope.launch {
            if(viewBinding.editIngMachine.text.toString().isEmpty())
            {
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , "진행장비를 입력하세요."
                    , GetString.BTNOKSTR)

                viewBinding.editIngMachine.requestFocus()
                return@launch
            }

            if(viewBinding.txtRecipe.text.toString().isEmpty())
            {

                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , "진행Rcp를 선택하세요."
                    , GetString.BTNYESSTR)
                return@launch
            }

            val sendMessage =
                MessageFactoryUtil.moveInLotInfo(
                    viewBinding.txtLotNo.text.toString(),
                    DeviceInfo.FACILITY,
                    viewBinding.editIngMachine.text.toString(),
                    "MVIN",
                    m_sOperation,
                    m_sSubOperation,
                    viewBinding.txtBatId.text.toString(),
                    viewBinding.txtRecipe.text.toString()
                )

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.LOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                var sNWCommentQty = messageBody.optString("NWCOMMENTQTY")
                sFICDChamber = messageBody.optString("FICDCHMBER")
                sCumCycle = messageBody.optString("CUMCYCLE")
                sCumCycleQty = messageBody.optString("CUMCYCLEQTY")  // 2020.08.05
       //         sCDmsg = messageBody.optString("CDMSG");
                sMultiMoveMSG = messageBody.optString("MULTIMOVEINMSG")
       //         sMacromsg = messageBody.optString("MACROMSG");
                sEtchReworkmsg = messageBody.optString("ETCHREWORKMSG");
       //         sScopemsg =  messageBody.optString("SCOPEMSG");
       //         sOvmsg =  messageBody.optString("sOvMSG");

                //CString sOXcmpMachine = FIND_VALUE_STRING(pItems,L"OXMACHINE");

                if (Integer.parseInt(sNWCommentQty) > 0) {
                    val errorMessage = "읽지 않은 작업성 COMMENT가 $sNWCommentQty 개 있습니다.\n읽은후 진행하세요."
                    val returnCode = OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_OK
                        , errorMessage
                        , GetString.BTNOKSTR)
                    return@launch
                }

                if (!viewBinding.txtBatId.text.isNullOrEmpty() && sMultiMoveMSG.isNotEmpty()) {
                    val returnCode = OkDialog.show(supportFragmentManager
                        , "WARNING"
                        , sMultiMoveMSG
                        , GetString.BTNOKSTR)
                }


                val recipeDialogIntent = Intent(applicationContext, RecipeDialogActivity::class.java)

                recipeDialogIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                recipeDialogIntent.putExtra("RECIPE", viewBinding.txtRecipe.text.toString() +" $m_sOverlayMessage")
                recipeDialogIntent.putExtra("SKIP", "")
                recipeDialogIntent.putExtra("EDGEFAR", m_edgeFar)


                recipeConfirmActivityResultLauncher.launch(recipeDialogIntent)

                /* old
                CRecipeConfirmDlg dlg;
                dlg.m_sRecipe = sRealRcp;
                */

                // Modification] Overlay 계측 Route가 없는경우 Overlay 육안 검사 메세지 추가 jy.Lim 2017.02.22

                //recipe dialog 추가해야댐
//                            CString ViewRecipe ;
//                            ViewRecipe.Format(L"%s %s",sRealRcp,m_sOverlayMessage);
//                            CRecipeConfirmDlg dlg;
//                            dlg.m_sRecipe = ViewRecipe;
//                            dlg.m_sLotname = m_sLotID;
//                            // 2020.12.14
//                            dlg.m_skip = L"";
//
//                            if(dlg.DoModal() != IDOK)
//                            {
//                                return;
//                            }
//                       moveIn()


            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)
            }
        }

        // Move 실행후 보여주는 것을 Lot 선택시 Text로 보여질수있도록 변경
        //if (sOXcmpMachine != L"")
        //{
        //CString sMsg;
        //sMsg.Format(L"사전 공정 진행 장비: \r\n"
        //	        L"[%s]",sOXcmpMachine);
        //MessageBox(sMsg,L"확인",MB_OK | MB_ICONINFORMATION);
        //}
        //

    }

    private fun checkDiCycle() {
        mainScope.launch {
            val sendMessage =
                MessageFactoryUtil.checkDiCycle(
                    viewBinding.txtLotNo.text.toString(),
                    DeviceInfo.FACILITY,
                    m_sOperation,
                    m_sSubOperation
                )


            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sDICYCLE = messageBody.optString("DICYCLE")
                //---[Modification] 2016.11.28 by jy.Lim (End)

                if (sDICYCLE == "Y") {
                    val recipeDialogIntent =
                        Intent(applicationContext, RecipeDialogActivity::class.java)

                    recipeDialogIntent.putExtra("LOTID", "")
                    recipeDialogIntent.putExtra(
                        "RECIPE",
                        "계측 대상 LOT 입니다.\n측정없이 SKIP 하시겠습니까?"
                    )
                    recipeDialogIntent.putExtra("SKIP", "OK")

                    recipeConfirmActivityResultLauncher.launch(recipeDialogIntent)

                } else {
                    val returnCode = OkCancelDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        "이번 공정을 SKIP 하시겠습니까?",
                        GetString.BTNYESSTR,
                        GetString.BTNNOSTR
                    )
                    if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                        return@launch
                    }

                    moveIn()
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

            }
        }

    }

    private fun moveIn() {
        mainScope.launch {
            // 아래 else문장안의 것을 옮김
            var sIsSkip = "N";
            var sReworkSkip = "N";
            if (viewBinding.checkCurrentOperationSkip.isChecked) sIsSkip = "Y";

            if (m_ReworkSkip) sReworkSkip = "Y";

            if (!viewBinding.txtBatId.text.isNullOrEmpty()) {
                openBatchMoveIn()
            } else {
                //	CString sIsSkip = L"N";
                //	if(m_oSkip) sIsSkip = L"Y";
                var sIsExposure = "N";
                if (m_oExposure) sIsExposure = "Y";

                //---[Modification] Nov 18, 2013. jy.Lim (Begin)
                var sReworkSkip = "N";
                if (m_ReworkSkip) sReworkSkip = "Y";
                //---[Modification] Nov 18, 2013. jy.Lim (End)

                val sendMessage = MessageFactoryUtil.moveIn(
                    viewBinding.txtLotNo.text.toString(),
                    DeviceInfo.FACILITY,
                    viewBinding.txtRecipe.text.toString(),
                    viewBinding.editIngMachine.text.toString(),
                    m_sOperation,
                    m_sSubOperation,
                    sIsSkip,
                    DeviceInfo.OPERATOR_ID,
                    sIsExposure,
                    m_sIdentCodeList,
                    m_sMaskTag,
                    viewBinding.txtQty.text.toString(),
                    viewBinding.editComment.text.toString(),
                    sReworkSkip
                )

                val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.MOVEIN)
                val isSuccessFul = message.isSuccessFul
                val result = message.result

                if (isSuccessFul) {
                    if (sFICDChamber != "") {
                        val returnCode = OkDailogAlram.show(supportFragmentManager
                            , "측정 CHAMBER 확인"
                            , sFICDChamber
                            , GetString.BTNOKSTR
                            ,applicationContext
                            ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                    }

                    if (sCumCycle != "") {
                        val returnCode = OkDailogAlram.show(supportFragmentManager
                            , "누적 장수 ($sCumCycleQty)"
                            , "$sCumCycle"
                            , GetString.BTNOKSTR
                            ,applicationContext
                            ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                    }

                    if (sCDmsg != "") {
                        val returnCode = OkDailogAlram.show(supportFragmentManager
                            , "CD 측정 POINT"
                            , "[CD 측정]\n $sCDmsg"
                            , GetString.BTNOKSTR
                            ,applicationContext
                            ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                    }

                    if(sMacromsg!=""){
                        val returnCode = OkDailogAlram.show(supportFragmentManager
                            , "Macro 측정 정보"
                            , "▶ Macro 측정 [ $sMacromsg ]"
                            , GetString.BTNOKSTR
                            ,applicationContext
                            ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                    }

                    if(sScopemsg !=""){
                        val returnCode = OkDailogAlram.show(supportFragmentManager
                            , "Scope 측정 정보"
                            , "$sScopemsg"
                            , GetString.BTNOKSTR
                            ,applicationContext
                            ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                    }

                    if(sOvmsg !=""){
                        val returnCode = OkDailogAlram.show(supportFragmentManager
                            , "Overlay 측정 정보"
                            , "$sOvmsg"
                            , GetString.BTNOKSTR
                            ,applicationContext
                            ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                    }

                    if(sEtchReworkmsg !=""){
                        val returnCode = OkDailogAlram.show(supportFragmentManager
                            , "Etch Rework Lot"
                            , "$sEtchReworkmsg"
                            , GetString.BTNOKSTR
                            ,applicationContext
                            ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                    }

                    lotInfoEnd()

                    val sProcard = viewBinding.editProbeCard.text.toString()
                    val sProcardID = m_ProbecardID

                    if(sProcard !="" && sProcardID !="")
                    {
                        setProbeCardHistory()
                    }

                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)

                    if (errorMessage == MVIN_ERROR_TYPE_TRANSACTION) {
                        val returnCode = OkDailogAlram.show(
                            supportFragmentManager,
                            "MOVE IN 실패",
                            "MOVE IN요청에 실패하였습니다.($errorMessage)\n RF Tag를 다시 읽고 시도 하십시오.",
                            GetString.BTNOKSTR,
                            applicationContext,
                            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                        )

                        viewBinding.btnOk.isEnabled = false
                    } else {
                        val returnCode = OkDailogAlram.show(
                            supportFragmentManager, "MOVE IN 실패", errorMessage, GetString.BTNOKSTR,applicationContext,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator )

                        viewBinding.btnOk.isEnabled = false
                    }
                }
            }
        }
    }

    private fun setProbeCardHistory(){
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.setProbeCardHistory(
                viewBinding.txtLotNo.text.toString(),
                DeviceInfo.FACILITY,
                viewBinding.txtQty.text.toString(),
                viewBinding.editIngMachine.text.toString(),
                m_sOperation,
                m_sSubOperation,
                viewBinding.txtCurrentOperation.text.toString(),
                DeviceInfo.OPERATOR_ID,
                viewBinding.editProbeCard.text.toString(),
                m_ProbecardID,
                "MOVEIN",
                viewBinding.editProbeOD.text.toString(),
                viewBinding.editProbeZ.text.toString()
            )
            val message =  MessageSender.send(supportFragmentManager, sendMessage, MessageName.PROBECARDSET)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {

            }
            else
            {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDailogAlram.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR ,applicationContext
                    ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
            }
        }
    }

    private fun lotInfoEnd(){
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.lotInfoEnd(
                viewBinding.txtLotNo.text.toString(),
                DeviceInfo.FACILITY,
                viewBinding.editIngMachine.text.toString(),
                "MOVEINEND",
                m_scopeSub
            )

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.LOTINFOEND)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                Log.d("recieve lotinfoend", messageBody.toString())

                val sMvinmsg = messageBody.optString("MVINMSG")
                val sAction = messageBody.optString("MVINACTION")

                if(!sMvinmsg.isNullOrEmpty()) {
                    val returnCode = OkDailogAlram.show(supportFragmentManager
                        , sAction
                        , sMvinmsg
                        , GetString.BTNOKSTR
                        ,applicationContext
                        ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                }

                val returnIntent = Intent()
                returnIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                setResult(Activity.RESULT_OK, returnIntent)
                finish()

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDailogAlram.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR
                    ,applicationContext
                    ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
            }
        }
    }

    private fun getRecipeInfo() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.recipeInfo(
                "N",
                viewBinding.txtLotNo.text.toString(),
                m_sOperation,
                m_sSubOperation,
                m_sProduct,
                m_mainEqpId,
                m_sOpType,
                DeviceInfo.FACILITY
            )

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.RECIPEINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                Log.d("recieve recipeinfo", messageBody.toString())

                val sEtchMessge = messageBody.optString("ETCHMESSAGE")
                m_edgeFar = messageBody.optString("EDGEFAR")
                //---[Addition] 2015.03.23 jy.Lim(Begin)
                //입력한 Lot별, 사전 Photo 진행 장비가 다른지 Check
                if (sEtchMessge != "") {
                    val returnCode = OkCancelDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        sEtchMessge,
                        GetString.BTNYESSTR,
                        GetString.BTNNOSTR
                    )
                    if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                        viewBinding.editIngMachine.setText("")
                        viewBinding.editIngMachine.requestFocus()
                        return@launch
                    }

                }
                //추가 2022.02.07
                val sInterLock = messageBody.optString("CHECKINTERLOCK");

                if (sInterLock != "") {
                    val returnCode = OkDailogAlram.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_WARNING
                        , sInterLock
                        , "OK"
                        ,applicationContext
                        ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                }
                //추가 2022.02.07



                val sMultiMoveinM = messageBody.optString("MULTIMOVEINACTION") //[Addition] 2019.09.16
                // ---[Addition] 2015.03.23 jy.Lim(Begin)
                val sRecipeID = messageBody.optString("RECIPE")
                m_sOverlayMessage = messageBody.optString("OVERLAYMESSAGE")

                //---[Addition] 2019.09.16 by jY.Lim (Begin)
                if (sMultiMoveinM != "") {
                    val returnCode = OkDailogAlram.show(supportFragmentManager
                        , "WARNING"
                        , sMultiMoveinM
                        , GetString.BTNOKSTR
                        ,applicationContext
                        ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                }
                viewBinding.txtRecipe.text = sRecipeID
                //        viewBinding.btnModify.isEnabled = true

                spinnerRecipeItems.clear()
                spinnerRecipeItems.add(sRecipeID)
                setRecipeSpinner(spinnerRecipeItems)
                if(sRecipeID!="") {
                    viewBinding.spinnerIngRcp.setSelection(1)
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                if (errorMessage == "현재 장비 상태가 비부하DOWN 입니다.") {
                    val returnCode = OkCancelDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        "현재 장비 상태가 비부하DOWN 입니다.\n장비 상태를 가동중(RUN)으로 변경 하시겠습니까?",
                        GetString.BTNYESSTR,
                        GetString.BTNNOSTR
                    )
                    if (returnCode == OkCancelDialog.RETURN_CODE_OK) {
                        changeEQPStatus()
                    }
                } else {
                    val returnCode = OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_ERROR
                        , errorMessage
                        , GetString.BTNOKSTR)

                    viewBinding.txtRecipe.text = ""
                }

            }
        }
    }


    private fun changeEQPStatus() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.changeEQPStatus(
                m_mainEqpId,
                DeviceInfo.FACILITY,
                "R  가동중",
                "RR001",
                "PDA_MVIN_UP",
                DeviceInfo.OPERATOR_ID,
                DeviceInfo.OPERATOR_NAME,
                ""
            )

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.CHANGEEQPSTATUS)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                Log.d("recieve changeEQPStatus", messageBody.toString())

                val returnCode = OkCancelDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_OK,
                    "장비상태가 변경되었습니다.\n" +
                            "진행장비의 RECIPE를 다시 요청 하시겠습니까?",
                    GetString.BTNYESSTR,
                    GetString.BTNNOSTR
                )
                if (returnCode == OkCancelDialog.RETURN_CODE_OK) {
                    getRecipeInfo()
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)
            }
        }
    }

    private fun getMCFDCMachineinfo() {
        mainScope.launch {
            val eqpId = viewBinding.editIngMachine.text.toString()
            val sendMessage = MessageFactoryUtil.mcFdcEqpInfo(eqpId)

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.MCFDCEQPINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                Log.d("recieve MCFDCEQPINFO", messageBody.toString())

                val sStatus = messageBody.optString("STATUS")
                val sMainEqp = messageBody.optString("EQPID")
                if (sStatus == "Remote") {
                    val returnCode = OkCancelDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        "[$sMainEqp] 장비는 REMOTE 대상 장비 입니다.\n" +
                                "계속 진행 하시겠습니까??",
                        GetString.BTNYESSTR,
                        GetString.BTNNOSTR
                    )
                    if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                        viewBinding.editIngMachine.setText("")
                        viewBinding.editIngMachine.requestFocus()
                        return@launch
                    }
                }
                getMachineInfo()
            } else {
                viewBinding.txtRecipe.text=""
                spinnerRecipeItems.clear()
                setRecipeSpinner(spinnerRecipeItems)
                viewBinding.editIngMachine.setText("")
                viewBinding.editIngMachine.requestFocus()
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)
            }
        }
    }

    private fun getMachineInfo() {
        mainScope.launch {
            if (m_sArea == "PHOTO" && m_sOpType == "P" && m_oExposure) {
                val returnCode = OkDailogAlram.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , "PHOTO,생산공정이고 노광과 INLINE인경우 장비를 변경할수 없습니다."
                    , GetString.BTNOKSTR
                    ,applicationContext
                    ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                return@launch
            }

            var lsMachineName = viewBinding.editIngMachine.text.toString()
            m_mainEqpId = viewBinding.editIngMachine.text.toString()




            if (!((m_sOpType != "M") && (viewBinding.txtStandardMachine.text.toString() != "FAB2") && (viewBinding.txtStandardMachine.text.toString() != "FAB5") && (viewBinding.txtStandardMachine.text.toString() != "FAB7") && (m_sArea != "PQC"))) {
                getRecipeInfo()
                return@launch
            }

            val sendMessage = MessageFactoryUtil.eqpInfo(lsMachineName, "MOVEIN", viewBinding.txtLotNo.text.toString())

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.EQPINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                Log.d("recieve eqpinfo", messageBody.toString())

                val sMainEqp = messageBody.optString("MAINEQPID")
                val sSubEqp = messageBody.optString("SUBEQPID")


                m_mainEqpId = sMainEqp
                //     viewBinding.editIngMachine.setText(sMainEqp)
                if (sSubEqp == sMainEqp) {
                    lsMachineName = sMainEqp
                } else {
                    lsMachineName = sSubEqp
                }


                if (!ValidateCheck(this@MoveInActivity).equipment(viewBinding.txtStandardMachine.text.toString(), lsMachineName)) {
                    viewBinding.editIngMachine.setText("")
                    viewBinding.editIngMachine.requestFocus()
                    return@launch
                }

                val sInterLock = messageBody.optString("CHECKINTERLOCK");

                if (sInterLock != "") {
                    val returnCode = OkDailogAlram.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_OK
                        , sInterLock
                        , "OK"
                        ,applicationContext
                        ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                }

                //           viewBinding.editIngMachine.setText(lsMachineName)

                getRecipeInfo()
            } else {
                viewBinding.txtRecipe.text=""
                spinnerRecipeItems.clear()
                setRecipeSpinner(spinnerRecipeItems)
                viewBinding.editIngMachine.setText("")
                viewBinding.editIngMachine.requestFocus()
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDailogAlram.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR
                    ,applicationContext
                    ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
            }
        }
    }

    private fun getProbeValue() {
        mainScope.launch {
            var lsProbeCard = viewBinding.editProbeCard.text.toString()
            var lsProsuctName = m_product
            var lsMachineName = viewBinding.editIngMachine.text.toString()

            val sendMessage =
                MessageFactoryUtil.probeCardValue(lsProbeCard, lsProsuctName, lsMachineName)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.PROBECARDVALUE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val sValue_OD = messageBody.optString("VALUE_OD")
                val sValue_Z = messageBody.optString("VALUE_Z")

                viewBinding.editProbeOD.setText(sValue_OD)
                viewBinding.editProbeZ.setText(sValue_Z)

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDailogAlram.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR,
                    applicationContext,
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                )

                viewBinding.editProbeCard.setText("")
                viewBinding.editProbeCard.requestFocus()
            }
        }
    }

    private fun getProbeCardInfo(){
        mainScope.launch {
            var lsProbeCard = viewBinding.editProbeCard.text.toString()
            var machine = viewBinding.editIngMachine.text.toString()

            val sendMessage = MessageFactoryUtil.probecardinfo(lsProbeCard,machine)
            val message =  MessageSender.send(supportFragmentManager, sendMessage, MessageName.PROBECARDINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            viewBinding.editProbeOD.setText("")
            viewBinding.editProbeZ.setText("")

            if(isSuccessFul){
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val sStatus = messageBody.optString("PROBECARDSTATUS")
                val sProbeCardNo = messageBody.optString("PROBECARDNO")
                val sMsg = messageBody.optString("PROBECARDMSG")
                val checkLastProbe = messageBody.optString("CHECKLASTPROBE")

                if(sStatus == "Y")
                {
                    if(checkLastProbe=="Y"){
                        OkDialog.show(
                            supportFragmentManager,
                            GetString.TXTDIALOGTITLE_WARNING,
                            "기존 Probe card와 다릅니다. 확인 하셨나요?",
                            GetString.BTNOKSTR
                        )
                    }
                    m_ProbecardID = sProbeCardNo
                    //viewBinding.editProbeCardNo.setText(sProbeCardNo)
                    if(m_processType == "WT") {
                        getProbeValue()
                    }
                }else {
                    if(sMsg != "")
                    {
                        OkDailogAlram.show(
                            supportFragmentManager, "PROBE CARD INTERLOCK",
                            sMsg,GetString.BTNOKSTR ,applicationContext
                            ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                        )
                    }else {
                        // 현재 Probecard의 상태가 대가가 아닐경우
                        OkDailogAlram.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            "사용할 수 없는 PROBECARD입니다.", GetString.BTNOKSTR ,applicationContext
                            ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                    }

                    viewBinding.editProbeCard.setText("")
                    //viewBinding.editProbeCardNo.setText("")
                    viewBinding.editProbeCard.requestFocus()
                }
            }else{
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDailogAlram.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR ,applicationContext
                    ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)

                viewBinding.editProbeCard.setText("")
                //viewBinding.editProbeCardNo.setText("")
                viewBinding.editProbeCard.requestFocus()
            }
        }
    }

    private suspend fun selectWafer():String {
        var returnWaferList = ""
        val sendMessage = MessageFactoryUtil.slotInfo(viewBinding.txtLotNo.text.toString(), DeviceInfo.FACILITY)

        val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.SLOTINFO)
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            Log.d("recieve slotinfo", messageBody.toString())

            val sEnabledWaferList = messageBody.optString("WAFERLIST");
            returnWaferList = sEnabledWaferList
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            val returnCode = OkDialog.show(supportFragmentManager
                , GetString.TXTDIALOGTITLE_ERROR
                , errorMessage
                , GetString.BTNOKSTR)
        }

        return returnWaferList
    }

    private fun openInlineActivity() {
        val lotId = viewBinding.txtLotNo.text.toString()
        val moveInInlineIntent = Intent(applicationContext, MoveInInlineActivity::class.java)
        moveInInlineIntent.putExtra("LOTID",lotId )
        moveInInlineIntent.putExtra("OPERATION", m_sOperation)
        moveInInlineActivityResultLauncher.launch(moveInInlineIntent)
    }

    private fun openProcessInquire() {
        val lotId = viewBinding.txtLotNo.text.toString()
        val isSkip = if(viewBinding.checkCurrentOperationSkip.isEnabled)  "Y"  else "N"
        var sReworkSkip = "N";
        if (m_ReworkSkip) sReworkSkip = "Y";

        val processInquireIntent = Intent(applicationContext, ProcessInquireActivity::class.java)
        processInquireIntent.putExtra("LOTID",lotId )
        processInquireIntent.putExtra("OPERATION", m_sOperation)
        processInquireIntent.putExtra("ISSKIP", isSkip)
        processInquireIntent.putExtra("REWORKSKIP", sReworkSkip)

        processInquireActivityResultLauncher.launch(processInquireIntent)
    }

    private fun openBatchMoveIn() {
        val batchMoveInIntent = Intent(applicationContext, BatchMoveInActivity::class.java)
        batchMoveInIntent.putExtra("BATCHID", viewBinding.txtBatId.text.toString())
        batchMoveInIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
        batchMoveInIntent.putExtra("EQPID", viewBinding.editIngMachine.text.toString())
        batchMoveInIntent.putExtra("RECIPE", viewBinding.txtRecipe.text.toString())
        batchMoveInIntent.putExtra("ISSKIP", "N")
        batchMoveInActivityResultLauncher.launch(batchMoveInIntent)
    }

    private fun setRecipeSpinner(items : ArrayList<String>){
        val myAdapter = ArrayAdapter(this, R.layout.contact_spinner_row_init, items)
        myAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerIngRcp.adapter = InitSpinnerAdapter(myAdapter, R.layout.contact_spinner_row_init, applicationContext)
    }


    private fun getInspection() {

        var sSampleVimsg =""
        var sSampleCDmsg =""
        var sSampleOvmsg =""

        mainScope.launch {
            val sendMessage = MessageFactoryUtil.checkinspection(
                viewBinding.txtLotNo.text.toString(),
                DeviceInfo.FACILITY,
                "DIMVIN",
                m_sOperation,
                m_sSubOperation
            )
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.CHECKINSPACTION
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                sMacromsg = messageBody.optString("MACROMSG");
                sScopemsg = messageBody.optString("SCOPEMSG");
                sCDmsg = messageBody.optString("CDMSG");
                sOvmsg = messageBody.optString("sOvMSG");
            }
        }
    }

}
