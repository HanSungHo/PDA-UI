package com.keyfoundry.hifos.config.service.update

//data class VersionInfo(
//    val version: Int,
//)

data class VersionInfo(var elements:Array<VersionName>)
data class VersionName(var versionName:String, var type:String)