/*
package com.keyfoundry.hifos.view.chat

sealed class TreeItem {
    data class AreaItem(val area: AreaGroup, var isExpanded: Boolean = true) : TreeItem()
    data class BayItem(val bay: BayGroup, var isExpanded: Boolean = true) : TreeItem()
    data class DeviceItem(val device: Device) : TreeItem()
}*/
