package com.keyfoundry.hifos.view.esheet.comment

import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.View
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityCommentViewBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CommentViewActivity : HFActivity() {
    init {
        this.update = false
    }

    companion object {
        private const val TAG = "CommentViewActivity"
    }

    private lateinit var viewBinding: ActivityCommentViewBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    lateinit var lotId: String
    lateinit var operation: String
    lateinit var subOperation: String
    lateinit var commentNo: String
    lateinit var operSequence: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityCommentViewBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.txtProcessNum.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtProcessStep.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtNo.movementMethod = ScrollingMovementMethod.getInstance()

        lotId = intent.getStringExtra("lotId").toString()
        operation = intent.getStringExtra("operation").toString()
        subOperation = intent.getStringExtra("subOperation").toString()
        commentNo = intent.getStringExtra("commentNo").toString()
        operSequence = ""

        viewBinding.txtLotNo.text = lotId
        viewBinding.txtNo.text = commentNo
        val processNum = "$operation$subOperation"
        viewBinding.txtProcessNum.text = processNum
        viewBinding.txtOperator.text = DeviceInfo.OPERATOR_ID

        viewBinding.btnOk.setOnClickListener(onClickListener)
        viewBinding.btnCancel.setOnClickListener(onClickListener)

        getCommentView()
    }

    private val onClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnOk.id -> commentSet()
                viewBinding.btnCancel.id -> finish()
            }
        }
    }

    private fun getCommentView() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.comment(
                lotId, DeviceInfo.FACILITY, operation, subOperation,
                commentNo, operSequence, DeviceInfo.OPERATOR_ID
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.COMMENT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val description = messageBody.optString("DESCRIPTION")
                val processStep = messageBody.optString("PROCESSSTEP")
                val password = messageBody.optString("PW")
                val isCurrent = messageBody.optString("ISCURRENT")
                val workCode = messageBody.optString("WORKCODE")
                val isCheck = messageBody.optString("ISCHECK")

                viewBinding.txtComment.text = description
                viewBinding.txtProcessStep.text = processStep
                viewBinding.editPassword.setText(password)

                if (isCurrent != "Y") {
                    viewBinding.btnOk.visibility = View.GONE
                    viewBinding.btnCancel.text = "닫기"
                } else {
                    if (workCode == "W" && isCheck == "N") {
                        if (DeviceInfo.PERMISSION == "C" || DeviceInfo.PERMISSION == "H" || DeviceInfo.PERMISSION == "B") {
                            viewBinding.btnOk.visibility = View.VISIBLE
                            viewBinding.btnCancel.text = "취소"
                        } else {
                            viewBinding.btnOk.visibility = View.GONE
                            viewBinding.btnCancel.text = "닫기"
                        }
                    } else {
                        viewBinding.btnOk.visibility = View.GONE
                        viewBinding.btnCancel.text = "닫기"
                    }
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun commentSet() {
        mainScope.launch {
            val password = viewBinding.editPassword.text.toString()

            val sendMessage = MessageFactoryUtil.commentSet(
                lotId, DeviceInfo.FACILITY, operation, subOperation, commentNo,
                DeviceInfo.OPERATOR_ID, DeviceInfo.OPERATOR_NAME, operSequence, password
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.COMMENTSET)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                finish()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }

        }
    }
}