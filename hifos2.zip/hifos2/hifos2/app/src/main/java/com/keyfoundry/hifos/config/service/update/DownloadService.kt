package com.keyfoundry.hifos.config.service.update

import android.app.IntentService
import android.content.Intent
import android.os.Environment
import android.util.Log
import androidx.core.content.FileProvider
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.keyfoundry.hifos.BuildConfig
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.service.RetrofitSyncService
import com.keyfoundry.hifos.config.service.RetrofitUpdateService
import com.keyfoundry.hifos.config.service.dto.ErrorData
import kotlinx.coroutines.*
import okhttp3.ResponseBody
import java.io.*
import kotlin.concurrent.thread
import kotlin.math.pow

class DownloadService : IntentService("Download Service") {

    companion object {
        private const val TAG = "DownloadService"
        private var downloadFlag = false

        // ★ Intent key 상수
        const val EXTRA_FILE_URL = "extra_file_url"
        const val EXTRA_FILE_NAME = "extra_file_name"
    }

    private var totalFileSize = 0.0

    override fun onHandleIntent(intent: Intent?) {

        // ★ Intent에서 파일명/URL 추출
        val fileUrl = intent?.getStringExtra(EXTRA_FILE_URL) ?: "upload/hifos.apk"
        val fileName = intent?.getStringExtra(EXTRA_FILE_NAME) ?: "hifos.apk"

        if(downloadFlag) {
            installApplication(fileName)
        } else {
            synchronized(this) {
                initDownload(fileUrl, fileName)
            }
        }

    }

    private fun initDownload(fileUrl: String, fileName: String) {
        Log.d(TAG, "initDownload")
        val request = RetrofitUpdateService.API.downloadFile(fileUrl)
        try {
            downloadFile(request?.execute()?.body(),fileName)
        } catch (e: IOException) {
            e.printStackTrace()
         //   Toast.makeText(applicationContext, e.message, Toast.LENGTH_SHORT).show()
        }
    }

    @Throws(IOException::class)
    private fun downloadFile(body: ResponseBody?, filename:String) {
        Log.d(TAG, "downloadFile")
        var count: Int
        val data = ByteArray(1024 * 4)
        val fileSize = body!!.contentLength()
        val bis: InputStream = BufferedInputStream(body.byteStream(), 1024 * 8)

        val savePath = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS).toString() + File.separator + "DOWNLOADS")

        if (!savePath.exists()) {
            try {
                savePath.mkdirs()
            } catch (e: SecurityException) {
                e.printStackTrace()
            }
        }
        val outputFile = File(savePath, filename)

        val output: OutputStream = FileOutputStream(outputFile)
        var total: Long = 0
        val startTime = System.currentTimeMillis()
        var timeCount = 1
        while (bis.read(data).also { count = it } != -1) {
            total += count.toLong()
            totalFileSize = (fileSize / 1024.0.pow(2.0))
            val current = total / 1024.0.pow(2.0)
            val progress = total * 100 / fileSize.toDouble()
            val currentTime = System.currentTimeMillis() - startTime
            val download = DownloadProgress()
            download.totalFileSize = totalFileSize
            if (currentTime > 1000 * timeCount) {
                download.currentFileSize = current
                download.progress = progress
                sendNotification(download)
                timeCount++
            }
            output.write(data, 0, count)
        }
        onDownloadComplete()
        output.flush()
        output.close()
        bis.close()

        downloadFlag = true

        Thread.sleep(100L)

        installApplication(filename)
    }

    private fun installApplication(fileName: String) {
        Log.d(TAG, "Install Application")

        val apkPath =
            File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS).toString() + File.separator + "DOWNLOADS").toString() + "/$fileName"
        //    val apkPath= filesDir.absolutePath + "/hifos.apk"
        val apkUri =
            FileProvider.getUriForFile(
                applicationContext,
                BuildConfig.APPLICATION_ID + ".fileprovider", File(apkPath)
            )

        val intent = Intent(Intent.ACTION_VIEW)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.setDataAndType(apkUri, "application/vnd.android.package-archive")

  //      startActivity(intent)

        //설치 화면이 안뜨는 경우가 있어 최대 3번 재시도 한다.
        for(i in 0..2) {
            startActivity(intent)
            Thread.sleep(50L)
        }


    }

    private fun sendNotification(downloadProgress: DownloadProgress) {
        Log.d(TAG, "sendNotification")
        sendIntent(downloadProgress)
    }

    private fun sendIntent(downloadProgress: DownloadProgress) {
        Log.d(TAG, "sendIntent")
        val intent = Intent("message_progress")
        intent.putExtra("download", downloadProgress)
        LocalBroadcastManager.getInstance(this@DownloadService).sendBroadcast(intent)
    }

    private fun onDownloadComplete() {
        Log.d(TAG, "onDownloadComplete")
        val download = DownloadProgress()
        download.progress = 100.0
        sendIntent(download)
    }

    override fun onTaskRemoved(rootIntent: Intent) {
//        notificationManager.cancel(0);
    }


}