package com.keyfoundry.hifos.view.diff

import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.KeyEvent.KEYCODE_ENTER
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import androidx.core.view.children
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityDiffInstParameterBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.util.*

class DiffInstParameterActivity : HFActivity() {
    companion object {
        private const val TAG = "DiffInstParameterActivity"
    }

    private lateinit var viewBinding: ActivityDiffInstParameterBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    lateinit var gridService: GridService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityDiffInstParameterBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()
            Log.d(TAG, lotId)
            viewBinding.editLotNo.setText(lotId)
            getEqpData()
        }

        //userInfoService = UserInfoService(applicationContext)
        gridService = GridService(applicationContext)

        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
            }
        })

        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                insertParameter()
            }
        })

        viewBinding.btnSearch.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val lotNo = viewBinding.editLotNo.text.toString().toUpperCase(Locale.ROOT)

                if (lotNo.replace(" ", "").isEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "LOT을 입력하세요.", GetString.BTNOKSTR
                    )
                } else {
                    getEqpData()
                }
            }
        })

        viewBinding.editLotNo.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)
                if (check) {
                    getEqpData()
                }

            } else if (event != null) { // Barcode Event
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)
                    if (check) {
                        getEqpData()
                    }
                }
            }
            true
        }
    }

    private fun getEqpData() {
        clearData()
        val lotNo = viewBinding.editLotNo.text.toString()
        val sendMessage = MessageFactoryUtil.diffEqpDataInfo(lotNo)
        mainScope.launch {
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.DIFFEQPDATAINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val lotProcessState = messageBody.optString("LOTPROCESSSTATE")
                if (!lotProcessState.equals("RUN")) {
                    OkDialog.show(
                        supportFragmentManager, "선측정 불가",
                        "MOVE IN 후에만 DATA 입력이 가능합니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editLotNo.setText("")
                    clearData()
                    return@launch
                }
                val batchId = messageBody.optString("BATCHID")
                val machineName =
                    messageBody.optString("MACHINENAME")
                val processOperationName =
                    messageBody.optString("PROCESSOPERATIONNAME")
                val reUpdate = messageBody.optString("REUPDATE")

                if (!reUpdate.equals("N")) {
                    val returnCode = OkCancelDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                        "[$reUpdate]에 이미 데이터가 입력 되었습니다.\n" +
                                "데이터를 다시 입력하시겠습니까?",
                        GetString.BTNYESSTR, GetString.BTNNOSTR
                    )
                    if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                        viewBinding.editLotNo.setText("")
                        return@launch
                    }
                }
                viewBinding.txtBatchId.text = batchId
                viewBinding.txtMachineName.text = machineName
                viewBinding.txtProcessNum.text = processOperationName
                getDiffParameter(machineName)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }

        }
    }

    private fun getDiffParameter(machineName: String) {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.getEqpPara(machineName, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.GETEQPPARA)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val getDate = messageBody.optString("GETDATE")
                if (getDate.equals("N")) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "입력가능한 Parameter가 없습니다.",
                        GetString.BTNOKSTR
                    )
                    viewBinding.editLotNo.setText("")
                    clearData()
                    return@launch
                }
                val eqpListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "EQPDATA")

                setGridData(eqpListJSON)
                viewBinding.btnOk.isEnabled = true
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }

        }
    }

    private fun insertParameter() {
        mainScope.launch {
            val machineName = viewBinding.txtMachineName.text.toString()
            val batchId = viewBinding.txtBatchId.text.toString()
            var eqpPara = ""
            var eqpParaNo = ""
            var eqpParaMax = ""

            val mainGrid = viewBinding.baseLayout.getChildAt(0) as CTMainLayout
            val mainTable = mainGrid.mainTable

            for (row in 0 until mainTable.childCount) {
                val columnIndex = gridService.getColumnIndex(mainGrid, "DATA")
                val dataRow = mainTable.getChildAt(row) as CTRowLayout
                val cellText = (dataRow.getChildAt(columnIndex) as TextView).text.toString()

                val mainRow = mainTable.getChildAt(row)

                if (cellText.isEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "모든 Parameter에 대해, 계측값을 입력하시기 바랍니다",
                        GetString.BTNOKSTR
                    )
                    return@launch
                }

                if (row == 0) {
                    eqpPara = cellText
                    eqpParaNo = gridService.getCellValue(mainRow, "NO")
                    eqpParaMax = gridService.getCellValue(mainRow, "MAX")
                } else {
                    eqpPara += "|" + cellText
                    eqpParaNo += "|" + gridService.getCellValue(mainRow, "NO")
                    eqpParaMax += "|" + gridService.getCellValue(mainRow, "MAX")
                }
            }

            val sendMessage = MessageFactoryUtil.insertPara(
                DeviceInfo.OPERATOR_ID, batchId, machineName, DeviceInfo.FACILITY,
                eqpPara, eqpParaNo, eqpParaMax
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.INSERTPARA)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val machineState = messageBody.optString("MACHIHNESTATE")

                if (!machineState.equals("")) {
                    OkDialog.show(
                        supportFragmentManager, "장비 상태 변경", machineState, GetString.BTNOKSTR
                    )
                }

                OkDialog.show(
                    supportFragmentManager, "완료", "정상 입력 되었습니다.", GetString.BTNOKSTR
                )

                viewBinding.editLotNo.setText("")
                clearData()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }

        }
    }

    private fun setGridData(gridData: JSONArray) {
        val columnData = linkedMapOf(
            "NO" to ColumnProperty("NO", Gravity.CENTER, false, 230),
            "PARA" to ColumnProperty("PARA", Gravity.CENTER, false, 210),
            "MIN" to ColumnProperty("MIN", Gravity.CENTER, false, 80),
            "MAX" to ColumnProperty("MAX", Gravity.CENTER, false, 80),
            "DATA" to ColumnProperty("DATA", Gravity.CENTER, false, 100, true),
        )

        val mainGrid = gridService.setGridPropData(columnData, gridData)
        viewBinding.baseLayout.addView(mainGrid)

        val mainTable = mainGrid.mainTable

        val manager: InputMethodManager =
            getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val editViewList = ArrayList<EditText>()

        for (mainRow in mainTable.children) {
            val editDataTextView = (mainRow as CTRowLayout).getChildAt(4) as EditText
            editViewList.add(editDataTextView)
            mainRow.isFocusable = false
            mainRow.isFocusableInTouchMode = false
        }

        for (i in 0 until editViewList.size) {

            editViewList[i].isSingleLine = true

            //숫자만 입력 가능하도록
            editViewList[i].inputType =
                InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL

            //enter key 누르면 아래로 focus 이동
            //마지막 row일경우 키보드 내림
            editViewList[i].setOnKeyListener { v, keyCode, event ->
                if (event.action == KeyEvent.ACTION_UP && keyCode == KEYCODE_ENTER) {
                    if (i != editViewList.size - 1) {
                        editViewList[i + 1].requestFocus()
                        manager.showSoftInput(editViewList[i + 1], InputMethodManager.SHOW_IMPLICIT)
                    }
                }

                false
            }
        }

        editViewList[0].requestFocus()
        manager.showSoftInput(editViewList[0], InputMethodManager.SHOW_IMPLICIT)
    }

    private fun clearData() {
        viewBinding.baseLayout.removeAllViews()

        viewBinding.txtBatchId.text = ""
        viewBinding.txtMachineName.text = ""
        viewBinding.txtProcessNum.text = ""

        viewBinding.btnOk.isEnabled = false
    }

}

