package com.keyfoundry.hifos.config.domain

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/*
* 안드로이드 내부 DB 서버 정보 Table
* */
@Entity(tableName = "server_info", indices = [Index(value = ["serverType"], unique = true)])
class ServerInfo {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo
    var no: Long? = null

    @ColumnInfo
    var serverName: String = ""

    @ColumnInfo
    var serverUrl: String = ""


    @ColumnInfo
    var serverType: String = ""

    @ColumnInfo
    var selectedServer: Boolean

    constructor(serverName : String, serverUrl : String
                , serverType : String, selectedServer : Boolean) {
        this.serverName = serverName
        this.serverUrl = serverUrl
        this.serverType = serverType
        this.selectedServer = selectedServer
    }

}
