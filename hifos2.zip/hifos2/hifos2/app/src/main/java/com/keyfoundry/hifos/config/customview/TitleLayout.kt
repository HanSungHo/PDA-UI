package com.keyfoundry.hifos.config.customview

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.TextView
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.databinding.TitleLayoutBinding

/*
* 화면 상단 TITLE 디자인 관련 Class
* */
class TitleLayout @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {
    var viewBinding: TitleLayoutBinding

    init {
        val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        viewBinding = TitleLayoutBinding.inflate(inflater)
        val thisView = inflater.inflate(R.layout.title_layout, this, false)

        addView(thisView)

        if (attrs != null) {
            val titleTextView = thisView.findViewById<TextView>(R.id.txt_title)

            val typeArray = context.obtainStyledAttributes(attrs, R.styleable.TitleLayout)
            titleTextView.text = typeArray.getString(R.styleable.TitleLayout_text)

            typeArray.recycle()
        }
    }
}