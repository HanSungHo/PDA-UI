package com.keyfoundry.hifos.config.const

// Mobile Server 및 Update Server 정보
interface ServerType {
    companion object{
        const val DEFAULT_SERVER = "DEFAULT_SERVER"
        const val SELECTED_SERVER = "SELECTED_SERVER"

        const val PROD_SERVER = "PROD_SERVER"
        const val DEV_SERVER = "DEV_SERVER"

        var DEFAULT_MOBILE_SERVER_URL = "http://127.0.0.1:8080"
        var DEFAULT_UPDATE_SERVER_URL = "http://127.0.0.1:8081"

        var MOBILE_SERVER_URL = DEFAULT_MOBILE_SERVER_URL
        var UPDATE_SERVER_URL = DEFAULT_UPDATE_SERVER_URL

        const val MOBILE_SERVER_NAME = "L4-DEVICE"

        const val PROD_MOBILE_SERVER_NAME = "L4-DEVICE"
        const val DEV_MOBILE_SERVER_NAME = "DEV-SERVER"

        const val PROD_MOBILE_SERVER_IP = "127.0.0.1"
        const val DEV_MOBILE_SERVER_IP = "10.0.0.1"

        const val MOBILE_SERVER_PORT = "8080"
        const val UPDATE_SERVER_PORT = "8081"

        // Timeout 설정
        const val RETROFIT_CONNECT_TIMEOUT = 10L
        const val RETROFIT_READ_TIMEOUT = 10L
        const val RETROFIT_WRITE_TIMEOUT = 10L
        //test
    }
}