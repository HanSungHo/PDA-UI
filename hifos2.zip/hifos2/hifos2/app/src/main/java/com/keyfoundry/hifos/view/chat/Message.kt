package com.keyfoundry.hifos.view.chat

data class Message(
    val roomId: String,
    val senderId: String,
    val senderIp: String,
    val text: String,
    val time: String,
    val type: String
)