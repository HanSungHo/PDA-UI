package com.keyfoundry.hifos.view.lot

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputFilter
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityLotStatusBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.cmm.WaferSelectActivity
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class LotStatusActivity : HFActivity() {
    companion object {
        private const val TAG = "LotStatusActivity"
    }

    private lateinit var viewBinding: ActivityLotStatusBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var searchHoldComment = ""
    private var searchWaferList = ""

    private var g_operation = ""
    private var g_Lot = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityLotStatusBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()

            viewBinding.editLotNo.setText(lotId)
            searchData(lotId)
        }

        viewBinding.editLotNo.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                if (check)
                    searchData(viewBinding.editLotNo.text.toString())
                else
                    clearData()
            } else if (event != null) { // Barcode Event
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                    if (check)
                        searchData(viewBinding.editLotNo.text.toString())
                    else
                        clearData()
                }
            }

            true
        }

        viewBinding.btnSearchLotNo.setOnClickListener(onSingleClickListener)
        viewBinding.btnWafer.setOnClickListener(onSingleClickListener)
        viewBinding.btnHoldCd.setOnClickListener(onSingleClickListener)
        viewBinding.btnClose.setOnClickListener(onSingleClickListener)
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchLotNo.id -> {
                    searchData(viewBinding.editLotNo.text.toString())
                }
                viewBinding.btnWafer.id -> {
                    if (viewBinding.btnWafer.isEnabled) {
                        val waferIntent = Intent(applicationContext, WaferSelectActivity::class.java)

                        waferIntent.putExtra("EDITABLE", "N")
                        waferIntent.putExtra("LOTID", viewBinding.editLotNo.text.toString())
                        waferIntent.putExtra("EXISTWAFERLIST", searchWaferList)

                        startActivity(waferIntent)
                    } else {
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            "조회된 정보가 없습니다.", GetString.BTNOKSTR
                        )
                    }
                }
                viewBinding.btnHoldCd.id -> {
                    if(searchHoldComment == "SPC OUT HOLD"){
                        getSlotParticleInfo()
                    } else {
                        if (searchHoldComment.isNotEmpty()) {
                            OkDialog.show(
                                supportFragmentManager, "HOLD Comment정보",
                                searchHoldComment, GetString.BTNOKSTR
                            )
                        }
                    }


                }
                viewBinding.btnClose.id -> {
                    finish()
                }
            }
        }
    }



    private fun clearData() {
        viewBinding.txtJobResult.text = null
        viewBinding.txtStatusResult.text = null
        viewBinding.txtProductName.text = null
        viewBinding.txtCurrentOperation.text = null
        viewBinding.tOperation.text = null
        viewBinding.txtRework.text = null
        viewBinding.txtRwCd.text = null
        viewBinding.txtHold.text = null
        viewBinding.txtHoldCd.text = null
        viewBinding.txtArea.text = null
        viewBinding.txtQuantity.text = null
        viewBinding.txtDueData.text = null
        viewBinding.txtBay.text = null
        viewBinding.txtOwner.text = null
        viewBinding.txtStk.text = null
        viewBinding.txtLotKinds.text = null
        viewBinding.txtMachine.text = null
        viewBinding.txtFacility.text = null

        viewBinding.txtStatusResult.background = null

        searchHoldComment = ""
        searchWaferList = ""

        viewBinding.btnWafer.isEnabled = false

        viewBinding.txtStatusResult.background = null
        viewBinding.txtStatusResult.setTextColor(Color.WHITE)
    }

    private fun searchData(lotId: String) {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@LotStatusActivity, currentFocus)

            clearData()

            if (lotId.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT ID을 입력하세요", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.lotInfo("NORMAL", lotId, DeviceInfo.FACILITY)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val product = messageBody.optString("PRODUCT")
                val facility = messageBody.optString("FACILITY")
                val operation = messageBody.optString("OPERATION")
                val customer = messageBody.optString("CUSTOMER")
                val category = messageBody.optString("CATEGORY")
                val engineer = messageBody.optString("ENGINEER")
                val packing = messageBody.optString("PACKING")
                val qty = messageBody.optString("QUANTITY")
                val goodChips = messageBody.optString("GOODCHIPS")
                val recipe = messageBody.optString("RECIPE")
                val eqpGroup = messageBody.optString("EQPGROUP")
                val commentQty = messageBody.optString("COMMENTQTY")
                val wCommentQty = messageBody.optString("WCOMMENTQTY")
                val batchId = messageBody.optString("BATCHID")
                val area = messageBody.optString("AREA")
                val workedEqpId = messageBody.optString("WORKEDEQPID")
                val workedRecipe = messageBody.optString("WORKEDRECIPE")
                val workedReticle = messageBody.optString("WORKEDRETICLE")
                val jobCode = messageBody.optString("JOBCODE")
                val processStep = messageBody.optString("PROCESSSTEP")
                val subOperation = messageBody.optString("SUBOPERATION")
                val opType = messageBody.optString("OPTYPE")
                val status = messageBody.optString("STATUS")
                val state = messageBody.optString("STATE")
                val holdStatus = messageBody.optString("HOLDSTATUS")
                val nextOperation = messageBody.optString("NEXTOPERATION")
                val nextSubOperation = messageBody.optString("NEXTSUBOPERATION")
                val nextProcessStep = messageBody.optString("NEXTPROCESSSTEP")
                val reworkInfo = messageBody.optString("REWORKINFO")
                val holdCode = messageBody.optString("HOLDCODE")
                val reworkCode = messageBody.optString("REWORKCODE")
                val dueDate = messageBody.optString("DUEDATE")
                val owner = messageBody.optString("OWNER")
                val bay = messageBody.optString("BAY")
                val stocker = messageBody.optString("STOCKER")
                val currentEqpID = messageBody.optString("CURRENTEQPID")
                val enabledWaferList = messageBody.optString("WAFERLIST")
                //[Addition] Jul 07, 2003. I. H. Lee
                val holdComment = messageBody.optString("HOLD_COMMENT")
                val reworkCount = messageBody.optString("REWORKCOUNT")

                g_Lot = viewBinding.editLotNo.text.toString()
                g_operation = "$operation-$subOperation"
                searchHoldComment = holdComment

//                var slotParticleList = ResponseDataToJsonUtil.getMessageBodyInValueNullCheckList(result, "SLOTPARTICLE", "SLOTPARTICLES").toString()

//                if(searchHoldComment=="SPC OUT HOLD") {
//                    searchHoldComment +="\n"
//
//                    slotParticleList = slotParticleList.replace("},", "\n").replace(Regex("[\"{}\\[\\]]"), "")
//                    searchHoldComment += slotParticleList
//                }

                searchWaferList = enabledWaferList

                val holdState = if (messageBody.optString("HOLDCODE") == "ONHOLD")
                    "Y"
                else
                    "N"

                val lotStatus = if (holdState == "Y")
                    "HOLD"
                else
                    messageBody.optString("STATUS")

                val currentStep = "$processStep($operation$subOperation)"
                val nextStep = "$nextProcessStep($nextOperation$nextSubOperation)"

                viewBinding.txtJobResult.text = jobCode
                viewBinding.txtStatusResult.text = lotStatus
                viewBinding.txtProductName.text = product
                viewBinding.txtCurrentOperation.text = currentStep
                viewBinding.tOperation.text = nextStep
                viewBinding.txtRework.text = reworkInfo
                viewBinding.txtReworkCount.text = reworkCount
                viewBinding.txtRwCd.text = reworkCode
                viewBinding.txtHold.text = holdState
                viewBinding.txtHoldCd.text = holdCode
                viewBinding.txtArea.text = area
                viewBinding.txtQuantity.text = qty

                val sDueDate = messageBody.optString("DUEDATE")

                if (sDueDate.isNotEmpty()) {
                    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA)
                    val newDueDate = sdf.parse(sDueDate)
                    viewBinding.txtDueData.text = sdf.format(newDueDate)
                }
                viewBinding.txtBay.text = bay
                viewBinding.txtOwner.text = owner
                viewBinding.txtStk.text = stocker
                viewBinding.txtLotKinds.text = category
                viewBinding.txtMachine.text = currentEqpID
                viewBinding.txtFacility.text = facility

                setStatusColor(lotStatus)
                viewBinding.btnWafer.isEnabled = true

                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()

            }
        }
    }

    private fun getSlotParticleInfo() {
        val sendMessage = MessageFactoryUtil.getSlotParticle(DeviceInfo.FACILITY, g_Lot, g_operation)

        mainScope.launch {
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                var sLotParticle =
                    ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "ITEMS").toString()

                sLotParticle =  sLotParticle.replace("},", "\n").replace(Regex("[\"{}\\[\\]]"), "").replace(",","  ")

                OkDialog.show(
                    supportFragmentManager, "HOLD Comment정보",
                    searchHoldComment + "\n" + sLotParticle, GetString.BTNOKSTR
                )

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    searchHoldComment + "\n" +errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setStatusColor(lotStatus: String) {
        when (lotStatus) {
            "RUN" -> {
                viewBinding.txtStatusResult.setBackgroundColor(Color.BLUE)
                viewBinding.txtStatusResult.setTextColor(Color.WHITE)
            }
            "WAIT", "" -> {
                viewBinding.txtStatusResult.background = null
                viewBinding.txtStatusResult.setTextColor(Color.WHITE)
            }
            "HOLD" -> {
                viewBinding.txtStatusResult.setBackgroundColor(Color.RED)
                viewBinding.txtStatusResult.setTextColor(Color.WHITE)
            }
            else -> {
                viewBinding.txtStatusResult.setBackgroundColor(Color.BLACK)
                viewBinding.txtStatusResult.setTextColor(Color.WHITE)
            }
        }
    }
}