package com.keyfoundry.hifos.config.grid

class LayoutBound {
    var rightBound = 0
    var bottomBound = 0
}