package com.keyfoundry.hifos.view.chat

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputFilter
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.service.RetrofitSyncService
import com.keyfoundry.hifos.config.service.udp.UDPMessageStore
import com.keyfoundry.hifos.config.utils.CommonUtil
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.message.MessageSender
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject


class ChatRoomActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MessageAdapter

    private lateinit var input: EditText
    private lateinit var sendBtn: Button

   // private lateinit var sendMessageLayOut: Layout

    private val messageList = mutableListOf<Message>()

    private lateinit var roomId: String
    private lateinit var roomName: String
    private val myId = "user1"

    private val mainScope = CoroutineScope(Dispatchers.Main)

    private val roomList = mutableListOf<Message>()

    private var gSenderId = ""
    private var gSenderIp = ""

    private var sendPdaId = ""

    private var userListByRoom: JSONArray = JSONArray()

    val wifiIp = CommonUtil.getLocalIpAddress()

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_room)

        roomId = if(intent.getStringExtra("roomId")==null){
            ""
        } else {
            intent.getStringExtra("roomId")!!
        }

        if(roomId == ""){
            val messageInputLayout = findViewById<LinearLayout>(R.id.messageInputLayOut)
            messageInputLayout.visibility = View.GONE // 숨김

            val menuButton = findViewById<ImageButton>(R.id.menuButton)
            menuButton.visibility = View.GONE // 숨김
        }

        sendPdaId = if(intent.getStringExtra("PDAID")==null){
            ""
        } else {
            intent.getStringExtra("PDAID")!!
        }

        if(sendPdaId != ""){

        }

        roomName = intent.getStringExtra("roomName")!!

        val roomNameText: TextView = findViewById(R.id.roomNameText)
        roomNameText.text = roomName

        val clear = intent.getBooleanExtra("clearMessages", false)

        if (clear) {
            UDPMessageStore.clearMessages(roomName)

            // Notification도 제거
            NotificationManagerCompat.from(this).cancel(roomName.hashCode())
        }

        recyclerView = findViewById(R.id.messageRecycler)
        input = findViewById(R.id.messageInput)

        val filter = InputFilter { source, _, _, _, _, _ ->
            if (source.contains(Regex("[\"'&<>]"))) "" else null
        }

        input.filters = arrayOf(filter)

        sendBtn = findViewById(R.id.sendButton)

        adapter = MessageAdapter(messageList, myId)

    //    sendMessageLayOut = findViewById(R.id.messageInputLayOut)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        getPdaMessageByRoom()

        val sendButton = findViewById<Button>(R.id.sendButton)

        sendButton.setOnClickListener {

            // 버튼 클릭 시 실행될 코드
            sendMessage()

        }

        val menuButton = findViewById<ImageButton>(R.id.menuButton)

        menuButton.setOnClickListener {
            val popup = PopupMenu(this, menuButton)
            popup.menu.add("참여자 보기")

            popup.setOnMenuItemClickListener { item ->
                when (item.title) {
                    "참여자 보기" -> {
                        showParticipants()
                    }
                }
                true
            }

            popup.show()
        }

//        WebSocketManager.listener = { msg ->
//            receiveMessage(msg)
//        }
//
//        sendBtn.setOnClickListener {
//            sendMessage()
//        }
    }



    fun sendMessage() {

        if(input.text.toString()==""){
            return
        }

        val request = SendMessageRequest(
            sType = "PRIVATE",
            sArea = "",
            sBay = "",
            recieveIpAddress = gSenderIp,
            sMsg = input.text.toString(),
            senderIpAddress = wifiIp.toString(),
            senderId = DeviceInfo.OPERATOR_NAME,
            roomId = roomId,
            sLevel = "NORMAL",
        )


        RetrofitSyncService.API.sendPdaMessage(request)
            .enqueue(object : retrofit2.Callback<Void> {

                override fun onResponse(
                    call: retrofit2.Call<Void>,
                    response: retrofit2.Response<Void>
                ) {
                    if (response.isSuccessful) {
                        val msg = Message(roomId, myId, wifiIp.toString(), request.sMsg, "", "NORMAL")
                        messageList.add(0, msg)
                        adapter.notifyItemInserted(0)
                        recyclerView.scrollToPosition(0)

                    } else {
                        println("전송 실패: ${response.code()}")
                    }
                }

                override fun onFailure(call: retrofit2.Call<Void>, t: Throwable) {
                    println("에러 발생: ${t.message}")
                }
            })

        input.setText("")
    }



    private fun receiveMessage(text: String) {

        runOnUiThread {

            val json = JSONObject(text)

            if (json.getString("type") == "message") {

                val msg = Message(
                    json.getString("roomId"),
                    json.getString("senderId"),
                    json.getString("senderIp"),
                    json.getString("text"),
                    json.getString("time"),
                    json.getString("messageLevel")
                )

                messageList.add(msg)

                adapter.notifyItemInserted(messageList.size - 1)

                recyclerView.scrollToPosition(messageList.size - 1)
            }
        }
    }



    private fun getPdaMessageByRoom() {
        mainScope.launch {

            val sendMessage = MessageFactoryUtil.getPdaMessagebyRoom(
                DeviceInfo.FACILITY, roomId, roomName, wifiIp
            )

            val message = MessageSender.send(
                supportFragmentManager,
                sendMessage,
                MessageName.NEWPDALIST
            )

            if (message.isSuccessFul) {

                val resultData = withContext(Dispatchers.Default) {

                    val messageListByRoom =
                        ResponseDataToJsonUtil.getMessageBodyList(message.result, "ITEMS")

                    val userList =
                        ResponseDataToJsonUtil.getMessageBodyInValueNullCheckList(
                            message.result, "USER", "USERS"
                        )

                    val tempList = mutableListOf<Message>()

                    var tempSenderIp = ""
                    var tempSenderId = ""

                    for (i in 0 until messageListByRoom.length()) {
                        val item = messageListByRoom.getJSONObject(i)

                        val senderId = item.optString("ROOM_NAME")
                        val text = item.optString("CONTENT")
                        val time = item.optString("CREATED_AT")
                        val level = item.optString("MESSAGE_LEVEL")
                        val senderIp = item.optString("SENDER_IP")

                        tempList.add(
                            Message(roomId, senderId, senderIp, text, time, level)
                        )

                        if (wifiIp != senderIp) {
                            tempSenderIp = senderIp
                            tempSenderId = senderId
                        }
                    }

                    Triple(userList, tempList, Pair(tempSenderIp, tempSenderId))
                }

                // 🔥 UI는 메인에서만
                userListByRoom = resultData.first
                messageList.addAll(resultData.second)

                gSenderIp = resultData.third.first
                gSenderId = resultData.third.second

                adapter.notifyDataSetChanged()
            }
             else {
//                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
//                OkDialog.show(
//                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
//                    errorMessage, GetString.BTNOKSTR
//                )
            }
        }
    }

    fun getUserList(): List<String> {
        val list = mutableListOf<String>()

        for (i in 0 until userListByRoom.length()) {
            val obj = userListByRoom.getJSONObject(i)

            // 실제 키값으로 수정하세요
            val name = obj.optString("PDAID")
            list.add(name)
        }

        return list
    }

    fun showParticipants() {
        val participants = getUserList()

        AlertDialog.Builder(this)
            .setTitle("참여자 목록")
            .setItems(participants.toTypedArray(), null)
            .setPositiveButton("닫기", null)
            .show()
    }
}