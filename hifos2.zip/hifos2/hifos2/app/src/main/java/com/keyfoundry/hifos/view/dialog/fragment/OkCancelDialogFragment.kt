package com.keyfoundry.hifos.view.dialog.fragment

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.os.Message
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.utils.OnSingleClickListener

class OkCancelDialogFragment : DialogFragment {
    lateinit var callbackDialog: CallBackDialog

    private var txtDialogTitle: String = ""
    private var txtDialogContent: String = ""
    private var btnOkstr: String = ""
    private var btnCancelStr: String = ""

    companion object {
        private const val TAG = "OkCancelDialogFragment"
    }

    interface CallBackDialog {
        fun okByOkCancelDialog(returnTag: String)
        fun cancelByOkCancelDialog(returnTag: String)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        Log.d(TAG, "onAttach")
        try {
            callbackDialog = activity as CallBackDialog
        } catch (e: ClassCastException) {
            Log.e(TAG, "${e.message}")
        }
    }

    constructor()

    constructor(
        txtDialogTitle: String, txtDialogContent: String,
        btnOkstr: String, btnCancelStr: String
    ) : this() {
        this.txtDialogTitle = txtDialogTitle
        this.txtDialogContent = txtDialogContent
        this.btnOkstr = btnOkstr
        this.btnCancelStr = btnCancelStr
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return object : Dialog(requireActivity(), theme) {
            override fun onBackPressed() {
                tag?.let { it1 -> callbackDialog.okByOkCancelDialog(it1) }
                dialog?.dismiss()
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.d(TAG, "onCreateView")
        val view = inflater.inflate(R.layout.fragment_dialog_ok_cancel, container, false)

        dialog?.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog?.setCancelable(false)

        val dialogTitle = view.findViewById<TextView>(R.id.txt_dialog_title)
        val dialogContent = view.findViewById<TextView>(R.id.txt_dialog_content)
        val btnOk = view.findViewById<Button>(R.id.btn_ok)
        val btnCancel = view.findViewById<Button>(R.id.btn_cancel)

        dialogTitle.text = txtDialogTitle
        dialogContent.text = txtDialogContent
        dialogContent.movementMethod = ScrollingMovementMethod()
        btnOk.text = btnOkstr
        btnCancel.text = btnCancelStr

        btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(view: View) {
                tag?.let { it1 -> callbackDialog.okByOkCancelDialog(it1) }
                dialog?.dismiss()
            }
        })

        btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                tag?.let { it1 -> callbackDialog.cancelByOkCancelDialog(it1) }
                dialog?.dismiss()
            }
        })

        return view
    }
}