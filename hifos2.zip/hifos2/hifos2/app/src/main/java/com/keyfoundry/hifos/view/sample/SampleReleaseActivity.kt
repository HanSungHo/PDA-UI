package com.keyfoundry.hifos.view.sample

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Vibrator
import android.text.InputFilter
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivitySampleReleaseBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDailogAlram
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SampleReleaseActivity : HFActivity() {
    companion object {
        private const val TAG = "SampleReleaseActivity"
    }
    private lateinit var viewBinding: ActivitySampleReleaseBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivitySampleReleaseBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        if(intent.getStringExtra("LOTID")?.isNotEmpty()==true){
            val lotID = intent.getStringExtra("LOTID").toString()
            viewBinding.editLotNo.setText(lotID)
            searchData(lotID)
        }

        viewBinding.editLotNo.setOnEditorActionListener { v, actionId, event ->
            if(actionId == EditorInfo.IME_ACTION_DONE) {
                val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                if (check) {
                    searchData(viewBinding.editLotNo.text.toString())
                }
                else{
                    clearData()
                }
            }else if(event !=null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                    if (check)
                        searchData(viewBinding.editLotNo.text.toString())
                    else
                        clearData()
                }
            }
            true
        }

        viewBinding.btnSearchLotNo.setOnClickListener(onSingleClickListener)
        viewBinding.btnClose.setOnClickListener(onSingleClickListener)
        viewBinding.btnExecution.setOnClickListener(onSingleClickListener)
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchLotNo.id -> {
                    searchData(viewBinding.editLotNo.text.toString())
                }
                viewBinding.btnExecution.id ->{
                    execution()
                }
                viewBinding.btnClose.id ->{
                    finish()
                }
            }
        }
    }

    private fun searchData(lotId: String) {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@SampleReleaseActivity, currentFocus)

            clearData()

            if (lotId.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT ID을 입력하세요", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.SampleReleaseInfo("S", lotId)

            val message = MessageSender.send( supportFragmentManager, sendMessage, MessageName.SAMPLERELEASEINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "ITEMS")
                val messageBody = messageListJSON.getJSONObject(0)


                val sSampleLotID = messageBody.optString("SLOTNAME")
                val sSampleQty = messageBody.optString("SQTY")
                val sSampleProd  =  messageBody.optString("SPROD")
                val sSampleOper  =   messageBody.optString("SOPER")
                val sSampleOperDesc = messageBody.optString("SOPERDESC")
                val sSampleRoute = messageBody.optString("SPROCESS")

                val sGroupProd = messageBody.optString("RPROD")
                val sGroupRoute = messageBody.optString("RPROCESS")
                val sGroupOper = messageBody.optString("ROPER")
                val sGroupMachine = messageBody.optString("RMACHINENAME")

                val sMainLotID = messageBody.optString("MLOTNAME")
                val sMainQty = messageBody.optString("MQTY")
                val sMainProd = messageBody.optString("MPROD")
                val sMainRoute = messageBody.optString("MPROCESS")
                val sMainOper = messageBody.optString("MOPER")
                val sMainOperDesc = messageBody.optString("MOPERDESC")
                val sMainLotState = messageBody.optString("MPROCESSSTATE")

                //Sample Release 공정정보
                viewBinding.txtReleaseProduct.text = sGroupProd
                viewBinding.txtReleaseRoute.text = sGroupRoute
                viewBinding.txtReleaseProcessname.text = sGroupOper
                viewBinding.txtReleaseMachinename.text = sGroupMachine

                //Sample Lot Area
                viewBinding.txtSampleLotname.text = sSampleLotID
                viewBinding.txtSampleQty.text = sSampleQty
                viewBinding.txtSampleProduct.text = sSampleProd
                viewBinding.txtSampleProcessname.text = sSampleOper
                viewBinding.txtSampleProcessnamedesc.text = sSampleOperDesc
                viewBinding.txtSampleRoute.text = sSampleRoute

                //Main Lot Group 정보
                viewBinding.txtMainLotname.text = sMainLotID
                viewBinding.txtMainQty.text = sMainQty
                viewBinding.txtMainProduct.text = sMainProd
                viewBinding.txtMainRoute.text = sMainRoute
                viewBinding.txtMainProcessname.text = sMainOper
                viewBinding.txtMainProcessdesc.text = sMainOperDesc
                viewBinding.txtMainState.text = sMainLotState
                // Release Check Box활성화 여부

                if(sMainLotID != null && ((sSampleRoute != sMainRoute)  || (sSampleOper != sMainOper) || (sMainLotState != "WAIT"))) {
                    viewBinding.btnExecution.isEnabled = false
                }else if(sMainLotID != null && (sSampleRoute == sMainRoute && sSampleOper == sMainOper) && (sMainLotState =="WAIT")) {
                    viewBinding.btnExecution.isEnabled = true
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
            }
        }
    }

    private fun execution() {
        mainScope.launch{

            if(viewBinding.txtSampleLotname.text =="") {
                OkDailogAlram.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    "Sample LotName이 확인되지 않습니다..",
                    GetString.POSITIVEBTNSTR,
                    applicationContext,
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                )
                return@launch
            }

            if(viewBinding.txtMainLotname.text ==""){
                OkDailogAlram.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    "Main LotName이 확인되지 않습니다..",
                    GetString.POSITIVEBTNSTR,
                    applicationContext,
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                return@launch
            }
            SampleRelease()
        }
    }

    private fun SampleRelease() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.SampleReleaseExecution(
                DeviceInfo.FACILITY,
                viewBinding.txtSampleLotname.text.toString(),
                viewBinding.txtReleaseMachinename.text.toString(),
                viewBinding.txtSampleQty.text.toString(),
                viewBinding.txtReleaseRoute.text.toString(),
                viewBinding.txtReleaseProcessname.text.toString(),
                DeviceInfo.OPERATOR_ID,
                viewBinding.txtMainComment.text.toString(),
                viewBinding.txtMainLotname.text.toString(),
                viewBinding.txtMainQty.text.toString()
            )

            val message = MessageSender.send(supportFragmentManager, sendMessage, MessageName.SAMPLERELEASEEXCUTION)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {

                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                //Log.d("recieve lotinfoend", messageBody.toString())

                val sSmsg = messageBody.optString("SUCESSMSG")

                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
                    sSmsg, GetString.BTNOKSTR
                )
                clearData()
                viewBinding.editLotNo.selectAll()

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearData() {

        viewBinding.editLotNo.text = null
        //Sample Release 공정정보
        viewBinding.txtReleaseProduct.text = null
        viewBinding.txtReleaseRoute.text = null
        viewBinding.txtReleaseProcessname.text = null
        viewBinding.txtReleaseMachinename.text = null

        //Sample Lot Area
        viewBinding.txtSampleLotname.text = null
        viewBinding.txtSampleQty.text = null
        viewBinding.txtSampleProduct.text = null
        viewBinding.txtSampleProcessname.text = null
        viewBinding.txtSampleProcessnamedesc.text = null
        viewBinding.txtSampleRoute.text = null

        //Sample Group 정보
        viewBinding.txtMainLotname.text = null
        viewBinding.txtMainQty.text = null
        viewBinding.txtMainProduct.text = null
        viewBinding.txtMainRoute.text = null
        viewBinding.txtMainProcessname.text = null
        viewBinding.txtMainProcessdesc.text = null
        viewBinding.txtMainComment.text = null
        viewBinding.txtMainState.text = null
        viewBinding.btnExecution.isEnabled = false
    }
}