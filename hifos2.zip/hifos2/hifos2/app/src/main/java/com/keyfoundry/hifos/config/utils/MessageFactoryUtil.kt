package com.keyfoundry.hifos.config.utils

import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.message.SendMessageHeader
import com.keyfoundry.hifos.message.SendMessageManager

/*
* 모바일서버에 보낼 메시지를 만들어주는 Class
* */
class MessageFactoryUtil {

    companion object {
        fun login(operatorId : String, password : String
                  , facility : String, bay : String) : String {
            val sendMessageHeader = SendMessageHeader("LOGIN", DeviceInfo.MOBILE_SERVER_NAME,
                DeviceInfo.DEVICE_NAME,"P","YES","","","")
            val sendMessageBody = """
                   |<OPERATORID>${operatorId}</OPERATORID> 
                   |<PASSWORD>${password}</PASSWORD>
                   |<BAY>${bay}</BAY>
                   |<FACILITY>${facility}</FACILITY>
                   |<DEVICENAME>${DeviceInfo.DEVICE_NAME}</DEVICENAME>
                   |<SERVERNAME>${DeviceInfo.MOBILE_SERVER_NAME}</SERVERNAME>
                  """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun facility() : String {
            val sendMessageHeader = SendMessageHeader("CONFINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                       |<IDENTCODE>F</IDENTCODE>
                      """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun area(facility : String) : String {
            val sendMessageHeader = SendMessageHeader("CONFINFO",DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME,"P","YES","","","")
            val sendMessageBody = """
                           |<IDENTCODE>A</IDENTCODE>
                           |<VALUE>${facility}</VALUE>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun eSheetInfo(lotId: String, historyCount: String, forwardCount: String, facility: String): String {
            val sendMessageHeader =SendMessageHeader("ESHEETINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")

            val sendMessageBody = """
                    |<LOTID>$lotId</LOTID>
                    |<HISTORYCOUNT>$historyCount</HISTORYCOUNT>
                    |<FORWARDCOUNT>$forwardCount</FORWARDCOUNT>
                    |<FACILITY>$facility</FACILITY>
                  """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun areaBayInfo(area: String, facility: String): String {
            val sendMessageHeader =SendMessageHeader("AREABAYINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")

            val sendMessageBody = """
                    |<AREA>$area</AREA>
                    |<FACILITY>$facility</FACILITY>
                  """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun areaBayInfo(facility: String): String{
            val sendMessageHeader =SendMessageHeader("AREABAYINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")

            val sendMessageBody = """
                    |<FACILITY>$facility</FACILITY>
                  """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun bayStockerInfo(bay: String, facility: String): String {
            val sendMessageHeader =SendMessageHeader("BAYSTOCKERINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")

            val sendMessageBody = """
                    |<BAY>$bay</BAY>
                    |<FACILITY>$facility</FACILITY>
                  """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun blstInfo(bay: String, stk: String, job: String, facility: String): String {
            val sendMessageHeader =SendMessageHeader("BLSTINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")

            val sendMessageBody = """
                    |<BAY>$bay</BAY>
                    |<STOCKER>$stk</STOCKER>
                    |<JOBCODE>$job</JOBCODE>
                    |<FACILITY>$facility</FACILITY>
                  """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun lotInfo(lotId: String, facility: String, type: String, userId: String): String {
            val sendMessageHeader =SendMessageHeader("LOTINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<TYPE>$type</TYPE>
                           |<OPERATORID>$userId</OPERATORID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun bayEQPInfo(bay: String, facility: String): String{
            val sendMessageHeader =SendMessageHeader("BAYEQPINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<BAYID>$bay</BAYID>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun eqpStatus(eqpId: String, facility: String): String {
            val sendMessageHeader =SendMessageHeader("EQPSTATUS", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun eqpDownCode(facility: String, eqpStatusCode: String, eqpId: String): String {
            val sendMessageHeader =SendMessageHeader("EQPDOWNCODE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<EQPSTATUSCODE>$eqpStatusCode</EQPSTATUSCODE>
                           |<EQPID>$eqpId</EQPID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun eqpDownComment(facility: String, downCode: String): String {
            val sendMessageHeader =SendMessageHeader("EQPDOWNCOMMENT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<DOWNCODE>$downCode</DOWNCODE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun checkNonLot(eqpId: String, facility: String, lastTime: String, userId: String, downCode: String): String {
            val sendMessageHeader =SendMessageHeader("CHECKNONLOT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<FACILITY>$facility</FACILITY>
                           |<LASTTIME>$lastTime</LASTTIME>
                           |<USERID>$userId</USERID>
                           |<EQPSTATUSCODE>$downCode</EQPSTATUSCODE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun changeEQPStatus(eqpId: String, facility: String, eqpStatusCode: String, eqpDownCode: String, comment: String, loginUserId: String, loginOperName: String, chamberMachine: String?): String {
            val sendMessageHeader =SendMessageHeader("CHANGEEQPSTATUS", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<FACILITY>$facility</FACILITY>
                           |<EQPSTATUSCODE>$eqpStatusCode</EQPSTATUSCODE>
                           |<EQPDOWNCODE>$eqpDownCode</EQPDOWNCODE>
                           |<COMMENT>$comment</COMMENT>
                           |<LOGINUSERID>$loginUserId</LOGINUSERID>
                           |<LOGINGUSERID1>$loginOperName</LOGINGUSERID1>
                           |<CHANGECHAMBER>$chamberMachine</CHANGECHAMBER>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun changeEQPStatus(eqpId: String, facility: String, eqpStatusCode: String, eqpDownCode: String, comment: String, loginUserId: String, loginOperName: String, chamberMachine: String?, mainFlag :String): String {
            val sendMessageHeader =SendMessageHeader("CHANGEEQPSTATUS", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<FACILITY>$facility</FACILITY>
                           |<EQPSTATUSCODE>$eqpStatusCode</EQPSTATUSCODE>
                           |<EQPDOWNCODE>$eqpDownCode</EQPDOWNCODE>
                           |<COMMENT>$comment</COMMENT>
                           |<LOGINUSERID>$loginUserId</LOGINUSERID>
                           |<LOGINGUSERID1>$loginOperName</LOGINGUSERID1>
                           |<CHANGECHAMBER>$chamberMachine</CHANGECHAMBER>
                           |<MAINFLAG>$mainFlag</MAINFLAG>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun checkChamber(facility: String, eqpId: String, mainState: String): String {
            val sendMessageHeader =SendMessageHeader("CHECKCHAMBER", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<EQPID>$eqpId</EQPID>
                           |<MAINSTATE>$mainState</MAINSTATE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun inlineInfo(lotId: String, facility: String, operation: String): String {
            val sendMessageHeader =SendMessageHeader("INLINEINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<OPERATION>$operation</OPERATION>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun maskLocationInfo(ident: String, reticleId:String, facility: String): String {
            val sendMessageHeader =SendMessageHeader("MASKINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<ID_IDENT>$ident</ID_IDENT>
                           |<RETICLEID>$reticleId</RETICLEID>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun inlineSet(lotId: String, facilityName:String, operation: String, maskTag: String, quantity: String, isFullInline: String, inLineitemsSum: String): String {
            val sendMessageHeader =SendMessageHeader("INLINESET", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facilityName</FACILITY>
                           |<OPERATION>$operation</OPERATION>
                           |<REALMASKTAG>$maskTag</REALMASKTAG>
                           |<QUANTITY>$quantity</QUANTITY>
                           |<ISFULLINLINE>$isFullInline</ISFULLINLINE>
                           |<INLINEITEMS>$inLineitemsSum</INLINEITEMS>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun commentList(lotId: String, facilityName:String, operation: String, subOperation: String, operSequence: String): String {
            val sendMessageHeader =SendMessageHeader("COMMENTLIST", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facilityName</FACILITY>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                           |<OPERSEQUENCE>$operSequence</OPERSEQUENCE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun comment(lotId: String, facilityName:String, operation: String, subOperation: String, commentNo:String, operSequence: String, operId: String): String {
            val sendMessageHeader =SendMessageHeader("COMMENT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facilityName</FACILITY>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                           |<COMMENTNO>$commentNo</COMMENTNO>
                           |<OPERSEQUENCE>$operSequence</OPERSEQUENCE>
                           |<OPERATORID>$operId</OPERATORID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun commentSet(lotId: String, facilityName:String, operation: String, subOperation: String, commentNo:String, operId: String, operName:String, operSequence: String,password:String): String {
            val sendMessageHeader =SendMessageHeader("COMMENTSET", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facilityName</FACILITY>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                           |<COMMENTNO>$commentNo</COMMENTNO>
                           |<OPERATORID>$operId</OPERATORID>
                           |<OPERNAME>$operName</OPERNAME>
                           |<OPERSEQUENCE>$operSequence</OPERSEQUENCE>
                           |<PASSWORD>$password</PASSWORD>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun pcmReworkRecipe(lotId: String): String{
            val sendMessageHeader =SendMessageHeader("PCMREWORKRECIPE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun maskInfo(ident: String, reticleId: String, facility: String): String{
            val sendMessageHeader =SendMessageHeader("MASKINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<ID_IDENT>$ident</ID_IDENT>
                           |<RETICLEID>$reticleId</RETICLEID>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getProcessFactoryLot(lotId: String): String{
            val sendMessageHeader =SendMessageHeader("GETPROCESSFACTORYLOT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }


        fun getFloorData(): String {
            val sendMessageHeader =SendMessageHeader("GETFLOORDATA", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = ""

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun inspMaskInfo(maskTag: String): String{
            val sendMessageHeader =SendMessageHeader("INSPMASKINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MASKTAG>$maskTag</MASKTAG>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getBayData(floor: String): String{
            val sendMessageHeader =SendMessageHeader("GETBAYDATA", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FLOOR>$floor</FLOOR>
                           """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun inspMaskStatCheck(reticleSeq: String): String{
            val sendMessageHeader =SendMessageHeader("INSPMASKSTATCHECK", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
            |<RETICLESEQ>$reticleSeq</RETICLESEQ>
            """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun inFactory(cf0: String, cf1: String, cf2: String, cf3: String, cf4: String, cf5: String, cf6: String): String{
            val sendMessageHeader =SendMessageHeader("INFACTORY", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
            |<CHANGEFACTORY0>$cf0</CHANGEFACTORY0>
            |<CHANGEFACTORY1>$cf1</CHANGEFACTORY1>
            |<CHANGEFACTORY2>$cf2</CHANGEFACTORY2>
            |<CHANGEFACTORY3>$cf3</CHANGEFACTORY3>
            |<CHANGEFACTORY4>$cf4</CHANGEFACTORY4>
            |<CHANGEFACTORY5>$cf5</CHANGEFACTORY5>
            |<CHANGEFACTORY6>$cf6</CHANGEFACTORY6>
            """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun inspMaskInsert(reticleSeq: String, eqpId: String, inspType: String, inspType2: String,inspResult: String, inspText: String, holdText:String, operId:String, operName: String, fabInDate:String): String{
            val sendMessageHeader =SendMessageHeader("INSPMASKINSERT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<RETICLESEQ>$reticleSeq</RETICLESEQ>
                           |<EQPID>$eqpId</EQPID>
                           |<INSPTYPE>$inspType</INSPTYPE>
                           |<INSPTYPE2>$inspType2</INSPTYPE2>
                           |<INSPRESULT>$inspResult</INSPRESULT>
                           |<INSPTEXT>$inspText</INSPTEXT>
                           |<HOLDTEXT>$holdText</HOLDTEXT>
                           |<USERID>$operId</USERID>
                           |<USERNAME>$operName</USERNAME>
                           |<FABINDATE>$fabInDate</FABINDATE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun diffEqpDataInfo(lotNo: String): String{
            val sendMessageHeader =SendMessageHeader("DIFFEQPDATAINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotNo</LOTID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getEqpPara(machineName: String, facilityName: String): String{
            val sendMessageHeader =SendMessageHeader("GETEQPPARA", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINE>$machineName</MACHINE>
                           |<FACILITY>$facilityName</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun insertPara(userId: String, batchId: String, machineName: String, facilityName: String, eqpPara: String, eqpParaNo: String, eqpParaMax: String): String{
            val sendMessageHeader =SendMessageHeader("INSERTPARA", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<USERID>$userId</USERID>
                           |<BATCHID>$batchId</BATCHID>
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<FACILITY>$facilityName</FACILITY>
                           |<EQPPARA>$eqpPara</EQPPARA>
                           |<EQPPARANO>$eqpParaNo</EQPPARANO>
                           |<EQPPARAMAX>$eqpParaMax</EQPPARAMAX>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun shelfCall(shelfNo: String): String{
            val sendMessageHeader =SendMessageHeader("SHELFCALL", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<SHELFNO>$shelfNo</SHELFNO>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun checkShelfLot(lotId: String, facility: String): String{
            val sendMessageHeader =SendMessageHeader("CHECKINSHELFLOT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun lotInShelf(insertShelfLot: String, shelfNo: String, userId: String): String{
            val sendMessageHeader =SendMessageHeader("LOTINSHELF", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<INSERTSHELFLOT>$insertShelfLot</INSERTSHELFLOT>
                           |<SHELFNO>$shelfNo</SHELFNO>
                           |<USERID>$userId</USERID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun lotOutShelf(deleteShelfLot: String, commentType: String, shelfNo: String, userId: String): String{
            val sendMessageHeader =SendMessageHeader("LOTOUTSHELF", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<DELETESHELFLOT>$deleteShelfLot</DELETESHELFLOT>
                           |<COMMANDTYPE>$commentType</COMMANDTYPE>
                           |<SHELFNO>$shelfNo</SHELFNO>
                           |<USERID>$userId</USERID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getPrInfo(prid:String , prlotno:String, viscosity:String, validdate:String): String {
            val sendMessageHeader = SendMessageHeader("SRPRINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")

            val sendMessageBody = """
                   |<PRID>$prid</PRID>
                   |<PRLOT>$prlotno</PRLOT>
                   |<VISCOSITY>$viscosity</VISCOSITY>
                   |<VALIDDATE>$validdate</VALIDDATE>
                  """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun prInput(Prid:String, PrDesc:String, Prcomp:String, Viscosty:String,PrLot:String, Validtime:String, Userid:String ,Username:String ):String{
            val sendMessageHeader = SendMessageHeader("PRINPUT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                   |<PRID>$Prid</PRID>
                   |<PRDESC>$PrDesc</PRDESC>
                   |<PRCOMP>$Prcomp</PRCOMP>
                   |<VISCOSITY>$Viscosty</VISCOSITY>
                   |<PRLOT>$PrLot</PRLOT>
                   |<VALIDTIME>$Validtime</VALIDTIME>
                   |<USERID>$Userid</USERID>
                   ||<USERNAME>$Username</USERNAME>
               
                  """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getDisPatch(reserve: String, rtd: String, wet: String): String{
            val sendMessageHeader =SendMessageHeader("GETDISPATCH", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<RESERVE>$reserve</RESERVE>
                           |<RTD>$rtd</RTD>
                           |<WET>$wet</WET>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun setDisPatch(machine: String, operId: String, operName: String, reserve:String, reserveItem: String): String{
            val sendMessageHeader =SendMessageHeader("SETDISPATCH", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINE>$machine</MACHINE>
                           |<USERID>$operId</USERID>
                           |<USERID1>$operName</USERID1>
                           |<RESERVE>$reserve</RESERVE>
                           |<RESERVEITEM>$reserveItem</RESERVEITEM>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun pumpStatus(pumpId: String): String{
            val sendMessageHeader =SendMessageHeader("PUMPSTATUS", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<PUMPID>$pumpId</PUMPID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun currentPrInfo(eqpId: String, pumpName: String, prId: String, prLot: String, vIsCosity: String): String{
            val sendMessageHeader =SendMessageHeader("CURRENTPRINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<PUMPNAME>$pumpName</PUMPNAME>
                           |<PRID>$prId</PRID>
                           |<PRLOT>$prLot</PRLOT>
                           |<VISCOSITY>$vIsCosity</VISCOSITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun stockOut(facility: String, port: String, rowNo: Int, stockers: String): String{
            val sendMessageHeader =SendMessageHeader("STOCKOUT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<PORT>$port</PORT>
                           |<ROWNO>$rowNo</ROWNO>
                           |<STOCKERS>
                           |$stockers
                           |</STOCKERS>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun carryInfo(lotId: String, facility: String): String{
            val sendMessageHeader =SendMessageHeader("CARRYINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun fabBayInfo(fab: String): String{
            val sendMessageHeader =SendMessageHeader("FABBAYINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FAB>$fab</FAB>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun pdaList(bay: String, facility: String): String{
            val sendMessageHeader =SendMessageHeader("PDALIST", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<BAY>$bay</BAY>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun carry(lotId: String, facility: String, nextFab: String, nextBay: String, nextStocker: String, port: String, pda: String, currentSTK: String): String{
            val sendMessageHeader =SendMessageHeader("CARRY", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<NEXTFAB>$nextFab</NEXTFAB>
                           |<NEXTBAY>$nextBay</NEXTBAY>
                           |<NEXTSTOCKER>$nextStocker</NEXTSTOCKER>
                           |<PORT>$port</PORT>
                           |<PDA>$pda</PDA>
                           |<CURRENTSTK>$currentSTK</CURRENTSTK>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun lotInfo(type: String, lotId: String, facility: String): String{
            val sendMessageHeader =SendMessageHeader("LOTINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<TYPE>$type</TYPE>
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun remoteEQPInfo2(eqpId: String, type: String, lotId: String, facility: String, operation: String, subOperation: String): String{
            val sendMessageHeader =SendMessageHeader("REMOTEEQPINFO2", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<TYPE>$type</TYPE>
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun photoChangeEQPStatus(machineName: String, eventUser: String): String{
            val sendMessageHeader =SendMessageHeader("PHOTOCHANGEEQPSTATUS", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACTORYNAME>FABCJ4</FACTORYNAME>
                           |<MACHINETYPE>ProductionMachine</MACHINETYPE>
                           |<STATEMODELNAME>EQP</STATEMODELNAME>
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<STATENAME>가동중</STATENAME>
                           |<DESCRIPTION>PROD_ST</DESCRIPTION>
                           |<MESSTATE>RUN</MESSTATE>
                           |<MAINSTATUS>RUN</MAINSTATUS>
                           |<SUBSTATUS>가동중</SUBSTATUS>
                           |<CTYPE>R</CTYPE>
                           |<DOWNCODE>RR001</DOWNCODE>
                           |<EVENTUSER>$eventUser</EVENTUSER>
                           |<EVENTCOMMENT>State Change In AUTO UI</EVENTCOMMENT>
                           |<ENTITYTYPE>TRACK</ENTITYTYPE>
                           |<CHAMBERMACHINE></CHAMBERMACHINE>
                           |<STATUS></STATUS>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun remoteEQPEENInfo(eqpId: String, type: String, lotId: String, facility: String, operation: String, subOperation: String): String{
            val sendMessageHeader =SendMessageHeader("REMOTEEQPEENINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<TYPE>$type</TYPE>
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun machinePortStatus(eqpId: String, portName: String): String{
            val sendMessageHeader =SendMessageHeader("MACHINEPORTSTATUS", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<PORTNAME>$portName</PORTNAME>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun recipeInfo(isPhoto: String, lotId: String, operation: String, subOperation: String, product:String,eqpId: String,opType:String,facility: String): String{
            val sendMessageHeader =SendMessageHeader("RECIPEINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<ISPHOTO>$isPhoto</ISPHOTO>
                           |<LOTID>$lotId</LOTID>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                           |<PRODUCT>$product</PRODUCT>
                           |<EQPID>$eqpId</EQPID>
                           |<OPTYPE>$opType</OPTYPE>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun recipeInfo_ASH(isPhoto: String, lotId: String, operation: String, subOperation: String, product:String,eqpId: String,opType:String,facility: String, chmEqpId: String): String{
            val sendMessageHeader =SendMessageHeader("RECIPEINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<ISPHOTO>$isPhoto</ISPHOTO>
                           |<LOTID>$lotId</LOTID>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                           |<PRODUCT>$product</PRODUCT>
                           |<EQPID>$eqpId</EQPID>
                           |<OPTYPE>$opType</OPTYPE>
                           |<FACILITY>$facility</FACILITY>
                           |<CHMEQPID>$chmEqpId</CHMEQPID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun recipeInfoDiff(isPhoto: String, lotId: String, operation: String, subOperation: String, product:String,eqpId: String,opType:String,facility: String, isDummy: String): String{
            val sendMessageHeader =SendMessageHeader("RECIPEINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<ISPHOTO>$isPhoto</ISPHOTO>
                           |<LOTID>$lotId</LOTID>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                           |<PRODUCT>$product</PRODUCT>
                           |<EQPID>$eqpId</EQPID>
                           |<OPTYPE>$opType</OPTYPE>
                           |<FACILITY>$facility</FACILITY>
                           |<ISDUMMY>$isDummy</ISDUMMY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun mcFdcEqpInfo(eqpId: String): String{
            val sendMessageHeader =SendMessageHeader("MCFDCEQPINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun eqpInfo(eqpId: String, moveIn:String, lotId: String): String{
            val sendMessageHeader =SendMessageHeader("EQPINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<MOVEIN>$moveIn</MOVEIN>
                           |<LOTID>$lotId</LOTID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun slotInfo(lotId: String, facility: String): String{
            val sendMessageHeader =SendMessageHeader("SLOTINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun loginUserCheck(userId: String, eqpId: String, autoMotive: String): String{
            val sendMessageHeader =SendMessageHeader("LOGINUSERCHECK", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<USERID>$userId</USERID>
                           |<EQPID>$eqpId</EQPID>
                           |<AUTOMOTIVE>$autoMotive</AUTOMOTIVE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun checkDiCycle(lotId: String, facility: String, operation:String, subOperation: String): String{
            val sendMessageHeader =SendMessageHeader("CHECKDICYCLE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun moveInLotInfo(lotId: String, facility: String, machineName:String, type: String, afOperM:String, afOperS: String, batchId: String, recipe:String): String{
            val sendMessageHeader =SendMessageHeader("LOTINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<TYPE>$type</TYPE>
                           |<AFOPERM>$afOperM</AFOPERM>
                           |<AFOPERS>$afOperS</AFOPERS>
                           |<BATCHID>$batchId</BATCHID>
                           |<RECIPE>$recipe</RECIPE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }


        fun moveIn(lotId: String, facility: String, recipe:String, eqpId: String, operation:String, subOperaion: String, isSkip: String, operatorId:String, isExposure:String, identCode:String, reticleId: String, quantity: String, comment:String, reworkSkip:String): String{
            val sendMessageHeader =SendMessageHeader("MOVEIN", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<RECIPE>$recipe</RECIPE>
                           |<EQPID>$eqpId</EQPID>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperaion</SUBOPERATION>
                           |<ISSKIP>$isSkip</ISSKIP>
                           |<OPERATORID>$operatorId</OPERATORID>
                           |<ISEXPOSURE>$isExposure</ISEXPOSURE>
                           |<IDENTCODE>$identCode</IDENTCODE>
                           |<RETICLEID>$reticleId</RETICLEID>
                           |<QUANTITY>$quantity</QUANTITY>
                           |<COMMENT>$comment</COMMENT>
                           |<REWORKSKIP>$reworkSkip</REWORKSKIP>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun lotInfoEnd(lotId: String, facility: String, machineName:String, type: String, scopeInspect:String): String{
            val sendMessageHeader =SendMessageHeader("LOTINFOEND", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<TYPE>$type</TYPE>
                           |<SCOPEINSPECT>$scopeInspect</SCOPEINSPECT>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }


        fun lossInfo(lotId: String, facility: String, operation: String, subOperation: String): String{
            val sendMessageHeader =SendMessageHeader("LOSSINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun reworkInfo(lotId: String, facility: String): String{
            val sendMessageHeader =SendMessageHeader("REWORKINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun rework(lotId: String, facility: String, eqpId: String, reworkCode: String,
                   comment: String, operatorId: String, operation: String, subOperation: String,
                   isCarry: String, bay: String, stoker: String, quantity: String): String {
            val sendMessageHeader =SendMessageHeader("REWORK", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<EQPID>$eqpId</EQPID>
                           |<REWORKCODE>$reworkCode</REWORKCODE>
                           |<COMMENT>$comment</COMMENT>
                           |<OPERATORID>$operatorId</OPERATORID>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                           |<ISCARRY>$isCarry</ISCARRY>
                           |<BAY>$bay</BAY>
                           |<STOCKER>$stoker</STOCKER>
                           |<QUANTITY>$quantity</QUANTITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun lotLastEvent(lotId: String, area: String): String{
            val sendMessageHeader =SendMessageHeader("LOTLSATEVENT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTNAME>$lotId</LOTNAME>
                           |<AREA>$area</AREA>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun moveOut(lotId: String, facility: String, eqpId:String, operation: String, subOperation: String,
                    recipe: String, opType: String, isSkip: String, operatorId: String, comment: String,
                    isCarry:String, bay:String, stocker:String, quantity: String, inputMaskLogo:String, wfInterLock:String): String{
            val sendMessageHeader =SendMessageHeader("MOVEOUT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<EQPID>$eqpId</EQPID>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                           |<RECIPE>$recipe</RECIPE>
                           |<OPTYPE>$opType</OPTYPE>
                           |<ISSKIP>$isSkip</ISSKIP>
                           |<OPERATORID>$operatorId</OPERATORID>
                           |<COMMENT>$comment</COMMENT>
                           |<ISCARRY>$isCarry</ISCARRY>
                           |<BAY>$bay</BAY>
                           |<STOCKER>$stocker</STOCKER>
                           |<QUANTITY>$quantity</QUANTITY>
                           |<INPUTMASKLOGO>$inputMaskLogo</INPUTMASKLOGO>
                           |<WFINTERLOCK>$wfInterLock</WFINTERLOCK>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun forwardSteps(lotId: String, facility: String, operation: String, subOperation: String): String{
            val sendMessageHeader =SendMessageHeader("FORWARDSTEPS", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun batchList(batId: String, facility: String): String{
            val sendMessageHeader =SendMessageHeader("BATCHLIST", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<BATCHID>$batId</BATCHID>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun updateSkipWafer(lotId: String, machineName: String, recipe: String, skipWafer:String, userId:String, skipReason:String, sMinus: String): String{
            val sendMessageHeader =SendMessageHeader("UPDATESKIPWAFER", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<RECIPENAME>$recipe</RECIPENAME>
                           |<SKIPWAFER>$skipWafer</SKIPWAFER>
                           |<USERID>$userId</USERID>
                           |<SKIPREASON>$skipReason</SKIPREASON>
                           |<SMINUS>$sMinus</SMINUS>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun realEqpId(facility: String, eqpId: String, type:String): String{
            val sendMessageHeader =SendMessageHeader("REALEQPID", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<EQPID>$eqpId</EQPID>
                           |<TYPE>$type</TYPE>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun measureInfo(lotId: String, facility: String, operation: String): String {
            val sendMessageHeader =SendMessageHeader("MEASUREINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<OPERATION>$operation</OPERATION>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }


        fun measureSet(lotId: String, facility: String, operation: String, subOperation: String, operatorId: String, quantity: String, sLotList:String, waferList:String, semSLotList:String, semWaferList:String): String {
            val sendMessageHeader =SendMessageHeader("MEASURESET", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                           |<OPERATORID>$operatorId</OPERATORID>
                           |<QUANTITY>$quantity</QUANTITY>
                           |<SLOTLIST>$sLotList</SLOTLIST>
                           |<WAFERLIST>$waferList</WAFERLIST>
                           |<SEMSLOTLIST>$semSLotList</SEMSLOTLIST>
                           |<SEMWAFERLIST>$semWaferList</SEMWAFERLIST>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun callCustomer(product: String): String{
            val sendMessageHeader =SendMessageHeader("CALLCUSTOMER", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<PRODUCT>$product</PRODUCT>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun split(lotId: String, facility: String, quantity: String, operation: String,
                  subOperation: String, product: String, isSample: String, sampleOper: String,
                  sampleSubOper: String, operatorId: String, splitItems: String, comment: String): String {
            val sendMessageHeader =SendMessageHeader("SPLIT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<QUANTITY>$quantity</QUANTITY>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                           |<PRODUCT>$product</PRODUCT>
                           |<ISSAMPLE>$isSample</ISSAMPLE>
                           |<SAMPLEOPER>$sampleOper</SAMPLEOPER>
                           |<SAMPLESUBOPER>$sampleSubOper</SAMPLESUBOPER>
                           |<OPERATORID>$operatorId</OPERATORID>
                           |<SPLITITEMS>
                           |$splitItems
                           |</SPLITITEMS>
                           |<COMMENT>$comment</COMMENT>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun slotInfo(lotId: String, facility: String, operatorId: String): String{
            val sendMessageHeader =SendMessageHeader("SLOTINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<OPERATORID>$operatorId</OPERATORID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun dummyEqpInfo(eqpId: String, lotId: String): String{
            val sendMessageHeader =SendMessageHeader("DUMMYEQPINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<LOTNO>$lotId</LOTNO>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun dummyEqpInput(lotName: String, lotLastEvent: String, category: String): String{
            val sendMessageHeader =SendMessageHeader("DUMMYEQPINPUT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTNAME>$lotName</LOTNAME>
                           |<LOTLASTEVENT>$lotLastEvent</LOTLASTEVENT>
                           |<CATEGORY>$category</CATEGORY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun sideDmmSelect(eventName: String, eqpId: String): String{
            val sendMessageHeader =SendMessageHeader("SIDEDMMSELECT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EVENT_NAME>$eventName</EVENT_NAME>
                           |<EQPID>$eqpId</EQPID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun sideDmmSelect(eventName: String, lotId: String, eqpId: String): String{
            val sendMessageHeader =SendMessageHeader("SIDEDMMSELECT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EVENT_NAME>$eventName</EVENT_NAME>
                           |<LOTNAME>$lotId</LOTNAME>
                           |<EQPID>$eqpId</EQPID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun sideDmmInsert(eventName: String, eqpId: String, lotId: String, operId: String, operDesc: String, inUser: String): String{
            val sendMessageHeader =SendMessageHeader("SIDEDMMINSERT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EVENT_NAME>$eventName</EVENT_NAME>
                           |<EQPID>$eqpId</EQPID>
                           |<LOTNAME>$lotId</LOTNAME>
                           |<OPERID>$operId</OPERID>
                           |<OPERDESC>$operDesc</OPERDESC>
                           |<INUSER>$inUser</INUSER>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun etchCommRcpFromb(lotId: String): String{
            val sendMessageHeader =SendMessageHeader("ETCH_COMMRCPFROMB", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun etchCommRcpFrombType2(lotId: String, sChkEqpid:String): String{
            val sendMessageHeader =SendMessageHeader("ETCH_COMMRCPFROMB", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<CHKEQPID>$sChkEqpid</CHKEQPID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun checkPellicle(reticleId: String, machineName: String): String{
            val sendMessageHeader =SendMessageHeader("CHECKPELLICLE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<RETICLEID>$reticleId</RETICLEID>
                           |<MACHINENAME>$machineName</MACHINENAME>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun checkMaskPMS(reticleId: String, pmsShelf: String): String{
            val sendMessageHeader =SendMessageHeader("CHECKMASKPMS", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<RETICLEID>$reticleId</RETICLEID>
                           |<PMSSHELF>$pmsShelf</PMSSHELF>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun maskStatusInfo(facility: String): String{
            val sendMessageHeader =SendMessageHeader("MASKSTATUSINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun maskLocGroupInfo(status: String, floor:String, facility: String): String{
            val sendMessageHeader =SendMessageHeader("MASKLOCGROUPINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<STATUS>$status</STATUS>
                           |<FLOOR>$floor</FLOOR>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun maskLocationInfo(status: String, locGroup: String, floor: String, facility: String): String{
            val sendMessageHeader =SendMessageHeader("MASKLOCATIONINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<STATUS>$status</STATUS>
                           |<LOCGROUP>$locGroup</LOCGROUP>
                           |<FLOOR>$floor</FLOOR>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun maskInfo(reticleId: String, facility: String): String{
            val sendMessageHeader =SendMessageHeader("MASKINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<RETICLEID>$reticleId</RETICLEID>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun changeMaskLocation(
            reticleId: String,
            facility: String,
            locType: String,
            location: String,
            etcStatus: String,
            etcLocation: String,
            etcDetailLoc: String,
            subLocation3: String,
            operatorId: String,
            floor: String
        ): String {
            val sendMessageHeader = SendMessageHeader("CHANGEMASKLOCATION", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<RETICLEID>$reticleId</RETICLEID>
                           |<FACILITY>$facility</FACILITY>
                           |<LOCTYPE>$locType</LOCTYPE>
                           |<LOCATION>$location</LOCATION>
                           |<ETCSTATUS>$etcStatus</ETCSTATUS>
                           |<ETCLOCATION>$etcLocation</ETCLOCATION>
                           |<ETCDETAILLOC>$etcDetailLoc</ETCDETAILLOC>
                           |<SUBLOCATION3>$subLocation3</SUBLOCATION3>
                           |<OPERATORID>$operatorId</OPERATORID>
                           |<FLOOR>$floor</FLOOR>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun photoLotStart(
            machineName: String,
            portName: String,
            lotName: String,
            product: String,
            recipe: String,
            prName: String,
            lotQty: String,
            reworkCode: String,
            barcCount: String,
            eqpType: String,
            operationName: String,
            operDesc: String,
            operMode: String,
            layerId: String,
            random: String,
            sampleFlag: String,
            userId: String,
            userName: String
        ): String {
            val sendMessageHeader =SendMessageHeader("PHOTOLOTSTART", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                            |<MACHINENAME>$machineName</MACHINENAME>
                            |<PORTNAME>$portName</PORTNAME>
                            |<LOTNAME>$lotName</LOTNAME>
                            |<PRODUCUT>$product</PRODUCUT>
                            |<RECIPE>$recipe</RECIPE>
                            |<PRNAME>$prName</PRNAME>
                            |<LOTQTY>$lotQty</LOTQTY>
                            |<REWORKCODE>$reworkCode</REWORKCODE>
                            |<BARC_COUNT>$barcCount</BARC_COUNT>
                            |<EQP_TYPE>$eqpType</EQP_TYPE>
                            |<OPERATIONNAME>$operationName</OPERATIONNAME>
                            |<OPERDESC>$operDesc</OPERDESC>
                            |<OPER_MODE>$operMode</OPER_MODE>
                            |<LAYERID>$layerId</LAYERID>
                            |<RANDOM>$random</RANDOM>
                            |<SAMPLEFLAG>$sampleFlag</SAMPLEFLAG>
                            |<USERID>$userId</USERID>
                            |<USERNAME>$userName</USERNAME>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun photoLotReserve(machineName: String, portName: String, lotName: String): String{
            val sendMessageHeader =SendMessageHeader("PHOTOLOTRESERVE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<PORTNAME>$portName</PORTNAME>
                           |<LOTNAME>$lotName</LOTNAME>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun batchListByLot(lotId: String, facility: String, status:String): String{
            val sendMessageHeader =SendMessageHeader("BATCHLISTBYLOT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<STATUS>$status</STATUS>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun batchListByLotInBatch(lotId: String, facility: String, case:String): String{
            val sendMessageHeader =SendMessageHeader("BATCHLISTBYLOT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<CASE>$case</CASE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun remoteMeaseEqpInfo(lotId: String, operation: String, subOperation: String, product: String, eqpId: String, opType: String, facility: String): String{
            val sendMessageHeader =SendMessageHeader("REMOTEMEASEQPINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                           |<PRODUCT>$product</PRODUCT>
                           |<EQPID>$eqpId</EQPID>
                           |<OPTYPE>$opType</OPTYPE>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun machinePortClean(machineName: String, portName: String): String{
            val sendMessageHeader =SendMessageHeader("MACHINEPORTCLEAR", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<PORTNAME>$portName</PORTNAME>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun remoteEqpInfo(eqpId: String): String{
            val sendMessageHeader =SendMessageHeader("REMOTEEQPINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }


        fun cvdTestMainInfo(eqpId: String): String{
            val sendMessageHeader =SendMessageHeader("CVDTESTMAININFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun cvdTestSubInfo(eqpId: String, mainId: String, typeId:String): String{
            val sendMessageHeader =SendMessageHeader("CVDTESTSUBINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<MAINID>$mainId</MAINID>
                           |<TYPEID>$typeId</TYPEID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun cvdTestBodyInfo(eqpId: String, mainId: String,  subId: String,typeId:String): String{
            val sendMessageHeader =SendMessageHeader("CVDTESTBODYINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<MAINID>$mainId</MAINID>
                           |<SUBID>$subId</SUBID>
                           |<TYPEID>$typeId</TYPEID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun FurnaceAbortRecipe(lotID: String): String{
            val sendMessageHeader =SendMessageHeader("FURNACEABORTRECIPE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotID</LOTID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun remoteRemanualLOT(lotId: String): String{
            val sendMessageHeader =SendMessageHeader("FURNACEREMANUALLOT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun remoteRemanualSave(lotId: String, eqpId: String, rcpId: String, userId : String): String{
            val sendMessageHeader =SendMessageHeader("FURNACEREMANUALSAVE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<EQPID>$eqpId</EQPID>
                           |<RCPID>$rcpId</RCPID>
                           |<USERID>$userId</USERID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun batchListByLotMoveIn(lotId: String, facility: String, status:String): String{
            val sendMessageHeader =SendMessageHeader("BATCHLISTBYLOT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<STATUS>$status</STATUS>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun batchListByLotMoveOut(lotId: String, batchId: String, machineName:String, facility:String, state:String): String{
            val sendMessageHeader =SendMessageHeader("BATCHLISTBYLOT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<BATCHID>$batchId</BATCHID>
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<FACILITY>$facility</FACILITY>
                           |<STATE>$state</STATE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun impRemoteStart(
            machineName: String, machineType: String, lotName: String, portName: String, recipeName: String,
            jotCode: String, productName: String, operation: String, isCarry: String, bay: String,
            stocker: String, eventUser: String): String {
            val sendMessageHeader =SendMessageHeader("IMPREMOTESTART", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<MACHINETYPE>$machineType</MACHINETYPE>
                           |<LOTNAME1>$lotName</LOTNAME1>
                           |<LOTNAME2></LOTNAME2>
                           |<PORTNAME>$portName</PORTNAME>
                           |<RECIPENAME>$recipeName</RECIPENAME>
                           |<JOBCODE1>$jotCode</JOBCODE1>
                           |<JOBCODE2></JOBCODE2>
                           |<PRODUCTNAME1>$productName</PRODUCTNAME1>
                           |<PRODUCTNAME2></PRODUCTNAME2>
                           |<OPERATION1>$operation</OPERATION1>
                           |<OPERATION2></OPERATION2>
                           |<ISCARRY>$isCarry</ISCARRY>
                           |<BAY>$bay</BAY>
                           |<STOCKER>$stocker</STOCKER>
                           |<EVENTUSER>$eventUser</EVENTUSER>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun teRcpSelection(eqpId: String, lotId: String): String{
            val sendMessageHeader =SendMessageHeader("TERCPSELECTION", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<LOTID>$lotId</LOTID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun machinePortStatus(eqpId: String, portName: String, lotId: String, recipe: String): String{
            val sendMessageHeader =SendMessageHeader("MACHINEPORTSTATUS", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<PORTNAME>$portName</PORTNAME>
                           |<LOTID>$lotId</LOTID>
                           |<RECIPE>$recipe</RECIPE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun machinePortStatus_KJ(eqpId: String, portName: String, lotId: String, recipe: String): String{
            val sendMessageHeader =SendMessageHeader("MACHINEPORTSTATUS_KJ", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<PORTNAME>$portName</PORTNAME>
                           |<LOTID>$lotId</LOTID>
                           |<RECIPE>$recipe</RECIPE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun furnace_KJCheck( lotId: String): String{
            val sendMessageHeader =SendMessageHeader("FURNACE_KJCHECK", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun memorization(eqpId: String, recipe: String, lotId: String, portName: String, chEqpId: String, userId:String, eqpType:String): String{
            val sendMessageHeader =SendMessageHeader("MEMORIZATION", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<RECIPE>$recipe</RECIPE>
                           |<LOTID>$lotId</LOTID>
                           |<PORTNAME>$portName</PORTNAME>
                           |<CH_EQPID>$chEqpId</CH_EQPID>
                           |<USER_ID>$userId</USER_ID>
                           |<EQP_TYPE>$eqpType</EQP_TYPE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun doorOpen(machineName: String, portName: String, areaName: String, machineType: String): String{
            val sendMessageHeader =SendMessageHeader("DOOROPEN", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<PORTNAME>$portName</PORTNAME>
                           |<AREANAME>$areaName</AREANAME>
                           |<MACHINETYPE>$machineType</MACHINETYPE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun remoteINTLKCheck(lotId: String, operation: String, subOperation: String, eqpId: String, recipe: String): String{
            val sendMessageHeader =SendMessageHeader("REMOTEINTLKCHECK", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                           |<EQPID>$eqpId</EQPID>
                           |<RECIPE>$recipe</RECIPE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun remoteStart(
            machineName: String, machineName2: String, machineType: String, areaName: String,
            lotName: String, portName: String, recipeName: String, productQty: String,
            operation: String, jobCode: String, productName: String, eventUser: String, precede_flag : String, Q_time_hold : String
        ): String {
            val sendMessageHeader =SendMessageHeader("REMOTESTART", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<MACHINENAME2>$machineName2</MACHINENAME2>
                           |<MACHINETYPE>$machineType</MACHINETYPE>
                           |<AREANAME>$areaName</AREANAME>
                           |<LOTNAME>$lotName</LOTNAME>
                           |<PORTNAME>$portName</PORTNAME>
                           |<RECIPENAME>$recipeName</RECIPENAME>
                           |<PRODUCTQTY>$productQty</PRODUCTQTY>
                           |<OPERATION>$operation</OPERATION>
                           |<JOBCODE>$jobCode</JOBCODE>
                           |<PRODUCTNAME>$productName</PRODUCTNAME>
                           |<EVENTUSER>$eventUser</EVENTUSER>
                           |<PRECEDE_FLAG>$precede_flag</PRECEDE_FLAG>
                           |<Q_TIME_HOLD>$Q_time_hold</Q_TIME_HOLD>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun FurnacerINTLKCheck(
            machineName: String, batchId: String,  recipeName: String,  lotList:String
        ): String {
            val sendMessageHeader =SendMessageHeader("FURNACEINTLKCHECK", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<BATCHID>$batchId</BATCHID>
                           |<RECIPENAME>$recipeName</RECIPENAME>
                           |<LOTLIST>$lotList</LOTLIST>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun FurnacerDummyRCPCheck(
            machineName: String,   recipeName: String
        ): String {
            val sendMessageHeader =SendMessageHeader("FURNACEDUMMYRCPCHECK", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<RECIPENAME>$recipeName</RECIPENAME>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun FurnaceremoteStart(
            machineName: String, lotName: String,  recipeName: String, eventUser: String, portName: String, cmdType: String, lotList:String,
            isDummy:String, tmpLotName : String, chkNoBatch : String, StepRemove : String
        ): String {
            val sendMessageHeader =SendMessageHeader("FURNACEREMOTESTART", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<BATCHID>$lotName</BATCHID>
                           |<RECIPENAME>$recipeName</RECIPENAME>
                           |<EVENTUSER>$eventUser</EVENTUSER>
                           |<PORTNAME>$portName</PORTNAME>
                           |<CMDTYPE>$cmdType</CMDTYPE>
                           |<LOTLIST>$lotList</LOTLIST>
                           |<ISDUMMY>$isDummy</ISDUMMY>
                           |<LOTNAME>$tmpLotName</LOTNAME>
                           |<CHKNOBATCH>$chkNoBatch</CHKNOBATCH>
                           |<STEPREMOVE>$StepRemove</STEPREMOVE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun FurnaceremoteStart_KEC(
            machineName: String, lotName: String,  recipeName: String, eventUser: String, portName: String, cmdType: String, lotList:String,
            isDummy:String, tmpLotName : String, chkNoBatch : String, StepRemove : String, MWFCount : String
        ): String {
            val sendMessageHeader =SendMessageHeader("FURNACEREMOTESTART_KEC", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<BATCHID>$lotName</BATCHID>
                           |<RECIPENAME>$recipeName</RECIPENAME>
                           |<EVENTUSER>$eventUser</EVENTUSER>
                           |<PORTNAME>$portName</PORTNAME>
                           |<CMDTYPE>$cmdType</CMDTYPE>
                           |<LOTLIST>$lotList</LOTLIST>
                           |<ISDUMMY>$isDummy</ISDUMMY>
                           |<LOTNAME>$tmpLotName</LOTNAME>
                           |<CHKNOBATCH>$chkNoBatch</CHKNOBATCH>
                           |<STEPREMOVE>$StepRemove</STEPREMOVE>
                           |<MWFCOUNT>$MWFCount</MWFCOUNT>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun FurnaceremoteStart_KJ(
            machineName: String, lotName: String,  recipeName: String, eventUser: String, portName: String, cmdType: String, lotList:String,
            isDummy:String, tmpLotName : String, chkNoBatch : String
        ): String {
            val sendMessageHeader =SendMessageHeader("FURNACEREMOTESTART_KJ", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<BATCHID>$lotName</BATCHID>
                           |<RECIPENAME>$recipeName</RECIPENAME>
                           |<EVENTUSER>$eventUser</EVENTUSER>
                           |<PORTNAME>$portName</PORTNAME>
                           |<CMDTYPE>$cmdType</CMDTYPE>
                           |<LOTLIST>$lotList</LOTLIST>
                           |<ISDUMMY>$isDummy</ISDUMMY>
                           |<LOTNAME>$tmpLotName</LOTNAME>
                           |<CHKNOBATCH>$chkNoBatch</CHKNOBATCH>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun FurnaceDummyRCP(
            machineName: String
        ): String {
            val sendMessageHeader =SendMessageHeader("FURNACEDUMMYRCP", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$machineName</MACHINENAME>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }


        fun remoteReStart(
            machineName: String, machineName2: String, machineType: String, areaName: String,
            lotName: String, portName: String, recipeName: String, productQty: String,
            operation: String, jobCode: String, productName: String, eventUser: String, precede_flag : String
        ): String {
            val sendMessageHeader =SendMessageHeader("REMOTERESTART", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<MACHINENAME2>$machineName2</MACHINENAME2>
                           |<MACHINETYPE>$machineType</MACHINETYPE>
                           |<AREANAME>$areaName</AREANAME>
                           |<LOTNAME>$lotName</LOTNAME>
                           |<PORTNAME>$portName</PORTNAME>
                           |<RECIPENAME>$recipeName</RECIPENAME>
                           |<PRODUCTQTY>$productQty</PRODUCTQTY>
                           |<OPERATION>$operation</OPERATION>
                           |<JOBCODE>$jobCode</JOBCODE>
                           |<PRODUCTNAME>$productName</PRODUCTNAME>
                           |<EVENTUSER>$eventUser</EVENTUSER>
                           |<PRECEDE_FLAG>$precede_flag</PRECEDE_FLAG>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun etchCommRcp(lotId: String, rcp: String, eqp: String, operid: String, operdesc: String): String{
            val sendMessageHeader =SendMessageHeader("ETCH_COMMRCP", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<RCP>$rcp</RCP>
                           |<EQP>$eqp</EQP>
                           |<PROCESSOPERATIONNAME>$operid</PROCESSOPERATIONNAME>
                           |<OPERATIONDESCRIPTION>$operdesc</OPERATIONDESCRIPTION>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun etchRcpDownload(lotId: String, rcp: String, eqp: String, userId: String, chm:String, parameter: String, downValue: String, step: String): String{
            val sendMessageHeader =SendMessageHeader("ETCH_RCP_DOWNLOAD", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<RCP>$rcp</RCP>
                           |<EQP>$eqp</EQP>
                           |<USERID>$userId</USERID>
                           |<CHM>$chm</CHM>
                           |<PARAMETER>$parameter</PARAMETER>
                           |<DOWN_VALUE>$downValue</DOWN_VALUE>
                           |<STEP>$step</STEP>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun measRemoteStart(
            machineName: String, machineType: String, lotName: String, portName: String,
            recipeName: String, procQty: String, measFlag: String, prodMachine: String,
            reworkFlag: String, eventUser: String, wfList: String, product: String, operation: String
        ): String {
            val sendMessageHeader =SendMessageHeader("MEASREMOTESTART", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<MACHINETYPE>$machineType</MACHINETYPE>
                           |<LOTNAME>$lotName</LOTNAME>
                           |<PORTNAME>$portName</PORTNAME>
                           |<RECIPENAME>$recipeName</RECIPENAME>
                           |<PROCQTY>$procQty</PROCQTY>
                           |<MEASFLAG>$measFlag</MEASFLAG>
                           |<PRODMACHINE>$prodMachine</PRODMACHINE>
                           |<REWORKFLAG>$reworkFlag</REWORKFLAG>
                           |<EVENTUSER>$eventUser</EVENTUSER>
                           |<WFLIST>$wfList</WFLIST>
                           |<PRODUCT>$product</PRODUCT>
                           |<OPERATION>$operation</OPERATION>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun metRecipeSearch(lotId: String,facility: String)
                : String {
            val sendMessageHeader =SendMessageHeader("METRECIPESEARCH", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun wetRemoteEqpInfo(eqpId: String): String{
            val sendMessageHeader =SendMessageHeader("WETREMOTEEQPINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun ramJobCancel(machineType: String, machineName: String, machineName2: String, eventUser: String, jobName1: String, jobName2: String): String{
            val sendMessageHeader =SendMessageHeader("RAMJOBCANCEL", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINETYPE>$machineType</MACHINETYPE>
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<MACHINENAME2>$machineName2</MACHINENAME2>
                           |<EVENTUSER>$eventUser</EVENTUSER>
                           |<JOBNAME1>$jobName1</JOBNAME1>
                           |<JOBNAME2>$jobName2</JOBNAME2>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun wetRemoteStart(
            machineName: String, machineName2: String, machineType: String, areaName: String,
            numCass: String, lotName: String, lotName2: String, recipeName: String,
            jobName: String, productQty: String, productQty2: String, operation: String,
            operation2: String, eventUser: String, isCarry: String, bay: String, stocker: String
        ): String {
            val sendMessageHeader =SendMessageHeader("WETREMOTESTART", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<MACHINENAME2>$machineName2</MACHINENAME2>
                           |<MACHINETYPE>$machineType</MACHINETYPE>
                           |<AREANAME>$areaName</AREANAME>
                           |<NUMCASS>$numCass</NUMCASS>
                           |<LOTNAME>$lotName</LOTNAME>
                           |<LOTNAME2>$lotName2</LOTNAME2>
                           |<RECIPENAME>$recipeName</RECIPENAME>
                           |<JOBNAME>$jobName</JOBNAME>
                           |<PRODUCTQTY>$productQty</PRODUCTQTY>
                           |<PRODUCTQTY2>$productQty2</PRODUCTQTY2>
                           |<OPERATION>$operation</OPERATION>
                           |<OPERATION2>$operation2</OPERATION2>
                           |<EVENTUSER>$eventUser</EVENTUSER>
                           |<ISCARRAY>$isCarry</ISCARRAY>
                           |<BAY>$bay</BAY>
                           |<STOCKER>$stocker</STOCKER>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun wetJobList(eqpId: String): String{
            val sendMessageHeader =SendMessageHeader("WETJOBLIST", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun impBatchRemoteStart(
            lotName1: String, lotName2: String, machineName: String, machineType: String,
            recipeName: String, isCarry: String, bay: String, stocker: String,
            eventUser: String, productName1: String, productName2: String, operation1: String,
            operation2: String, jobCode1: String, jobCode2: String
        ): String {
            val sendMessageHeader =SendMessageHeader("IMPBATCHREMOTESTART", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTNAME1>$lotName1</LOTNAME1>
                           |<LOTNAME2>$lotName2</LOTNAME2>
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<MACHINETYPE>$machineType</MACHINETYPE>
                           |<RECIPENAME>$recipeName</RECIPENAME>
                           |<ISCARRY>$isCarry</ISCARRY>
                           |<BAY>$bay</BAY>
                           |<STOCKER>$stocker</STOCKER>
                           |<EVENTUSER>$eventUser</EVENTUSER>
                           |<PRODUCTNAME1>$productName1</PRODUCTNAME1>
                           |<PRODUCTNAME2>$productName2</PRODUCTNAME2>
                           |<OPERATION1>$operation1</OPERATION1>
                           |<OPERATION2>$operation2</OPERATION2>
                           |<JOBCODE1>$jobCode1</JOBCODE1>
                           |<JOBCODE2>$jobCode2</JOBCODE2>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun blotInfo(lotId: String, facility:String, zone: String, eqpId:String, addedLotId: String): String{
            val sendMessageHeader =SendMessageHeader("BLOTINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>
                           |<ZONE>$zone</ZONE>
                           |<EQPID>$eqpId</EQPID>
                           |<ADDEDLOTID>$addedLotId</ADDEDLOTID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun batchCountSearch(): String{
            val sendMessageHeader =SendMessageHeader("BATCHCOUNTSERCH", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = ""

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun deleteBatch(facility: String, type: String, batchId: String, operatorId: String): String{
            val sendMessageHeader =SendMessageHeader("BATCHCRT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<TYPE>$type</TYPE>
                           |<BATCHID>$batchId</BATCHID>
                           |<OPERATORID>$operatorId</OPERATORID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun batchCrt(facility: String, type: String, batchId: String, eqpId: String,batchType:String,childCheck:String,mBatchId:String?,childZone:String?,operatorId:String, rowNo:String, mwCount:String, batchItems:String,addMessage:String): String{
            val sendMessageHeader =SendMessageHeader("BATCHCRT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<TYPE>$type</TYPE>
                           |<BATCHID>$batchId</BATCHID>
                           |<EQPID>$eqpId</EQPID>
                           |<BATCHTYPE>$batchType</BATCHTYPE>
                           |<CHALIDCHECK>$childCheck</CHALIDCHECK>
                           |<MBATCHID>$mBatchId</MBATCHID>
                           |<CHALIDZONE>$childZone</CHALIDZONE>
                           |<OPERATORID>$operatorId</OPERATORID>
                           |<ROWNO>$rowNo</ROWNO>
                           |<MWCOUNT>$mwCount</MWCOUNT>
                           |<BATCHITEMS>$batchItems</BATCHITEMS>$addMessage
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun batchCrtCheck(facility: String, eqpId: String, chalidCheck: String, batchItems: String): String{
            val sendMessageHeader =SendMessageHeader("BATCHCRTCHECK", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<EQPID>$eqpId</EQPID>
                           |<CHALIDCHECK>$chalidCheck</CHALIDCHECK>
                           |<BATCHITEMS>$batchItems</BATCHITEMS>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getParentBatchId(facility: String, lotId: String, machineName: String): String{
            val sendMessageHeader =SendMessageHeader("GETPARENTBATCHID", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<LOTID>$lotId</LOTID>
                           |<MACHINENAME>$machineName</MACHINENAME>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getBatchZone(facility: String, mBatchId: String): String{
            val sendMessageHeader =SendMessageHeader("GETBATCHZONE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<MBATCHID>$mBatchId</MBATCHID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun prInfo(eqpId: String, pumpName: String, prId:String, prLot:String, vIsCosity:String, validate:String): String{
            val sendMessageHeader =SendMessageHeader("PRINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<PUMPNAME>$pumpName</PUMPNAME>
                           |<PRID>$prId</PRID>
                           |<PRLOT>$prLot</PRLOT>
                           |<VISCOSITY>$vIsCosity</VISCOSITY>
                           |<VALIDDATE>$validate</VALIDDATE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun comparePrInfo(eqpId: String, pumpName: String, prId:String, prLot:String, vIsCosity:String, time:String, banJangId:String): String{
            val sendMessageHeader =SendMessageHeader("COMPAREPRINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<PUMPNAME>$pumpName</PUMPNAME>
                           |<PRID>$prId</PRID>
                           |<PRLOT>$prLot</PRLOT>
                           |<VISCOSITY>$vIsCosity</VISCOSITY>
                           |<TIME>$time</TIME>
                           |<BANJANGID>$banJangId</BANJANGID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }


        fun prChange(eqpId: String, pumpName: String, prId:String, prDesc:String, prComp:String, vIsCosity:String, prLot:String, validateTime:String, userId:String, userName:String, bLeak:String, inDate:String): String{
            val sendMessageHeader =SendMessageHeader("PRCHANGE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<PUMPNAME>$pumpName</PUMPNAME>
                           |<PRID>$prId</PRID>
                           |<PRDESC>$prDesc</PRDESC>
                           |<PRCOMP>$prComp</PRCOMP>
                           |<VISCOSITY>$vIsCosity</VISCOSITY>
                           |<PRLOT>$prLot</PRLOT>
                           |<VALIDTIME>$validateTime</VALIDTIME>
                           |<USERID>$userId</USERID>
                           |<USERNAME>$userName</USERNAME>
                           |<LEAK>$bLeak</LEAK>
                           |<INDATE>$inDate</INDATE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun config(
            facility: String, area: String, bay: String, deviceName: String, ipAddr: String, userId: String
        ): String {
            val sendMessageHeader =SendMessageHeader("CONFIG", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<AREA>$area</AREA>
                           |<BAY>$bay</BAY>
                           |<DEVICENAME>$deviceName</DEVICENAME>
                           |<IPADDR>$ipAddr</IPADDR>
                           |<USERID>$userId</USERID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun fqcSampling(lotId: String, opType: String, eqpId: String, oper: String, subOper: String): String{
            val sendMessageHeader =SendMessageHeader("FQCSAMPLING", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<OPTYPE>$opType</OPTYPE>
                           |<EQPID>$eqpId</EQPID>
                           |<OPER>$oper</OPER>
                           |<SUBOPER>$subOper</SUBOPER>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun newPdaList(facility: String, area: String, bay: String, myIp: String): String{
            val sendMessageHeader =SendMessageHeader("NEWPDALIST", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<AREA>$area</AREA>
                           |<BAY>$bay</BAY>
                           |<MYIP>$myIp</MYIP>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getwaferinfo(lotid: String): String{
            val sendMessageHeader =SendMessageHeader("GETWAFER", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """                           
                           |<LOTID>$lotid</LOTID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)

        }

        fun checkinspection(lotId: String, facility: String, type: String, afOperM:String, afOperS: String): String{
            val sendMessageHeader =SendMessageHeader("CHECKINSPACTION", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facility</FACILITY>                           
                           |<TYPE>$type</TYPE>
                           |<AFOPERM>$afOperM</AFOPERM>
                           |<AFOPERS>$afOperS</AFOPERS>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun probecardinfo (probecardId :String,  machine :String): String{
            val sendMessageHeader =SendMessageHeader("PROBECARDINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")

            val sendMessageBody = """
                           |<PROBECARD>$probecardId</PROBECARD>
                           |<MACHINE>$machine</MACHINE>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun probeCardValue(probecardId :String, prod :String, Machine :String): String{
            val sendMessageHeader =SendMessageHeader("PROBECARDVALUE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")

            val sendMessageBody = """
                           |<PROBECARD>$probecardId</PROBECARD>
                           |<PRODUCT>$prod</PRODUCT>
                           |<MACHINE>$Machine</MACHINE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)

        }


        fun setProbeCardHistory(LotId: String, Facility: String, Qty: String, Macnine: String,operation:String, subOperation: String,
                                OperationDecs : String, operatorId:String,  probecard :String,probecardId :String,Type :String,ValueOD :String, ValueZ : String) : String{
            val sendMessageHeader =SendMessageHeader("PROBECARDSET", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")

            val sendMessageBody = """
                           |<LOTNAME>$LotId</LOTNAME>
                           |<FACILITY>$Facility</FACILITY>  
                           |<QTY>$Qty</QTY>
                           |<MACHINENAME>$Macnine</MACHINENAME>  
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>                           
                           |<OPERATIONDESC>$OperationDecs</OPERATIONDESC>
                           |<OPERATORID>$operatorId</OPERATORID>
                           |<PROBECARD>$probecard</PROBECARD>
                           |<PROBECARDID>$probecardId</PROBECARDID>
                           |<TYPE>$Type</TYPE>
                           |<VALUEOD>$ValueOD</VALUEOD>
                           |<VALUEZ>$ValueZ</VALUEZ>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun CheckFuture (LotId: String,operation:String, subOperation: String) : String{
            val sendMessageHeader =SendMessageHeader("CHECKFUTURE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")

            val sendMessageBody = """
                           |<LOTNAME>$LotId</LOTNAME>                             
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>                                                      
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }


        fun checkPhotoSample(lotId: String, slocation: String): String{
            val sendMessageHeader =SendMessageHeader("CHECKPHOTOSAMPLE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<LOCATION>$slocation</LOCATION>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getEdcData(lotId: String, facilityName:String, operation: String, subOperation: String, recipe: String, OperationDesc: String): String {
            val sendMessageHeader =SendMessageHeader("GETEDCDATA", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FACILITY>$facilityName</FACILITY>
                           |<OPERATION>$operation</OPERATION>
                           |<SUBOPERATION>$subOperation</SUBOPERATION>
                           |<OPERATIONDESC>$OperationDesc</OPERATIONDESC>
                           |<RECIPE>$recipe</RECIPE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun SampleReleaseInfo(Type : String,lotId: String) :String{
            val sendMessageHeader =SendMessageHeader("SAMPLERELEASEINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<TYPE>$Type</TYPE>
                           |<LOTID>$lotId</LOTID>                          
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun EtchInspectionInfo(Type : String,lotId: String) :String{
            val sendMessageHeader =SendMessageHeader("ETCHINSPINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<TYPE>$Type</TYPE>
                           |<LOTID>$lotId</LOTID>                          
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun EtchInspectionexecution(sFactoryName : String, slot : String, sProd : String, sOperation : String, sOperationDesc : String, sMachine : String ,
                                    sUserid : String, sComment : String) :String {
            val sendMessageHeader =SendMessageHeader("ETCHINSPEXCUTION", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                    |<FACILITY>$sFactoryName</FACILITY>
                    |<LOTNAME>$slot</LOTNAME>
                    |<PRODUCTSPEC>$sProd</PRODUCTSPEC>
                    |<MACHINE>$sMachine</MACHINE>         
                    |<OPERATION>$sOperation</OPERATION>
                    |<OPERATIONDESC>$sOperationDesc</OPERATIONDESC>
                    |<USERID>$sUserid</USERID>
                    |<COMMENT>$sComment</COMMENT>
                     """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }


        fun SampleReleaseExecution(sFactoryName : String, sSampleLot : String, sMachine :String, sSampleQty : String, sRoute : String, sOperation : String, sUserid : String,
                                   sComment : String, sMaintLotname : String, sMaintLotQty : String ) :String {
            val sendMessageHeader =SendMessageHeader("SAMPLERELEASEEXECUTION", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                    |<FACILITY>$sFactoryName</FACILITY>
                    |<SAMPLELOTNAME>$sSampleLot</SAMPLELOTNAME>
                    |<SAMPLEMACHINE>$sMachine</SAMPLEMACHINE>
                    |<SAMPLEQTY>$sSampleQty</SAMPLEQTY>
                    |<ROUTE>$sRoute</ROUTE>
                    |<OPERATION>$sOperation</OPERATION>
                    |<USERID>$sUserid</USERID>
                    |<COMMENT>$sComment</COMMENT>
                    |<MAINLOTNAME>$sMaintLotname</MAINLOTNAME>
                    |<MAINQTY>$sMaintLotQty</MAINQTY>
                     """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun MeasLotInfo(facility: String, eqpId: String,portName: String): String{
            val sendMessageHeader =SendMessageHeader("MEASLOTINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<EQPID>$eqpId</EQPID>
                           |<PORTNAME>$portName</PORTNAME>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }


        fun XrfItemInfo(facility: String, Area: String): String{
            val sendMessageHeader =SendMessageHeader("XRFITEMINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<AREA>$Area</AREA>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun XrfEqpInfo(facility: String, Area: String, Item: String): String{
            val sendMessageHeader =SendMessageHeader("XRFEQPINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<AREA>$Area</AREA>
                           |<ITEM>$Item</ITEM>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun XrfCategoryInfo(facility: String, Area: String, Item: String, Eqp: String): String{
            val sendMessageHeader =SendMessageHeader("XRFCATEGORYINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<AREA>$Area</AREA>
                           |<ITEM>$Item</ITEM>
                           |<PRODEQP>$Eqp</PRODEQP>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun XrfSampleInfo(facility: String, Area: String, Item: String, Eqp: String, Category: String): String{
            val sendMessageHeader =SendMessageHeader("XRFSAMPLEINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<AREA>$Area</AREA>
                           |<ITEM>$Item</ITEM>
                           |<PRODEQP>$Eqp</PRODEQP>
                           |<CATEGORY>$Category</CATEGORY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun XrfParaInfo(facility: String, Area: String, Item: String, Eqp: String, Category: String, Sample: String): String{
            val sendMessageHeader =SendMessageHeader("XRFPARAINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<AREA>$Area</AREA>
                           |<ITEM>$Item</ITEM>
                           |<PRODEQP>$Eqp</PRODEQP>
                           |<CATEGORY>$Category</CATEGORY>
                           |<SAMPLE>$Sample</SAMPLE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun XrfRecipeInfo(facility: String, Area: String, Item: String, Eqp: String, Category: String, Sample: String, Para: String): String{
            val sendMessageHeader =SendMessageHeader("XRFRECIPEINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<AREA>$Area</AREA>
                           |<ITEM>$Item</ITEM>
                           |<PRODEQP>$Eqp</PRODEQP>
                           |<CATEGORY>$Category</CATEGORY>
                           |<SAMPLE>$Sample</SAMPLE>
                           |<PARAMETER>$Para</PARAMETER>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun XrfTableLoad(Eqp: String): String{
            val sendMessageHeader =SendMessageHeader("XRFTABLEINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<PRODEQP>$Eqp</PRODEQP>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun XrfTableLotInfo(facility: String, eqpId: String,Tablename: String): String{
            val sendMessageHeader =SendMessageHeader("XRFTABLELOTINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                           |<TABLE>$Tablename</TABLE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun XrfRemoteStart(Maineqp: String, EqpType: String, Port: String, Slot: String, EQP: String, Recipe: String, Sample: String, Userid: String, Username: String, Item: String, Para: String, Thick: String, Table: String): String{
            val sendMessageHeader =SendMessageHeader("XRFREMOTESTART", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$Maineqp</MACHINENAME>
                           |<PORTNAME>$Port</PORTNAME>
                           |<EQP_TYPE>$EqpType</EQP_TYPE>
                           |<ITEM>$Item</ITEM>
                           |<PARA>$Para</PARA>
                           |<SLOT>$Slot</SLOT>
                           |<PRODEQP>$EQP</PRODEQP>
                           |<RECIPE>$Recipe</RECIPE>
                           |<THICK>$Thick</THICK>
                           |<SAMPLE>$Sample</SAMPLE>
                           |<TABLE>$Table</TABLE>
                           |<USERID>$Userid</USERID>
                           |<USERNAME>$Username</USERNAME>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun batchType(facility: String,batId: String, type: String): String{
            val sendMessageHeader =SendMessageHeader("BATCHTYPE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<BATCHID>$batId</BATCHID>                           
                           |<BATCHTYPE>$type</BATCHTYPE>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun GetCabinetInfo(cabinetname : String): String{
            val sendMessageHeader =SendMessageHeader("GETCABINETINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<CABINETNAME>$cabinetname</CABINETNAME>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun SetGasusage(cabinetname : String, userid: String, pressure : String, weight : String, comment : String) : String {
            val sendMessageHeader =SendMessageHeader("SETGASUSAGE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<CABINETNAME>$cabinetname</CABINETNAME>
                           |<USERID>$userid</USERID>
                           |<PRESSURE>$pressure</PRESSURE>
                           |<WEIGHT>$weight</WEIGHT>
                           |<COMMENT>$comment</COMMENT>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getWaferTYpe(lotName : String) : String {
            val sendMessageHeader =SendMessageHeader("GETWAFERTYPE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTNAME>$lotName</LOTNAME>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun ComPareWaferType(lotName: String, wafertype: String, initialboxname : String, comment : String, userid : String) : String {
            val sendMessageHeader =SendMessageHeader("COMPAREWAFERTYPE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTNAME>$lotName</LOTNAME>
                           |<WAFERTYPE>$wafertype</WAFERTYPE>
                           |<INITIALBOXNAME>$initialboxname</INITIALBOXNAME>
                           |<COMMENT>$comment</COMMENT>
                           |<USERID>$userid</USERID>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getProcessFlow(facility: String, product: String, processOper :String) : String {
            val sendMessageHeader =SendMessageHeader("GETPROCESSFLOW", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                        |<FACTORYNAME>$facility</FACTORYNAME>
                        |<PRODUCT>$product</PRODUCT>
                        |<PROCESSOPER>$processOper</PROCESSOPER>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)

        }

        fun getProcessOperation(facility: String, product: String, processFlow:String) : String {
            val sendMessageHeader =SendMessageHeader("GETPROCESSOPERATION", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                        |<FACTORYNAME>$facility</FACTORYNAME>
                        |<PRODUCT>$product</PRODUCT>
                        |<PROCESSFLOW>$processFlow</PROCESSFLOW>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)

        }

        fun getTagId(facility: String) : String {
            val sendMessageHeader =SendMessageHeader("GETTAGID", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                        |<FACTORYNAME>$facility</FACTORYNAME>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)

        }

        fun getTagPosition(lotId: String) : String {
            val sendMessageHeader =SendMessageHeader("GETTAGPOSITION", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                        |<LOTNAME>$lotId</LOTNAME>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun insertEen(lotName: String, userId: String, facility: String, product: String, operation: String, actionPoint:String, processFlow:String, tagComment:String, tagId:String?) : String {
            val sendMessageHeader =SendMessageHeader("INSERTEEN", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                        |<LOTNAME>$lotName</LOTNAME>
                        |<USERID>$userId</USERID>
                        |<FACILITY>$facility</FACILITY>
                        |<PRODUCT>$product</PRODUCT>
                        |<OPERATION>$operation</OPERATION>
                        |<ACTIONPOINT>$actionPoint</ACTIONPOINT>
                        |<PROCESSFLOW>$processFlow</PROCESSFLOW>
                        |<TAGCOMMENT>$tagComment</TAGCOMMENT>
                        |<TAGID>$tagId</TAGID>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun updateEen(lotName: String, userId: String, facility: String, product: String, operation: String, actionPoint:String, eenId: String, processFlow:String, tagComment:String, tagId:String?, oldTagComment : String, changeCause : String) : String {
            val sendMessageHeader =SendMessageHeader("UPDATEEEN", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                        |<LOTNAME>$lotName</LOTNAME>
                        |<USERID>$userId</USERID>
                        |<FACILITY>$facility</FACILITY>
                        |<PRODUCT>$product</PRODUCT>
                        |<OPERATION>$operation</OPERATION>
                        |<ACTIONPOINT>$actionPoint</ACTIONPOINT>
                        |<EENID>$eenId</EENID>
                        |<PROCESSFLOW>$processFlow</PROCESSFLOW>
                        |<TAGCOMMENT>$tagComment</TAGCOMMENT>
                        |<TAGID>$tagId</TAGID>
                        |<OLDTAGCOMMENT>$oldTagComment</OLDTAGCOMMENT>
                        |<CHANGECAUSE>$changeCause</CHANGECAUSE>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun deleteEen(lotName: String, userId: String, facility: String, product: String, operation: String, actionPoint:String, eenId: String, processFlow:String, tagComment:String, tagId:String?, changeCause : String) : String {
            val sendMessageHeader =SendMessageHeader("DELETEEEN", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                        |<LOTNAME>$lotName</LOTNAME>
                        |<USERID>$userId</USERID>
                        |<FACILITY>$facility</FACILITY>
                        |<PRODUCT>$product</PRODUCT>
                        |<OPERATION>$operation</OPERATION>
                        |<ACTIONPOINT>$actionPoint</ACTIONPOINT>
                        |<EENID>$eenId</EENID>
                        |<PROCESSFLOW>$processFlow</PROCESSFLOW>
                        |<TAGCOMMENT>$tagComment</TAGCOMMENT>
                        |<TAGID>$tagId</TAGID>
                        |<CHANGECAUSE>$changeCause</CHANGECAUSE>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getEenList(lotId: String, facility: String): String {
            val sendMessageHeader =SendMessageHeader("GETEENLIST", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTNAME>$lotId</LOTNAME>
                           |<FACILITY>$facility</FACILITY>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }


        fun XrfEqpTypeCheck(eqpId: String): String{
            val sendMessageHeader =SendMessageHeader("XRFEQPTYPECHECK", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<EQPID>$eqpId</EQPID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun AitLotInfo(eqpId: String): String{
            val sendMessageHeader =SendMessageHeader("AITLOTINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$eqpId</LOTID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun AitRemoteStart(eqpId: String, Recipe: String, Lotid: String, Port: String, PRODMID: String, Slot: String, Userid: String, Username: String): String{
            val sendMessageHeader =SendMessageHeader("AITREMOTESTART", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$eqpId</MACHINENAME>
                           |<RECIPE>$Recipe</RECIPE>
                           |<PORTNAME>$Port</PORTNAME>
                           |<RUN_NO>$Lotid</RUN_NO>
                           |<PRODEQP>$PRODMID</PRODEQP>
                           |<SLOT>$Slot</SLOT>
                           |<USERID>$Userid</USERID>
                           |<USERNAME>$Username</USERNAME>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun esdinsert(esdid : String, item : String , floor : String , area : String , bay : String , input1 : String ,input2 : String ,input3 : String ,input4 : String , desc1 : String , desc2 : String , desc3 : String , desc4 : String , reasons : String , users : String ) : String {
            val sendMessageHeader =SendMessageHeader("ESDINSERT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                   |<ESDID>$esdid</ESDID>
                   |<ITEM>$item</ITEM>
                   |<FLOOR>$floor</FLOOR>
                   |<AREA>$area</AREA>
                   |<BAY>$bay</BAY>
                   |<INPUT1>$input1</INPUT1>
                   |<INPUT2>$input2</INPUT2>
                   |<INPUT3>$input3</INPUT3>
                   |<INPUT4>$input4</INPUT4>
                   |<DESC1>$desc1</DESC1>
                   |<DESC2>$desc2</DESC2>
                   |<DESC3>$desc3</DESC3>
                   |<DESC4>$desc4</DESC4>
                   |<REASONS>$reasons</REASONS>
                   |<USERS>$users</USERS>
                  """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun intlkpopupcheck(mastertime : String, event_type : String , notice_type : String , ipaddress : String , client_type : String , hostname : String ,target_url : String ,user_confirm : String ,user_confirm_id : String , user_confirm_time : String , eqpid : String , recipe : String , lotid : String , slot : String  ) : String {
            val sendMessageHeader =SendMessageHeader("INTLKPOPUPCHECK", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                   |<MASTERTIMESTAMP>$mastertime</MASTERTIMESTAMP>
                   |<EVENT_TYPE>$event_type</EVENT_TYPE>
                   |<NOTICE_TYPE>$notice_type</NOTICE_TYPE>
                   |<IP>$ipaddress</IP>
                   |<CLIENT_TYPE>$client_type</CLIENT_TYPE>
                   |<HOSTNAME>$hostname</HOSTNAME>
                   |<TARGET_URL>"NULL"</TARGET_URL>
                   |<USER_CONFIRM>$user_confirm</USER_CONFIRM>
                   |<USER_CONFIRM_ID>$user_confirm_id</USER_CONFIRM_ID>
                   ||<USER_CONFIRM_TIME>$user_confirm_time</USER_CONFIRM_TIME>
                   |<EQPID>$eqpid</EQPID>
                   |<RECIPE>$recipe</RECIPE>
                   |<LOTID>$lotid</LOTID>
                   |<SLOT>$slot</SLOT>
                  """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }


        fun mdscontent(mastertime : String, sAREANAME : String , sPROCTYPE : String ,sMACHINENAME : String ,sPARAMETER : String, sSAMPLE : String, sCreateTime : String) : String {
            val sendMessageHeader =SendMessageHeader("MDSCONTENT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                   |<MASTERTIMESTAMP>$mastertime</MASTERTIMESTAMP>
                   |<AREANAME>$sAREANAME</AREANAME>
                   |<PROCTYPE>$sPROCTYPE</PROCTYPE>
                   |<MACHINENAME>$sMACHINENAME</MACHINENAME>
                   |<PARAMETER>$sPARAMETER</PARAMETER>
                   |<SAMPLE>$sSAMPLE</SAMPLE>
                   |<CREATETIME>$sCreateTime</CREATETIME>
                  """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun mdsinsert(sINSPECT_COMMENT : String, sACT_COMMENT : String , sUSER_ID : String , sACTION_TIMESTAMP : String , sAREANAME : String , sPROCTYPE : String ,sMACHINENAME : String ,sPARAMETER : String, sSAMPLE : String,sCreateTime : String) : String {
            val sendMessageHeader =SendMessageHeader("MDSINSERT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                   |<INSPECT_COMMENT>$sINSPECT_COMMENT</INSPECT_COMMENT>
                   |<ACT_COMMENT>$sACT_COMMENT</ACT_COMMENT>
                   |<USER_ID>$sUSER_ID</USER_ID>
                   |<ACTION_TIMESTAMP>$sACTION_TIMESTAMP</ACTION_TIMESTAMP>
                   |<AREANAME>$sAREANAME</AREANAME>
                   |<PROCTYPE>$sPROCTYPE</PROCTYPE>
                   |<MACHINENAME>$sMACHINENAME</MACHINENAME>
                   |<PARAMETER>$sPARAMETER</PARAMETER>
                   |<SAMPLE>$sSAMPLE</SAMPLE>
                   |<CREATETIME>$sCreateTime</CREATETIME>
                  """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getSlotParticle(facility: String, lotId: String, oper: String): String{
            val sendMessageHeader =SendMessageHeader("SLOTPARTICLE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<LOTID>$lotId</LOTID>
                           |<OPERATION>$oper</OPERATION>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getMergeLot(facility: String, lotId: String): String{
            val sendMessageHeader =SendMessageHeader("GETMERGELOT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<LOTID>$lotId</LOTID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getAutoMergeLot(facility: String, lotId: String): String{
            val sendMessageHeader =SendMessageHeader("GETAUTOMERGELOT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<LOTID>$lotId</LOTID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }
        fun executeMergeLot(facility: String, lotName: String, productSpec: String, route: String, operation :String,qty: String, operatorId: String, comment:String,mergeLot: String): String{
            val sendMessageHeader =SendMessageHeader("EXECUTEMERGE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACTORYNAME>$facility</FACTORYNAME>
                           |<LOTNAME>$lotName</LOTNAME>
                           |<PRODUCTSPECNAME>$productSpec</PRODUCTSPECNAME>
                           |<ROUTE>$route</ROUTE>
                           |<PROCESSOPERATIONNAME>$operation</PROCESSOPERATIONNAME>
                           |<QTY>$qty</QTY>
                           |<OPERATORID>$operatorId</OPERATORID>
                           |<COMMENT>$comment</COMMENT>
                           |<MERGELOT>$mergeLot</MERGELOT>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun executeAutoMergeLot(facility: String, lotName: String, parentLotName: String, productSpec: String, route: String, operation :String,qty: String, operatorId: String, comment:String,mergeLot: String): String{
            val sendMessageHeader =SendMessageHeader("EXECUTEAUTOMERGE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACTORYNAME>$facility</FACTORYNAME>
                           |<LOTNAME>$lotName</LOTNAME>
                           |<PARENTLOTNAME>$parentLotName</PARENTLOTNAME>
                           |<PRODUCTSPECNAME>$productSpec</PRODUCTSPECNAME>
                           |<ROUTE>$route</ROUTE>
                           |<PROCESSOPERATIONNAME>$operation</PROCESSOPERATIONNAME>
                           |<QTY>$qty</QTY>
                           |<OPERATORID>$operatorId</OPERATORID>
                           |<COMMENT>$comment</COMMENT>
                           |<MERGELOT>$mergeLot</MERGELOT>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getMachineInfo(facility: String, eqpId: String): String{
            val sendMessageHeader =SendMessageHeader("GETMACHINEINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<EQPID>$eqpId</EQPID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun insertOperationHistory(facility: String, lotName: String, machineName: String, operation: String, poDesc :String, operatorId: String, productSpec:String,area: String): String{
            val sendMessageHeader =SendMessageHeader("INSERTOPERATIONHISTORY", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACTORYNAME>$facility</FACTORYNAME>
                           |<LOTNAME>$lotName</LOTNAME>
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<PROCESSOPERATIONNAME>$operation</PROCESSOPERATIONNAME>
                           |<PODESC>$poDesc</PODESC>
                           |<OPERATORID>$operatorId</OPERATORID>
                           |<PRODUCTSPECNAME>$productSpec</PRODUCTSPECNAME>
                           |<AREA>$area</AREA>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getOperationProcessCount(facility: String, lotName: String, machineName: String, operation: String, poDesc :String, operatorId: String, productSpec:String,area: String): String{
            val sendMessageHeader =SendMessageHeader("GETOPERATIONCOUNT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACTORYNAME>$facility</FACTORYNAME>
                           |<LOTNAME>$lotName</LOTNAME>
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<PROCESSOPERATIONNAME>$operation</PROCESSOPERATIONNAME>
                           |<PODESC>$poDesc</PODESC>
                           |<OPERATORID>$operatorId</OPERATORID>
                           |<PRODUCTSPECNAME>$productSpec</PRODUCTSPECNAME>
                           |<AREA>$area</AREA>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getAutoMergeLot2(lotName: String, parentLotName: String, lotList: String): String{
            val sendMessageHeader =SendMessageHeader("GETAUTOMERGELOT2", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotName</LOTID>
                           |<PARENTLOTID>$parentLotName</PARENTLOTID>
                           |<LOTLIST>$lotList</LOTLIST>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }
        fun AITLotInfo(lotId: String, Facility: String) : String {
            val sendMessageHeader =SendMessageHeader("AITLOTINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotId</LOTID>
                           |<FAB>$Facility</FAB>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun AITRecipeInfo(Recipeid: String) : String {
            val sendMessageHeader =SendMessageHeader("AITRECIPEINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<RECIPE>$Recipeid</RECIPE>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getScopeLotInfo(lotName: String): String{
            val sendMessageHeader =SendMessageHeader("GETSCOPELOTINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$lotName</LOTID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun inputScopeData(factoryName:String, lotName: String,processOper:String,machineName:String, layerId:String, sideRinse:String,weeWidth:String,logo:String,sLotList:String,faultCategory:String?, user:String): String{
            val sendMessageHeader =SendMessageHeader("INPUTSCOPEDATA", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACTORYNAME>$factoryName</FACTORYNAME>
                           |<LOTID>$lotName</LOTID>
                           |<PROCESSOPERATIONNAME>$processOper</PROCESSOPERATIONNAME>
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<LAYERID>$layerId</LAYERID>
                           |<SIDERINSE>$sideRinse</SIDERINSE>
                           |<WEE>$weeWidth</WEE>
                           |<LOGO>$logo</LOGO>
                           |<SLOTLIST>$sLotList</SLOTLIST>
                           |<FAULTCATEGORY>$faultCategory</FAULTCATEGORY>
                           |<INPUTUSER>$user</INPUTUSER>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun checkBatchCount(factoryName: String,machineName: String, eventUser: String): String{
            val sendMessageHeader =SendMessageHeader("CHECKBATCHCOUNT", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACTORYNAME>$factoryName</FACTORYNAME>
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<USERID>$eventUser</USERID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun sendTimeOutData(sendMessage: String,timeOutTime: String, wifiPower: String, pdaTime : String): String{
            val sendMessageHeader =SendMessageHeader("TIMEOUTLIST", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<SENDMESSAGE>$sendMessage</SENDMESSAGE>
                           |<TIMEOUTITME>$timeOutTime</TIMEOUTITME>
                           |<WIFIPOWER>$wifiPower</WIFIPOWER>
                           |<PDATIME>$pdaTime</PDATIME>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun AEGISLotInfo(LotId: String,Machine: String): String{
            val sendMessageHeader =SendMessageHeader("AEGISLOTINFO", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<LOTID>$LotId</LOTID>
                           |<MACHINE>$Machine</MACHINE>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun AEGISRemoteStart(eqpId: String, Recipe: String, Lotid: String, Port: String, PRODMID: String, Slot: String, Userid: String, Username: String): String{
            val sendMessageHeader =SendMessageHeader("AEGISREMOTESTART", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$eqpId</MACHINENAME>
                           |<RECIPE>$Recipe</RECIPE>
                           |<PORTNAME>$Port</PORTNAME>
                           |<RUN_NO>$Lotid</RUN_NO>
                           |<PRODEQP>$PRODMID</PRODEQP>
                           |<SLOT>$Slot</SLOT>
                           |<USERID>$Userid</USERID>
                           |<USERNAME>$Username</USERNAME>
                          """.trimMargin()
            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getMachineInform(factoryName: String,type: String, machineName: String): String{
            val sendMessageHeader =SendMessageHeader("GETMACHINEINFORM", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACTORYNAME>$factoryName</FACTORYNAME>
                           |<TYPE>$type</TYPE>
                           |<MACHINENAME>$machineName</MACHINENAME>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun addMachineInform(factoryName: String,type: String, machineName: String, content: String, userId: String): String{
            val sendMessageHeader =SendMessageHeader("ADDMACHINEINFORM", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACTORYNAME>$factoryName</FACTORYNAME>
                           |<TYPE>$type</TYPE>
                           |<MACHINENAME>$machineName</MACHINENAME>
                           |<CONTENT>$content</CONTENT>
                           |<USERID>$userId</USERID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun AegisModeChange(EQPID: String, MODE: String, Userid: String, Username: String): String{
            val sendMessageHeader =SendMessageHeader("AEGISMODECHANGE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<MACHINENAME>$EQPID</MACHINENAME>
                           |<MODE>$MODE</MODE>
                           |<USERID>$Userid</USERID>
                           |<USERNAME>$Username</USERNAME>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun MEASChamberCoverage(factoryName: String, Product: String, Ownercode: String, Opercode: String, Lotid: String, userId: String): String{
            val sendMessageHeader =SendMessageHeader("MEASCHAMBERCOVERAGE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACTORYNAME>$factoryName</FACTORYNAME>
                           |<LOTID>$Lotid</LOTID>
                           |<PRODUCT>$Product</PRODUCT>
                           |<OWNERCODE>$Ownercode</OWNERCODE>
                           |<OPERCODE>$Opercode</OPERCODE>
                           |<USERID>$userId</USERID>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getPdaMessage(facility: String, area: String, wifiIp: String?): String{
            val sendMessageHeader =SendMessageHeader("GETPDAMESSAGE", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<AREA>$area</AREA>
                           |<IPADDR>$wifiIp</IPADDR>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

        fun getPdaMessagebyRoom(facility: String, roomId: String, roomName: String, wifiIp: String?): String{
            val sendMessageHeader =SendMessageHeader("GETPDAROOMMESSAGEBYROOM", DeviceInfo.MOBILE_SERVER_NAME, DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
            val sendMessageBody = """
                           |<FACILITY>$facility</FACILITY>
                           |<ROOMID>$roomId</ROOMID>
                           |<ROOMNAME>$roomName</ROOMNAME>
                           |<IPADDR>$wifiIp</IPADDR>
                          """.trimMargin()

            return SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
        }

    }
}