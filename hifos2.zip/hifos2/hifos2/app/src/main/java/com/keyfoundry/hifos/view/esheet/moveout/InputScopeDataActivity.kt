package com.keyfoundry.hifos.view.esheet.moveout

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.spinner.SpinnerItem
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityInputScopeDataBinding
import com.keyfoundry.hifos.databinding.ActivityWaferSelectBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.cmm.WaferSelectActivity
import com.keyfoundry.hifos.view.cmm.wafer.SelectWafer
import com.keyfoundry.hifos.view.cmm.wafer.WaferAdapter
import com.keyfoundry.hifos.view.cmm.wafer.WaferInfo
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.DecimalFormat
import java.util.ArrayList

class InputScopeDataActivity : HFActivity() {
    companion object {
        private const val TAG = "InputScopeDataActivity"
    }

    private lateinit var viewBinding: ActivityInputScopeDataBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var selectWafer: SelectWafer

    private var gLotId = ""
    private var gFactoryName = ""
    private var gProcessOperation = ""
    private var gMachineName = ""
    private var gLayerId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityInputScopeDataBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editLotId.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.txtWaferList.movementMethod = ScrollingMovementMethod.getInstance()

        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnModify.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)

        viewBinding.editLotId.setOnEditorActionListener(onEditorActionListener)
        viewBinding.btnSearchLotId.setOnClickListener(onSingleClickListener)

        viewBinding.spinnerFaultCategory.onItemSelectedListener = itemSelectListener

        selectWafer = SelectWafer(25)

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()
            viewBinding.editLotId.setText(lotId)
            viewBinding.editLotId.isEnabled = false
            viewBinding.btnSearchLotId.isEnabled = false
            getScopeLotInfo()
        }



    }

    private val onEditorActionListener =
        TextView.OnEditorActionListener { v, actionId, event ->
            when (v.id) {
                viewBinding.editLotId.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        val check = BarcodeStyle(this).lotId(viewBinding.editLotId)

                        if (check) {
                            getScopeLotInfo()
                        } else {
                            viewBinding.editLotId.setText("")
                            clearData()
                        }
                    } else if (event != null) {
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            val check = BarcodeStyle(this).lotId(viewBinding.editLotId)

                            if (check) {
                                getScopeLotInfo()
                            } else {
                                viewBinding.editLotId.setText("")
                                clearData()
                            }
                        }
                    }
                }
            }

            true
        }

    private val itemSelectListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {

            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerFaultCategory.id -> {

                    }

                }
            }

        }

        override fun onNothingSelected(parent: AdapterView<*>?) {

        }
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnModify.id -> {
                    resetWafer()
                }
                viewBinding.btnCancel.id -> {
                    cancel()
                }
                viewBinding.btnSearchLotId.id -> {
                    getScopeLotInfo()
                }
                viewBinding.btnOk.id -> {
                    inputData()
                }
            }
        }
    }

    private fun inputData(){
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.inputScopeData(gFactoryName,
                gLotId,
                gProcessOperation,
                gMachineName,
                gLayerId,
                viewBinding.editSideRinse.text.toString(),
                viewBinding.editWeeWidth.text.toString(),
                viewBinding.editLogo.text.toString(),
                viewBinding.txtWaferList.text.toString(),
                viewBinding.spinnerFaultCategory.selectedItem?.toString(),
                DeviceInfo.OPERATOR_ID)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MESSAGE
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {

                OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_OK
                    , "데이터가 저장 되었습니다."
                    , GetString.BTNOKSTR)

                val moveOutIntent =
                    Intent(applicationContext, MoveOutActivity::class.java)

                moveOutIntent.putExtra("LOTID", viewBinding.editLotId.text.toString())
                moveOutIntent.putExtra("LOGO", viewBinding.editLogo.text.toString())
                moveOutIntent.putExtra("WAFERLIST", viewBinding.txtWaferList.text.toString())

                setResult(Activity.RESULT_OK, moveOutIntent)
                finish()


            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)
            }
        }
    }

    private fun spinnerProcessOperation(itemList : ArrayList<String>){
        val spinnerAdapter =
            ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerFaultCategory.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
    }

    private fun getScopeLotInfo() {
        mainScope.launch {

            val sendMessage = MessageFactoryUtil.getScopeLotInfo(viewBinding.editLotId.text.toString())

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MESSAGE
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                if(messageBody.optString("ISEXIST").equals("Y")){
                    val returnCode = OkCancelDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_WARNING, "이전에 이미 입력한 데이터가 있습니다.\n기존 데이터를 삭제하고 다시 입력하시겠습니까?",
                        GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
                    )
                    if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                        return@launch
                    }
                }

                gLotId = messageBody.optString("LOTNAME")
                gFactoryName = messageBody.optString("FACTORYNAME")
                gProcessOperation = messageBody.optString("PROCESSOPERATIONNAME")
                gMachineName = messageBody.optString("MACHINENAME")
                gLayerId = messageBody.optString("LAYERID")


                selectWafer()

                val spinnerOperationItems = arrayListOf<String>()
                val spinnerFaultJSON =
                    ResponseDataToJsonUtil.getMessageBodyInValueList(result, "FAULTS", "FAULT")

                for (i in 0 until spinnerFaultJSON.length()) {
                    val operationName = spinnerFaultJSON.getJSONObject(i)
                    spinnerOperationItems.add(operationName.optString("TYPEVALUE"))
                }
                spinnerProcessOperation(spinnerOperationItems)

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

            }
        }
    }

    private fun selectWafer() {
        mainScope.launch {

            val sendMessage = MessageFactoryUtil.slotInfo(viewBinding.editLotId.text.toString(), DeviceInfo.FACILITY)

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.SLOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                var waferList = messageBody.optString("WAFERLIST");

                val regex = Regex("[A-Za-z]+[0-9]+\\.([0-9]+)")
                val matchResults = regex.findAll(waferList)
                val result = matchResults.map { it.groupValues[1] }.joinToString(",")

                setWaferButtonList(result, true, "", "")

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)
            }

        }

    }

    private fun resetWafer() {
        var realCount = selectWafer.currentCount

        for (count in 0 until viewBinding.rcWaferList.childCount) {
            val waferButton =
                viewBinding.rcWaferList.layoutManager?.findViewByPosition(count) as Button

            if (waferButton.isEnabled && waferButton.isSelected && realCount > 0) {
                waferButton.performClick()
                realCount--
            }
        }
    }

    private fun cancel() {
        val returnIntent = Intent()
        setResult(Activity.RESULT_CANCELED, returnIntent)

        finish()
    }

    private fun setWaferButtonList(
        waferList: String?, editable: Boolean, disableList: String?, selectList: String?
    ) {
        if (waferList != null) {
            val slotMap = makeSlotMapList(waferList)
            viewBinding.rcWaferList.layoutManager =
                object : GridLayoutManager(this, 5, LinearLayoutManager.VERTICAL, false) {
                    override fun canScrollVertically(): Boolean {
                        return false
                    }
                }

            viewBinding.rcWaferList.adapter = WaferAdapter(
                this, slotMap, editable,
                disableList, selectList, selectWafer, supportFragmentManager
            )
        }
    }

    private fun makeSlotMapList(waferString: String): MutableList<WaferInfo> {
        val waferList = waferString.split(",")
        val wafercount = waferList.count(); //요기서 수정을 해야함.
        var value = ""
        var key = ""
        val slotMapList = mutableListOf<WaferInfo>()
        var bresult = false

        var slotIndex = 0
        for (i in 1..25) {

            if(wafercount < i) {
                 value = ""
                 key = ""
            }
            else {
                 key = waferList[slotIndex]
                 value = key.substring(key.lastIndexOf(".") + 1, key.length)
            }

            val df = DecimalFormat("00")
            val buttonIndex = df.format(i)

            bresult = false
            for(iw in 0..wafercount-1) {
                var tempkey = waferList[iw]
                var tempvalue =  tempkey.substring(tempkey.lastIndexOf(".") + 1, tempkey.length)

                if(buttonIndex == tempvalue) {
                    key = waferList[iw]
                    value = key.substring(key.lastIndexOf(".") + 1, key.length)
                    bresult = true
                }
            }

            if(!bresult)
            {
                value = ""
                key = ""
            }

            if(value == buttonIndex.toString()){
                val waferInfo = WaferInfo(key, buttonIndex.toString())
                waferInfo.machine = ""
                slotMapList.add(waferInfo)
                slotIndex++
            } else {
                val waferInfo = WaferInfo("empty", buttonIndex.toString())
                waferInfo.machine = ""
                slotMapList.add(waferInfo)
            }
        }

        return slotMapList
    }

    private fun clearData(){
        gLotId = ""
        gFactoryName = ""
        gProcessOperation = ""
        gMachineName = ""
        gLayerId = ""


        viewBinding.txtWaferList.text = ""
        viewBinding.editLogo.setText("")
        viewBinding.editWeeWidth.setText("")
        viewBinding.editSideRinse.setText("")

        resetWafer()
    }

}