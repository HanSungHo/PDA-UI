package com.keyfoundry.hifos.config.grid;

import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.view.GestureDetectorCompat;

import com.keyfoundry.hifos.config.utils.GridService;

import java.util.ArrayList;
import java.util.HashMap;

public class CTRowLayout extends TableRow {
    private ArrayList<Integer> mColumnWidths = new ArrayList<>();
    private int myWidth = 0;
    private int myHeight = 0;
    private int maxChildHeight = 0;
    private boolean preMeasured = false;

    public CTRowLayout(Context context) {
        super(context);
        init();
    }

    public CTRowLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        this.setClickable(true);
    }

    @SuppressWarnings({"UnusedDeclaration"})
    public ArrayList<Integer> getColumnWidths() {
        return mColumnWidths;
    }

    @SuppressWarnings({"UnusedDeclaration"})
    public void setColumnWidths(ArrayList<Integer> mColumnWidths) {
        this.mColumnWidths = mColumnWidths;
    }

    @SuppressWarnings({"UnusedDeclaration"})
    public int getMaxChildHeight() {
        return maxChildHeight;
    }

    @SuppressWarnings({"UnusedDeclaration"})
    public void setMaxChildHeight(int maxChildHeight) {
        this.maxChildHeight = maxChildHeight;
    }

    @Override
    public void setOrientation(int orientation) {
        throw new UnsupportedOperationException("Setting the Orientation is not supported");
    }

    private void preMeasure() {
        // Reset stored size as we are measuring again
        myWidth = 0;
        myHeight = 0;
        // Measure UNSPECIFIED
        int measureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);

        final int count = getChildCount();
        for (int i = 0; i < count; ++i) {
            final View child = getChildAt(i);
            if (child == null) {
                continue;
            }
            if (child.getVisibility() == View.GONE) {
                continue;
            }

            measureChildWithMargins(child, measureSpec, 0, measureSpec, 0);
            int childWidth = child.getMeasuredWidth();
            int childHeight = child.getMeasuredHeight();
            mColumnWidths.add(childWidth);
            myWidth += childWidth;
            maxChildHeight = Math.max(maxChildHeight, childHeight);

        }

        // Add my padding
        myWidth = myWidth + getPaddingLeft() + getPaddingRight();
        myHeight = maxChildHeight + getPaddingTop() + getPaddingBottom();

        // Check against our minimum height and width
        myWidth = Math.max(myWidth, getSuggestedMinimumWidth());
        myHeight = Math.max(myHeight, getSuggestedMinimumHeight());

        setMeasuredDimension(myWidth, myHeight);

        preMeasured = true;
    }

    private void fixedMeasure() {
        // Reset stored size as we are measuring again
        myWidth = 0;
        myHeight = 0;
        // Measure EXACTLY
        int heightMeasureSpec = MeasureSpec.makeMeasureSpec(maxChildHeight, MeasureSpec.EXACTLY);

        final int count = getChildCount();
        for (int i = 0; i < count; ++i) {
            int widthMeasureSpec = MeasureSpec.makeMeasureSpec(mColumnWidths.get(i), MeasureSpec.EXACTLY);
            View child = getChildAt(i);
            if (child == null) {
                continue;
            }
            if (child.getVisibility() == View.GONE) {
                continue;
            }

            // Ask the child to match the parent so it fills out the whole cell
            TableRow.LayoutParams childLayoutParams = new TableRow.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
            child.setLayoutParams(childLayoutParams);

            measureChildWithMargins(child, widthMeasureSpec, 0, heightMeasureSpec, 0);

            // Calculate new row width using the width we have set each column to
            myWidth += mColumnWidths.get(i);
        }

        // Add my padding
        myWidth = myWidth + getPaddingLeft() + getPaddingRight();
        myHeight = maxChildHeight + getPaddingTop() + getPaddingBottom();

        // Check against our minimum height and width
        myWidth = Math.max(myWidth, getSuggestedMinimumWidth());
        myHeight = Math.max(myHeight, getSuggestedMinimumHeight());

        setMeasuredDimension(myWidth, myHeight);
    }

    public String cellValue(String colName) {
        HashMap<String, Object> rowData = ((GridService.RowData) this.getTag()).getRowDataList();

        String returnValue = "";
        if (rowData.get(colName) != null)
            returnValue = rowData.get(colName).toString();

        return returnValue;
    }

    public String cellValue(int columnIndex) {
        TextView cellTextView = (TextView) (this.getChildAt(columnIndex));

        return cellTextView.getText().toString();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        if (preMeasured) {
            fixedMeasure();
        } else {
            // For first Measure
            preMeasure();
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        try {
            if (this.getParent() != null) {
                CTSubLayout parentLayout = (CTSubLayout) this.getParent();
                parentLayout.setCurrentRowIndex(parentLayout.indexOfChild(this));
            }
        } catch (Exception e) {

        }

        return super.dispatchTouchEvent(ev);
    }
}
