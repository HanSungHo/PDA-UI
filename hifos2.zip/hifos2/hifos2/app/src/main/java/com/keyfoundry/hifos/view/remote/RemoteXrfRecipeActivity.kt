package com.keyfoundry.hifos.view.remote

import android.os.Bundle
import android.text.InputFilter
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.GridService
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityRemoteXrfRecipeSetBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.*
import okhttp3.internal.notify
import org.json.JSONArray
import org.json.JSONObject
import java.lang.Exception

class RemoteXrfRecipeActivity : HFActivity() {
    companion object {
        private const val TAG = "RemoteXrfRecipeActivity"
    }

    lateinit var viewBinding: ActivityRemoteXrfRecipeSetBinding
    private lateinit var gridService: GridService

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var mainEqpId = "";

    private val spinnerItemsArray = arrayListOf<String>()

    var getItem = ""
    var ItemIdx = 0
    var getEqp = ""
    var EqpIdx = 0
    var getCategory = ""
    var CategoryIdx = 0
    var getSample = ""
    var SampleIdx = 0
    var getPara = ""
    var ParaIdx = 0

    var getitemflag = false

    var Item = "";
    var eqpId = "";
    var category = "";
    var sample = "";
    var para = "";

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityRemoteXrfRecipeSetBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        gridService = GridService(applicationContext)

        if (intent.getStringExtra("SLOT")?.isNotEmpty() == true) {
            val selslot = intent.getStringExtra("SLOT")

            viewBinding.txtSlot.setText(selslot)

            viewBinding.txtSlot.requestFocus()
            viewBinding.txtSlot.selectAll()
        }

        getItem = intent.getStringExtra("ITEM").toString()
        getEqp = intent.getStringExtra("PRODEQP").toString()
        getCategory = intent.getStringExtra("CATEGORY").toString()
        getSample = intent.getStringExtra("SAMPLE").toString()
        getPara = intent.getStringExtra("PARA").toString()


        getXrfItem()


        viewBinding.btnSave.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)

        viewBinding.spinnerItem.onItemSelectedListener = itemSelectedListener
        viewBinding.spinnerProdeqp.onItemSelectedListener = itemSelectedListener
        viewBinding.spinnerCategory.onItemSelectedListener = itemSelectedListener
        viewBinding.spinnerMds.onItemSelectedListener = itemSelectedListener
        viewBinding.spinnerPara.onItemSelectedListener = itemSelectedListener



//
//        if (intent.getStringExtra("PRODEQP")!= "null" && intent.getStringExtra("PRODEQP")!= "") {
//            eqpId = intent.getStringExtra("PRODEQP").toString()
//
//            viewBinding.spinnerProdeqp.setSpinnerText(eqpId)
//        }
//
//        if (intent.getStringExtra("SAMPLE")!= "null" && intent.getStringExtra("SAMPLE")!= "") {
//            sample = intent.getStringExtra("SAMPLE").toString()
//
//            viewBinding.spinnerMds.setSpinnerText(sample)
//        }
//
//        if (intent.getStringExtra("PARA")!= "null" && intent.getStringExtra("PARA")!= "")  {
//            para = intent.getStringExtra("PARA").toString()
//
//            viewBinding.spinnerPara.setSpinnerText(para)
//        }



    }

//    fun Spinner.setSpinnerText(text: String) {
//        for (i in 0 until this.adapter.count) {
//            if (this.adapter.getItem(i).toString().contains(text)) {
//                this.setSelection(i)
//            }
//        }
//    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSave.id -> {
                    execute()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    private fun clearData() {
        //viewBinding.spinnerItem.removeAllViews()
    }

    private fun getXrfItem()
    {
        try {

            mainScope.launch {
                clearData()

                val sendMessage = MessageFactoryUtil.XrfItemInfo(DeviceInfo.FACILITY, DeviceInfo.AREA)
                val message =
                    MessageSender.send(supportFragmentManager, sendMessage, MessageName.XRFITEMINFO)
                val isSuccessFul = message.isSuccessFul
                val result = message.result

                if (isSuccessFul) {
                    val bayListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "BAYS")

                    val spinnerBayItems = arrayListOf<String>()

                    for (i in 0 until bayListJSON.length()) {
                        val bay = bayListJSON.getJSONObject(i)
                        spinnerBayItems.add(bay.getString("BAY"))
                        if(bay.getString("BAY") == getItem ){
                            ItemIdx = i+1
                        }
                    }

                    val spinnerAdapter = ArrayAdapter(
                        applicationContext, R.layout.contact_spinner_row_init, spinnerBayItems
                    )
                    spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                    viewBinding.spinnerItem.adapter = InitSpinnerAdapter(
                        spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                    )

                    if (getItem != "null" && getItem!= "") {
                        //val getItem = intent.getStringExtra("ITEM").toString()

                        viewBinding.spinnerItem.setSelection(ItemIdx)
                        getItem = ""
                    }

                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR
                    )
                }
            }

//            if (intent.getStringExtra("ITEM") != "null" && intent.getStringExtra("ITEM")!= "") {
//                //val getItem = intent.getStringExtra("ITEM").toString()
//
//                viewBinding.spinnerItem.setSelection(ItemIdx)
//            }

        } catch (e: Exception){
            println("catch : ${e.message}")
        }

    }

    fun setSpinnerItem()
    {
        if(spinnerItemsArray.count() != 0)        {
            val spinnerItemAdapter = ArrayAdapter(
                applicationContext, R.layout.contact_spinner_row_init, spinnerItemsArray
            )
            spinnerItemAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
            viewBinding.spinnerItem.adapter = InitSpinnerAdapter(
                spinnerItemAdapter, R.layout.contact_spinner_row_init, applicationContext
            )
        }

    }

    private fun getXrfProdeqp()
    {
        mainScope.launch {
            clearData()

            val sendMessage = MessageFactoryUtil.XrfEqpInfo(DeviceInfo.FACILITY, DeviceInfo.AREA,Item)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.XRFEQPINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val bayListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "BAYS")

                val spinnerBayItems = arrayListOf<String>()

                for (i in 0 until bayListJSON.length()) {
                    val bay = bayListJSON.getJSONObject(i)
                    spinnerBayItems.add(bay.getString("BAY"))
                    if(bay.getString("BAY") == getEqp ){
                        EqpIdx = i+1
                    }
                }

                val spinnerAdapter = ArrayAdapter(
                    applicationContext, R.layout.contact_spinner_row_init, spinnerBayItems
                )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerProdeqp.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                if (getEqp != "null" && getEqp != "") {
                    //val getItem = intent.getStringExtra("ITEM").toString()

                    viewBinding.spinnerProdeqp.setSelection(EqpIdx)
                    getEqp = ""
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun getXrfCategory()
    {
        mainScope.launch {
            clearData()

            val sendMessage = MessageFactoryUtil.XrfCategoryInfo(DeviceInfo.FACILITY, DeviceInfo.AREA,Item,eqpId)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.XRFCATEGORYINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val bayListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "BAYS")

                val spinnerBayItems = arrayListOf<String>()

                for (i in 0 until bayListJSON.length()) {
                    val bay = bayListJSON.getJSONObject(i)
                    spinnerBayItems.add(bay.getString("BAY"))
                    if(bay.getString("BAY") == getCategory ){
                        CategoryIdx = i+1
                    }
                }

                val spinnerAdapter = ArrayAdapter(
                    applicationContext, R.layout.contact_spinner_row_init, spinnerBayItems
                )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerCategory.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                if (getCategory != "null" && getCategory!= "") {
                    //val getItem = intent.getStringExtra("ITEM").toString()

                    viewBinding.spinnerCategory.setSelection(CategoryIdx)
                    getCategory = ""
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun getXrfSample()
    {
        mainScope.launch{
            val sendMessageItemname =
                MessageFactoryUtil.XrfSampleInfo(DeviceInfo.FACILITY,DeviceInfo.AREA,Item,eqpId,category)

            val message = MessageSender.send(
                supportFragmentManager, sendMessageItemname, MessageName.XRFSAMPLEINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val bayListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "BAYS")

                val spinnerBayItems = arrayListOf<String>()

                for (i in 0 until bayListJSON.length()) {
                    val bay = bayListJSON.getJSONObject(i)
                    spinnerBayItems.add(bay.getString("BAY"))
                    if(bay.getString("BAY") == getSample ){
                        SampleIdx = i+1
                    }
                }

                val spinnerAdapter = ArrayAdapter(
                    applicationContext, R.layout.contact_spinner_row_init, spinnerBayItems
                )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerMds.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                if (getSample != "null" && getSample!= "") {
                    //val getItem = intent.getStringExtra("ITEM").toString()

                    viewBinding.spinnerMds.setSelection(SampleIdx)
                    getSample = ""
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun getXrfPara()
    {
        mainScope.launch{
            val sendMessageItemname =
                MessageFactoryUtil.XrfParaInfo(DeviceInfo.FACILITY,DeviceInfo.AREA,Item,eqpId,category,sample)

            val message = MessageSender.send(
                supportFragmentManager, sendMessageItemname, MessageName.XRFPARAINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val bayListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "BAYS")

                val spinnerBayItems = arrayListOf<String>()

                for (i in 0 until bayListJSON.length()) {
                    val bay = bayListJSON.getJSONObject(i)
                    spinnerBayItems.add(bay.getString("BAY"))
                    if(bay.getString("BAY") == getPara ){
                        ParaIdx = i+1
                    }
                }

                val spinnerAdapter = ArrayAdapter(
                    applicationContext, R.layout.contact_spinner_row_init, spinnerBayItems
                )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerPara.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                if (getPara != "null" && getPara!= "") {
                    //val getItem = intent.getStringExtra("ITEM").toString()

                    viewBinding.spinnerPara.setSelection(ParaIdx)
                    getPara=""
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun getXrfRecipe()
    {
        mainScope.launch{
            val sendMessageItemname =
                MessageFactoryUtil.XrfRecipeInfo(DeviceInfo.FACILITY,DeviceInfo.AREA,Item,eqpId,category,sample,para)

            val message = MessageSender.send(
                supportFragmentManager, sendMessageItemname, MessageName.XRFRECIPEINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val bayListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "BAYS")

                val spinnerBayItems = arrayListOf<String>()

                for (i in 0 until bayListJSON.length()) {
                    val bay = bayListJSON.getJSONObject(i)
                    viewBinding.txtRecipe.setText(bay.getString("BAY"))
                    val ifThick = bay.getString("CONTEXT01")

                    if(ifThick == "Y") {
                        viewBinding.linearThick.visibility = View.VISIBLE
                    }
                    else{
                        viewBinding.linearThick.visibility = View.GONE
                    }
                }
//                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
//                val pItem = messageBody.optString("RECIPE")
//                viewBinding.txtSlot.setText(para)

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerItem.id -> {
                        if(viewBinding.spinnerItem.selectedItem != null) {
                            Item = viewBinding.spinnerItem.selectedItem.toString()
                            getXrfProdeqp()
                        }
                    }
                    viewBinding.spinnerProdeqp.id -> {
                        if(viewBinding.spinnerProdeqp.selectedItem != null) {
                            eqpId = viewBinding.spinnerProdeqp.selectedItem.toString()
                            getXrfCategory()
                        }
                    }
                    viewBinding.spinnerCategory.id -> {
                        if(viewBinding.spinnerCategory.selectedItem != null) {
                            category = viewBinding.spinnerCategory.selectedItem.toString()
                            getXrfSample()
                        }
                    }
                    viewBinding.spinnerMds.id -> {
                        if(viewBinding.spinnerMds.selectedItem != null) {
                            sample = viewBinding.spinnerMds.selectedItem.toString()
                            getXrfPara()
                        }
                    }
                    viewBinding.spinnerPara.id -> {
                        if(viewBinding.spinnerPara.selectedItem != null) {
                            para = viewBinding.spinnerPara.selectedItem.toString()
                            getXrfRecipe()
                        }
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) { }
    }

    private fun Null_check(): Boolean
    {
        if(viewBinding.spinnerItem.selectedItem == null){
            return false
        }

        if(viewBinding.spinnerProdeqp.selectedItem == null){
            return false

        }

        if(viewBinding.spinnerCategory.selectedItem== null){
            return false

        }

        if(viewBinding.spinnerMds.selectedItem == null){
            return false

        }

        if(viewBinding.spinnerPara.selectedItem == null){
            return false

        }

        if(viewBinding.txtRecipe.text.toString() == ""){
            return false

        }

        if(viewBinding.txtSlot.text.toString() == ""){
            return false
        }

        return true
    }

    private fun execute()
    {

        if(Null_check() == false){
            return
        }


        intent.putExtra("ITEM",viewBinding.spinnerItem.selectedItem.toString())
        intent.putExtra("PRODEQP",viewBinding.spinnerProdeqp.selectedItem.toString())
        intent.putExtra("CATEGORY",viewBinding.spinnerCategory.selectedItem.toString())
        intent.putExtra("SAMPLE",viewBinding.spinnerMds.selectedItem.toString())
        intent.putExtra("PARA",viewBinding.spinnerPara.selectedItem.toString())
        intent.putExtra("RECIPE",viewBinding.txtRecipe.text.toString())
        intent.putExtra("SLOT",viewBinding.txtSlot.text.toString())
        intent.putExtra("THICK",viewBinding.txtThick.text.toString())
        setResult(RESULT_OK, intent)
        finish()
    }

}

