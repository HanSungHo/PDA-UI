package com.keyfoundry.hifos.view.esheet.comment

import android.content.Intent
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.GestureDetectorCompat
import androidx.core.view.children
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.CTSubLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.utils.GridService
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityCommentListBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CommentListActivity : HFActivity() {
    companion object {
        private const val TAG = "CommentListActivity"
    }

    private lateinit var viewBinding: ActivityCommentListBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    lateinit var lotId: String
    lateinit var operation: String
    lateinit var subOperation: String
    lateinit var processStep: String
    lateinit var operSeq: String

    lateinit var gridService: GridService

    inner class DrawerGestureListener(
        private val commentNo: String,
        private val row: CTRowLayout
    ) : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(e: MotionEvent?): Boolean {

            viewBinding.txtCommentNo.text = commentNo
            row.isPressed = true

            return super.onSingleTapUp(e)
        }

        override fun onDoubleTap(e: MotionEvent?): Boolean {
            openCommentView(commentNo)
            return super.onDoubleTap(e)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityCommentListBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        gridService = GridService(applicationContext)

        lotId = intent.getStringExtra("LOTID").toString()
        operation = intent.getStringExtra("OPERATION").toString()
        subOperation = intent.getStringExtra("SUBOPERATION").toString()
        processStep = intent.getStringExtra("PROCESSSTEP").toString()
        operSeq = intent.getStringExtra("OPERSEQUENCE").toString()

        viewBinding.txtCommentNo.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtProcessNum.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtProcessStep.movementMethod = ScrollingMovementMethod.getInstance()

        viewBinding.txtLotNo.text = lotId
        val processNum = "$operation$subOperation"
        viewBinding.txtProcessNum.text = processNum
        viewBinding.txtProcessStep.text = processStep

        viewBinding.btnRead.setOnClickListener(onClickListener)
        viewBinding.btnClose.setOnClickListener(onClickListener)

        getCommentList()
    }

    private val onClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnRead.id -> {
                    val commentNo = viewBinding.txtCommentNo.text.toString()
                    if (commentNo == "") {
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            "Comment를 선택 해 주세요", GetString.BTNOKSTR
                        )
                        return
                    }

                    openCommentView(commentNo)
                }
                viewBinding.btnClose.id -> {
                    finish()
                }
            }
        }
    }

    private fun openCommentView(commentNo: String) {
        val commentViewIntent = Intent(this, CommentViewActivity::class.java)

        commentViewIntent.putExtra("lotId", lotId)
        commentViewIntent.putExtra("commentNo", commentNo)
        commentViewIntent.putExtra("operation", operation)
        commentViewIntent.putExtra("subOperation", subOperation)
        commentViewIntent.putExtra("operSeq", operSeq)

        startActivity(commentViewIntent)
    }

    private fun getCommentList() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.commentList(
                lotId, DeviceInfo.FACILITY, operation, subOperation, processStep
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.COMMENTLIST)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val commentListJSON =
                    ResponseDataToJsonUtil.getMessageBodyList(result, "COMMENTITEMS")

                val columnData = linkedMapOf(
                    "NO" to ColumnProperty("NO", Gravity.CENTER, false, 80),
                    "SUBOPERATION" to ColumnProperty("SUB", Gravity.CENTER, false),
                    "WORKCODE" to ColumnProperty("W", Gravity.CENTER, false),
                    "TRACKTYPE" to ColumnProperty("TYPE", Gravity.CENTER, false),
                    "ISCHECK" to ColumnProperty("R", Gravity.CENTER, false),
                    "WRITER" to ColumnProperty("작성자", Gravity.CENTER, false),
                    "WRITETIME" to ColumnProperty("작성일시", Gravity.CENTER, false),
                    "READER" to ColumnProperty("읽은사람", Gravity.CENTER, false),
                    "READTIME" to ColumnProperty("읽은시간", Gravity.CENTER, false)
                )

                val gridData = gridService.setGridPropData(columnData, commentListJSON)
                viewBinding.baseLayout.addView(gridData)

                selectComment(gridData)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setRowColor(v: View, event: MotionEvent?) {
        val parentLayout = v.parent as CTSubLayout
        parentLayout.currentRowIndex = parentLayout.indexOfChild(v)

        if (event?.action == MotionEvent.ACTION_UP)
            v.requestFocus()
    }

    private fun selectComment(gridData: CTMainLayout) {
        for (row in gridData.mainTable.children) {
            val commentNo = gridService.getCellValue(row, "NO")

            val mDetector =
                GestureDetectorCompat(this, DrawerGestureListener(commentNo, row as CTRowLayout))

            row.setOnTouchListener { v, event ->
                mDetector.onTouchEvent(event)
                setRowColor(row, event)

                true
            }
        }
    }
}

