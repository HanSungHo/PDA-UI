package com.keyfoundry.hifos.view.remote

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputFilter
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.BarcodeStyle
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityRemoteAitBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.cmm.wafer.WaferselectAIT_Activity
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RemoteAITActivity : HFActivity() {
    companion object {
        private const val TAG = "RemoteAitActivity"
    }

    lateinit var viewBinding: ActivityRemoteAitBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var lsChangeRecipe = false
    private var exposure = false
    private var searchArea = ""
    private var searchOpType = ""
    private var mainEqpId = ""
    private var searchOperation = ""
    private var searchSubOperation = ""
    private var searchProcessStep = ""
    private var searchOperSeq = ""
    private var searchSuperEqpId = ""
    private var searchEqpArea = ""
    private var searchEqpType = ""
    private var searchReworkFlag = ""

    private var startEqp = ""
    private var startEqpType = "AIT"
    private var startPort = ""
    private var startSlot = ""
    private var startRecipe = ""
    private var startProdeqp = ""
    private var startMid = ""
    private var startLot = ""
    private var startPara = ""
    private var startThick = ""
    private var startTable = ""
    private var startFolder = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityRemoteAitBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)
        //setContentView(R.layout.activity_remote_ait)

        //소문자 -> 대문자
        viewBinding.editSelectMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editProductMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        //setInitDisable()
        //setFlagData()

        if (intent.getStringExtra("Eqpid")?.isNotEmpty() == true) {
            viewBinding.editSelectMachine.setText(intent.getStringExtra("Eqpid").toString())
            setEqpInfo()
        }


        viewBinding.spinnerPort.onItemSelectedListener = itemSelectedListener

        viewBinding.editSelectMachine.setOnEditorActionListener(editorActionLister)
        viewBinding.editLotNo.setOnEditorActionListener(editorActionLister)
        viewBinding.editProductMachine.setOnEditorActionListener(editorActionLister)

        viewBinding.btnSearchIngMachine.setOnClickListener(onSingleClickListener)
        viewBinding.btnClearPort.setOnClickListener(onSingleClickListener)
        viewBinding.btnSelectWafer.setOnClickListener(onSingleClickListener)
        viewBinding.btnStart.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
        viewBinding.editLotNo.requestFocus()
    }

    private val editorActionLister =
        TextView.OnEditorActionListener { v, actionId, event ->
            when (v.id) {
                viewBinding.editSelectMachine.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        val check = BarcodeStyle(this).eqpId(viewBinding.editSelectMachine)
                        if (check) {
                            mainScope.launch {
                                //setEqpInfo()
                            }
                        }
                    } else if (event != null) { // Barcode Event
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            val check = BarcodeStyle(this).eqpId(viewBinding.editSelectMachine)
                            if (check) {
                                mainScope.launch {
                                    //setEqpInfo()
                                }
                            }
                        }
                    }
                }
                viewBinding.editLotNo.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        mainScope.launch {
                            getLotinfo()
                        }
                    } else if (event != null) { // Barcode Event
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            mainScope.launch {
                                getLotinfo()
                            }
                        }
                    }
                }
                viewBinding.editProductMachine.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        BarcodeStyle(this).eqpId(viewBinding.editProductMachine)
                    } else if (event != null) { // Barcode Event
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            BarcodeStyle(this).eqpId(viewBinding.editProductMachine)
                        }
                    }
                }
            }

            true
        }

    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerPort.id -> {
                        setPortState()
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private fun clearPortState() {
        viewBinding.txtPortStatus.text = ""
        viewBinding.txtPortStatus.background = null
    }
    private fun setPortColor(portState: String) {
        when (portState) {
            "INIT" -> {
                viewBinding.txtPortStatus.setBackgroundColor(Color.RED)
                viewBinding.txtPortStatus.setTextColor(Color.WHITE)
            }
            "RUN" -> {
                viewBinding.txtPortStatus.setBackgroundColor(Color.BLUE)
                viewBinding.txtPortStatus.setTextColor(Color.WHITE)
            }
            "PENDING" -> {
                viewBinding.txtPortStatus.setBackgroundColor(getColor(R.color.portPending))
                viewBinding.txtPortStatus.setTextColor(Color.BLACK)
            }
            "READY" -> {
                viewBinding.txtPortStatus.setBackgroundColor(Color.GREEN)
                viewBinding.txtPortStatus.setTextColor(Color.BLACK)
            }
            "RESERVED" -> {
                viewBinding.txtPortStatus.setBackgroundColor(Color.YELLOW)
                viewBinding.txtPortStatus.setTextColor(Color.BLACK)
            }
            "COMPLETE" -> {
                viewBinding.txtPortStatus.setBackgroundColor(getColor(R.color.portCompleted))
                viewBinding.txtPortStatus.setTextColor(Color.BLACK)
            }
            "IDLE" -> {
                viewBinding.txtPortStatus.setBackgroundColor(getColor(R.color.portIdle))
                viewBinding.txtPortStatus.setTextColor(Color.WHITE)
            }
        }
    }
    private fun setPortState() {
        mainScope.launch {
            clearPortState()

            if (viewBinding.spinnerPort.selectedItem == null)
                return@launch

            viewBinding.btnClearPort.isEnabled = false

            val portId = viewBinding.spinnerPort.selectedItem.toString()

            val sendMessage =
                MessageFactoryUtil.machinePortStatus(viewBinding.editSelectMachine.text.toString(), portId)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.AITREMOTESTART
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val portState = messageBody.optString("PORTSTATENAME")
                val ackMsg = messageBody.optString("ACKMSG")

                viewBinding.txtPortStatus.text = portState

                setPortColor(portState)

                if (portState == "RUN" || portState == "PENDING" || portState == "RESERVED") {
                    val portMsg = """
                    |해당 PORT가 진행중입니다.
                    |장비 및 진행할 LOT을 다시 확인 바랍니다.
                    |""".trimMargin()
                    OkDialog.show(
                        supportFragmentManager,
                        "장비 MASSAGE",
                        portMsg,
                        GetString.BTNOKSTR
                    )
                    viewBinding.btnClearPort.isEnabled = true
                    viewBinding.btnStart.isEnabled = false

                    if (ackMsg.isNotEmpty()) {
                        OkDialog.show(
                            supportFragmentManager, "PORT WARNING", ackMsg, GetString.BTNOKSTR
                        )
                    }
                } else if (portState.isEmpty()) {
                    val portMsg = """
                    |PORT 정보를 가져올 수 없습니다.
                    |잠시후 다시 확인 바랍니다.
                    |""".trimMargin()
                    OkDialog.show(
                        supportFragmentManager,
                        "장비 MASSAGE",
                        portMsg,
                        GetString.BTNOKSTR
                    )
                    viewBinding.btnStart.isEnabled = false
                    viewBinding.btnClearPort.isEnabled = false
                } else if (portState == "READY") {
                    viewBinding.btnStart.isEnabled = true
                    viewBinding.btnClearPort.isEnabled = true

                    //getLotinfo()
                } else
                    viewBinding.btnStart.isEnabled = false
                viewBinding.btnClearPort.isEnabled = true
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }
    private fun clearEqpInfo() {
        viewBinding.spinnerPort.adapter = null
        mainEqpId = ""
    }

    private fun setEqpInfo() {
        mainScope.launch {
            clearEqpInfo()

            if (viewBinding.editSelectMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "장비명을 입력하여 주세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage =
                MessageFactoryUtil.remoteEqpInfo(viewBinding.editSelectMachine.text.toString())

            val message =
                MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.REMOTEEQPINFO
                )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val pCount = messageBody.optString("PCOUNT")
                val portname = messageBody.optString("PORTNAME")
                val pmMessage = messageBody.optString("PMMESSAGE")
                mainEqpId = messageBody.optString("MAINEQPID")

                if (pmMessage.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, "PM주기 경고", pmMessage, GetString.BTNOKSTR
                    )
                }
                if (pCount == "N") {
                    OkDialog.show(
                        supportFragmentManager, GetString.ERRMSG,
                        "진행중인 LOT이 있어 진행이 불가합니다.", GetString.BTNOKSTR
                    )
                    return@launch
                }

                val portList = portname.split(",")
                val spinnerAdapter =
                    ArrayAdapter(
                        applicationContext,
                        R.layout.contact_spinner_row_init,
                        portList
                    )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerPort.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )



                //viewBinding.spinnerPort.requestFocus()

                viewBinding.spinnerPort.setSelection(1)
                setPortState()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchIngMachine.id -> {
                    getLotinfo()
                }
                viewBinding.btnClearPort.id -> {
                    initPortState()
                }
                viewBinding.btnSelectWafer.id -> {
                    executeSelectWafer()
                }
                viewBinding.btnStart.id -> {
                    executeStart()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    private fun executeSelectWafer() {
        mainScope.launch {
            val lotId = viewBinding.editLotNo.text.toString()
            val sendMessage = MessageFactoryUtil.slotInfo(lotId, DeviceInfo.FACILITY)

            val message = MessageSender.send(
                supportFragmentManager,
                sendMessage,
                MessageName.SLOTINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val enableWaferList = messageBody.optString("WAFERLIST")

                if (enableWaferList.isNotEmpty()) {
                    var nextIntent =
                        Intent(applicationContext, WaferselectAIT_Activity::class.java)
                    val cnt = enableWaferList.split(",").count().toString()

                    nextIntent.putExtra("LOTID", viewBinding.editLotNo.text.toString())
                    nextIntent.putExtra("EXISTWAFERLIST", enableWaferList)
                    nextIntent.putExtra("FIXEDCOUNT", cnt)
                    nextIntent.putExtra("CATEGORY", "ETC")
                    //dlg.m_SelectedMachine = m_sComment;

                    activityWaferSelectLauncher.launch(nextIntent)
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private val activityWaferSelectLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                it.data?.let { intent ->
                    var selectedWaferList = intent.getStringExtra("SELECTEDWAFERLIST")

                    if (selectedWaferList != null) {
                        viewBinding.txtWafer.setText(selectedWaferList)
                        viewBinding.txtWaferCount.setText(
                            selectedWaferList.split(",").count().toString())
                    }
                }
            }
        }

    private fun initPortState() {
        mainScope.launch {
            val portName = viewBinding.spinnerPort.selectedItem.toString()
            val sendMessage = MessageFactoryUtil.machinePortClean(searchSuperEqpId, portName)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.SLOTINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager, "DOOR OPEN",
                    "해당 PORT 초기화 명령을 전송하였습니다.", GetString.BTNOKSTR
                )

                //setPortStatus()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun getLotinfo() {
        mainScope.launch {
            //clearEqpInfo()

            val sendMessage =
                MessageFactoryUtil.AitLotInfo(viewBinding.editLotNo.text.toString())

            val message =
                MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.AITLOTINFO
                )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                try {
                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                    val ItemList =
                        ResponseDataToJsonUtil.getMessageBodyList(result, "ITEMS")
                    val tempLotHoldState = ItemList.getJSONObject(0).optString("LOTHOLDSTATE")
                    val tempProcessState = ItemList.getJSONObject(0).optString("LOTPROCESSSTATE")

                    if (tempProcessState == "RUN") {
                        val runMessage = """
                        현재 RUN 중인 LOT입니다.
                    """.trimIndent()

                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            runMessage, GetString.BTNOKSTR
                        )

                        viewBinding.editLotNo.setText("")
                        viewBinding.editLotNo.requestFocus()
                        viewBinding.editLotNo.selectAll()

                        return@launch
                    }

                    if (tempLotHoldState == "OnHold") {
                        val holdMessage = """
                        현재 HOLD 중인 LOT입니다.
                    """.trimIndent()

                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            holdMessage, GetString.BTNOKSTR
                        )

                        return@launch
                    }


                    val tempJobCode = ItemList.getJSONObject(0).optString("JOBCODE")
                    val tempQuantity = ItemList.getJSONObject(0).optString("PRODUCTQUANTITY")
                    val tempOperDesc = ItemList.getJSONObject(0).optString("OPERDESC")
                    val tempOperCode = ItemList.getJSONObject(0).optString("OPERCODE")
                    val tempProduct = ItemList.getJSONObject(0).optString("PRODUCTSPECNAME")
                    val temprcp = ItemList.getJSONObject(0).optString("RECIPE")
                    val tempeqp = ItemList.getJSONObject(0).optString("MACHINENAME")
                    val tempfab = ItemList.getJSONObject(0).optString("FAB")
                    val tempeng = ItemList.getJSONObject(0).optString("ENGINEERNAME")

                    getRecipeinfo(temprcp)

                    viewBinding.editProductMachine.setText(tempeqp)
                    viewBinding.editRecipe.setText(temprcp)


                    viewBinding.txtJobCode.setText(tempJobCode)
                    viewBinding.txtQty.setText(tempQuantity)
                    viewBinding.txtCurrentOperation.setText(tempOperDesc)
                    viewBinding.txtProduct.setText(tempProduct)
                    viewBinding.txtFacility.setText(tempfab)
                    viewBinding.txtEngineer.setText(tempeng)


                    return@launch
                }
                finally {
                    return@launch
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }


    }

    private fun getRecipeinfo(RecipeID:String) {
        mainScope.launch {
            //clearEqpInfo()

            val sendMessage =
                MessageFactoryUtil.AITRecipeInfo(RecipeID)

            val message =
                MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.AITRECIPEINFO
                )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                try {

                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                    val ItemList =
                        ResponseDataToJsonUtil.getMessageBodyList(result, "ITEMS")

                    val tempPATH = ItemList.getJSONObject(0).optString("RCP_PATH")
                    viewBinding.editRecipeFolder.setText(tempPATH)
                }
                finally {

                }
                return@launch
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }


    private fun getWfInfo() {
        mainScope.launch {
            clearEqpInfo()

            val sendMessage =
                MessageFactoryUtil.AitLotInfo(viewBinding.editLotNo.text.toString())

            val message =
                MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.AITLOTINFO
                )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {

                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val tempLotState = messageBody.optString("LOTSTATE")
                val tempLotHoldState = messageBody.optString("LOTHOLDSTATE")
                val tempProcessState = messageBody.optString("LOTPROCESSSTATE")

                if (tempProcessState == "RUN") {
                    val runMessage = """
                        현재 RUN 중인 LOT입니다.
                    """.trimIndent()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        runMessage, GetString.BTNOKSTR
                    )

                    viewBinding.editLotNo.setText("")
                    viewBinding.editLotNo.requestFocus()
                    viewBinding.editLotNo.selectAll()

                    return@launch
                }

                if (tempLotHoldState == "OnHold") {
                    val holdMessage = """
                        현재 HOLD 중인 LOT입니다.
                    """.trimIndent()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        holdMessage, GetString.BTNOKSTR
                    )

                    viewBinding.editLotNo.setText("")
                    viewBinding.editLotNo.requestFocus()
                    viewBinding.editLotNo.selectAll()

                    return@launch
                }

//                if (tempLotState != "Released") {
//                    val stateMessage = """
//                        Lot($lotId)이 Released 상태가 아니면
//                        BACKUP BAY를 변경할수 없습니다.
//                    """.trimIndent()
//
//                    OkDialog.show(
//                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
//                        stateMessage, GetString.BTNOKSTR
//                    )
//
//                    lotEditText.setText("")
//                    lotEditText.requestFocus()
//                    lotEditText.selectAll()
//
//                    return@launch
//                }

                val tempJobCode = messageBody.optString("JOBCODE")
                val tempQuantity = messageBody.optString("PRODUCTQUANTITY")
                val tempOperDesc = messageBody.optString("OPERATIONDESCRIPTION")
                val tempOperCode = messageBody.optString("PROCESSOPERATIONNAME")
                val tempProduct = messageBody.optString("PRODUCTSPECNAME")
                val temprcp = messageBody.optString("RCP")
                val tempeqp = messageBody.optString("EQP")
                val tempfab = messageBody.optString("FACTORYNAME")

                viewBinding.editProductMachine.setText(tempeqp)
                viewBinding.editRecipe.setText(temprcp)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun executeStart()    {
        mainScope.launch {

            startSlot = ""
            startProdeqp = ""
            startMid = ""
            startRecipe = ""
            startLot= ""
            startPara= ""
            startThick = ""
            startTable = ""

            startEqp = viewBinding.editSelectMachine.text.toString()
            startPort = viewBinding.spinnerPort.selectedItem.toString()
            startRecipe = viewBinding.editRecipeFolder.text.toString() + "|" + viewBinding.editRecipe.text.toString()
            startLot = viewBinding.editLotNo.text.toString()
            startMid = viewBinding.editProductMachine.text.toString()
            startSlot = viewBinding.txtWafer.text.toString()



            val sendMessage =
                MessageFactoryUtil.AitRemoteStart(
                    startEqp,
                    startRecipe,
                    startLot,
                    startPort,
                    startMid,
                    startSlot,
                    DeviceInfo.OPERATOR_ID,
                    DeviceInfo.OPERATOR_NAME
                )

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.AITREMOTESTART
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul){
                OkDialog.show(
                    supportFragmentManager, "전송 성공",
                    "성공적으로 START 명령을 전송하였습니다.", GetString.BTNOKSTR
                )
                viewBinding.txtPortStatus.setBackgroundColor(getColor(R.color.portPending))
                viewBinding.txtPortStatus.setText("PENDING")
                viewBinding.txtPortStatus.setTextColor(Color.BLACK)
                viewBinding.editLotNo.setText("")
            }
            else{
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }


        }

    }

}