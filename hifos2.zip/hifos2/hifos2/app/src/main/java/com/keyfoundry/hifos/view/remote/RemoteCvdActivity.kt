package com.keyfoundry.hifos.view.remote

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Vibrator
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.isVisible
import androidx.viewbinding.ViewBinding
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityRemoteCvdBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.RemoteRecipeDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDailogAlram
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.comment.CommentListActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RemoteCvdActivity : HFActivity() {
    companion object {
        private const val TAG = "RemoteCvdActivity"
    }

    private lateinit var viewBinding: ActivityRemoteCvdBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var lsChangeRecipe = false
    private var lsChangeEqpGroup = false
    private var isMainEqp = ""
    private var searchArea = ""
    private var searchOpType = ""
    private var searchOperation = ""
    private var searchSubOperation = ""
    private var searchProcessStep = ""
    private var searchOperSeq = ""
    private var searchSuperEqpId = ""
    private var searchEqpArea = ""
    private var searchEqpType = ""

    private var isPRECEDE = ""
    private var isQTIMEHOLD = ""

    private var exposure = false
    private var scrubber = ""

    private var rfReadCount = 0//[Addition] Jul 24, 2005. I. H. Lee

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityRemoteCvdBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.txtMachine.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtEngineer.movementMethod = ScrollingMovementMethod.getInstance()

        //소문자 -> 대문자
        viewBinding.editSelectMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        initDisable()

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()
            viewBinding.txtLotNo.text = lotId
            //---[Modification] Mar 26, 2007. by I. H. Lee (Begin)
            searchData(lotId)
            //---[Modification] Mar 26, 2007. by I. H. Lee (End)
            //if(m_sSelEquipID != "")
            //{
            //	GetMachineInfo();
            //}
        }

        viewBinding.editSelectMachine.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                val check = BarcodeStyle(this).eqpId(viewBinding.editSelectMachine)

                if (check) {
                    mainScope.launch {
                        secondCheck(viewBinding.editSelectMachine.text.toString())
                        getMachineInfo(viewBinding.editSelectMachine.text.toString())
                    }
                }
            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).eqpId(viewBinding.editSelectMachine)

                    if (check) {
                        mainScope.launch {
                            secondCheck(viewBinding.editSelectMachine.text.toString())
                            getMachineInfo(viewBinding.editSelectMachine.text.toString())
                        }
                    }
                }
            }

            true
        }

        viewBinding.btnEqpCancel.setOnClickListener(onSingleClickListener)
        viewBinding.btnClearPort.setOnClickListener(onSingleClickListener)
        viewBinding.btnOpen.setOnClickListener(onSingleClickListener)
        viewBinding.btnReadComment.setOnClickListener(onSingleClickListener)
        viewBinding.btnRcp.setOnClickListener(onSingleClickListener)
        viewBinding.btnStart.setOnClickListener(onSingleClickListener)
        viewBinding.btnRestart.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)

        viewBinding.spinnerPort.onItemSelectedListener = itemSelectedListener
        viewBinding.spinnerRecipe.onItemSelectedListener = itemSelectedListener

        viewBinding.layoutSP.visibility = View.GONE
        viewBinding.checkboxSPPT.setOnCheckedChangeListener { compoundButton, b ->
            if(b)
            {
                viewBinding.checkboxSPP.isChecked = false;
                viewBinding.checkboxSPT.isChecked = false;

                viewBinding.checkboxSPP.setTextColor(Color.WHITE);
                viewBinding.checkboxSPT.setTextColor(Color.WHITE);
                viewBinding.checkboxSPPT.setTextColor(Color.GREEN);
            }
            else
                viewBinding.checkboxSPPT.setTextColor(Color.WHITE);
        }
        viewBinding.checkboxSPP.setOnCheckedChangeListener { compoundButton, b ->
            if(b)
            {
                viewBinding.checkboxSPPT.isChecked = false;
                viewBinding.checkboxSPT.isChecked = false;

                viewBinding.checkboxSPP.setTextColor(Color.GREEN);
                viewBinding.checkboxSPT.setTextColor(Color.WHITE);
                viewBinding.checkboxSPPT.setTextColor(Color.WHITE);
            }
            else
                viewBinding.checkboxSPP.setTextColor(Color.WHITE);
        }
        viewBinding.checkboxSPT.setOnCheckedChangeListener { compoundButton, b ->
            if(b)
            {
                viewBinding.checkboxSPP.isChecked = false;
                viewBinding.checkboxSPPT.isChecked = false;

                viewBinding.checkboxSPP.setTextColor(Color.WHITE);
                viewBinding.checkboxSPT.setTextColor(Color.GREEN);
                viewBinding.checkboxSPPT.setTextColor(Color.WHITE);
            }
            else
                viewBinding.checkboxSPT.setTextColor(Color.WHITE);
        }

        viewBinding.spinnerTYPE.adapter =null
        val spinnerAdapter = ArrayAdapter(
            applicationContext, R.layout.contact_spinner_row_init,
            "선행;주기;추검".split(";")
        )
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerTYPE.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
        viewBinding.spinnerTYPE.setSelection(1, false)
    }

    private fun initDisable() {
        viewBinding.btnEqpCancel.isEnabled = false
        viewBinding.btnReadComment.isEnabled = false
        viewBinding.btnOpen.isEnabled = false
//        viewBinding.spinnerRecipe.isEnabled = false
        viewBinding.btnClearPort.isEnabled = false
        viewBinding.btnRestart.isEnabled = false
        viewBinding.btnStart.isEnabled = false

        viewBinding.layoutQTime.visibility = View.VISIBLE
        viewBinding.btnRcp.visibility = View.GONE

        rfReadCount = 0
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnEqpCancel.id -> {
                    executeEqpCancel()
                }
                viewBinding.btnClearPort.id -> {
                    executeClearPort()
                }
                viewBinding.btnOpen.id -> {
                    executeOpen()
                }
                viewBinding.btnReadComment.id -> {
                    executeCommentList()
                }
                viewBinding.btnRcp.id -> {
                    executeCommRcp()
                }
                viewBinding.btnStart.id -> {
                    executeStart()
                }
                viewBinding.btnRestart.id -> {
                    executeReStart()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    private fun executeEqpCancel() {
        viewBinding.editSelectMachine.setText("")
        viewBinding.btnEqpCancel.isEnabled = false
        viewBinding.btnClearPort.isEnabled = false
        viewBinding.btnRestart.isEnabled = false
        viewBinding.btnStart.isEnabled = false
    }

    private fun executeClearPort() {
        mainScope.launch {
            if (viewBinding.spinnerPort.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Port를 먼저 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val portName = viewBinding.spinnerPort.selectedItem.toString()

            val checkCode = OkCancelDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                "PORT [$portName]을(를) 초기화 하고 [IDLE]상태로 바꾸시겠습니까?",
                GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
            )

            if (checkCode == OkCancelDialog.RETURN_CODE_CANCEL)
                return@launch

            val sendMessage =
                MessageFactoryUtil.machinePortClean(searchSuperEqpId, portName)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MACHINEPORTCLEAR
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager, "PORT 초기화",
                    "해당 PORT 초기화 명령을 전송하였습니다.", GetString.BTNOKSTR
                )

                setPortState()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun executeOpen() {
        mainScope.launch {
            if (viewBinding.spinnerPort.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Port를 먼저 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val portName = viewBinding.spinnerPort.selectedItem.toString()

            val checkCode = OkCancelDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                "PORT [$portName]의 DOOR를 OPEN 하시겠습니까?",
                GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
            )

            if (checkCode == OkCancelDialog.RETURN_CODE_CANCEL)
                return@launch

            val sendMessage = MessageFactoryUtil.doorOpen(
                searchSuperEqpId, portName, searchEqpArea, searchEqpType
            )
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.DOOROPEN
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager, "DOOR OPEN",
                    "DOOR OPEN 명령을 전송하였습니다.", GetString.BTNOKSTR
                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun executeCommentList() {
        val nextIntent = Intent(this, CommentListActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
        nextIntent.putExtra("OPERATION", searchOperation)
        nextIntent.putExtra("SUBOPERATION", searchSubOperation)
        nextIntent.putExtra("PROCESSSTEP", searchProcessStep)
        nextIntent.putExtra("OPERSEQUENCE", searchOperSeq)
        startActivity(nextIntent)
    }

    private fun executeCommRcp() {
        val nextIntent = Intent(this, RemoteEtchCommRcpActivity::class.java)

        val eqpId = if (searchSuperEqpId.isEmpty())
            viewBinding.editSelectMachine.text.toString()
        else
            searchSuperEqpId

        nextIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
        nextIntent.putExtra("EQPID", eqpId)
        nextIntent.putExtra("RECIPE", viewBinding.spinnerRecipe.selectedItem.toString())
        nextIntent.putExtra("OPERID", searchOperation)
        nextIntent.putExtra("OPERDESC", searchProcessStep)
        startActivity(nextIntent)
    }

    private fun executeStart() {
        mainScope.launch {
            if (viewBinding.editSelectMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행장비를 입력하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.spinnerPort.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Port를 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.spinnerRecipe.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Rcp를 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val portName = viewBinding.spinnerPort.selectedItem.toString()
            val recipeName = viewBinding.spinnerRecipe.selectedItem.toString()

            if (searchEqpType == "UNITY-II" && recipeName.lastIndexOf("+") > -1) {
                val value = recipeName.substring(recipeName.lastIndexOf("+") + 1, recipeName.length)

                if (portName == "1" && value.lastIndexOf("A") < 0) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "Port정보와 Chamber Recipe가 불일치합니다.", GetString.BTNOKSTR
                    )
                    return@launch
                } else if (portName == "2" && value.lastIndexOf("B") < 0) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "Port정보와 Chamber Recipe가 불일치합니다.", GetString.BTNOKSTR
                    )
                    return@launch
                }
            }

            if (!checkComment())
                return@launch

            //레시피 확인 Dialog
            val recipeIntent = Intent(this@RemoteCvdActivity, RemoteRecipeDialog::class.java)
            recipeIntent.putExtra(RemoteRecipeDialog.RECIPE_LIST, recipeName)
            recipeIntent.putExtra(RemoteRecipeDialog.LOT_NO, viewBinding.txtLotNo.text.toString())
            startLauncher.launch(recipeIntent)
        }
    }

    private fun executeReStart() {
        mainScope.launch {
            if (viewBinding.editSelectMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행장비를 입력하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.spinnerPort.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Port를 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.spinnerRecipe.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Rcp를 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val portName = viewBinding.spinnerPort.selectedItem.toString()
            val recipeName = viewBinding.spinnerRecipe.selectedItem.toString()

            if (searchEqpType == "UNITY-II" && recipeName.lastIndexOf("+") > -1) {
                val value = recipeName.substring(recipeName.lastIndexOf("+") + 1, recipeName.length)

                if (portName == "1" && value.lastIndexOf("A") < 0) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "Port정보와 Chamber Recipe가 불일치합니다.", GetString.BTNOKSTR
                    )
                    return@launch
                } else if (portName == "2" && value.lastIndexOf("B") < 0) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "Port정보와 Chamber Recipe가 불일치합니다.", GetString.BTNOKSTR
                    )
                    return@launch
                }
            }

            if (!checkComment())
                return@launch

            //레시피 확인 Dialog
            val recipeIntent = Intent(this@RemoteCvdActivity, RemoteRecipeDialog::class.java)
            recipeIntent.putExtra(RemoteRecipeDialog.RECIPE_LIST, recipeName)
            reStartLauncher.launch(recipeIntent)
        }
    }

    private val startLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                remoteStart()
            }
        }

    private val reStartLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                remoteReStart()
            }
        }

    private suspend fun checkInterLock(): Boolean {
        val check: Boolean

        val lotId = viewBinding.txtLotNo.text.toString()
        val recipe = viewBinding.spinnerRecipe.selectedItem.toString()

        val sendMessage = MessageFactoryUtil.remoteINTLKCheck(
            lotId, searchOperation, searchSubOperation, isMainEqp, recipe
        )
        val message = MessageSender.send(
            supportFragmentManager, sendMessage, MessageName.REMOTEINTLKCHECK
        )
        val isSuccessFul = message.isSuccessFul
        val result = message.result
        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val popUp = messageBody.optString("POPUP")

            if (popUp.isNotEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
                    popUp, GetString.BTNOKSTR
                )
            }

            check = true
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            check = if (errorMessage != MessageSender.ERRORMSG_MSGBODY) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
                false
            } else {
                true
            }
        }

        return check
    }

    private fun remoteStart() {
        mainScope.launch {
            if (!checkInterLock())
                return@launch

            val machineName = searchSuperEqpId
            val machineName2 = viewBinding.editSelectMachine.text.toString()
            val machineType = searchEqpType
            val areaName = searchEqpArea
            val lotName = viewBinding.txtLotNo.text.toString()
            val portName = viewBinding.spinnerPort.selectedItem.toString()
            val recipeName = viewBinding.spinnerRecipe.selectedItem.toString()
            val productQty = viewBinding.txtQty.text.toString()
            val operation = "$searchOperation-$searchSubOperation"
            val jobCode = viewBinding.txtJobCode.text.toString()
            val productName = viewBinding.txtProduct.text.toString()
            val eventUser = DeviceInfo.OPERATOR_ID
            //cMsg.BodyAdd(L"RECIPENAME",SelRecipe);
            var precede_flag =""
            if(viewBinding.layoutSP.visibility == View.VISIBLE )
            {
                if(viewBinding.checkboxSPPT.isChecked())
                    precede_flag = "PT"
                else if(viewBinding.checkboxSPP.isChecked())
                    precede_flag = "P"
                else if(viewBinding.checkboxSPT.isChecked())
                    precede_flag = "T"
                if(precede_flag.isNotEmpty()) {
                    precede_flag += viewBinding.spinnerTYPE.selectedItem.toString()

                    if (isPRECEDE == precede_flag) {
                    } else
                        precede_flag += "USER";
                }
            }

            val sendMessage = MessageFactoryUtil.remoteStart(
                machineName, machineName2, machineType, areaName, lotName, portName,
                recipeName, productQty, operation, jobCode, productName, eventUser, precede_flag, isQTIMEHOLD
            )
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.REMOTESTART
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                setResult(RESULT_OK)
                finish()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDailogAlram.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR, applicationContext,
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                )
            }
        }
    }

    private fun remoteReStart() {
        mainScope.launch {
            val machineName = searchSuperEqpId
            val machineName2 = viewBinding.editSelectMachine.text.toString()
            val machineType = searchEqpType
            val areaName = searchEqpArea
            val lotName = viewBinding.txtLotNo.text.toString()
            val portName = viewBinding.spinnerPort.selectedItem.toString()
            val recipeName = viewBinding.spinnerRecipe.selectedItem.toString()
            val productQty = viewBinding.txtQty.text.toString()
            val operation = "$searchOperation-$searchSubOperation"
            val jobCode = viewBinding.txtJobCode.text.toString()
            val productName = viewBinding.txtProduct.text.toString()
            val eventUser = DeviceInfo.OPERATOR_ID
            var precede_flag =""
            if(viewBinding.layoutSP.visibility == View.VISIBLE )
            {
                if(viewBinding.checkboxSPPT.isChecked())
                    precede_flag = "PT"
                else if(viewBinding.checkboxSPP.isChecked())
                    precede_flag = "P"
                else if(viewBinding.checkboxSPT.isChecked())
                    precede_flag = "T"
                if(precede_flag.isNotEmpty()) {
                    precede_flag += viewBinding.spinnerTYPE.selectedItem.toString();
                    if (isPRECEDE == precede_flag) {
                    } else
                        precede_flag += "USER";
                }
            }

            val sendMessage = MessageFactoryUtil.remoteReStart(
                machineName, machineName2, machineType, areaName, lotName, portName,
                recipeName, productQty, operation, jobCode, productName, eventUser, precede_flag
            )
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.REMOTERESTART
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                setResult(RESULT_OK)
                finish()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDailogAlram.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR, applicationContext,
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                )
            }
        }
    }

    private suspend fun checkComment(): Boolean {
        val lotId = viewBinding.txtLotNo.text.toString()

        val sendMessage = MessageFactoryUtil.lotInfo("MVIN", lotId, DeviceInfo.FACILITY)
        val message = MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
        val isSuccessFul = message.isSuccessFul
        val result = message.result
        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val nwCommentQty = messageBody.optString("NWCOMMENTQTY")

            return if (nwCommentQty.isNotEmpty() && nwCommentQty.toInt() > 0) {
                val commentMsg = """
                            |읽지 않은 작업성 COMMENT가 [$nwCommentQty]가 있습니다.
                            |읽은후 진행하세요.
                        """.trimMargin()
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    commentMsg, GetString.BTNOKSTR
                )

                false
            } else {
                true
            }
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )

            return false
        }
    }

    private fun secondCheck(eqpId: String) {
        var checkCount = 0
        scrubber = ""

        for (count in eqpId.indices) {
            if (eqpId[count] == '-')
                checkCount++
        }

        if (checkCount == 2 && eqpId != "RD-51-05" && eqpId != "R-6-1" && eqpId != "R-67-1") {
            scrubber = eqpId.substring(eqpId.length - 1, eqpId.length)
            val tempEqpId = eqpId.substring(0, eqpId.length - 2)
            viewBinding.editSelectMachine.setText(tempEqpId)
        }
    }

    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerPort.id -> {
                        setPortState()
                    }
                    viewBinding.spinnerRecipe.id -> {
                        memorizationRecipe()
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private fun setPortState() {
        mainScope.launch {
            clearPortState()

            if (viewBinding.spinnerPort.selectedItem == null)
                return@launch

            viewBinding.btnClearPort.isEnabled = false

            val portId = viewBinding.spinnerPort.selectedItem.toString()
            val lotId = viewBinding.txtLotNo.text.toString()

            var recipe = ""
            if (viewBinding.spinnerRecipe.selectedItem != null)
                recipe = viewBinding.spinnerRecipe.selectedItem.toString()

            val sendMessage =
                MessageFactoryUtil.machinePortStatus(searchSuperEqpId, portId, lotId, recipe)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MACHINEPORTSTATUS
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val chma_ret = messageBody.optString("CHMA_RET")
                val chmb_ret = messageBody.optString("CHMB_RET")
                val portState = messageBody.optString("PORTSTATENAME")
                val portLotName = messageBody.optString("PORTLOTNAME")
                val ackMsg = messageBody.optString("ACKMSG")

                viewBinding.txtPortState.text = portState
                setPortColor(portState)

                var unity = ""

                if (chma_ret.isNotEmpty() && chmb_ret.isEmpty())
                    unity = chma_ret
                else if (chma_ret.isEmpty() && chmb_ret.isNotEmpty())
                    unity = chmb_ret
                else if (chma_ret.isNotEmpty() && chmb_ret.isNotEmpty())
                    unity += chma_ret + "\n" + chmb_ret

                if (unity.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                        "이전 진행 이력\n\n $unity", GetString.BTNOKSTR
                    )
                }


                if (searchEqpType == "SCRUBBER" && ( searchSuperEqpId == "5C09-06" || searchSuperEqpId =="5C09-03") ) {
                    viewBinding.btnClearPort.isEnabled = true
                    viewBinding.btnStart.isEnabled = true
                    return@launch
                }

                if (portState == "RUN" || portState == "PENDING" || portState == "RESERVED") {
                    val portMsg = """
                        |해당 PORT가 진행중입니다.
                        |장비 및 진행할 LOT을 다시 확인 바랍니다.
                    """.trimMargin()
                    OkDialog.show(supportFragmentManager, "장비 MESSAGE", portMsg, GetString.BTNOKSTR)
                    viewBinding.btnClearPort.isEnabled = true
                    viewBinding.btnStart.isEnabled = false

                    if (viewBinding.txtLotNo.text.toString() != portLotName)
                        viewBinding.btnClearPort.isEnabled = true
                    else if (portState == "RESERVED")
                        viewBinding.btnRestart.isEnabled = true

                    if (ackMsg.isNotEmpty()) {
                        OkDialog.show(
                            supportFragmentManager, "PORT WORNING", ackMsg, GetString.BTNOKSTR
                        )
                    }
                } else if (portState.isEmpty()) {
                    val portMsg = """
                        |PORT 정보를 가져올 수 없습니다.   
                        |잠시후 다시 확인 바랍니다.
                    """.trimMargin()
                    OkDialog.show(supportFragmentManager, "장비 MESSAGE", portMsg, GetString.BTNOKSTR)

                    viewBinding.btnStart.isEnabled = false
                    viewBinding.btnRestart.isEnabled = false
                    viewBinding.btnClearPort.isEnabled = false
                }
                else if (searchEqpType == "P5000-T" || searchEqpType == "P5000-N" || searchEqpType == "P5000-W") {
                    when (portState) {
                        "COMPLETE" -> {
                            val portMsg = """
                                |이전 완료 LOT이 Unload 되지 않았습니다.  
                                |LOT을 Unload 후 진행할 LOT을 LOADING 바랍니다.
                            """.trimMargin()
                            OkDialog.show(
                                supportFragmentManager, "장비 MESSAGE", portMsg, GetString.BTNOKSTR
                            )

                            viewBinding.btnClearPort.isEnabled = true
                            viewBinding.btnStart.isEnabled = false
                        }
                        else -> {
                            viewBinding.btnStart.isEnabled = true
                            viewBinding.btnClearPort.isEnabled = false
                            viewBinding.btnRestart.isEnabled = false
                        }
                    }
                }
                else {
                    viewBinding.btnClearPort.isEnabled = searchEqpType == "AG_RTP"

                    viewBinding.btnStart.isEnabled = true
                    viewBinding.btnRestart.isEnabled = false
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setPortColor(portState: String) {
        when (portState) {
            "RUN" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.BLUE)
                viewBinding.txtPortState.setTextColor(Color.WHITE)
            }
            "PENDING" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portPending))
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "READY" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.GREEN)
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "RESERVED" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.YELLOW)
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "COMPLETE" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portCompleted))
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "IDLE" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portIdle))
                viewBinding.txtPortState.setTextColor(Color.WHITE)
            }
        }
    }

    private fun memorizationRecipe() {
        mainScope.launch {
            if (viewBinding.spinnerRecipe.selectedItem == null)
                return@launch

            if (searchSuperEqpId.isEmpty())
                return@launch

            val recipe = viewBinding.spinnerRecipe.selectedItem.toString()
            val lotId = viewBinding.txtLotNo.text.toString()

            var portId = ""
            if (viewBinding.spinnerPort.selectedItem != null)
                portId = viewBinding.spinnerPort.selectedItem.toString()

            // 20210907 추가
            val chEqpId = viewBinding.editSelectMachine.text.toString()

            val sendMessage =
                MessageFactoryUtil.memorization(searchSuperEqpId, recipe, lotId, portId, chEqpId, DeviceInfo.OPERATOR_ID,searchEqpType)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MEMORIZATION)
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                viewBinding.spinnerPort.isEnabled = true

                val popUp = messageBody.optString("POPUP")
                val comRcpChk = messageBody.optString("ETCH_COMMRCP")
                val qTime = messageBody.optString("Q-TIME")
                val precede_flag = messageBody.optString("PRECEDE_FLAG")
                val precede_flag_ETCH = messageBody.optString("PRECEDE_FLAG_ETCH")
                val qTimeFlag = messageBody.optString("QTIME_FLAG")
                val qTimeFlag_W = messageBody.optString("QTIME_FLAG_W")

                if(precede_flag.isNotEmpty())
                {
                    viewBinding.checkboxSPPT.isChecked = false
                    viewBinding.checkboxSPP.isChecked = false
                    viewBinding.checkboxSPT.isChecked = false
                    viewBinding.layoutSP.visibility = View.VISIBLE
                    if( precede_flag == "PT선행" )
                        viewBinding.checkboxSPPT.isChecked = true;
                    else if( precede_flag == "P선행" )
                        viewBinding.checkboxSPP.isChecked = true;
                    else if( precede_flag == "T선행" )
                        viewBinding.checkboxSPT.isChecked = true;
                    else if ( precede_flag == "선행" )    // 선행 주기로 변경
                        viewBinding.spinnerTYPE.setSelection(2, false)

                    isPRECEDE = precede_flag;
                }
                else if(precede_flag_ETCH.isNotEmpty())
                {
                    viewBinding.spinnerTYPE.adapter =null
                    val spinnerAdapter = ArrayAdapter(
                        applicationContext, R.layout.contact_spinner_row_init,
                        "SAMPLE;1st MAIN;추검".split(";")
                    )
                    spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                    viewBinding.spinnerTYPE.adapter = InitSpinnerAdapter(
                        spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                    )
                    viewBinding.spinnerTYPE.setSelection(1, false)

                    viewBinding.checkboxSPPT.isChecked = false
                    viewBinding.checkboxSPP.isChecked = false
                    viewBinding.checkboxSPT.isChecked = false
                    viewBinding.layoutSP.visibility = View.VISIBLE

                    viewBinding.checkboxSPPT.text = "C+P";
                    viewBinding.checkboxSPP.text = "CD";
                    viewBinding.checkboxSPT.text = "PQC";

                    isPRECEDE = precede_flag_ETCH;
                }
                else
                    viewBinding.layoutSP.visibility = View.GONE

                if (popUp.isNotEmpty())
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
                        popUp, GetString.BTNOKSTR
                    )

                if (comRcpChk == "Y")
                    viewBinding.btnRcp.visibility = View.VISIBLE
                else
                    viewBinding.btnRcp.visibility = View.GONE

                if (qTime.isNotEmpty()) {
                    viewBinding.txtQTime.text = qTime
                    viewBinding.layoutQTime.visibility = View.VISIBLE
                } else {
                    viewBinding.txtQTime.text = ""
                    viewBinding.layoutQTime.visibility = View.GONE
                }

                if(qTimeFlag.isNotEmpty())
                {   // 26.09.23 q-time over 시 팝업 문구 후 처리
                    val continueValue = OkCancelDialog.show(
                        supportFragmentManager, "Q-Time Over", "Q-Time 대상 Lot 입니다, 진행 하시겠습니까?",
                        GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
                    )

                    if (continueValue == OkCancelDialog.RETURN_CODE_CANCEL) {
                        viewBinding.spinnerPort.isEnabled = false
                        viewBinding.btnStart.isEnabled = false
                    }
                    else
                        isQTIMEHOLD = "Y";
                }
                else if(qTimeFlag_W.isNotEmpty())
                {
                    val continueValue = OkCancelDialog.show(
                        supportFragmentManager, "Q-Time 근접", "Q-Time 2hr 이내 근접 Lot 입니다, 진행 하시겠습니까?",
                        GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
                    )

                    if (continueValue == OkCancelDialog.RETURN_CODE_CANCEL) {
                        viewBinding.spinnerPort.isEnabled = false
                        viewBinding.btnStart.isEnabled = false
                    }
                    else
                        isQTIMEHOLD = "Y";
                }
                else
                    isQTIMEHOLD = "";

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)

                if (errorMessage == MessageSender.ERRORMSG_MSGBODY) {
                    viewBinding.btnRcp.visibility = View.GONE
                    viewBinding.layoutQTime.visibility = View.GONE
                } else {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR
                    )
                    viewBinding.spinnerPort.isEnabled = false
                    viewBinding.btnStart.isEnabled = false
                }
            }
        }
    }

    private fun clearData() {
        lsChangeRecipe = false
        lsChangeEqpGroup = false

        viewBinding.txtCommentCount.text = ""
        viewBinding.txtMachine.text = ""
        viewBinding.txtJobCode.text = ""
        viewBinding.txtProduct.text = ""
        viewBinding.txtCurrentOperation.text = ""
        viewBinding.txtQty.text = ""
        viewBinding.txtFacility.text = ""
        viewBinding.txtCustomer.text = ""
        viewBinding.txtSaleType.text = ""
        viewBinding.txtEngineer.text = ""
        viewBinding.txtPacking.text = ""
        viewBinding.txtGoodChips.text = ""

        searchOperation = ""
        searchSubOperation = ""
        searchProcessStep = ""
        searchOperSeq = ""
        isQTIMEHOLD = "";

        viewBinding.spinnerRecipe.adapter = null
    }

    //---[Addition] Mar 26, 2007. by I. H. Lee (Begin)
    // RF Module을 사용하지 않을 경우 Lot, Machine에 대한 정보를 얻기위해 사용한다.
    private fun searchData(lotId: String) {
        mainScope.launch {
            clearData()

            val sendMessage = MessageFactoryUtil.lotInfo("MVIN", lotId, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val product = messageBody.optString("PRODUCT")
                val facility = messageBody.optString("FACILITY")
                var operation = messageBody.optString("OPERATION")
                val customer = messageBody.optString("CUSTOMER")
                val category = messageBody.optString("CATEGORY")
                val engineer = messageBody.optString("ENGINEER")
                val packing = messageBody.optString("PACKING")
                val qty = messageBody.optString("QUANTITY")
                val goodChips = messageBody.optString("GOODCHIPS")
                val recipe = messageBody.optString("RECIPE")
                val changeRecipe = messageBody.optString("CHANGERECIPE")
                val eqpGroup = messageBody.optString("EQPGROUP")
                val changeEqpGroup = messageBody.optString("CHANGEEQPGROUP")
                val commentQty = messageBody.optString("COMMENTQTY")
                val nwCommentQty = messageBody.optString("NWCOMMENTQTY")
                val batchId = messageBody.optString("BATCHID")
                val area = messageBody.optString("AREA")
                val workedEqpId = messageBody.optString("WORKEDEQPID")
                val workedRecipe = messageBody.optString("WORKEDRECIPE")
                val workedReticle = messageBody.optString("WORKEDRETICLE")
                val jobCode = messageBody.optString("JOBCODE")
                var processStep = messageBody.optString("PROCESSSTEP")
                val subOperation = messageBody.optString("SUBOPERATION")
                val opType = messageBody.optString("OPTYPE")
                val status = messageBody.optString("STATUS")
                val state = messageBody.optString("STATE")
                val holdStatus = messageBody.optString("HOLDSTATUS")
                val operSeq = messageBody.optString("OPERSEQUENCE")
                val etcMsg = messageBody.optString("ETCMSG")
                val machineName = messageBody.optString("MACHINENAME")
                val portName = messageBody.optString("PORTNAME")
                //LOT정보 조회시 예약 정보 확인
                val machineRecipeName = messageBody.optString("MACHINERECIPENAME")
                val lotResUser = messageBody.optString("LOTRESUSER")
                val skipAllowFlag =
                    messageBody.optString("SKIPALLOWFLAG")//---[Addition] Nov 22, 2007. by I. H. Lee

                if (operation == "10000") {
                    operation = "10005"
                    processStep = "LASER MARKING"
                }

                if (state == "RUN") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 MOVE IN된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.isEnabled = false
                    return@launch
                }

                if (state != "WIP" && operation != "10005") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "$state 상태 입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.isEnabled = false
                    return@launch
                }

                if (holdStatus == "ONHOLD") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "HOLD된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.isEnabled = false
                    return@launch
                }

                if (area == "PHOTO") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "PHOTO 진행 LOT입니다. PHOTO 자동화 기능을 이용해 주세요.", GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.isEnabled = false
                    return@launch
                }

                if (area == "IMP") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "IMP 진행 LOT입니다. IMP 자동화기능을 이용해 주세요.", GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.isEnabled = false
                    return@launch
                }

                //sBatchId.TrimLeft();
                //m_sBatchID = sBatchId;
                viewBinding.txtCommentCount.text = commentQty

                lsChangeRecipe = if (changeRecipe.isNotEmpty())
                    recipe != changeRecipe
                else
                    false

                if (changeEqpGroup.isNotEmpty()) {
                    if (eqpGroup == changeEqpGroup) {
                        viewBinding.txtMachine.text = eqpGroup
                        lsChangeEqpGroup = false
                    } else {
                        viewBinding.txtMachine.text = changeEqpGroup
                        lsChangeEqpGroup = true
                        //GetDlgItem(IDC_EDIT_EQP_ID)->Invalidate();
                    }
                } else {
                    viewBinding.txtMachine.text = eqpGroup
                    lsChangeEqpGroup = false
                    //GetDlgItem(IDC_EDIT_EQP_ID)->Invalidate();
                }

                val currentStep = "$processStep($operation$subOperation)"

                viewBinding.txtJobCode.text = jobCode
                viewBinding.txtProduct.text = product
                viewBinding.txtCurrentOperation.text = currentStep
                viewBinding.txtQty.text = qty
                viewBinding.txtFacility.text = facility
                viewBinding.txtCustomer.text = customer
                viewBinding.txtSaleType.text = category
                viewBinding.txtEngineer.text = engineer
                viewBinding.txtPacking.text = packing
                viewBinding.txtGoodChips.text = goodChips

                searchOperation = operation
                searchSubOperation = subOperation
                searchProcessStep = processStep
                searchOperSeq = operSeq

                viewBinding.btnEqpCancel.isEnabled = viewBinding.editSelectMachine.text.isNotEmpty()
                viewBinding.btnReadComment.isEnabled =
                    commentQty.isNotEmpty() && commentQty.toInt() > 0

                if (etcMsg.isNotEmpty()) {
                    OkDialog.show(supportFragmentManager, "정보", etcMsg, GetString.BTNOKSTR)
                }

                viewBinding.btnStart.isEnabled = true

                if (nwCommentQty.isNotEmpty() && nwCommentQty.toInt() > 0) {
                    val commentMsg = """
                        |읽지 않은 작업성 COMMENT가 [$nwCommentQty]가 있습니다.
                        |읽은후 진행하세요.
                    """.trimMargin()
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                        commentMsg, GetString.BTNOKSTR
                    )
                }

                if (lotResUser.isNotEmpty()) {
                    viewBinding.editSelectMachine.isEnabled = false
                    viewBinding.spinnerRecipe.isEnabled = false
                    viewBinding.spinnerPort.isEnabled = false
                    viewBinding.btnStart.isEnabled = false
                    viewBinding.editSelectMachine.setText(machineName)

                    getMachineInfo(machineName)

                    if (viewBinding.spinnerPort.adapter != null) {
                        val portAdapter = viewBinding.spinnerPort.adapter
                        for (count in 0 until portAdapter.count) {
                            if (portAdapter.getItem(count) == portName) {
                                viewBinding.spinnerPort.setSelection(count, false)
                                break
                            }
                        }
                    }

                    viewBinding.spinnerRecipe.adapter = null
                    val itemList = arrayListOf(machineRecipeName)
                    val spinnerAdapter = ArrayAdapter(
                        applicationContext, R.layout.contact_spinner_row_init, itemList
                    )
                    spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                    viewBinding.spinnerRecipe.adapter = InitSpinnerAdapter(
                        spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                    )

                    viewBinding.spinnerRecipe.setSelection(1, false)
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearPortState() {
        viewBinding.txtPortState.text = ""
        viewBinding.txtPortState.background = null
    }

    private fun clearPortInfo() {
        viewBinding.spinnerPort.adapter = null
        viewBinding.btnClearPort.isEnabled = false
        clearPortState()
    }

    private fun clearMachineInfo() {
        isMainEqp = ""
        searchSuperEqpId = ""
        searchEqpArea = ""
        searchEqpType = ""

        clearPortInfo()
    }

    private suspend fun getMachineInfo(eqpId: String) {
        clearMachineInfo()

        if (searchArea == "PHOTO" && searchOpType == "P" && exposure) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "PHOTO진행 LOT입니다. PHOTO 자동화 기능을 이용해 주세요.", GetString.BTNOKSTR
            )

            return
        }

        var isMachineName = eqpId
        isMainEqp = eqpId

        val valEqpId = viewBinding.txtMachine.text.toString()
        if (searchOpType != "M" && valEqpId != "FAB2" && valEqpId != "FAB5" && valEqpId != "FAB7" && searchArea != "PQC") {
            val sendMessage = MessageFactoryUtil.remoteEqpInfo(isMachineName)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.REMOTEEQPINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val mainEqp = messageBody.optString("MAINEQPID")
                val procEqp = messageBody.optString("PROCEQPID")
                val eqpArea = messageBody.optString("EQPAREA")
                val eqpType = messageBody.optString("EQPTYPE")
                val isDoorOpen = messageBody.optString("ISDOOROPEN")
                //2015.06.01 장비 PM 주기 체크 수정
                val pmMessage = messageBody.optString("PMMESSAGE")
                val portName = messageBody.optString("PORTNAME")
                //2016.12.21 장비 TEST 주기 알림
                val cycleMessage = messageBody.optString("CYCLE_MESSAGE")

                if (pmMessage.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, "PM주기 경고", pmMessage, GetString.BTNOKSTR
                    )
                }

                viewBinding.btnOpen.isEnabled = isDoorOpen == "Y"

                var portList = portName.split(",")
                // START 22.05.19 SEQUEL A Chamber는 PORT 1,2 B Chamber는 Port 3,4
                // 24.03.11 CONCEPT2-SEQUEL 추가
                if( eqpType == "SEQUEL" || eqpType == "CONCEPT2-SEQUEL" ||
                    viewBinding.editSelectMachine.text.toString().startsWith("EC04-1") ||
                    viewBinding.editSelectMachine.text.toString().startsWith("EC04-2")) {
                    if(  viewBinding.editSelectMachine.text.toString().endsWith("A"))
                        portList = ("1,2").split(",")
                    else if(  viewBinding.editSelectMachine.text.toString().endsWith("B"))
                        portList = ("3,4").split(",")
                }

                val spinnerAdapter = ArrayAdapter(
                    applicationContext, R.layout.contact_spinner_row_init, portList
                )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerPort.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                if (scrubber.isNotEmpty()) {
                    if (portList.contains(scrubber)) {
                        val position = portList.indexOf(scrubber)
                        viewBinding.spinnerPort.setSelection(position + 1, false)
                    }
                }

                if (cycleMessage.isNotEmpty()) {
                    val cycleList = cycleMessage.split("/")
                    for (cycle in cycleList) {
                        OkDialog.show(
                            supportFragmentManager, "계측 주기 알림", cycle, GetString.BTNOKSTR
                        )
                    }
                }

                isMainEqp = procEqp
                isMachineName = procEqp
                searchSuperEqpId = mainEqp
                searchEqpArea = eqpArea
                searchEqpType = eqpType

                // start 23.02.21 장비 누적 데이터 표시
                viewBinding.txtCHMA.text = messageBody.optString("PARA1");
                viewBinding.txtCHMA.setBackgroundColor(Color.parseColor("#FFFFFFFF"))
                if(!viewBinding.txtCHMA.text.isEmpty())
                {
                    viewBinding.txtCHMA.isVisible = true
                    viewBinding.lblCHMA.isVisible = true

                    if( messageBody.optString("PARA1_LIMIT").toString() == "OVER" )
                        viewBinding.txtCHMA.setBackgroundColor(Color.parseColor("#FFFF0000"))
                    else if( messageBody.optString("PARA1_LIMIT").toString() == "N90" )
                        viewBinding.txtCHMA.setBackgroundColor(Color.parseColor("#FFFFFF00"))
                    else if( messageBody.optString("PARA1_LIMIT").toString() == "N80" )
                        viewBinding.txtCHMA.setBackgroundColor(Color.parseColor("#FF32CD32"))
                }
                else
                {
                    viewBinding.txtCHMA.isVisible = false
                    viewBinding.lblCHMA.isVisible = false
                }

                viewBinding.txtCHMB.text = messageBody.optString("PARA2");
                viewBinding.txtCHMB.setBackgroundColor(Color.parseColor("#FFFFFFFF"))
                if(!viewBinding.txtCHMB.text.isEmpty())
                {
                    viewBinding.txtCHMB.isVisible = true
                    viewBinding.lblCHMB.isVisible = true

                    if( messageBody.optString("PARA2_LIMIT").toString() == "OVER" )
                        viewBinding.txtCHMB.setBackgroundColor(Color.parseColor("#FFFF0000"))
                    else if( messageBody.optString("PARA2_LIMIT").toString() == "N90" )
                        viewBinding.txtCHMB.setBackgroundColor(Color.parseColor("#FFFFFF00"))
                    else if( messageBody.optString("PARA2_LIMIT").toString() == "N80" )
                        viewBinding.txtCHMB.setBackgroundColor(Color.parseColor("#FF32CD32"))
                }
                else
                {
                    viewBinding.txtCHMB.isVisible = false
                    viewBinding.lblCHMB.isVisible = false
                }

                viewBinding.txtCHMC.text = messageBody.optString("PARA3");
                viewBinding.txtCHMC.setBackgroundColor(Color.parseColor("#FFFFFFFF"))
                if(!viewBinding.txtCHMC.text.isEmpty())
                {
                    viewBinding.txtCHMC.isVisible = true
                    viewBinding.lblCHMC.isVisible = true

                    if( messageBody.optString("PARA3_LIMIT").toString() == "OVER" )
                        viewBinding.txtCHMC.setBackgroundColor(Color.parseColor("#FFFF0000"))
                    else if( messageBody.optString("PARA3_LIMIT").toString() == "N90" )
                        viewBinding.txtCHMC.setBackgroundColor(Color.parseColor("#FFFFFF00"))
                    else if( messageBody.optString("PARA3_LIMIT").toString() == "N80" )
                        viewBinding.txtCHMC.setBackgroundColor(Color.parseColor("#FF32CD32"))
                }
                else
                {
                    viewBinding.txtCHMC.isVisible = false
                    viewBinding.lblCHMC.isVisible = false
                }

                viewBinding.txtCHMD.text = messageBody.optString("PARA4");
                viewBinding.txtCHMD.setBackgroundColor(Color.parseColor("#FFFFFFFF"))
                if(!viewBinding.txtCHMD.text.isEmpty())
                {
                    viewBinding.txtCHMD.isVisible = true
                    viewBinding.lblCHMD.isVisible = true

                    if( messageBody.optString("PARA4_LIMIT").toString() == "OVER" )
                        viewBinding.txtCHMD.setBackgroundColor(Color.parseColor("#FFFF0000"))
                    else if( messageBody.optString("PARA4_LIMIT").toString() == "N90" )
                        viewBinding.txtCHMD.setBackgroundColor(Color.parseColor("#FFFFFF00"))
                    else if( messageBody.optString("PARA4_LIMIT").toString() == "N80" )
                        viewBinding.txtCHMD.setBackgroundColor(Color.parseColor("#FF32CD32"))
                }
                else
                {
                    viewBinding.txtCHMD.isVisible = false
                    viewBinding.lblCHMD.isVisible = false
                }
                // end

                val check = ValidateCheck(this@RemoteCvdActivity).equipment(
                    viewBinding.txtMachine.text.toString(), isMachineName
                )

                if (!check) {
//                        OkDialog.show(
//                            supportFragmentManager, "계측 주기 알림",
//                            "[$isMachineName]장비가 기준장비에 존재하지 않습니다.", GetString.BTNOKSTR
//                        )

                    viewBinding.editSelectMachine.setText("")
                    viewBinding.editSelectMachine.requestFocus()
                    return
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
                //실패시 Global 변수 초기화
                //Add By wj.Kim
                searchSuperEqpId = ""
                searchEqpArea = ""
                searchEqpType = ""
                //End
                viewBinding.editSelectMachine.setText("")
                viewBinding.editSelectMachine.requestFocus()
                return
            }
        }

        viewBinding.editSelectMachine.setText(isMachineName)
        getRecipeInfo()

        viewBinding.editSelectMachine.requestFocus()
        viewBinding.editSelectMachine.selectAll()
    }

    private suspend fun getRecipeInfo() {
        val lotId = viewBinding.txtLotNo.text.toString()
        val product = viewBinding.txtProduct.text.toString()

        val sendMessage = MessageFactoryUtil.recipeInfo(
            "N", lotId, searchOperation, searchSubOperation,
            product, isMainEqp, searchOpType, DeviceInfo.FACILITY
        )

        val message = MessageSender.send(
            supportFragmentManager, sendMessage, MessageName.RECIPEINFO
        )
        val isSuccessFul = message.isSuccessFul
        val result = message.result
        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            //---[Addition] 2015.03.23 jy.Lim(Begin)
            //입력한 Lot별, 사전 Photo 진행 장비가 다른지 Check
            val etchMessage = messageBody.optString("ETCHMESSAGE")
            if (etchMessage.isNotEmpty()) {
                val returnCode = OkCancelDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_OK, etchMessage,
                    GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
                )

                if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                    viewBinding.editSelectMachine.setText("")
                    viewBinding.editSelectMachine.requestFocus()

                    return
                }
            }
            //---[Addition] 2015.03.23 jy.Lim(End)

            val recipe = messageBody.optString("RECIPE")
            val downCH = messageBody.optString("DOWN_CH")

            //2018.06.26 uk OMEGA Recipe 구분자는 '-'
            val headRecipeName: String
            var tempRecipeName: String
            val checkIdx: Int

            when (searchEqpType) {
                "OMEGA RAPIER" -> {
                    val lastIndex = recipe.lastIndexOf("-")
                    checkIdx = recipe.lastIndexOf("-")

                    headRecipeName = recipe.substring(0, lastIndex + 1)
                    tempRecipeName = recipe.substring(lastIndex + 1, recipe.length)
                }
                "DFM" -> {
                    val lastIndex = recipe.lastIndexOf("_")
                    checkIdx = recipe.lastIndexOf("_")

                    headRecipeName = recipe.substring(0, lastIndex + 1)
                    tempRecipeName = recipe.substring(lastIndex + 1, recipe.length)
                }
                "UNITY-II" -> {// 201012 uk UNITY-II CHAMBER RECIPE 추가
                    val lastIndex = recipe.lastIndexOf("+")
                    checkIdx = recipe.lastIndexOf("+")

                    headRecipeName = recipe.substring(0, lastIndex + 1)
                    tempRecipeName = recipe.substring(lastIndex + 1, recipe.length)
                }
                "ALTUS" -> {
                    val index = if (recipe.indexOf(",") > 0)
                        recipe.indexOf(",")
                    else
                        0

                    val altusRcp = recipe.substring(0, index)
                    val startIdx = if (altusRcp.length - 2 > 0)
                        altusRcp.length - 2
                    else
                        0

                    if (recipe.substring(startIdx, altusRcp.length) == "AB") {
                        checkIdx = index - 3

                        headRecipeName = recipe.substring(0, index - 2)
                        tempRecipeName = recipe.substring(index - 2, recipe.length)
                    } else {
                        val lastIndex = recipe.lastIndexOf(":")
                        checkIdx = recipe.lastIndexOf(":")

                        headRecipeName = recipe.substring(0, lastIndex + 1)
                        tempRecipeName = recipe.substring(lastIndex + 1, recipe.length)
                    }
                }
                else -> {
                    val lastIndex = recipe.lastIndexOf(":")
                    checkIdx = recipe.lastIndexOf(":")

                    headRecipeName = recipe.substring(0, lastIndex + 1)
                    tempRecipeName = recipe.substring(lastIndex + 1, recipe.length)
                }
            }

            // START 22.05.19 SEQUEL A Chamber는 A가 포함된 Recipe, B Chamber는 B가 포함된 Recipe
            // 24.03.11 CONCEPT2-SEQUEL 추가
            if( searchEqpType == "SEQUEL" ||searchEqpType == "CONCEPT2-SEQUEL"  )
            {
                val tempRecipeList = tempRecipeName.split(",")
                tempRecipeName = "";
                for (tempRecipe in tempRecipeList) {
                    if ( viewBinding.editSelectMachine.text.toString().endsWith("A")
                        && tempRecipe == "B" )
                            continue;
                    else if ( viewBinding.editSelectMachine.text.toString().endsWith("B")
                        && tempRecipe == "A" )
                            continue;
                    if(tempRecipeName != "")
                        tempRecipeName += ","
                    tempRecipeName += tempRecipe
                }
            }
            else if(viewBinding.editSelectMachine.text.toString().startsWith("EC04-1") ||
                    viewBinding.editSelectMachine.text.toString().startsWith("EC04-2"))
            {
                val tempRecipeList = tempRecipeName.split(",")
                tempRecipeName = "";
                for (tempRecipe in tempRecipeList) {
                    if ( viewBinding.editSelectMachine.text.toString().endsWith("A")
                        && tempRecipe != "A" )
                        continue;
                    else if ( viewBinding.editSelectMachine.text.toString().endsWith("B")
                        && tempRecipe != "B" )
                        continue;
                    if(tempRecipeName != "")
                        tempRecipeName += ","
                    tempRecipeName += tempRecipe
                }
            }
            else if( viewBinding.editSelectMachine.text.toString().equals("B01-02") ||viewBinding.editSelectMachine.text.toString().equals("B01-03") )
            {
                val tempRecipeList = tempRecipeName.split(",")
                tempRecipeName = "";
                for (tempRecipe in tempRecipeList) {
                    if ( (scrubber == "1" || scrubber =="2" )
                        && tempRecipe != "A" )
                        continue;
                    else if ( (scrubber == "3" || scrubber =="4" )
                        && tempRecipe != "B" )
                        continue;
                    if(tempRecipeName != "")
                        tempRecipeName += ","
                    tempRecipeName += tempRecipe
                }
            }
            else if( searchEqpType == "UVAS" ) {
                // 230406 uvas #05 -> 5, #15 -> 15
                val tempRecipeList = tempRecipeName.split(",")
                tempRecipeName = "";
                for (tempRecipe in tempRecipeList) {
                    if(tempRecipeName != "")
                        tempRecipeName += ","

                    val index = tempRecipe.lastIndexOf("(")
                    var recipe = tempRecipe
                    if (index > -1)
                        recipe = tempRecipe.substring(0, index)

                    if( recipe.startsWith("#0"))
                        tempRecipeName +=  recipe.replace("#0","")
                    else
                        tempRecipeName +=  recipe.replace("#","")
                }
            }


            val recipeList = arrayListOf<String>()
            if (downCH.isEmpty()) {
                val tempRecipeList = tempRecipeName.split(",")
                for (tempRecipe in tempRecipeList)
                    recipeList.add(headRecipeName + tempRecipe)
            } else {
                val tempRecipeList = tempRecipeName.split(",")
                val downList = downCH.split(",")

                val arrRecipeList = tempRecipeList.toCollection(ArrayList())

                for (tempRecipe in tempRecipeList) {
                    for (down in downList) {
                        if (searchEqpType == "HPT" ) {
                            var htpRcpIdx = tempRecipe.lastIndexOf("_")
                            if (htpRcpIdx < 0)
                                htpRcpIdx = 0

                            val htpRcp = tempRecipe.substring(htpRcpIdx + 1, tempRecipe.length)

                            if (htpRcp.indexOf(down) >= 0) {
                                if (arrRecipeList.contains(tempRecipe))
                                    arrRecipeList.remove(tempRecipe)
                            }
                        } else {
                            if (!(tempRecipe.indexOf(down) < 0 || checkIdx <= 0)) {
                                if (arrRecipeList.contains(tempRecipe))
                                    arrRecipeList.remove(tempRecipe)
                            }
                        }
                    }
                }

                for (arrRecipe in arrRecipeList) {
                    recipeList.add(headRecipeName + arrRecipe)
                }
            }

            if (searchEqpType == "MBB730") {// MBB730은 IDLE TIME 용 Recipe가 추가로 필요함.
                val itemList = arrayListOf<String>()
                for (recipeName in recipeList) {
                    val lastIndex = recipeName.lastIndexOf(")")
                    val proRecipe = recipeName.substring(lastIndex + 1, recipeName.length)
                    itemList.add("PRO_$proRecipe")
                    itemList.add(proRecipe)
                }

                val spinnerAdapter = ArrayAdapter(
                    applicationContext, R.layout.contact_spinner_row_init, itemList
                )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerRecipe.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                if (itemList.count() > 0)
                    viewBinding.spinnerRecipe.setSelection(1, false)
            } else if (searchEqpType == "TE8500") {
                val teRcpSendMessage = MessageFactoryUtil.teRcpSelection(isMainEqp, lotId)

                val teRcpMessage = MessageSender.send(
                    supportFragmentManager, teRcpSendMessage, MessageName.TERCPSELECTION
                )
                val teRcpIsSuccessFul = teRcpMessage.isSuccessFul
                val teRcpResult = teRcpMessage.result
                if (teRcpIsSuccessFul) {
                    val teRcpMessageBody = ResponseDataToJsonUtil.getMessageBody(teRcpResult)
                    val teFlag = teRcpMessageBody.optString("TE_FLAG")
                    val teRcp = teRcpMessageBody.optString("TE_RCP")
                    val teOrders = teRcpMessageBody.optString("TE_ORDERS")

                    var sRecipeList = recipeList.joinToString(";")

                    if (teFlag == "Y") {
                        if (teOrders == "0") {
                            val orderMsg = """
                                    |Eng'r Inform
                                    |$teRcp Recipe가 선택되었습니다.
                                """.trimMargin()
                            OkDialog.show(
                                supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
                                orderMsg, GetString.BTNOKSTR
                            )

                            sRecipeList = "$teRcp;$sRecipeList"
                        } else {
                            if (teRcp.isEmpty()) {
                                //MessageBox(L"Tuning Recipe가 없습니다.",L"알림",MB_OK | MB_ICONEXCLAMATION);
                            } else if (teRcp == sRecipeList) {
                                OkDialog.show(
                                    supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
                                    "동일 Recipe 입니다.", GetString.BTNOKSTR
                                )
                            } else if (teRcp != sRecipeList) {
                                OkDialog.show(
                                    supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
                                    "Recipe가 선택되었습니다.", GetString.BTNOKSTR
                                )

                                sRecipeList = "$teRcp;$sRecipeList"
                            }
                        }
                    }

                    val spinnerAdapter = ArrayAdapter(
                        applicationContext, R.layout.contact_spinner_row_init,
                        sRecipeList.split(";")
                    )
                    spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                    viewBinding.spinnerRecipe.adapter = InitSpinnerAdapter(
                        spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                    )

                    if (teRcp.isNotEmpty()) {
                        if (sRecipeList.split(";").contains(teRcp)) {
                            val position = sRecipeList.split(";").indexOf(teRcp)
                            viewBinding.spinnerRecipe.setSelection(position + 1, false)
                        }
                    } else {
                        viewBinding.spinnerRecipe.setSelection(1, false)
                    }
                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR
                    )

                    return
                }
            } else {

                val spinnerAdapter = ArrayAdapter(
                    applicationContext, R.layout.contact_spinner_row_init,
                    (if( searchEqpType == "HPT"  ||searchEqpType == "CENTURA5200 MXP" ||searchEqpType == "eMAX CT" ||searchEqpType == "DPS METAL" ||searchEqpType == "DPS POLY" )
                        recipeList.sortedWith(compareByDescending { it.length })
                    else if(searchEqpType == "UNITY-II" && (viewBinding.txtCustomer.text == "MPS Inc" ||viewBinding.txtCustomer.text == "Renesas Electronics Operations" ||viewBinding.txtCustomer.text == "Renesas Design Bingen GmbH" ) )
                        recipeList
                    else if(searchEqpType == "UNITY-II" )
                        recipeList.sortedWith(compareByDescending { it.length })
                    else recipeList)
                )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerRecipe.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                viewBinding.spinnerRecipe.setSelection(1, false)
            }
            viewBinding.btnEqpCancel.isEnabled = true
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )

            viewBinding.spinnerRecipe.adapter = null
            clearPortInfo()
        }
    }
}