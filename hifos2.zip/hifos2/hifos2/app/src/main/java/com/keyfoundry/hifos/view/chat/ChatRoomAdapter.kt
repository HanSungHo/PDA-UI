package com.keyfoundry.hifos.view.chat

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.service.RetrofitSyncService
import com.keyfoundry.hifos.config.service.udp.UDPMessageStore
import com.keyfoundry.hifos.config.utils.CommonUtil
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.message.MessageSender
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject

class ChatRoomAdapter(
    private var chatList: List<ChatRoom>,
    private val onItemClick: (ChatRoom) -> Unit // 클릭 이벤트 전달
) : RecyclerView.Adapter<ChatRoomAdapter.ChatVH>() {

    inner class ChatVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val roomName: TextView = itemView.findViewById(R.id.roomName)
        val lastMessage: TextView = itemView.findViewById(R.id.lastMessage)
        val time: TextView = itemView.findViewById(R.id.time)
        val unreadCount: TextView = itemView.findViewById(R.id.unreadCount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatVH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chat_room, parent, false)
        return ChatVH(view)
    }

    override fun onBindViewHolder(holder: ChatVH, position: Int) {
        val chat = chatList[position]

        holder.roomName.text = chat.roomName
        holder.lastMessage.text = chat.lastMessage
        holder.time.text = chat.time
        holder.unreadCount.text = chat.unReadCount.toString()
        holder.unreadCount.visibility = if (chat.unReadCount == "0") View.GONE else View.VISIBLE

        // 🔹 클릭 이벤트
        holder.itemView.setOnClickListener {
            onItemClick(chat)
        }
    }

    override fun getItemCount(): Int = chatList.size

    fun updateData(newList: List<ChatRoom>) {
        this.chatList = newList
        notifyDataSetChanged()
    }
}