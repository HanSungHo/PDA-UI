package com.keyfoundry.hifos.config.utils

import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Context.INPUT_METHOD_SERVICE
import android.content.Intent
import android.net.wifi.WifiManager
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import com.keyfoundry.hifos.view.dialog.DeviceNameCheckActivity
import java.math.BigInteger
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.UnknownHostException
import java.nio.ByteOrder
import java.util.*

class CommonUtil {
    companion object {
        //키보드 숨기기 기능
        fun hideKeyboard(context: AppCompatActivity, current: View?) {
            val imm: InputMethodManager =
                context.getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(current?.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
        }

        //PDA 설정 IP 불러오는 기능
        fun wifiIpAddress(context: Context): String? {
            val wifiManager =
                context.getSystemService(AppCompatActivity.WIFI_SERVICE) as WifiManager
            var ipAddress = wifiManager.connectionInfo.ipAddress

            if (ByteOrder.nativeOrder().equals(ByteOrder.LITTLE_ENDIAN)) {
                ipAddress = Integer.reverseBytes(ipAddress)
            }
            val ipByteArray: ByteArray = BigInteger.valueOf(ipAddress.toLong()).toByteArray()

            return try {
                InetAddress.getByAddress(ipByteArray).hostAddress
            } catch (ex: UnknownHostException) {
                Log.e("WIFIIP", "Unable to get host address.")
                null
            }
        }

        fun getLocalIpAddress(): String? {
            try {
                val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
                for (intf in interfaces) {
                    val addrs = Collections.list(intf.inetAddresses)
                    for (addr in addrs) {
                        if (!addr.isLoopbackAddress) {
                            val sAddr = addr.hostAddress
                            // IPv4 주소인지 확인
                            val isIPv4 = sAddr.indexOf(':') < 0
                            if (isIPv4) {
                                return sAddr
                            }
                        }
                    }
                }
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
            return null
        }

        // PDA 기기명 불러오는 기능
        // Bluetooth 명이 PDA 명
        // AR로 시작이 아닐시 PDA 이름변경 화면으로 이동
        fun checkPDAName(context: Context) {
            if (BluetoothAdapter.getDefaultAdapter()?.name == null)
                return

            val btName = BluetoothAdapter.getDefaultAdapter()?.name.toString()

            val startName = if (btName.length > 2) btName.substring(0, 2) else btName

            if (startName.toUpperCase(Locale.ROOT) != "AR" || btName.length > 10) {
                val newIntent = Intent(context, DeviceNameCheckActivity::class.java)
                context.startActivity(newIntent)
            }
        }
    }
}