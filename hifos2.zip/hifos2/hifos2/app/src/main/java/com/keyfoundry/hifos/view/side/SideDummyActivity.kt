package com.keyfoundry.hifos.view.side

import android.os.Bundle
import android.text.InputFilter
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivitySideDummyBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SideDummyActivity : HFActivity() {
    companion object {
        private const val TAG = "SideDummyActivity"
    }

    private lateinit var viewBinding: ActivitySideDummyBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var searchOperId = ""
    private var searchOperDesc = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivitySideDummyBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editEqpId.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        viewBinding.editEqpId.setOnEditorActionListener(editorActionListener)
        viewBinding.editLotNo.setOnEditorActionListener(editorActionListener)
        viewBinding.btnSearchEqp.setOnClickListener(onSingleClickListener)
        viewBinding.btnSearchLot.setOnClickListener(onSingleClickListener)
        viewBinding.btnIn.setOnClickListener(onSingleClickListener)
        viewBinding.btnOut.setOnClickListener(onSingleClickListener)
        viewBinding.btnClose.setOnClickListener(onSingleClickListener)
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchEqp.id -> {
                    getEqpInfo()
                }
                viewBinding.btnSearchLot.id -> {
                    getLotInfo()
                }
                viewBinding.btnIn.id -> {
                    // SIDE DUMMY IN 처리
                    executeInOut("IN")
                }
                viewBinding.btnOut.id -> {
                    // SIDE DUMMY OUT 처리
                    executeInOut("OUT")
                }
                viewBinding.btnClose.id -> {
                    finish()
                }
            }
        }
    }

    private fun executeInOut(eventName: String) {
        mainScope.launch {
            if (viewBinding.editEqpId.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, "ERROR",
                    "장비명을 입력하여 주세요.", GetString.BTNOKSTR
                )

                viewBinding.editEqpId.requestFocus()
                viewBinding.editEqpId.selectAll()
                return@launch
            }

            if (viewBinding.editLotNo.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, "ERROR",
                    "LOT을 입력하여 주세요.", GetString.BTNOKSTR
                )

                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
                return@launch
            }

            val sendMessage = MessageFactoryUtil.sideDmmInsert(
                eventName, viewBinding.editEqpId.text.toString(),
                viewBinding.editLotNo.text.toString(), searchOperId,
                searchOperDesc, DeviceInfo.OPERATOR_NAME
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.SIDEDMMINSERT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                clearEQPSearchInfo()
                viewBinding.btnIn.isEnabled = false
                viewBinding.btnOut.isEnabled = false

                if (eventName == "IN") {
                    viewBinding.editEqpId.setText("")
                } else if (eventName == "OUT") {
                    viewBinding.editLotNo.isClickable = true
                    viewBinding.editLotNo.isFocusable = true
                    viewBinding.editLotNo.isFocusableInTouchMode = true
                    viewBinding.editLotNo.requestFocus()
                    viewBinding.editLotNo.selectAll()
                    viewBinding.btnSearchLot.isEnabled = true
                }

                viewBinding.editEqpId.requestFocus()

                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val ret = messageBody.optString("RET")
                if (ret.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_OK, ret, GetString.BTNOKSTR
                    )
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
                return@launch
            }
        }
    }

    private val editorActionListener = TextView.OnEditorActionListener { v, actionId, event ->
        when (v.id) {
            viewBinding.editEqpId.id -> {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val check = BarcodeStyle(this).eqpId(viewBinding.editEqpId)

                    if (check)
                        getEqpInfo()

                } else if (event != null) {
                    if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                        val check = BarcodeStyle(this).eqpId(viewBinding.editEqpId)

                        if (check)
                            getEqpInfo()
                    }
                }
            }
            viewBinding.editLotNo.id -> {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                    if (check)
                        getLotInfo()

                } else if (event != null) {
                    if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                        val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                        if (check)
                            getLotInfo()
                    }
                }
            }
        }

        true
    }

    private fun clearInfo() {
        clearEQPSearchInfo()
        clearLotSearchInfo()

        viewBinding.editLotNo.isClickable = false
        viewBinding.editLotNo.isFocusable = false

        viewBinding.btnSearchLot.isEnabled = false
        viewBinding.btnOut.isEnabled = false
        viewBinding.btnIn.isEnabled = false
    }

    private fun clearEQPSearchInfo() {
        viewBinding.editLotNo.setText("")
        viewBinding.txtProcessNum.text = ""
        viewBinding.txtProcessName.text = ""
        viewBinding.txtInDate.text = ""
        viewBinding.txtInUser.text = ""
    }

    private fun clearLotSearchInfo() {
        searchOperId = ""
        searchOperDesc = ""
    }


    private fun getEqpInfo() {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@SideDummyActivity, currentFocus)

            clearInfo()

            if (viewBinding.editEqpId.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, "ERROR",
                    "장비명을 입력하여 주세요.", GetString.BTNOKSTR
                )

                viewBinding.editEqpId.requestFocus()
                viewBinding.editEqpId.selectAll()
                return@launch
            }

            val sendMessage =
                MessageFactoryUtil.sideDmmSelect("EQP", viewBinding.editEqpId.text.toString())

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.SIDEDMMSELECT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val lotID = messageBody.optString("LOTNAME")
                val oper = messageBody.optString("PROCESSOPERATIONNAME")
                val operDesc = messageBody.optString("PODESC")
                val inDate = messageBody.optString("IN_TIME")
                val inUser = messageBody.optString("IN_USER")

                viewBinding.txtProcessNum.text = oper
                viewBinding.txtProcessName.text = operDesc

                searchOperId = oper
                searchOperDesc = operDesc

                viewBinding.txtInDate.text = inDate
                viewBinding.txtInUser.text = inUser

                if (lotID.isEmpty()) {
                    viewBinding.btnSearchLot.isEnabled = true
                    viewBinding.editLotNo.isClickable = true
                    viewBinding.editLotNo.isFocusable = true
                    viewBinding.editLotNo.isFocusableInTouchMode = true
                    viewBinding.editLotNo.requestFocus()
                    viewBinding.editLotNo.selectAll()
                } else {
                    viewBinding.editLotNo.setText(lotID)
                    viewBinding.btnOut.isEnabled = true
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editEqpId.requestFocus()
                viewBinding.editEqpId.selectAll()
                return@launch
            }
        }
    }

    private fun getLotInfo() {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@SideDummyActivity, currentFocus)

            clearLotSearchInfo()

            if (viewBinding.editLotNo.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, "ERROR",
                    "LOT을 입력하여 주세요.", GetString.BTNOKSTR
                )

                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
                return@launch
            }

            val sendMessage = MessageFactoryUtil.sideDmmSelect(
                "LOT", viewBinding.editLotNo.text.toString(), viewBinding.editEqpId.text.toString()
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.SIDEDMMSELECT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val oper = messageBody.optString("PROCESSOPERATIONNAME")
                val operDesc = messageBody.optString("PODESC")

                searchOperId = oper
                searchOperDesc = operDesc

                viewBinding.txtProcessNum.text = oper
                viewBinding.txtProcessName.text = operDesc

                viewBinding.btnIn.isEnabled = true
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
                return@launch
            }
        }
    }
}