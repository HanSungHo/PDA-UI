package com.keyfoundry.hifos.view.cmm.wafer

class SelectWafer(val maxCount: Int) {
    var currentCount = 0
    var disableCount = 0
}