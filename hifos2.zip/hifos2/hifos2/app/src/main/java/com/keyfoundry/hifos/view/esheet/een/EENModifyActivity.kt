package com.keyfoundry.hifos.view.esheet.een

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.spinner.SpinnerItem
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityEenModifyBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.lang.Exception
import java.util.ArrayList


/*
*   EEN 등록하기 기능 화면 (Addition by Sunggil Hwang, 2024.01.19)
    Requested by 제조팀 김택용 FL
* */
class EENModifyActivity :  HFActivity() {
     companion object {
         private const val TAG = "SettingEEN"
     }

    private lateinit var viewBinding: ActivityEenModifyBinding
    private lateinit var keyboardVisibilityUtils: KeyboardVisibilityUtils

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    lateinit var lotId: String
    lateinit var operation: String
    lateinit var processStep: String
    lateinit var operSeq: String
    lateinit var factoryname: String
    lateinit var product: String
    lateinit var route: String
    lateinit var eenId: String
    lateinit var tagId: String
    lateinit var tagComment: String
    lateinit var oldTagComment: String
    lateinit var actionPoint: String
    lateinit var poDesc: String

    var initTagFlag = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityEenModifyBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        keyboardVisibilityUtils = KeyboardVisibilityUtils(window,
            onShowKeyboard = { keyboardHeight ->
                viewBinding.svRoot.run {
                    smoothScrollTo(scrollX, scrollY + keyboardHeight)
                }
            })

        lotId = intent.getStringExtra("LOTID").toString()
        factoryname = intent.getStringExtra("FACTORYNAME").toString()
        product = intent.getStringExtra("PRODUCT").toString()
        route = intent.getStringExtra("ROUTE").toString()
        operation = intent.getStringExtra("OPERATION").toString()
        processStep = intent.getStringExtra("PROCESSSTEP").toString()
        operSeq = intent.getStringExtra("OPERSEQUENCE").toString()
        eenId = intent.getStringExtra("EENID").toString()
        tagComment = intent.getStringExtra("TAGCOMMENT").toString()
        actionPoint = intent.getStringExtra("ACTIONPOINT").toString()
        tagId = intent.getStringExtra("TAGID").toString()
        poDesc = intent.getStringExtra("PODESC").toString()

        oldTagComment = tagComment

        viewBinding.txtLotId.text = lotId
        viewBinding.txtFacility.text = factoryname
        viewBinding.txtProduct.text = product
        viewBinding.txtRoute.text = route
        viewBinding.txtOperation.text = operation
        viewBinding.txtEenid.text = eenId
        viewBinding.txtPodesc.text = poDesc
        viewBinding.editComment.setText(tagComment)
        viewBinding.spinnerTagId.onItemSelectedListener = itemSelectListener
        viewBinding.btnConfirm.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)

        setSpinnerTag()
        spinnerActionPoint()

    }

    private fun setSpinnerTag(){
        mainScope.launch {
            var sendMessage = MessageFactoryUtil.getTagId(factoryname)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.GETTAGID)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val tagListStr = messageBody.optString("TAGLIST")

                val dataList = ParseUtil.stringTo2D(tagListStr);

                setSpinnerTag(dataList)

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR)
            }
        }
    }

    private fun setSpinnerTag(dataList : Array<Array<String>>?) {
        val itemList = arrayListOf<SpinnerItem>()

        dataList?.forEachIndexed { index, row ->
            itemList.add(SpinnerItem(row[1], row[0]))
        }

        val spinnerAdapter =
            ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerTagId.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
        val positionToSelect = itemList.indexOfFirst { it.value == tagId }

        if (positionToSelect != -1) {
            viewBinding.spinnerTagId.setSelection(positionToSelect+1)
        }

    }

    private val itemSelectListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {

                if (parent != null) {
                    when (parent.id) {
                        viewBinding.spinnerTagId.id -> {
                            if(!initTagFlag) {
                                viewBinding.editComment.setText((viewBinding.spinnerTagId.selectedItem as? SpinnerItem)?.key)
                            }
                            initTagFlag = false;
                        }
                    }
                }

        }

        override fun onNothingSelected(parent: AdapterView<*>?) {

        }
    }


    private fun spinnerActionPoint(){
        val itemList = arrayListOf("MOVEIN", "MOVEOUT")

        val spinnerAdapter =
            ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerActionPoint.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )

        if(actionPoint=="MOVEIN"){
            viewBinding.spinnerActionPoint.setSelection(1)
        } else {
            viewBinding.spinnerActionPoint.setSelection(2)
        }
    }

    private fun updateEenMessage(){
        if (viewBinding.spinnerActionPoint.selectedItem == null)
        {
            OkDialog.show(
                supportFragmentManager, "Action Point 입력",
                "Action Point를 입력하세요.", GetString.BTNOKSTR)
            return;
        }
        if (viewBinding.editComment.text.toString() == "")
        {
            OkDialog.show(
                supportFragmentManager, "Tag Comment 입력",
                "Tag Comment를 입력하세요.", GetString.BTNOKSTR)
            return;
        }

        val returnCode = OkCancelDialog.show(
            supportFragmentManager,
            GetString.TXTDIALOGTITLE_OK,
            "수정하시겠습니까?",
            GetString.BTNYESSTR,
            GetString.BTNNOSTR
        )

        if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
            return
        }

        val sendMessage = MessageFactoryUtil.updateEen(
            viewBinding.txtLotId.text.toString(),
            DeviceInfo.OPERATOR_ID,
            viewBinding.txtFacility.text.toString().trim(),
            viewBinding.txtProduct.text.toString().trim(),
            viewBinding.txtOperation.text.toString().trim(),
            viewBinding.spinnerActionPoint.selectedItem.toString(),
            viewBinding.txtEenid.text.toString().trim(),
            viewBinding.txtRoute.text.toString().trim(),
            viewBinding.editComment.text.toString(),
            viewBinding.spinnerTagId.selectedItem?.toString(),
            oldTagComment,
            viewBinding.editModifyReason.text.toString()
        )

        mainScope.launch {
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_OK,
                    "EEN Update가 완료 되었습니다.",
                    GetString.BTNOKSTR
                )

                val returnIntent = Intent()
                returnIntent.putExtra("LOTID", lotId)
                setResult(Activity.RESULT_OK, returnIntent)
                finish()

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )

            }
        }
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnConfirm.id -> {
                    updateEenMessage()
                }
                viewBinding.btnCancel.id ->{
                    CommonUtil.hideKeyboard(this@EENModifyActivity, currentFocus)
                    finish()
                }
            }
        }
    }
}