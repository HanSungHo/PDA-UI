package com.keyfoundry.hifos.view.esheet

import android.nfc.Tag
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.CompoundButton
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.utils.GridService
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityEsheetEdcBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray


class EsheetEdcActivity : HFActivity(){
    companion object {
        private const val Tag = "EsheetEdcActivity"
    }


    lateinit var  viewBinding: ActivityEsheetEdcBinding
    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)
    private var gsType =""

    lateinit var lotId: String
    lateinit var operation: String
    lateinit var subOperation: String
    lateinit var processStep: String
    lateinit var Recipe : String
    lateinit var gridService: GridService

    private val columnData1 = linkedMapOf(
        "SLOTID" to ColumnProperty("SLOT", Gravity.CENTER, false,50),
        "PRODEQPID1" to ColumnProperty("생산장비", Gravity.CENTER, false),
        "MEASEQPID" to ColumnProperty("계측장비", Gravity.CENTER, false),
        "PARAMETER" to ColumnProperty("PARA", Gravity.CENTER, false),
        "RECIPEID" to ColumnProperty("RECIPE", Gravity.CENTER, false),
        "MIN" to ColumnProperty("MIN", Gravity.CENTER, false),
        "MAX" to ColumnProperty("MAX", Gravity.CENTER, false),
        "AVG" to ColumnProperty("AVG", Gravity.CENTER, false),
        "QUL" to ColumnProperty("QUL", Gravity.CENTER, false),
        "QCL" to ColumnProperty("QCL", Gravity.CENTER, false),
        "QLL" to ColumnProperty("QLL", Gravity.CENTER, false),
        "SITECOUNT" to ColumnProperty("SITECOUNT", Gravity.CENTER, false),
        "VALUE1" to ColumnProperty("1", Gravity.CENTER, false),
        "VALUE2" to ColumnProperty("2", Gravity.CENTER, false),
        "VALUE3" to ColumnProperty("3", Gravity.CENTER, false),
        "VALUE4" to ColumnProperty("4", Gravity.CENTER, false),
        "VALUE5" to ColumnProperty("5", Gravity.CENTER, false),
        "VALUE6" to ColumnProperty("6", Gravity.CENTER, false),
        "VALUE7" to ColumnProperty("7", Gravity.CENTER, false),
        "VALUE8" to ColumnProperty("8", Gravity.CENTER, false),
        "VALUE9" to ColumnProperty("9", Gravity.CENTER, false),
        "RANGE" to ColumnProperty("RANGE", Gravity.CENTER, false)
    )
    private val columnData2 = linkedMapOf(
        "SLOTID" to ColumnProperty("SLOT", Gravity.CENTER, false,50),
        "PRODEQPID1" to ColumnProperty("생산장비", Gravity.CENTER, false ),
        "MEASEQPID" to ColumnProperty("계측장비", Gravity.CENTER, false),
        "PARAMETER" to ColumnProperty("PARA", Gravity.CENTER, false),
        "RECIPEID" to ColumnProperty("RECIPE", Gravity.CENTER, false),
        "MINX" to ColumnProperty("MINX", Gravity.CENTER, false),
        "MINY" to ColumnProperty("MINY", Gravity.CENTER, false),
        "MAXX" to ColumnProperty("MAXX", Gravity.CENTER, false),
        "MAXY" to ColumnProperty("MAXY", Gravity.CENTER, false),
        "AVGX" to ColumnProperty("AVGX", Gravity.CENTER, false),
        "AVGV" to ColumnProperty("AVGY", Gravity.CENTER, false),
        "QUL" to ColumnProperty("QUL", Gravity.CENTER, false),
        "QCL" to ColumnProperty("QCL", Gravity.CENTER, false),
        "QLL" to ColumnProperty("QLL", Gravity.CENTER, false),
        "SITECOUNT" to ColumnProperty("SITECOUNT", Gravity.CENTER, false),
        "VALUE1" to ColumnProperty("1", Gravity.CENTER, false),
        "VALUE2" to ColumnProperty("2", Gravity.CENTER, false),
        "VALUE3" to ColumnProperty("3", Gravity.CENTER, false),
        "VALUE4" to ColumnProperty("4", Gravity.CENTER, false),
        "VALUE5" to ColumnProperty("5", Gravity.CENTER, false),
        "VALUE6" to ColumnProperty("6", Gravity.CENTER, false),
        "VALUE7" to ColumnProperty("7", Gravity.CENTER, false),
        "VALUE8" to ColumnProperty("8", Gravity.CENTER, false),
        "VALUE9" to ColumnProperty("9", Gravity.CENTER, false),
        "VALUE10" to ColumnProperty("10", Gravity.CENTER, false),
        "VALUE11" to ColumnProperty("11", Gravity.CENTER, false),
        "VALUE12" to ColumnProperty("12", Gravity.CENTER, false),
        "VALUE13" to ColumnProperty("13", Gravity.CENTER, false),
        "VALUE14" to ColumnProperty("14", Gravity.CENTER, false),
        "VALUE15" to ColumnProperty("15", Gravity.CENTER, false),
        "VALUE16" to ColumnProperty("16", Gravity.CENTER, false),
        "VALUE17" to ColumnProperty("17", Gravity.CENTER, false),
        "VALUE18" to ColumnProperty("18", Gravity.CENTER, false),
        "VALUE19" to ColumnProperty("19", Gravity.CENTER, false),
        "RANGEX" to ColumnProperty("RANGEX", Gravity.CENTER, false),
        "RANGEY" to ColumnProperty("RANGEY", Gravity.CENTER, false)
    )
    private val columnData1C = linkedMapOf(
        "SLOTID" to ColumnProperty("SLOT", Gravity.CENTER, false,50),
        "PRODEQPID1" to ColumnProperty("생산장비", Gravity.CENTER, false),
        "MEASEQPID" to ColumnProperty("계측장비", Gravity.CENTER, false),
        "PARAMETER" to ColumnProperty("PARA", Gravity.CENTER, false),
        "RECIPEID" to ColumnProperty("RECIPE", Gravity.CENTER, false),
        "MIN" to ColumnProperty("MIN", Gravity.CENTER, false),
        "MAX" to ColumnProperty("MAX", Gravity.CENTER, false),
        "AVG" to ColumnProperty("AVG", Gravity.CENTER, false),
        "QUL" to ColumnProperty("QUL", Gravity.CENTER, false,0),
        "QCL" to ColumnProperty("QCL", Gravity.CENTER, false,0),
        "QLL" to ColumnProperty("QLL", Gravity.CENTER, false,0),
        "SITECOUNT" to ColumnProperty("SITECOUNT", Gravity.CENTER, false,0),
        "VALUE1" to ColumnProperty("1", Gravity.CENTER, false,0),
        "VALUE2" to ColumnProperty("2", Gravity.CENTER, false,0),
        "VALUE3" to ColumnProperty("3", Gravity.CENTER, false,0),
        "VALUE4" to ColumnProperty("4", Gravity.CENTER, false,0),
        "VALUE5" to ColumnProperty("5", Gravity.CENTER, false,0),
        "VALUE6" to ColumnProperty("6", Gravity.CENTER, false,0),
        "VALUE7" to ColumnProperty("7", Gravity.CENTER, false,0),
        "VALUE8" to ColumnProperty("8", Gravity.CENTER, false,0),
        "VALUE9" to ColumnProperty("9", Gravity.CENTER, false,0),
        "RANGE" to ColumnProperty("RANGE", Gravity.CENTER, false)
    )
    private val columnData2C = linkedMapOf(
        "SLOTID" to ColumnProperty("SLOT", Gravity.CENTER, false,50),
        "PRODEQPID1" to ColumnProperty("생산장비", Gravity.CENTER, false ),
        "MEASEQPID" to ColumnProperty("계측장비", Gravity.CENTER, false),
        "PARAMETER" to ColumnProperty("PARA", Gravity.CENTER, false),
        "RECIPEID" to ColumnProperty("RECIPE", Gravity.CENTER, false),
        "MINX" to ColumnProperty("MINX", Gravity.CENTER, false),
        "MINY" to ColumnProperty("MINY", Gravity.CENTER, false),
        "MAXX" to ColumnProperty("MAXX", Gravity.CENTER, false),
        "MAXY" to ColumnProperty("MAXY", Gravity.CENTER, false),
        "AVGX" to ColumnProperty("AVGX", Gravity.CENTER, false),
        "AVGV" to ColumnProperty("AVGY", Gravity.CENTER, false),
        "QUL" to ColumnProperty("QUL", Gravity.CENTER, false),
        "QCL" to ColumnProperty("QCL", Gravity.CENTER, false),
        "QLL" to ColumnProperty("QLL", Gravity.CENTER, false),
        "SITECOUNT" to ColumnProperty("SITECOUNT", Gravity.CENTER, false),
        "VALUE1" to ColumnProperty("1", Gravity.CENTER, false,0),
        "VALUE2" to ColumnProperty("2", Gravity.CENTER, false,0),
        "VALUE3" to ColumnProperty("3", Gravity.CENTER, false,0),
        "VALUE4" to ColumnProperty("4", Gravity.CENTER, false,0),
        "VALUE5" to ColumnProperty("5", Gravity.CENTER, false,0),
        "VALUE6" to ColumnProperty("6", Gravity.CENTER, false,0),
        "VALUE7" to ColumnProperty("7", Gravity.CENTER, false,0),
        "VALUE8" to ColumnProperty("8", Gravity.CENTER, false,0),
        "VALUE9" to ColumnProperty("9", Gravity.CENTER, false,0),
        "VALUE10" to ColumnProperty("10", Gravity.CENTER, false,0),
        "VALUE11" to ColumnProperty("11", Gravity.CENTER, false,0),
        "VALUE12" to ColumnProperty("12", Gravity.CENTER, false,0),
        "VALUE13" to ColumnProperty("13", Gravity.CENTER, false,0),
        "VALUE14" to ColumnProperty("14", Gravity.CENTER, false,0),
        "VALUE15" to ColumnProperty("15", Gravity.CENTER, false,0),
        "VALUE16" to ColumnProperty("16", Gravity.CENTER, false,0),
        "VALUE17" to ColumnProperty("17", Gravity.CENTER, false,0),
        "VALUE18" to ColumnProperty("18", Gravity.CENTER, false,0),
        "VALUE19" to ColumnProperty("19", Gravity.CENTER, false,0),
        "RANGEX" to ColumnProperty("RANGEX", Gravity.CENTER, false),
        "RANGEY" to ColumnProperty("RANGEY", Gravity.CENTER, false)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityEsheetEdcBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)
        gridService = GridService(applicationContext)

        lotId = intent.getStringExtra("LOTID").toString()
        operation = intent.getStringExtra("OPERATION").toString()
        subOperation = intent.getStringExtra("SUBOPERATION").toString()
        processStep = intent.getStringExtra("PROCESSSTEP").toString()
        Recipe = intent.getStringExtra("REALRECIPE").toString()

        viewBinding.txtLotNo.text = lotId
        val processNum = "$operation$subOperation"

        viewBinding.btnClose.setOnClickListener(onClickListener)
        viewBinding.chkAll.setOnCheckedChangeListener(onCheckedChangeListener)

        getEDCData();
    }

    private val onClickListener = object  : OnSingleClickListener(){
        override fun onSingleClick(it: View) {
            when(it.id){
                viewBinding.btnClose.id ->{
                    finish()
                }
            }
        }
    }

    private val onCheckedChangeListener =
        CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            getEDCData()
        }

    private fun getEDCData(){
        mainScope.launch {
            viewBinding.baseLayout.removeAllViews()
            val sendMessage = MessageFactoryUtil.getEdcData(
                lotId, DeviceInfo.FACILITY, operation, subOperation, Recipe,processStep
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.GETEDCDATA)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                 gsType = messageBody.optString("PROCESSTYPE")
                val commentListJSON =
                    ResponseDataToJsonUtil.getMessageBodyList(result, "ITEMS")

                if(gsType == "THICK" || gsType == "CD")
                {
                    if(viewBinding.chkAll.isChecked) {
                        val gridData = gridService.setGridPropData(columnData1, commentListJSON)
                        viewBinding.baseLayout.addView(gridData)
                    }
                    else {
                        val gridData = gridService.setGridPropData(columnData1C, commentListJSON)
                        viewBinding.baseLayout.addView(gridData)
                    }
                }
                else if(gsType =="OVERLAY")
                {
                    if(viewBinding.chkAll.isChecked) {
                        val gridData = gridService.setGridPropData(columnData2, commentListJSON)
                        viewBinding.baseLayout.addView(gridData)
                    }
                    else{
                        val gridData = gridService.setGridPropData(columnData2C, commentListJSON)
                        viewBinding.baseLayout.addView(gridData)
                    }
                }
            }
            else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR)
            }
        }
    }

}

