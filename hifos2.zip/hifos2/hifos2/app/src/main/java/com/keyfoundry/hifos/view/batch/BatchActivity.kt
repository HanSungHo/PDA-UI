package com.keyfoundry.hifos.view.batch

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.children
import androidx.core.view.get
import androidx.core.view.isGone
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.*
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityBatchBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog_batch
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
// get test
class BatchActivity : HFActivity() {

    companion object {
        private const val TAG = "BatchActivity"
        private const val MAX_BATCH_COUNT = 6
    }

    enum class RadioType { RUN, M }

    private lateinit var viewBinding : ActivityBatchBinding

    private lateinit var gridService: GridService
    private lateinit var gridList: CTMainLayout
    private lateinit var columnData : LinkedHashMap<String, ColumnProperty>

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var batchItemList = JSONArray()
    private var selectedRowIndex = 0

    private var m_lot_sProcessState =""
    private var m_lot_sProcessType = ""
    private var pslotname = ""
    private var psjaCount = ""
    private var m_lot_Recipe = ""

    var zoneViewList = ArrayList<TextView>()
    var thuvViewList = ArrayList<TextView>()
    var ptViewList = ArrayList<TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityBatchBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        activityInit()
        setGrid()

        viewBinding.editMachine.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                val check = BarcodeStyle(this).eqpId(viewBinding.editMachine)
                if(check){
                    getMachineInfo()
                }

            } else if (event != null) { // Barcode Event
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).eqpId(viewBinding.editMachine)
                    if(check){
                        getMachineInfo()
                    }
                }
            }

            true
        }

        viewBinding.editLotNo.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)
                if(check){
                    getLotInfo()
                }

            } else if (event != null) { // Barcode Event
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)
                    if(check){
                        getLotInfo()
                    }
                }
            }

            true
        }

        viewBinding.radioRun.setOnCheckedChangeListener { buttonView, isChecked ->
            if(isChecked){
                checkedRadioButton(RadioType.RUN)
                viewBinding.spinnerMonitorWaferCount.isEnabled = false
                for(zoneView in zoneViewList) {
                    zoneView.isGone = false
                }
            }
        }

        viewBinding.radioM.setOnCheckedChangeListener { buttonView, isChecked ->
            if(isChecked){
                checkedRadioButton(RadioType.M)
                viewBinding.spinnerMonitorWaferCount.isEnabled = true
                for(zoneView in zoneViewList) {
                    zoneView.isGone = true
                }
            }
        }

        viewBinding.btnChange.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(v: View) {
                setBatch()
            }
        })

        viewBinding.btnDeleteBatch.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(v: View) {
                batchItemList.remove(selectedRowIndex)
                batchItemList.remove(selectedRowIndex)
                selectedRowIndex--
                updateGrid(false)
                viewBinding.btnDeleteBatch.isEnabled = false
                viewBinding.txtProductName.text = ""
                viewBinding.txtStep.text = ""
                viewBinding.txtCount.text=""
                viewBinding.editLotNo.setText("")
            }
        })

        viewBinding.btnSearch.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(v: View) {
                getLotInfo()
            }
        })

        viewBinding.btnSearchBC.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(v: View) {
                getBatchCount()
            }
        })

        viewBinding.btnDelete.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(v: View) {
                deleteBatch()
            }
        })

        viewBinding.btnInitialize.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(v: View) {
                viewBinding.baseLayout.removeAllViews()
                viewBinding.editMachine.setText("")
                viewBinding.editLotNo.setText("")
                viewBinding.txtBatId.text=""
                viewBinding.txtProductName.text=""
                viewBinding.txtCount.text=""
                viewBinding.txtStep.text=""
                viewBinding.checkBoxChild.isChecked = false
                viewBinding.checkBoxChildBatch.isChecked = false
                m_lot_sProcessState=""
                batchItemList = JSONArray()
                selectedRowIndex = 0
                setGrid()
                pslotname = ""
                viewBinding.btnPssearch.isEnabled = false
                viewBinding.btnPssearch.text = "子"
            }
        })

        viewBinding.checkBoxChild.setOnCheckedChangeListener{compoundButton, b ->
            if(b){
                getParentBatchId()
            } else {
                viewBinding.spinnerBatchId.setSelection(0)
                viewBinding.spinnerZone.setSelection(0)
                viewBinding.spinnerBatchId.isEnabled = false
                viewBinding.spinnerZone.isEnabled = false
            }
        }

        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(v: View) {
                finish()
            }
        })

        viewBinding.btnPssearch.setOnClickListener(object  : OnSingleClickListener(){
            override fun onSingleClick(it: View) {
                var sBatchid = viewBinding.txtBatId.text.toString()

                if(pslotname != "") {
                    viewBinding.baseLayout.removeAllViews()
                    viewBinding.editMachine.setText("")
                    viewBinding.editLotNo.setText("")
                    viewBinding.txtBatId.text = ""
                    viewBinding.txtProductName.text = ""
                    viewBinding.txtCount.text = ""
                    viewBinding.txtStep.text = ""
                    viewBinding.checkBoxChild.isChecked = false
                    viewBinding.checkBoxChildBatch.isChecked = false
                    m_lot_sProcessState = ""
                    batchItemList = JSONArray()
                    selectedRowIndex = 0
                    setGrid()
                    viewBinding.editLotNo.setText(pslotname)
                    getLotInfo()
                }

                if(psjaCount.toInt() >1 )
                {
                    val batchsubIntent = Intent(applicationContext ,BatchsubActivity::class.java )

                    batchsubIntent.putExtra("MOBATCHID",sBatchid)
                    BatchsubActivityResultLauncher.launch(batchsubIntent)
                }
            }
        })
    }

    private val activityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {

            }
        }

    private val BatchsubActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->
                    val jlot = intent.getStringExtra("JALOTNAME").toString()

                    if(jlot != "")
                    {
                        viewBinding.baseLayout.removeAllViews()
                        viewBinding.editMachine.setText("")
                        viewBinding.editLotNo.setText("")
                        viewBinding.txtBatId.text = ""
                        viewBinding.txtProductName.text = ""
                        viewBinding.txtCount.text = ""
                        viewBinding.txtStep.text = ""
                        viewBinding.checkBoxChild.isChecked = false
                        viewBinding.checkBoxChildBatch.isChecked = false
                        m_lot_sProcessState = ""
                        batchItemList = JSONArray()
                        selectedRowIndex = 0
                        setGrid()
                        viewBinding.editLotNo.setText(jlot)
                        getLotInfo()
                    }
                }
            }
        }

    private fun checkedRadioButton(radioType : RadioType){
        when(radioType){
            RadioType.RUN -> {
                viewBinding.radioRun.isChecked = true
                viewBinding.radioM.isChecked = false

            }
            RadioType.M -> {
                viewBinding.radioRun.isChecked = false
                viewBinding.radioM.isChecked = true
            }
        }
    }

    private fun activityInit() {
        viewBinding.txtBatId.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtProductName.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtStep.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtCount.movementMethod = ScrollingMovementMethod.getInstance()
        checkedRadioButton(RadioType.RUN)
        gridService = GridService(applicationContext)
        setBatchOrderSpinner(arrayListOf<String>("1","2","3","4","5","6"))
        setZoneSpinner(arrayListOf<String>("P01","P02","P03","P04","P05","P06"))
        viewBinding.editMachine.requestFocus()
        viewBinding.spinnerMonitorWaferCount.isEnabled = false
    }
    private fun setGrid(){
        columnData = linkedMapOf(
            "NUM" to ColumnProperty("N", Gravity.CENTER, false,0),
            "ISDCOL" to ColumnProperty("Z", Gravity.CENTER, false, 60),
            "LOTID" to ColumnProperty("Lot No", Gravity.CENTER, false,175),
            "PRODUCT" to ColumnProperty("제품명", Gravity.CENTER, false,0),
            "QUANTITY" to ColumnProperty("수량", Gravity.CENTER, false),
            "PROCESSSTEP" to ColumnProperty("공정명", Gravity.CENTER, false, 0),
            "OPERATION" to ColumnProperty("공정번호", Gravity.CENTER, false, 0),
            "SUBOPERATION" to ColumnProperty("SUB공정번호", Gravity.CENTER, false, 0),
            "N" to ColumnProperty("", Gravity.CENTER, false, 0),
            "RECIPE" to ColumnProperty("RECIPE", Gravity.CENTER, false, 222),
            "VIEWCOUNT" to ColumnProperty("Depo/Recycle/Cum", Gravity.CENTER, false, 0),
            "WAFERTYPE" to ColumnProperty("Type", Gravity.CENTER, false, 0),
            "THIN" to ColumnProperty("TH(UV)", Gravity.CENTER, false, 110),
            "THSPEC" to ColumnProperty("TH측정기준", Gravity.CENTER, false,0),
            "PTIN" to ColumnProperty("PT", Gravity.CENTER, false, 80),
            "PTSPEC" to ColumnProperty("PT측정기준", Gravity.CENTER, false,0),
            "STATUS" to ColumnProperty("STATUS", Gravity.CENTER, false,0)
        )

        var setGridList = JSONArray()
        val emptyObject = JSONObject()
        emptyObject.put("NUM", selectedRowIndex)
        setGridList.put(emptyObject)

        gridList = gridService.setGridPropData(columnData, setGridList)

        viewBinding.baseLayout.addView(gridList)

        val firstRow = gridList.mainTable.children.elementAt(0) as CTRowLayout
        firstRow.setBackgroundColor(Color.rgb(168,200, 240))

        for(row in gridList.mainTable.children){
            val status = gridService.getCellValue(row,"STATUS")
            val thuvTextView = (row as CTRowLayout).getChildAt(2) as TextView

            if(status == "RUN")
            {
                thuvTextView.setTextColor(Color.parseColor("#00c936"))
                // row.setBackgroundColor(Color.rgb(153,255,255))
                //row.setBackgroundResource(R.drawable.esheet_opertype_pm_color)
            }
        }


        zoneViewList.add((gridList.columnHeaderTable.getChildAt(0) as TableRow)[1] as TextView)
        zoneViewList.add(firstRow.getChildAt(1) as TextView)
    }

    private fun getMachineInfo(){
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.realEqpId(DeviceInfo.FACILITY, viewBinding.editMachine.text.toString(), "BACHCREATE")

            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.REALEQPID)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                Log.d(TAG, "{$result}")
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val eqpId = messageBody.optString("EQPID")
                val msg = messageBody.optString("MSG")

                if (msg != "")
                {
                    OkDialog.show(supportFragmentManager ,GetString.TXTDIALOGTITLE_WARNING,msg,GetString.BTNOKSTR)
                }

                viewBinding.editMachine.setText(eqpId)
                viewBinding.editLotNo.requestFocus()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

                viewBinding.editMachine.setText("")
                viewBinding.editMachine.requestFocus()
            }

        }
    }

    private fun getLotInfo(){

        var addedLotId = ""

        for(i in 0 until batchItemList.length()) {
            if ((batchItemList[i] as JSONObject).opt("LOTID")!="" && (batchItemList[i] as JSONObject).opt("LOTID")!= null) {
                if(i!=0)
                    addedLotId += ","

                addedLotId += "'" + (batchItemList[i] as JSONObject).opt("LOTID") + "'"
            }
        }

        mainScope.launch {
            val sendMessage = MessageFactoryUtil.blotInfo(viewBinding.editLotNo.text.toString(), DeviceInfo.FACILITY, (selectedRowIndex+1).toString(), viewBinding.editMachine.text.toString(),addedLotId)

            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.BLOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                Log.d(TAG, "{$result}")
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sProduct = messageBody.optString("PRODUCT")
                val sOperation = messageBody.optString("OPERATION")
                val sSubOperation = messageBody.optString("SUBOPERATION")
                val sProcessStep = messageBody.optString("PROCESSSTEP")
                val sQty = messageBody.optString("QUANTITY")
                val sBatchID = messageBody.optString("BATCHID")
                val sRecipe = messageBody.optString("STEPRECIPE")
                val sZone = messageBody.optString("LIMITZONE")	//ModifiCation by kck 2011.10.31 장비별 Zone 제한 추가
                val sProcessState = messageBody.optString("STATUS")

                // Dummy/Test Lot 추가로 인한 변수추가  2015.06.15 jy.Lim
                var sViewCount = messageBody.optString("VIEWCOUNT")
                val sCheckmachine = messageBody.optString("CHECKMACHINE")
                val sCheckOpertion = messageBody.optString("CHECKOPERTION")
                val sCheckDepoComment = messageBody.optString("CHECKDEPOCOMMENT")
                val sCheckRecycleComment = messageBody.optString("CHECKRECYCLECOMMENT")


                var sWaferType = messageBody.optString("PROCESSNAME")
                var sProcessname = messageBody.optString("PROCESSNAME")

                val sMaxbatchMessage = messageBody.optString("MAXBATCHMESSAGE")   //---[Addition] 2015.11.04 by jy.Lim
                val sPtin  = messageBody.optString("PTIN")
                val sPtspec  = messageBody.optString("PTSPEC")
                val sQtimeCheck = messageBody.optString("CHECKQTIME")  // --[Addition] 2020.06.11 jy.Lim
                val sCheckThicknessComment = messageBody.optString("CHECKTHCIKNESSCOMMENT")  // --[Addition] 2021.07.21 jy.Lim
                val sProcessType = messageBody.optString("PROCESSOPERATIONTYPE")  // --[Addition] 2022.04.26 jy.Lim
                val sJaLotname = messageBody.optString("JALOT")  // --[Addition] 2022.04.28 jy.Lim  BatchID로 들어옴
                val sMoLotname = messageBody.optString("MOLOT")  // --[Addition] 2022.05.03 jy.Lim BatchID로 들어옴
                val sCheckRecipe = messageBody.optString("CHECKRECIPE")  // --[Addition] 2023.05.17 jy.Lim
                val sJaCount = messageBody.optString("JACOUNT")  // --[Addition] 2023.05.24 jy.Lim  BatchID구분

                val sLimitRecipe = messageBody.optString("LIMITRECIPE")  // --[Addition] 2025.03.11 sunggil  Zone 제한 Recipe
                val sFqcSample = messageBody.optString("FQCSAMPLE")  // --[Addition] 2025.08.05 sunggil  G-Oxide FQM Sampling

                if (sViewCount != "")
                {
                    //	 MessageBox(sViewCount,L"확인1",MB_OK | MB_ICONEXCLAMATION);
                    viewBinding.txtCount.text = sViewCount
                }
                else
                {
                    viewBinding.txtCount.text = ""
                }

                var oSearch = false
                viewBinding.btnPssearch.isEnabled= false

                if(viewBinding.txtBatId.text.isNotEmpty()) // 변경
                {
                    if(sBatchID.isNotEmpty() && viewBinding.txtBatId.text.toString() != sBatchID)
                    {
                        OkDialog.show(supportFragmentManager
                            , GetString.TXTDIALOGTITLE_ERROR
                            , "[${viewBinding.editLotNo.text}]은 [$sBatchID]BATCH ID에 포함되어 있는 LOT입니다."
                            , GetString.BTNOKSTR)
                        return@launch
                    }
                }
                else // 등록
                {
                    if(sBatchID.isNotEmpty())
                    {
                        if(selectedRowIndex == 0)
                        {
                            val returnCode = OkCancelDialog.show(
                                supportFragmentManager,
                                GetString.TXTDIALOGTITLE_INFORM,
                                "[${viewBinding.editLotNo.text}]은 [$sBatchID]BATCH ID에 포함되어 있는 LOT입니다.\n" +
                                        "조회 하시겠습니까?",
                                GetString.BTNYESSTR,
                                GetString.BTNNOSTR
                            )
                            if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                                return@launch
                            }

                            oSearch = true
                        }
                        else
                        {
                            OkDialog.show(supportFragmentManager
                                , GetString.TXTDIALOGTITLE_ERROR
                                , "[${viewBinding.editLotNo.text}]은 [$sBatchID]BATCH ID에 포함되어 있는 LOT입니다."
                                , GetString.BTNOKSTR)
                            return@launch
                        }
                    }
                    //2021.01.19
                }

                if(!oSearch)
                {
                    if (sCheckmachine.isNotEmpty())
                    {
                        OkDialog.show(supportFragmentManager
                            , GetString.TXTDIALOGTITLE_OK
                            , sCheckmachine
                            , GetString.BTNOKSTR)
                        return@launch
                    }

                    if (sCheckOpertion.isNotEmpty())
                    {
                        OkDialog.show(supportFragmentManager
                            , GetString.TXTDIALOGTITLE_OK
                            , sCheckOpertion
                            , GetString.BTNOKSTR)
                        return@launch
                    }

                    if (sCheckDepoComment.isNotEmpty())
                    {
                        OkDialog.show(supportFragmentManager
                            , GetString.TXTDIALOGTITLE_OK
                            , sCheckDepoComment
                            , GetString.BTNOKSTR)
                        return@launch
                    }
                    //---[Addition] 2021.07.21 by jy.Lim (Begin)
                    if (sCheckThicknessComment.isNotEmpty())
                    {
                        OkDialog.show(supportFragmentManager
                            , GetString.TXTDIALOGTITLE_OK
                            , sCheckThicknessComment
                            , GetString.BTNOKSTR)
                        return@launch
                    }
                    //---[Addition] 2021.07.21 by jy.Lim (End)
                    if (sCheckRecycleComment.isNotEmpty())
                    {
                        OkDialog.show(supportFragmentManager
                            , GetString.TXTDIALOGTITLE_OK
                            , sCheckRecycleComment
                            , GetString.BTNOKSTR)
                        return@launch
                    }
                }
                //---[Addition] 2015.11.04 by jy.Lim (Begin)
                if(sMaxbatchMessage.isNotEmpty())
                {
                    OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_OK
                        , sMaxbatchMessage
                        , GetString.BTNOKSTR)
                    return@launch
                }
                //---[Addition] 2015.11.04 by jy.Lim (End)

                //---[Addition] 2020.06.11 by jy.Lim (Begin)
                if (sQtimeCheck.isNotEmpty())
                {
                    OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_OK
                        , sQtimeCheck
                        , GetString.BTNOKSTR)
                }
                //---[Addition] 2020.06.11 by jy.Lim (Begin)

                if (sFqcSample.isNotEmpty())
                {
                    OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_INFORM
                        , sFqcSample
                        , GetString.BTNOKSTR)
                }


                val sCurrentStep= "$sProcessStep($sOperation$sSubOperation)"

                viewBinding.txtProductName.text = sProduct
                viewBinding.txtStep.text = sCurrentStep

                var sThSpec = "Y"

                if (sWaferType == "MW_TEST")
                {
                    sWaferType = "D/W";
                    sThSpec = "N";
                }
                else
                {
                    sViewCount = "";
                    sWaferType = "";
                }

                if(oSearch)
                {

                    getBatchListByLot("")

                    // sJaLotname sMoLotname sJaCount

                    if(sJaLotname == "" &&  sMoLotname =="")
                    {
                        viewBinding.btnPssearch.isEnabled = false
                    }
                    else
                    {
                        psjaCount = "0"
                        viewBinding.btnPssearch.isEnabled = true
                        pslotname = ""
                        if(sJaLotname != "")
                        {
                            viewBinding.btnPssearch.text = "子"
                            if(sJaCount.toInt() == 1) {
                                pslotname = sJaLotname
                            }
                            else {
                                psjaCount = sJaCount
                            }
                        }
                        else
                        {
                            viewBinding.btnPssearch.text = "母"
                            pslotname = sMoLotname
                        }

                    }
                    /*
                    삭제 2023.05.24
                    if (sJaLotname =="" && sMoLotname == "")
                    {
                        viewBinding.btnPssearch.isEnabled = false
                    }
                    else
                    {
                        viewBinding.btnPssearch.isEnabled = true

                        if(sJaLotname != "")
                        {
                            viewBinding.btnPssearch.text = "子"
                            pslotname = sJaLotname
                        }
                        else
                        {
                            viewBinding.btnPssearch.text = "母"
                            pslotname = sMoLotname
                        }
                    }
                    */

                }
                else
                {
                    if(!viewBinding.checkBoxChildBatch.isChecked)  // addtion 2021.01.28 자 Batch 생성시에는 Zone 제한 Check를 하지 않도록 if문 추가
                    {
                        if(sZone != "O")
                        {
                            if(sLimitRecipe == sRecipe) {   // addition 2025.03.11 zone 제한 recipe도 비교하도록 수정
                                OkDialog.show(
                                    supportFragmentManager,
                                    GetString.TXTDIALOGTITLE_ERROR,
                                    "[${viewBinding.editLotNo.text}] Lot은 해당Zone [$sZone]에서 Batch진행 할 수 없습니다. 다시 선택해 주세요.",
                                    GetString.BTNOKSTR
                                )
                                return@launch
                            }
                        }
                    }
                    var lotInfoObject = JSONObject()

                    if(selectedRowIndex == MAX_BATCH_COUNT){
                        OkDialog.show(supportFragmentManager
                            , GetString.TXTDIALOGTITLE_ERROR
                            , "LOT을 입력할 ROW를 먼저 선택하세요."
                            , GetString.BTNOKSTR)
                        viewBinding.editLotNo.setText("")
                        viewBinding.editLotNo.requestFocus()
                        return@launch
                    }

                    for(i in 0 until batchItemList.length()) {
                        if (viewBinding.editLotNo.text.toString() == (batchItemList[i] as JSONObject).opt("LOTID")) {
                            OkDialog.show(
                                supportFragmentManager,
                                GetString.TXTDIALOGTITLE_ERROR,
                                "이미 BATCH구성된 LOT입니다.",
                                GetString.BTNOKSTR
                            )
                            viewBinding.editLotNo.setText("")
                            viewBinding.editLotNo.requestFocus()
                            return@launch
                        }
                    }

                    if(m_lot_sProcessState == "")
                    {
                        m_lot_sProcessState = sProcessState;
                    }
                    else
                    {
                        if(m_lot_sProcessState != sProcessState)
                        {
                            OkDialog.show(
                                supportFragmentManager,
                                GetString.TXTDIALOGTITLE_ERROR,
                                "[${viewBinding.editLotNo.text}] LOT의 상태는  [$sProcessState]\n" +
                                        "이미구성된 LOT의 상태와 동일하지 않아\n" +
                                        "BATCH를 구성할 수 없습니다.",
                                GetString.BTNOKSTR
                            )
                            viewBinding.editLotNo.setText("")
                            viewBinding.editLotNo.requestFocus()
                            return@launch
                        }
                    }

                    //Addition 2022.04.26 jy.Lim (동일한 sProcessoperationType이 아닌경우 InterLock처리 (Begin)
                    //Addition 2022.04.27 jy.Lim (sWaferType != "MW_TEST" 추가하여 Dummy TEST 제외)
                    if (m_lot_sProcessType == "")
                    {
                        if(sProcessname != "MW_TEST")
                        {
                            m_lot_sProcessType = sProcessType
                        }
                    }
                    else
                    {
                        if(sProcessname != "MW_TEST") {
                            if (m_lot_sProcessType != sProcessType) {
                                OkDialog.show(
                                    supportFragmentManager,
                                    GetString.TXTDIALOGTITLE_ERROR,
                                    "[${viewBinding.editLotNo.text}] Lot의 공정은  [$sProcessType] 이며,\n" +
                                            "이전 입력한 Lot의 공정 Type과 달라 Batch 생성이 불가 합니다.",
                                    GetString.BTNOKSTR
                                )
                                viewBinding.editLotNo.setText("")
                                viewBinding.editLotNo.requestFocus()
                                return@launch
                            }
                        }
                    }
                    ///Addition 2022.04.26 jy.Lim(End)

                    ///Addition 2023.05.17 jy.Lim(Begin)
                    if (m_lot_Recipe == "")
                    {
                        if(sProcessname != "MW_TEST")
                        {
                            m_lot_Recipe = sCheckRecipe
                        }
                    }
                    else
                    {
                        if(sProcessname != "MW_TEST") {
                            if (m_lot_Recipe != sCheckRecipe) {
                                OkDialog.show(
                                    supportFragmentManager,
                                    GetString.TXTDIALOGTITLE_ERROR,
                                    "[${viewBinding.editLotNo.text}] Lot의 Recipe는  [$sCheckRecipe] 이며,\n" +
                                            "이전 입력한 Lot의 Recipe와 달라 Batch 생성이 불가 합니다.",
                                    GetString.BTNOKSTR
                                )
                                viewBinding.editLotNo.setText("")
                                viewBinding.editLotNo.requestFocus()
                                return@launch
                            }
                        }
                    }
                    ///Addition 2023.05.17 jy.Lim(End)

                    lotInfoObject.put("NUM", selectedRowIndex)
                    if(viewBinding.radioM.isChecked) {
                        lotInfoObject.put("ISDCOL", "N")
                    } else {
                        lotInfoObject.put("ISDCOL", "Y")
                    }
                    lotInfoObject.put("LOTID", viewBinding.editLotNo.text.toString())
                    lotInfoObject.put("PRODUCT", sProduct)
                    lotInfoObject.put("QUANTITY", sQty)
                    lotInfoObject.put("PROCESSSTEP", sCurrentStep)
                    lotInfoObject.put("OPERATION", sOperation)
                    lotInfoObject.put("SUBOPERATION", sSubOperation)
                    lotInfoObject.put("N", "N")
                    lotInfoObject.put("RECIPE", sRecipe)
                    lotInfoObject.put("VIEWCOUNT", sViewCount)
                    lotInfoObject.put("WAFERTYPE", sWaferType)
                    lotInfoObject.put("THIN", "N")
                    lotInfoObject.put("THSPEC", sThSpec)
                    if(sPtin != ""){
                        lotInfoObject.put("PTIN", "Y")
                    } else {
                        lotInfoObject.put("PTIN", "N")
                    }
                    if(sPtspec != ""){
                        lotInfoObject.put("PTSPEC", "Y")
                    } else {
                        lotInfoObject.put("PTSPEC", "N")
                    }

                    Log.d(TAG, "LOTINFOOBJECT : $lotInfoObject")

                    batchItemList.put(selectedRowIndex, lotInfoObject)

                    updateGrid(false)
                    setButtonStatus()
                }


                viewBinding.editLotNo.setText("")
                viewBinding.editLotNo.requestFocus()

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

                viewBinding.editLotNo.setText("")
                viewBinding.editLotNo.requestFocus()
            }

        }
    }

    private fun getBatchListByLot(lotId: String)
    {
        var sLotName = ""
        batchItemList = JSONArray()

        if(lotId =="")
        {
            if(viewBinding.editLotNo.text.toString() == "" || viewBinding.editLotNo.text.toString() == "D/W")
            {
                OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , "LOT NO를 입력하세요."
                    , GetString.BTNOKSTR)
                return
            }

            sLotName  = viewBinding.editLotNo.text.toString()
        }
        else
        {
            sLotName = lotId
        }

        //val sendMessage = MessageFactoryUtil.batchListByLotInBatch(viewBinding.editLotNo.text.toString(), DeviceInfo.FACILITY, "SERCH")
        val sendMessage = MessageFactoryUtil.batchListByLotInBatch(sLotName, DeviceInfo.FACILITY, "SERCH") // 2022.04.28

        mainScope.launch {
            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.BATCHLISTBYLOT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                Log.d("BatchListByLot", "{$result}")
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sBatchID = messageBody.optString("BATCHID")
                val sEqpID = messageBody.optString("EQPID")
                val sBatchType = messageBody.optString("BATCHTYPE")
                val sMonitorWaferCount = messageBody.optString("MWCOUNT")
                val sRecipe = messageBody.optString("RECIPE")

                viewBinding.txtBatId.text = sBatchID
                viewBinding.editMachine.setText(sEqpID)


                for(i in 1..MAX_BATCH_COUNT) {
                    if(viewBinding.spinnerMonitorWaferCount.getItemAtPosition(i)==sMonitorWaferCount) {
                        viewBinding.spinnerMonitorWaferCount.setSelection(i)
                    }
                }
                if(sBatchType == "R")
                {
                    checkedRadioButton(RadioType.RUN)
                }
                else
                {
                    checkedRadioButton(RadioType.M)

                }

                val sPbatchID = messageBody.optString("PARENTBATCHID")
                val sChildZone = messageBody.optString("CHILDZONE")

                if(sPbatchID.isNotEmpty())
                {
                    val spinnerBatchIdList = arrayListOf<String>()
                    spinnerBatchIdList.add(sPbatchID)
                    setBatchIdSpinner(spinnerBatchIdList)

                    viewBinding.spinnerBatchId.setSelection(1)
                    viewBinding.spinnerBatchId.isEnabled = false
                    viewBinding.checkBoxChild.isEnabled = false
                }
                else
                {
                    viewBinding.checkBoxChild.isEnabled = true
                }


                if(sChildZone.isNotEmpty())
                {
                    viewBinding.spinnerZone.isEnabled = false

                    for(i in 1..MAX_BATCH_COUNT){
                        if(viewBinding.spinnerZone.getItemAtPosition(i)==sChildZone) {
                            viewBinding.spinnerZone.setSelection(i)
                        }
                    }
                }

                val itemList = ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "BATCHITEMS")

                for(i in 0 until itemList.length()){
                    val lotInfoObject = JSONObject()
                    lotInfoObject.put("NUM", i.toString())
                    lotInfoObject.put("ISDCOL", (itemList[i] as JSONObject).opt("ISDCOL"))
                    lotInfoObject.put("LOTID", (itemList[i] as JSONObject).opt("LOTID"))
                    lotInfoObject.put("QUANTITY", (itemList[i] as JSONObject).opt("QUANTITY"))
                    lotInfoObject.put("PROCESSSTEP", (itemList[i] as JSONObject).opt("PROCESSSTEP"))
                    lotInfoObject.put("OPERATION", (itemList[i] as JSONObject).opt("OPERATION"))
                    lotInfoObject.put("SUBOPERATION", (itemList[i] as JSONObject).opt("SUBOPERATION"))
                    lotInfoObject.put("VIEWCOUNT", (itemList[i] as JSONObject).opt("VIEWCOUNT"))
                    lotInfoObject.put("WAFERTYPE", "")


                    if(!(itemList[i] as JSONObject).opt("LOTID")?.toString().isNullOrEmpty()){
                        lotInfoObject.put("PRODUCT", (itemList[i] as JSONObject).opt("PRODUCT"))
                        lotInfoObject.put("RECIPE", sRecipe)

                        if(!(itemList[i] as JSONObject).opt("PTIN")?.toString().isNullOrEmpty()){
                            lotInfoObject.put("PTIN", "Y")
                        } else {
                            lotInfoObject.put("PTIN", "N")
                        }

                        if(!(itemList[i] as JSONObject).opt("PTSPEC")?.toString().isNullOrEmpty()){
                            lotInfoObject.put("PTSPEC", "Y")
                        } else {
                            lotInfoObject.put("PTSPEC", "N")
                        }

                        if(!(itemList[i] as JSONObject).opt("PTSPEC")?.toString().isNullOrEmpty()){
                            lotInfoObject.put("PTSPEC", "Y")
                        } else {
                            lotInfoObject.put("PTSPEC", "N")
                        }

                        if(!(itemList[i] as JSONObject).opt("THIN")?.toString().isNullOrEmpty()){
                            lotInfoObject.put("THIN", "Y")
                        } else {
                            lotInfoObject.put("THIN", "N")
                        }

                        if(!(itemList[i] as JSONObject).opt("THSPEC")?.toString().isNullOrEmpty()){
                            lotInfoObject.put("THSPEC", "Y")
                        } else {
                            lotInfoObject.put("THSPEC", "N")
                        }
                    }

                    lotInfoObject.put("STATUS",(itemList[i] as JSONObject).opt("STATUS"))

                    if(lotInfoObject.optString("LOTID").isNotEmpty()) {
                        batchItemList.put(lotInfoObject)
                    }
                }

                if(batchItemList.length()<MAX_BATCH_COUNT){
                    val emptyObject = JSONObject()
                    emptyObject.put("NUM", batchItemList.length())
                    batchItemList.put(emptyObject)
                }

                updateGrid(true)
                setButtonStatus()

                for(row in gridList.mainTable.children){
                    val status = gridService.getCellValue(row,"STATUS")
                    val thuvTextView = (row as CTRowLayout).getChildAt(2) as TextView
                    if(status == "RUN")
                    {
                        //gridService.setBodyCellColor(row, Color.parseColor("#00000000"))
                        //row.setBackgroundColor(Color.parseColor("#00000000"))
                        //row.setBackgroundResource(R.drawable.esheet_opertype_pm_color)
                        //row.setBackgroundColor(Color.rgb(153,255,255))
                        thuvTextView.setTextColor(Color.parseColor("#00c936"))

                    }
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

            }

        }

    }

    private fun getBatchCount() {
        val sendMessage = MessageFactoryUtil.batchCountSearch()

        mainScope.launch {
            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.BATCHCOUNTSERCH)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                Log.d("batchcount", "{$result}")
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val sBatchCountView = messageBody.optString("BATCHCOUNTVIEW")

                if(sBatchCountView.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager,
                        "BATCH COUNT 확인",
                        sBatchCountView,
                        GetString.BTNOKSTR
                    )
                } else {
                    OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_ERROR
                        , "BATCHCOUNT 가 확인되지 않습니다."
                        , GetString.BTNOKSTR)
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

            }

        }
    }

    private fun deleteBatch(){

        var type = "D"
        val batchId = viewBinding.txtBatId.text.toString()
        val eqpId = viewBinding.editMachine.text.toString()
        var batchType = ""
        var childCheck = ""
        var mBatchId : String? = ""
        var childZone : String? = ""
        var operatorId = DeviceInfo.OPERATOR_ID

        if(viewBinding.txtBatId.text.isEmpty())
        {
            OkDialog.show(supportFragmentManager
                , GetString.TXTDIALOGTITLE_ERROR
                , "먼저 BATCH ID를 조회하세요."
                , GetString.BTNOKSTR)
            return
        }

        val returnCode = OkCancelDialog.show(
            supportFragmentManager,
            GetString.TXTDIALOGTITLE_ERROR,
            "[${viewBinding.txtBatId.text}] BATCH ID를 삭제 하시겠습니까?" ,
            GetString.BTNYESSTR,
            GetString.BTNNOSTR
        )
        if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
            return
        }

        childCheck = if(viewBinding.checkBoxChild.isChecked) "Y" else ""

        val sendMessage = MessageFactoryUtil.batchCrt(DeviceInfo.FACILITY,type,batchId,eqpId,batchType,childCheck,mBatchId,childZone,operatorId,
            MAX_BATCH_COUNT.toString(),"","","")

        mainScope.launch {
            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.BATCHCRT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                finish()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

            }

        }
    }

    private fun setBatch(){
        if(viewBinding.radioM.isChecked)
        {
            val monitorWaferCount = viewBinding.spinnerMonitorWaferCount.selectedItem?.toString()
            if(monitorWaferCount.isNullOrEmpty())
            {
                OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , "MONITOR WAFER 갯수를 입력하세요."
                    , GetString.BTNOKSTR)
                return
            }

            if(monitorWaferCount.toString().toInt() > MAX_BATCH_COUNT)
            {
                OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , "MONITOR WAFER 갯수는 6개를 넘을수 없습니다."
                    , GetString.BTNOKSTR)
                return
            }
        }

        if(viewBinding.editMachine.text.toString().isEmpty())
        {
            OkDialog.show(supportFragmentManager
                , GetString.TXTDIALOGTITLE_ERROR
                , "장비를 입력하세요."
                , GetString.BTNOKSTR)
            return
        }

        var batchList =  arrayListOf<String>()

        for (mainRow in gridList.mainTable.children) {

            var sZone =  ((mainRow as ViewGroup).getChildAt(1) as TextView).text
            val sLotID = gridService.getCellValue(mainRow, "LOTID")
            val sProduct = gridService.getCellValue(mainRow, "PRODUCT")
            val sQuantity = gridService.getCellValue(mainRow, "QUANTITY")
            val sOperation = gridService.getCellValue(mainRow, "OPERATION")
            val sSubOperation = gridService.getCellValue(mainRow, "SUBOPERATION")
            val sLotType = gridService.getCellValue(mainRow, "WAFERTYPE")
            val sThin = ((mainRow as ViewGroup).getChildAt(12) as TextView).text
            val sPtin = ((mainRow as ViewGroup).getChildAt(14) as TextView).text


            if (viewBinding.radioM.isChecked || sLotID == "D/W" || sLotType == "D/W") {
                sZone = "N"
            }

            batchList.add("""
                |<ITEM>
                |<ZONE>$sZone</ZONE>
                |<LOTID>$sLotID</LOTID>
                |<OPERATION>$sOperation</OPERATION>
                |<SUBOPERATION>$sSubOperation</SUBOPERATION>
                |<SLOTTYPE>$sLotType</SLOTTYPE>
                |<PTIN>$sPtin</PTIN>
                |<THIN>$sThin</THIN>
                |</ITEM>
                |
                """.trimMargin())
        }

        while(batchList.size< MAX_BATCH_COUNT){
            batchList.add("""
                |<ITEM>
                |<ZONE></ZONE>
                |<LOTID></LOTID>
                |<OPERATION></OPERATION>
                |<SUBOPERATION></SUBOPERATION>
                |<SLOTTYPE></SLOTTYPE>
                |<PTIN></PTIN>
                |<THIN></THIN>
                |</ITEM>
                |
                """.trimMargin())
        }

        if(viewBinding.checkBoxChild.isChecked) {
            if (viewBinding.spinnerBatchId.selectedItem?.toString().isNullOrEmpty() || viewBinding.spinnerZone.selectedItem?.toString().isNullOrEmpty())
            {
                OkDialog.show(supportFragmentManager
                    , "필수 입력"
                    , "모 BATCH ID와 자 ZONE을 입력 하세요."
                    , GetString.BTNOKSTR)
                return
            }
            createBatch(batchList, "")
        } else {
            setBatchCheck(batchList)
        }

    }

    private fun createBatch(batchList : ArrayList<String>, addMessage:String) {
        var type = "M"
        val batchId = viewBinding.txtBatId.text.toString()
        val eqpId = viewBinding.editMachine.text.toString()
        var batchType = "M"
        var childCheck = ""
        var mBatchId : String? = ""
        var childZone : String? = ""
        var operatorId = DeviceInfo.OPERATOR_ID

        if(viewBinding.checkBoxChild.isChecked){
            childCheck = "Y"
            mBatchId = viewBinding.spinnerBatchId.selectedItem?.toString()
            childZone = viewBinding.spinnerZone.selectedItem?.toString()
            operatorId = "[Y]$operatorId"
        }

        var nDummyCount = 0

        //---[Addition] May 18, 2004. I. H. Lee
        // Run Count가 되지 않도록 되어 있어 이를 개선함
        var	nRunCount = 0

        for(mainRow in gridList.mainTable.children){
            val type = gridService.getCellValue(mainRow, "WAFERTYPE")

            if(type == "D/W"){
                nDummyCount++
            } else {
                nRunCount++
            }
        }

        var mwCount : String? = ""
        if(!viewBinding.radioM.isChecked)
        {
            mwCount = nRunCount.toString()
        } else {
            mwCount = viewBinding.spinnerMonitorWaferCount.selectedItem?.toString()!!
        }

        if(batchId.isEmpty())
        {
            type= "C"
        }

        if(viewBinding.radioRun.isChecked)
        {
            batchType = "R"
        }

        var batchItems = ""
        for(a in batchList){
            batchItems += a
        }

        val sendMessage = MessageFactoryUtil.batchCrt(DeviceInfo.FACILITY,type,batchId,eqpId,batchType,childCheck,mBatchId,childZone,operatorId,
            MAX_BATCH_COUNT.toString(),mwCount,batchItems,addMessage)

        mainScope.launch {
            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.BATCHCRT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sInterlockMsg = messageBody.optString("INTERLOCKMSG")
                val sttInterlockMsg = messageBody.optString("TTINTERLOCKMSG")
                val sNoticeDown = messageBody.optString("NOTICEDOWN");

                if(sInterlockMsg != "")
                {
                    OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_WARNING
                        , sInterlockMsg
                        , GetString.BTNOKSTR)
                }

                if(sttInterlockMsg != "")
                {
                    OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_WARNING
                        , sttInterlockMsg
                        , GetString.BTNOKSTR)
                }

                if(sNoticeDown != "")
                {
                    OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_WARNING
                        , sNoticeDown
                        , GetString.BTNOKSTR)
                }


                finish()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

            }

        }
    }

    private fun setBatchCheck(batchList : ArrayList<String>){

        var childCheck = "N"

        if(viewBinding.checkBoxChild.isChecked){
            childCheck = "Y"
        }

        var batchItems = ""
        for(a in batchList){
            batchItems += a
        }

        val sendMessage = MessageFactoryUtil.batchCrtCheck(DeviceInfo.FACILITY,viewBinding.editMachine.text.toString(), childCheck, batchItems)

        mainScope.launch {
            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.BATCHCRTCHECK)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sSampleMsg = messageBody.optString("BATCHMESSGE");
                val sCumcount =  messageBody.optString("CUMCOUNT");
                val sMaxcount =  messageBody.optString("MAXCOUNT");
                val sUpFlag = messageBody.optString("UPDATEFLAG");
                val sUVFlag = messageBody.optString("UVFLAG");
                val sSampleCycle = messageBody.optString("SAMPLECYCLE");
                val sRemote = messageBody.optString("REMOTE");

                if (sSampleMsg != "")
                {
                    val returnCode = OkCancelDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_ERROR,
                        "$sSampleMsg\n\n선택을 하시겠습니까?",
                        GetString.BTNYESSTR,
                        GetString.BTNNOSTR
                    )

                    if (returnCode == OkCancelDialog.RETURN_CODE_OK) {
                        return@launch
                    }
                }

                var createBatchAddMessage = ""

                if (sSampleCycle!= "")
                {
                    createBatchAddMessage =
                        """
                        |<CUMCOUNT>$sCumcount</CUMCOUNT>
                        |<MAXCOUNT>$sMaxcount</MAXCOUNT>
                        |<UPDATEFLAG>$sUpFlag</UPDATEFLAG>
                        |<UVFLAG>$sUVFlag</UVFLAG>
                        |<SAMPLECYCLE>$sSampleCycle</SAMPLECYCLE>
                        |""".trimMargin()
                }

                if(sRemote != "")
                {
                    OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_INFORM
                        , "Remote 장비 입니다."
                        , GetString.BTNOKSTR)
                }

                createBatch(batchList, createBatchAddMessage)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

            }
        }
    }

    private fun setButtonStatus() {

        if(selectedRowIndex==MAX_BATCH_COUNT) {
            viewBinding.btnDeleteBatch.isEnabled = false
        } else {
            val selectedLotId = (batchItemList[selectedRowIndex] as JSONObject).opt("LOTID")?.toString()
            if(!selectedLotId.isNullOrEmpty() && selectedRowIndex==MAX_BATCH_COUNT-1){
                viewBinding.btnDeleteBatch.isEnabled = true
            } else {
                viewBinding.btnDeleteBatch.isEnabled = !selectedLotId.isNullOrEmpty() && selectedRowIndex == batchItemList.length()-2
            }
        }


        if(viewBinding.txtBatId.text.toString().isEmpty())
        {
            viewBinding.btnChange.setText("등록")
            viewBinding.btnDelete.isEnabled = false
        }
        else
        {
            viewBinding.btnChange.setText("변경")
            viewBinding.btnDelete.isEnabled = true
        }

        if(viewBinding.radioRun.isChecked){
            for(zoneView in zoneViewList) {
                zoneView.isGone = false
            }
        } else {
            for(zoneView in zoneViewList) {
                zoneView.isGone = true
            }
        }
        //      viewBinding.btnSearch.isEnabled = viewBinding.editLotNo.text.toString() != "" && viewBinding.editLotNo.text.toString() != "D/W"

        viewBinding.spinnerMonitorWaferCount.isEnabled = viewBinding.radioM.isChecked

        if(!viewBinding.checkBoxChild.isChecked)
        {
            viewBinding.spinnerBatchId.isEnabled = false
            viewBinding.spinnerZone.isEnabled = false
        }

    }

    private fun updateGrid(batchFlag:Boolean){
        viewBinding.baseLayout.removeAllViews()

        if(!batchFlag) {
            selectedRowIndex++
        }

        if(batchItemList.length()<MAX_BATCH_COUNT && selectedRowIndex == batchItemList.length()) {
            val emptyObject = JSONObject()
            emptyObject.put("NUM", selectedRowIndex)
            batchItemList.put(emptyObject)
        }

        gridList = gridService.setGridPropData(columnData, batchItemList)

        viewBinding.baseLayout.addView(gridList)

        selectBatchLot(gridList)

        if(selectedRowIndex<MAX_BATCH_COUNT) {
            val addRow = gridList.mainTable.children.elementAt(selectedRowIndex) as CTRowLayout
            addRow.isSelected = true
            addRow.setBackgroundColor(Color.rgb(168, 200, 240))
        }
    }

    private fun getParentBatchId() {
        var sLotID = ""
        for(mainRow in gridList.mainTable.children){
            val sTemplot = gridService.getCellValue(mainRow, "LOTID")
            val sTempType = gridService.getCellValue(mainRow, "WAFERTYPE")

            if(sTemplot != "" || sTempType != "D/W")
            {
                sLotID = if (sLotID != "") {
                    "$sLotID,$sTemplot"
                } else {
                    sTemplot
                }
            }
        }

        if(viewBinding.editMachine.text.toString().isEmpty())
        {
            OkDialog.show(supportFragmentManager
                , GetString.TXTDIALOGTITLE_ERROR
                , "장비명 먼저 입력후 선택하세요"
                , GetString.BTNOKSTR)
            return
        }

        // 입력된 Lot이 없는 경우
        if(sLotID.isEmpty() || sLotID == null|| sLotID == "null")
        {
            OkDialog.show(supportFragmentManager
                , GetString.TXTDIALOGTITLE_ERROR
                , "LOT 먼저 입력후 선택하세요"
                , GetString.BTNOKSTR)
            viewBinding.checkBoxChild.isChecked = false
            return
        }

        val sendMessage = MessageFactoryUtil.getParentBatchId(DeviceInfo.FACILITY, sLotID, viewBinding.editMachine.text.toString())

        mainScope.launch {
            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.GETPARENTBATCHID)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val batchIdList = ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "ITEMS")

                val spinnerBatchIdList = arrayListOf<String>()
                for (i in 0 until batchIdList.length()) {
                    val batchId = batchIdList.getJSONObject(i)
                    spinnerBatchIdList.add(batchId.optString("BATCHID"))
                }

                if(spinnerBatchIdList.size>0) {
                    setBatchIdSpinner(spinnerBatchIdList)
                    viewBinding.spinnerBatchId.setSelection(1)
                    viewBinding.spinnerBatchId.isEnabled = true
                    viewBinding.spinnerZone.isEnabled = true
                }

            } else {
                viewBinding.checkBoxChild.isChecked = false
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

            }

        }

    }

    private fun selectBatchLot(gridData: CTMainLayout) {
        val columnHeaderList = CTSubLayout(this, GridType.COLUMN_GRID)
        gridData.columnHeaderTable.getChildAt(0) as TableRow

        zoneViewList.clear()
        zoneViewList.add((gridData.columnHeaderTable.getChildAt(0) as TableRow)[1] as TextView)

        for (row in gridData.mainTable.children) {
            val zoneTextView = (row as CTRowLayout).getChildAt(1) as TextView
            zoneViewList.add(zoneTextView)
            zoneTextView.setOnClickListener(object : OnSingleClickListener() {
                override fun onSingleClick(it: View) {
                    if((row.getChildAt(2) as TextView).text.toString()!="D/W" && viewBinding.radioRun.isChecked) {
                        if (zoneTextView.text == "N") {
                            zoneTextView.text = "Y"
                        } else if (zoneTextView.text == "Y") {
                            zoneTextView.text = "N"
                        }
                    }
                }
            })

            val thuvTextView = (row as CTRowLayout).getChildAt(12) as TextView
            thuvTextView.setOnClickListener(object : OnSingleClickListener() {
                override fun onSingleClick(it: View) {
                    if((row.getChildAt(13) as TextView).text.toString()=="Y" ) {
                        if (thuvTextView.text == "N") {
                            thuvTextView.text = "Y"
                        } else if (thuvTextView.text == "Y") {
                            thuvTextView.text = "N"
                        }
                    }
                }
            })


            val ptTextView = (row as CTRowLayout).getChildAt(14) as TextView
            ptTextView.setOnClickListener(object : OnSingleClickListener() {
                override fun onSingleClick(it: View) {
                    if((row.getChildAt(2) as TextView).text.toString()!="D/W" && (row.getChildAt(2) as TextView).text.toString()!="" && (row.getChildAt(13) as TextView).text.toString()=="Y" ) {
                        if((row.getChildAt(15) as TextView).text.toString()=="Y") {
                            if (ptTextView.text == "N") {
                                ptTextView.text = "Y"
                            } else if (ptTextView.text == "Y") {
                                ptTextView.text = "N"
                            }
                        }
                    }
                }
            })

            row.setOnTouchListener { v, event ->
                for(row in gridData.mainTable.children){
                    if(row.isSelected){
                        row.setBackgroundColor(Color.parseColor("#00FFFFFF"))
                    }
                }

                selectedRowIndex = (row.getChildAt(0) as TextView).text.toString().toInt()

                val selectedLotId = (row.getChildAt(2) as TextView).text.toString()
                val selectedStaticCount = (row.getChildAt(10) as TextView).text.toString()
                viewBinding.editLotNo.setText(selectedLotId)
                viewBinding.txtProductName.text = (row.getChildAt(3) as TextView).text.toString()
                viewBinding.txtCount.text = selectedStaticCount

                if(selectedLotId.isEmpty()){
                    viewBinding.txtStep.text = ""
                } else if(selectedLotId=="D/W"||selectedStaticCount=="D/W"){
                    viewBinding.txtStep.text = "D/W"
                }
                viewBinding.txtStep.text = (row.getChildAt(5) as TextView).text.toString() +
                        "(" +  (row.getChildAt(6) as TextView).text.toString() +  (row.getChildAt(7) as TextView).text.toString() + ")"

                row.setBackgroundColor(Color.rgb(168, 200, 240))
                row.isSelected = true

                setButtonStatus()

                true
            }
        }
    }

    private fun getZone(){
        val sMBatchID = viewBinding.spinnerBatchId.selectedItem?.toString()
        if(sMBatchID.isNullOrEmpty())
        {
            return
        }
        val sendMessage = MessageFactoryUtil.getBatchZone(DeviceInfo.FACILITY, sMBatchID)

        mainScope.launch {
            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.GETBATCHZONE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val zone = messageBody.optString("ZONE")

                for(i in 1..MAX_BATCH_COUNT){
                    if(viewBinding.spinnerZone.getItemAtPosition(i)==zone) {
                        viewBinding.spinnerZone.setSelection(i)
                    }
                }
            } else {
                viewBinding.checkBoxChild.isChecked = false
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

            }

        }

    }

    private fun setBatchOrderSpinner(items : ArrayList<String>){
        //1. set spinner
        val spinnerAdapter = ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, items)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerMonitorWaferCount.adapter = InitSpinnerAdapter(spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext)
    }

    private fun setBatchIdSpinner(items : ArrayList<String>){
        //1. set spinner
        val spinnerAdapter = ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, items)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerBatchId.adapter = InitSpinnerAdapter(spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext)

        viewBinding.spinnerBatchId.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View,
                position: Int,
                id: Long
            ) {
                if(viewBinding.checkBoxChild.isChecked) {
                    getZone()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }
    }

    private fun setZoneSpinner(items : ArrayList<String>){
        //1. set spinner
        val spinnerAdapter = ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, items)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerZone.adapter = InitSpinnerAdapter(spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext)
    }
}