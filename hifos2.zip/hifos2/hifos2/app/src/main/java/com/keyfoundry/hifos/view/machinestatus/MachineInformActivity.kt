package com.keyfoundry.hifos.view.machinestatus

import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityMachineInformBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.batch.BatchsubActivity
import com.keyfoundry.hifos.view.dialog.MachineSelectDialogActivity
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.machinestatus.detail.MachineStatusDetailActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MachineInformActivity : HFActivity() {
    companion object {
        private const val TAG = "MachineInformActivity"
    }

    private lateinit var viewBinding: ActivityMachineInformBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityMachineInformBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editEqpId.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        viewBinding.editEqpId.setOnEditorActionListener(onEditorListener)

        viewBinding.btnSearchMachine.setOnClickListener(onSingleClickListener)
        viewBinding.btnChange.setOnClickListener(onSingleClickListener)
        viewBinding.btnClose.setOnClickListener(onSingleClickListener)

        if(intent.getStringExtra("MACHINENAME")?.isNotEmpty() == true){
            viewBinding.editEqpId.setText(intent.getStringExtra("MACHINENAME"))
            getMachineInform("DEFAULT")
        }


        viewBinding.radioGroup.setOnCheckedChangeListener { group, checkedId ->
            val type = when (checkedId) {
                viewBinding.radioMachine.id -> "MACHINE"
                viewBinding.radioOperation.id -> "PROCESS"
                else -> "UNKNOWN"
            }
            getMachineInform("DEFAULT")
        }

    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchMachine.id -> {
                    getMachineInform("DEFAULT")
                }
                viewBinding.btnChange.id -> {
                    setMachineInform()
                }
                viewBinding.btnClose.id -> {
                    finish()
                }
            }
        }
    }

    private val onEditorListener =
        TextView.OnEditorActionListener { v: TextView?, actionId: Int, event: KeyEvent? ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                when (v?.id) {
                    viewBinding.editEqpId.id -> {
                        val check = BarcodeStyle(this).eqpId(viewBinding.editEqpId)

                        if (check)
                            getMachineInform("DEFAULT")
                        else
                            clearInfo()

                        viewBinding.editEqpId.requestFocus()
                        viewBinding.editEqpId.selectAll()
                    }


                }
            } else if (event != null) { // Barcode Event
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    when (v?.id) {
                        viewBinding.editEqpId.id -> {
                            val check = BarcodeStyle(this).eqpId(viewBinding.editEqpId)

                            if (check)
                                getMachineInform("DEFAULT")
                            else
                                clearInfo()

                            viewBinding.editEqpId.requestFocus()
                            viewBinding.editEqpId.selectAll()
                        }

                    }
                }
            }

            true
        }

    private fun clearInfo() {

        viewBinding.editInformContent.setText("")
    }

    private fun getMachineInform(type:String) {

        var sType = type
        if(type=="DEFAULT") {
            sType = "MACHINE"
            if (viewBinding.radioOperation.isChecked) {
                sType = "PROCESS"
            }
        }

        mainScope.launch {
            val sendMessage = MessageFactoryUtil.getMachineInform(DeviceInfo.FACILITY, sType, viewBinding.editEqpId.text.toString())
            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if(isSuccessFul){

                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                viewBinding.editInformContent.setText(messageBody.optString("INFORM_CONTENT"))
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setMachineInform() {

        var type = "MACHINE"
        if(viewBinding.radioOperation.isChecked){
            type = "PROCESS"
        }

        mainScope.launch {
            val sendMessage = MessageFactoryUtil.addMachineInform(DeviceInfo.FACILITY, type, viewBinding.editEqpId.text.toString(), viewBinding.editInformContent.text.toString(), DeviceInfo.OPERATOR_ID)
            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if(isSuccessFul){

                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                viewBinding.editInformContent.setText(messageBody.optString("INFORM_CONTENT"))

                getMachineInform("DEFAULT")

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }

    }

}