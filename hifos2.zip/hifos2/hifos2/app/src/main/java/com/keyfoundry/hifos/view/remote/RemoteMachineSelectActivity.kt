package com.keyfoundry.hifos.view.remote

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.os.Bundle
import android.os.Vibrator
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityRemoteMachineSelectBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDailogAlram
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class RemoteMachineSelectActivity : HFActivity() {
    companion object {
        private const val TAG = "AutomationActivity"
    }

    lateinit var viewBinding: ActivityRemoteMachineSelectBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var treeFlag = ""
    private var searchC1Stepper = ""
    private var searchArea = ""
    private var searchOperation = ""
    private var searchSubOperation = ""
    private var searchOperDesc = ""
    private var searchLocal = ""
    private var mainEqpId = ""
    private var searchRemoteCode = ""
    private var searchOperMode = ""
    private var searchLayerId = ""
    private var searchRandomFlag = ""
    private var searchEqpType = ""
    private var searchBarcCount = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityRemoteMachineSelectBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.txtEqpGroup.movementMethod = ScrollingMovementMethod.getInstance()

        //소문자 -> 대문자
        viewBinding.editMachineSelect.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.btnRePort.isEnabled = false;

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()
            viewBinding.txtLotNo.text = lotId

            if (lotId.isNotEmpty()) {
                searchData(lotId)
            }
        }

        viewBinding.editMachineSelect.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                val check = BarcodeStyle(this).eqpId(viewBinding.editMachineSelect)

                if (check)
                    setEQPInfo()
            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).eqpId(viewBinding.editMachineSelect)

                    if (check)
                        setEQPInfo()
                }
            }

            true
        }

        viewBinding.spinnerPort.onItemSelectedListener = itemSelectedListener

        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnClose.setOnClickListener(onSingleClickListener)
        viewBinding.btnRePort.setOnClickListener(onSingleClickListener)
    }

    private fun clearLotInfo() {
        treeFlag = ""
        searchC1Stepper = ""
        searchArea = ""
        searchOperation = ""
        searchSubOperation = ""
        searchOperDesc = ""

        viewBinding.txtStatus.text = ""
        viewBinding.txtProduct.text = ""
        viewBinding.txtJobCode.text = ""
        viewBinding.txtCurrentOper.text = ""
        viewBinding.txtNextOper.text = ""
        viewBinding.txtHold.text = ""
        viewBinding.txtQty.text = ""
        viewBinding.txtEqpGroup.text = ""

        clearEQPInfo()
    }

    private fun searchData(lotId: String) {
        mainScope.launch {
            clearLotInfo()

            if (lotId.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT NO를 입력하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.lotInfo("MVIN", lotId, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val product = messageBody.optString("PRODUCT")
                val facility = messageBody.optString("FACILITY")
                var operation = messageBody.optString("OPERATION")
                val customer = messageBody.optString("CUSTOMER")
                val category = messageBody.optString("CATEGORY")
                val engineer = messageBody.optString("ENGINEER")
                val packing = messageBody.optString("PACKING")
                val qty = messageBody.optString("QUANTITY")
                val goodChips = messageBody.optString("GOODCHIPS")
                val recipe = messageBody.optString("RECIPE")
                val eqpGroup = messageBody.optString("EQPGROUP")
                val commentQty = messageBody.optString("COMMENTQTY")
                val wCommentQty = messageBody.optString("WCOMMENTQTY")
                val batchId = messageBody.optString("BATCHID")
                val area = messageBody.optString("AREA")
                val workedEqpId = messageBody.optString("WORKEDEQPID")
                val workedRecipe = messageBody.optString("WORKEDRECIPE")
                val workedReticle = messageBody.optString("WORKEDRETICLE")
                val jobCode = messageBody.optString("JOBCODE")
                val processStep = messageBody.optString("PROCESSSTEP")
                val subOperation = messageBody.optString("SUBOPERATION")
                val opType = messageBody.optString("OPTYPE")
                val status = messageBody.optString("STATUS")
                val state = messageBody.optString("STATE")
                val holdStatus = messageBody.optString("HOLDSTATUS")
                val nextOperation = messageBody.optString("NEXTOPERATION")
                val nextSubOperation = messageBody.optString("NEXTSUBOPERATION")
                val nextProcessStep = messageBody.optString("NEXTPROCESSSTEP")
                val reworkInfo = messageBody.optString("REWORKINFO")
                val holdCode = messageBody.optString("HOLDCODE")
                val reworkCode = messageBody.optString("REWORKCODE")
                val dueDate = messageBody.optString("DUEDATE")
                val owner = messageBody.optString("OWNER")
                val bay = messageBody.optString("BAY")
                val stocker = messageBody.optString("STOCKER")
                val currentEqpID = messageBody.optString("CURRENTEQPID")
                val enabledWaferList = messageBody.optString("WAFERLIST")
                val lotResUser = messageBody.optString("LOTRESUSER")
                val treeStatus = messageBody.optString("TREEFLAG")
                val c1Stepper = messageBody.optString("C1STEPPERNAME")
                val photoType =
                    messageBody.optString("PHOTOTYPE")//---[Addition] 2015.02.10 HV Asher공정 Photo 진행 관련 PhotoType 추가 wjKim
                val inlineSample =
                    messageBody.optString("INLINESAMPLEMESSGE")//---[Addition] 2015.03.18 Inline Sampling Messge 추가 메세지가 있다면  POP_up  jy.Lim
                val eqpType =
                    messageBody.optString("EQPTYPE")//---[Addition] 2015.04.23 END PHOTO 자동화 진행 대응 -wj.Kim
                val eqpModel = messageBody.optString("EQP_MODEL")

                //val prName = messageBody.optString("PRNAME")//20171114 jmlee
                //val sampleFlag = messageBody.optString("SAMPLEFLAG")//20171114 jmlee

                //int aa = sPRNAME.Find('=',0);
                //int bb = sSampleflag.Find('=',0);

                //m_sPRname = sPRNAME;
                //m_sSampleflag = sSampleflag.Mid(bb,sSampleflag.GetLength());
                //m_sRecipe = sRecipe;

                val currentOper = "$processStep($operation$subOperation)"
                val nextOper = "$nextProcessStep($nextOperation$nextSubOperation)"

                treeFlag = treeStatus
                searchC1Stepper = c1Stepper
                //20171114 jmlee
                searchOperation = operation
                searchSubOperation = subOperation
                searchOperDesc = processStep
                //searchArea = area
                //m_sBay = sBay;
                //m_sLotType = sCategory;

                if (state == "WIP")
                    viewBinding.txtStatus.text = status
                else
                    viewBinding.txtStatus.text = state

                setStatusColor()

                viewBinding.txtProduct.text = product
                viewBinding.txtJobCode.text = jobCode
                viewBinding.txtCurrentOper.text = currentOper
                viewBinding.txtNextOper.text = nextOper

                if (holdStatus == "ONHOLD")
                    viewBinding.txtHold.text = "Y"
                else
                    viewBinding.txtHold.text = "N"

                viewBinding.txtQty.text = qty
                viewBinding.txtEqpGroup.text = eqpGroup

                if (operation == "10000")
                    operation = "10005"

//                if(reworkInfo == "R")
//                    reworkYN = "Y"
//                else
//                    reworkYN = "N"

                if (status == "RUN") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 MOVE IN된 LOT입니다.", GetString.BTNOKSTR
                    )
                    viewBinding.editMachineSelect.isEnabled = false
                    viewBinding.btnOk.isEnabled = false

                    return@launch
                }

                if (state != "WIP" && operation != "10005") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "$state 상태 입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )
                    viewBinding.editMachineSelect.isEnabled = false
                    viewBinding.btnOk.isEnabled = false

                    return@launch
                }

                if (holdStatus == "ONHOLD") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "HOLD된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )
                    viewBinding.editMachineSelect.isEnabled = false
                    viewBinding.btnOk.isEnabled = false

                    return@launch
                }

                if (inlineSample.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.BTNOKSTR,
                        inlineSample, GetString.BTNOKSTR
                    )
                }

//                if(opType == "M"&&processStep.contains("CD"))
                if (opType == "M" && photoType != "DI" && !processStep.contains("CD")) {
                    val nextIntent = Intent(applicationContext, RemoteMeasActivity::class.java)
                    nextIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                    activityFactoryResultLauncher.launch(nextIntent)
                }
                //201012 UK DI이거나 CD인 경우
//                else if (photoType == "PH" || eqpType == "TRACK" || eqpType == "STEPPER" || (opType == "M" && eqpModel == "" && processStep.contains("CD")))
                else if (photoType == "PH" || eqpType == "TRACK" || eqpType == "STEPPER" || (opType == "M" && eqpModel == ""
                            && (photoType == "DI" || processStep.contains("CD")))
                ) {
                    if (treeFlag == "Y") {
                        if (searchC1Stepper.isEmpty()) {
                            OkDialog.show(
                                supportFragmentManager, GetString.BTNOKSTR,
                                "Tree 진행 설정되었으나 이전 진행 장비를 찾을수 없습니다. 장비 ASSIGN 후 진행바랍니다.",
                                GetString.BTNOKSTR
                            )

                            viewBinding.editMachineSelect.isEnabled = false
                            viewBinding.btnOk.isEnabled = false

                            return@launch
                        } else {
                            OkDialog.show(
                                supportFragmentManager,
                                GetString.BTNOKSTR,
                                "Tree 진행 설정된 LOT입니다. $searchC1Stepper 에서 자동화 진행 가능합니다.",
                                GetString.BTNOKSTR
                            )
                            viewBinding.btnOk.isEnabled = false

                            return@launch
                        }
                    }
                } else if (area == "IMP") {
                    val nextIntent = Intent(applicationContext, RemoteImpMainActivity::class.java)
                    nextIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                    activityFactoryResultLauncher.launch(nextIntent)
//                } else if (eqpModel == "RAM8500I" || eqpModel == "RAM8500Z") {
//                    val nextIntent = Intent(applicationContext, RemoteRamcoActivity::class.java)
//                    nextIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
//                    activityFactoryResultLauncher.launch(nextIntent)
                } else if (area != "PHOTO" && !(operation == "70000" && (subOperation == "02" || subOperation == "10" || subOperation == "11"))) {
                    val nextIntent = Intent(applicationContext, RemoteCvdActivity::class.java)
                    nextIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                    activityFactoryResultLauncher.launch(nextIntent)
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private val activityFactoryResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                setResult(RESULT_OK)
                finish()
            } else {
                setResult(RESULT_CANCELED)
                finish()
            }
        }

    private fun setEQPInfo() {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@RemoteMachineSelectActivity, currentFocus)

            clearEQPInfo()

//            if (searchArea != "PHOTO" && !(searchOperation == "70000" && (searchSubOperation == "10" || searchOperation == "11")))
//            if (searchArea != "PHOTO") {
//                OkDialog.show(
//                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
//                    "PHOTO 진행 LOT이 아닙니다.", GetString.BTNOKSTR
//                )
//                return@launch
//            }

            val tempEqpId = viewBinding.editMachineSelect.text.toString()
            val onlyEQPLastIdx = tempEqpId.lastIndexOf("-")

            if(onlyEQPLastIdx==-1){
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "유효하지 않은 장비입니다.", GetString.BTNOKSTR
                )
                viewBinding.editMachineSelect.setText("")
                return@launch
            }
            val onlyEqpId = tempEqpId.substring(0, onlyEQPLastIdx)
            val onlyPortId = tempEqpId.substring(onlyEQPLastIdx + 1, tempEqpId.length)

            viewBinding.editMachineSelect.setText("")
            viewBinding.editMachineSelect.setText(onlyEqpId)

            var isMainMachine = viewBinding.editMachineSelect.text.toString()
            mainEqpId = viewBinding.editMachineSelect.text.toString()

            val tempEQPLastIdx = onlyEqpId.lastIndexOf("-")
            var firstIdx = 0
            var lastIdx = 0

            if (tempEQPLastIdx - 2 > 0)
                firstIdx = tempEQPLastIdx - 2

            if (tempEQPLastIdx > 0)
                lastIdx = tempEQPLastIdx

            val tempEQPFirstName = onlyEqpId.substring(0, firstIdx)
            val tempEQPLastName = onlyEqpId.substring(lastIdx, onlyEqpId.length)
            val stepperEQPName = "${tempEQPFirstName}01${tempEQPLastName}"

            viewBinding.editMachineSelect.setText(onlyEqpId)

            if (treeFlag == "Y") {
                if (searchC1Stepper.isEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "Tree 진행 설정되었으나 이전 진행 장비를 찾을수 없습니다. 장비 ASSIGN 후 진행바랍니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editMachineSelect.isEnabled = false
                    viewBinding.btnOk.isEnabled = false

                    return@launch
                } else if (searchC1Stepper != stepperEQPName) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "Tree 진행 설정된 LOT입니다. $searchC1Stepper 에서 자동화 진행 가능합니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editMachineSelect.isEnabled = false
                    viewBinding.btnOk.isEnabled = false

                    return@launch
                }
            }

            val eqpGroup = viewBinding.txtEqpGroup.text
            if ((eqpGroup != "FAB2") && (eqpGroup != "FAB5") && (eqpGroup != "FAB7") && (searchArea != "PQC")) {
                val sendMessage = MessageFactoryUtil.remoteEQPInfo2(
                    isMainMachine, "MVIN", viewBinding.txtLotNo.text.toString(),
                    DeviceInfo.FACILITY, searchOperation, searchSubOperation
                )
                val message = MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.REMOTEEQPINFO2
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result

                if (isSuccessFul) {
                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                    val mainEqp = messageBody.optString("MAINEQPID")
                    val subEqp = messageBody.optString("PROCEQPID")
                    val local = messageBody.optString("ISLOCALTRACK")
                    val prName = messageBody.optString("PRNAME")//20171114 jmlee
                    val recipe = messageBody.optString("RECIPE")//20171114 jmlee
                    val operMode = messageBody.optString("INLINEMODE")//20171114 jmlee
                    val layerId = messageBody.optString("LAYERID")//20171114 jmlee
                    val randomFlag = messageBody.optString("RANDOMFLAG")//20171114 jmlee
                    val sampleFlag = messageBody.optString("SAMPLEFLAG")//20171114 jmlee
                    val eqpType = messageBody.optString("EQPTYPE")//20171114 jmlee
                    val remoteCode = messageBody.optString("REWORK_CODE")//20171114 jmlee
                    val barcCount = messageBody.optString("BARCCOUNT")//20171013 jmlee BarcCount 체크
                    val pmMessage = messageBody.optString("PMMESSAGE")//2015.06.01 장비 PM 주기 체크 수정
                    val portName = messageBody.optString("PORTNAME")

                    viewBinding.txtRecipe.text = recipe
                    viewBinding.txtPr.text = prName

                    searchLocal = local
                    searchRemoteCode = remoteCode
                    searchOperMode = operMode
                    searchLayerId = layerId
                    searchRandomFlag = randomFlag
                    searchEqpType = eqpType
                    searchBarcCount = barcCount

                    if (sampleFlag == "InRework")
                        viewBinding.txtRework.text = "Y"
                    else
                        viewBinding.txtRework.text = "N"

                    //20171013 jmlee BarcCount 체크
                    if (barcCount.isNotEmpty()) {
                        val iBarcCount = barcCount.toInt()
                        when {
                            iBarcCount == 1 -> {
                                val countMsg = """
                                        |첫 BARC 공정 또는 추가 BAKE 진행 LOT입니다.
                                        |BARC Count : [$barcCount]
                                        |계측 진행 바랍니다.
                                    """.trimMargin()

                                OkDialog.show(
                                    supportFragmentManager, "BARC COUNT",
                                    countMsg, GetString.BTNOKSTR
                                )
                            }
                            iBarcCount == 30 -> {
                                val countMsg = """
                                        |30번째 BARC 공정 또는 추가 BAKE 진행 LOT입니다.
                                        |BARC Count : [$barcCount]
                                        |계측 진행 바랍니다.
                                    """.trimMargin()

                                OkDialog.show(
                                    supportFragmentManager, "BARC COUNT",
                                    countMsg, GetString.BTNOKSTR
                                )
                            }
                            iBarcCount > 30 -> {
                                val countMsg = """
                                        |BARC 공정 또는 추가 BAKE 진행을 30 LOT 이상 진행하였습니다.
                                        |BARC Count : [$barcCount]
                                        |공정 PM 바랍니다.
                                    """.trimMargin()

                                OkDialog.show(
                                    supportFragmentManager, "BARC COUNT",
                                    countMsg, GetString.BTNOKSTR
                                )
                            }
                        }
                    }

                    //2015.06.01 장비 PM 주기 체크 수정
                    if (pmMessage.isNotEmpty()) {
                        OkDialog.show(
                            supportFragmentManager, "PM주기 경고",
                            pmMessage, GetString.BTNOKSTR
                        )
                    }

                    val portList = portName.split(",")
                    val spinnerAdapter =
                        ArrayAdapter(
                            applicationContext, R.layout.contact_spinner_row_init, portList
                        )
                    spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                    viewBinding.spinnerPort.adapter = InitSpinnerAdapter(
                        spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                    )

                    if (onlyPortId.isNotEmpty()) {
                        if (portList.contains(onlyPortId))
                            viewBinding.spinnerPort.setSelection(portList.indexOf(onlyPortId) + 1)
                    }

                    if (mainEqp == subEqp) {
                        mainEqpId = mainEqp
                        isMainMachine = mainEqp
                    } else {
                        mainEqpId = mainEqp
                        isMainMachine = subEqp
                    }

                    //20170912 jmlee, local Track 장비 인 경우 EEN 체크
                    if (local == "Y")
                        remoteEQPEENInfo(isMainMachine)

                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)

                    if (errorMessage.contains("현재 장비 상태가")) {
                        val returnCode = OkCancelDialog.show(
                            supportFragmentManager, GetString.BTNOKSTR, errorMessage,
                            GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
                        )

                        if (returnCode == OkCancelDialog.RETURN_CODE_OK) {
                            photoChangeEQPStatus(isMainMachine,onlyPortId)// [ uk 20180514 ] Photo Inline Remote Code Copy
                            return@launch
                        }

                        viewBinding.editMachineSelect.requestFocus()
                        viewBinding.editMachineSelect.selectAll()
                    } else {
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            errorMessage, GetString.BTNOKSTR
                        )

                        viewBinding.editMachineSelect.requestFocus()
                        viewBinding.editMachineSelect.selectAll()
                    }
                }

            }
        }
    }

    private fun remoteEQPEENInfo(isMainMachine: String) {
        mainScope.launch {
            // EQP가 MAIN인지 SUB인지 체크
            val sendMessage = MessageFactoryUtil.remoteEQPEENInfo(
                isMainMachine, "MVIN", viewBinding.txtLotNo.text.toString(),
                DeviceInfo.FACILITY, searchOperation, searchSubOperation
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.REMOTEEQPINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                setPortStatus()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editMachineSelect.requestFocus()
                viewBinding.editMachineSelect.selectAll()
            }
        }
    }

    private fun photoChangeEQPStatus(isMainMachine: String, sPORTID :String) {
        mainScope.launch {
            val sendMessage =
                MessageFactoryUtil.photoChangeEQPStatus(isMainMachine, DeviceInfo.OPERATOR_ID)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.PHOTOCHANGEEQPSTATUS
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val successMessage = """
                            |장비상태 변경하였습니다.
                        """.trimMargin()

                OkDialog.show(
                    supportFragmentManager, "변경 완료", successMessage, GetString.BTNOKSTR
                )
                viewBinding.editMachineSelect.setText( viewBinding.editMachineSelect.text.toString() + "-"+ sPORTID)
                setEQPInfo()
                return@launch
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setStatusColor() {
        val status = viewBinding.txtStatus.text.toString()

        if (status == "RUN") {
            viewBinding.txtStatus.setBackgroundColor(Color.BLUE)
            viewBinding.txtStatus.setTextColor(Color.WHITE)
        } else if (status == "WAIT" || status == "") {
            viewBinding.txtStatus.setBackgroundColor(Color.parseColor("#ffffE0"))
            viewBinding.txtStatus.setTextColor(Color.parseColor("#000040"))
        } else if (status == "HOLD") {
            viewBinding.txtStatus.setBackgroundColor(Color.parseColor("#ff0000"))
            viewBinding.txtStatus.setTextColor(Color.WHITE)
        } else {
            viewBinding.txtStatus.setBackgroundColor(Color.BLACK)
            viewBinding.txtStatus.setTextColor(Color.WHITE)
        }
    }

    private fun clearPortStatus() {
        viewBinding.txtPortStatus.text = ""
        viewBinding.txtPortStatus.setTextColor(Color.BLACK)

        val drawablePadding = Rect()
        val top = viewBinding.txtPortStatus.paddingTop + drawablePadding.top
        val left = viewBinding.txtPortStatus.paddingLeft + drawablePadding.left
        val right = viewBinding.txtPortStatus.paddingRight + drawablePadding.right
        val bottom = viewBinding.txtPortStatus.paddingBottom + drawablePadding.bottom

        viewBinding.txtPortStatus.setBackgroundResource(R.drawable.radius_box_boder_base)
        viewBinding.txtPortStatus.setPadding(left, top, right, bottom)
    }

    private fun clearEQPInfo() {
        mainEqpId = ""
        searchLocal = ""
        searchRemoteCode = ""
        searchOperMode = ""
        searchLayerId = ""
        searchRandomFlag = ""
        searchEqpType = ""
        searchBarcCount = ""

        viewBinding.txtRecipe.text = ""
        viewBinding.txtPr.text = ""
        viewBinding.txtRework.text = ""
        viewBinding.spinnerPort.adapter = null

        clearPortStatus()
    }

    private fun setPortStatusColor(portStatus: String) {
        val drawablePadding = Rect()
        val top = viewBinding.txtPortStatus.paddingTop + drawablePadding.top
        val left = viewBinding.txtPortStatus.paddingLeft + drawablePadding.left
        val right = viewBinding.txtPortStatus.paddingRight + drawablePadding.right
        val bottom = viewBinding.txtPortStatus.paddingBottom + drawablePadding.bottom

        when (portStatus) {
            "RUN" -> {
                viewBinding.txtPortStatus.setBackgroundResource(R.drawable.port_state_run)
                viewBinding.txtPortStatus.setTextColor(Color.WHITE)
            }
            "PENDING" -> {
                viewBinding.txtPortStatus.setBackgroundResource(R.drawable.port_state_pending)
                viewBinding.txtPortStatus.setTextColor(Color.BLACK)
            }
            "READY" -> {
                viewBinding.txtPortStatus.setBackgroundResource(R.drawable.port_state_ready)
                viewBinding.txtPortStatus.setTextColor(Color.BLACK)
            }
            "RESERVED" -> {
                viewBinding.txtPortStatus.setBackgroundResource(R.drawable.port_state_reserved)
                viewBinding.txtPortStatus.setTextColor(Color.BLACK)
            }
            "COMPLETE" -> {
                viewBinding.txtPortStatus.setBackgroundResource(R.drawable.port_state_comlete)
                viewBinding.txtPortStatus.setTextColor(Color.BLACK)
            }
            "IDLE" -> {
                viewBinding.txtPortStatus.setBackgroundResource(R.drawable.port_state_idle)
                viewBinding.txtPortStatus.setTextColor(Color.WHITE)
            }
        }

        viewBinding.txtPortStatus.setPadding(left, top, right, bottom)
    }

    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerPort.id -> {
                        setPortStatus()
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {

        }
    }

    private fun setPortStatus() {
        mainScope.launch {
            if (viewBinding.spinnerPort.selectedItem == null)
                return@launch

            clearPortStatus()

            val sendMessage = MessageFactoryUtil.machinePortStatus(
                viewBinding.editMachineSelect.text.toString(),
                viewBinding.spinnerPort.selectedItem.toString()
            )

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MACHINEPORTSTATUS
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val portStatus = messageBody.optString("PORTSTATENAME")
                val ackMsg = messageBody.optString("ACKMSG")
                viewBinding.btnRePort.isEnabled = true;
                viewBinding.txtPortStatus.text = portStatus
                setPortStatusColor(portStatus)

                if (portStatus == "RUN" || portStatus == "PENDING" || portStatus == "RESERVED" || portStatus == "COMPLETE") {
                    val portMsg = """
                                |해당 PORT가 진행중입니다.
                                |장비 및 진행할 LOT을 다시 확인 바랍니다.
                            """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, "장비 MASSAGE",
                        portMsg, GetString.BTNOKSTR
                    )

                    if (ackMsg.isNotEmpty()) {
                        OkDialog.show(
                            supportFragmentManager, "PORT WORNING",
                            ackMsg, GetString.BTNOKSTR
                        )
                    }

                    viewBinding.editMachineSelect.requestFocus()
                    viewBinding.editMachineSelect.selectAll()
                    viewBinding.btnOk.isEnabled = false

                    return@launch
                } else if (portStatus != "READY") {
                    OkDialog.show(
                        supportFragmentManager, "장비 MASSAGE",
                        "CST가 LOAD되어 있지 않습니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editMachineSelect.requestFocus()
                    viewBinding.editMachineSelect.selectAll()
                    viewBinding.btnOk.isEnabled = false

                    return@launch
                } else if (portStatus.isEmpty()) {
                    val portMsg = """
                                |PORT 정보를 가져올 수 없습니다.
                                |잠시후 다시 확인 바랍니다.
                            """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, "장비 MASSAGE",
                        portMsg, GetString.BTNOKSTR
                    )

                    viewBinding.editMachineSelect.requestFocus()
                    viewBinding.editMachineSelect.selectAll()
                    viewBinding.btnOk.isEnabled = false

                    return@launch
                } else {
                    viewBinding.btnOk.isEnabled = true
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editMachineSelect.requestFocus()
                viewBinding.editMachineSelect.selectAll()
            }
        }
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnOk.id -> {
                    execute()
                }
                viewBinding.btnClose.id -> {
                    finish()
                }
                viewBinding.btnRePort.id -> {
                    setPortStatus()
                }
            }
        }
    }

    private fun execute() {
        mainScope.launch {
            if (searchLocal == "Y") {
                if (viewBinding.spinnerPort.selectedItem == null) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "진행 Port를 먼저 선택하세요.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                val confirmMessage = """
                    |해당 장비는 Local Track 장비 입니다.
                    |[${viewBinding.spinnerPort.selectedItem}]번 PORT에 LOT [${viewBinding.txtLotNo.text}]을(를) 작업 예약 하시겠습니까?
                """.trimMargin()

                val returnCode = OkCancelDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                    confirmMessage, GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
                )

                if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL)
                    return@launch

                val reworkStateFlag = if (viewBinding.txtRework.text.toString() == "Y")
                    "R"
                else
                    "M"

                val machineName = viewBinding.editMachineSelect.text.toString()
                val portName = viewBinding.spinnerPort.selectedItem.toString()
                val lotName = viewBinding.txtLotNo.text.toString()
                val product = viewBinding.txtProduct.text.toString()
                val recipe = viewBinding.txtRecipe.text.toString()
                val prName = viewBinding.txtPr.text.toString().trim()
                val lotQty = viewBinding.txtQty.text.toString()
                val reworkCode = searchRemoteCode
                val barcCount = searchBarcCount
                val eqpType = searchEqpType
                val operationName = searchOperation
                val operDesc = searchOperDesc
                val operMode = searchOperMode
                val layerId = searchLayerId
                val random = searchRandomFlag

                //20171121 jmlee , local track 작업 예약 추가
                val sendMessage = MessageFactoryUtil.photoLotStart(
                    machineName, portName, lotName, product, recipe, prName, lotQty,
                    reworkCode, barcCount, eqpType, operationName, operDesc, operMode, layerId,
                    random, reworkStateFlag, DeviceInfo.OPERATOR_ID, DeviceInfo.OPERATOR_NAME
                )

                val message = MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.PHOTOLOTSTART
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result

                if (isSuccessFul) {
                    setResult(RESULT_OK)
                    finish()
                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    OkDailogAlram.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR, applicationContext,
                        getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    )
                }
            } else {
                if (viewBinding.spinnerPort.selectedItem == null) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "진행 Port를 먼저 선택하세요.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                val portName = viewBinding.spinnerPort.selectedItem.toString()
                val lotName = viewBinding.txtLotNo.text.toString()

                val returnCode = OkCancelDialog.show(
                    supportFragmentManager, GetString.BTNOKSTR,
                    "[$portName]번 PORT에 LOT [$lotName]을(를) 예약 하시겠습니까?",
                    GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
                )

                if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL)
                    return@launch

                val sendMessage = MessageFactoryUtil.photoLotReserve(mainEqpId, portName, lotName)

                val message = MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.PHOTOLOTRESERVE
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result

                if (isSuccessFul) {
                    setResult(RESULT_OK)
                    finish()
                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    OkDailogAlram.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR, applicationContext,
                        getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    )
                }
            }
        }
    }
}