package com.keyfoundry.hifos.config.utils

import android.view.View

/*
* 연속 클릭을 방지하기 위해 만든 Class
**/
abstract class OnSingleClickListener(
    private val clickDelayMilliSecond: Long = CLICK_DELAY_TIME
) : View.OnClickListener {

    companion object {
        private const val CLICK_DELAY_TIME = 1000L
    }

    private var lastClickTime = 0L

    protected abstract fun onSingleClick(it: View)

    override fun onClick(v: View) {
        val now = System.currentTimeMillis()
        if (now - lastClickTime > clickDelayMilliSecond) {
            onSingleClick(v)
            lastClickTime = now
        }
    }
}
