package com.keyfoundry.hifos.config.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.keyfoundry.hifos.config.domain.ServerInfo

/*
* 안드로이드 내부 DB ServerInfo 관련 쿼리
* */
@Dao
interface ServerInfoDao {
    @Query("select * from server_info")
    fun getAll(): List<ServerInfo>

    @Query("select * from server_info where serverType = :serverType")
    fun getServerInfo(serverType:String): ServerInfo

    @Query("update server_info set serverUrl = :serverUrl, selectedServer = :selected where serverType = :serverType")
    fun updateServerInfo(serverUrl:String, serverType:String, selected:Boolean)

    @Query("select * from server_info where selectedServer = 1")
    fun getSelectedServerInfo() : ServerInfo

    @Query("select serverUrl from server_info where serverType = 'PROD_SERVER' ")
    fun getUpdateServerUrl() : String

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(serverInfo: ServerInfo)

    @Query("delete from server_info")
    fun deleteAll()
}