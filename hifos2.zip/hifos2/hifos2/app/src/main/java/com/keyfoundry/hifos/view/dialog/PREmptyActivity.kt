package com.keyfoundry.hifos.view.dialog

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.utils.CommonUtil
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivityPremptyBinding
import com.keyfoundry.hifos.message.MessageSender
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter


class PREmptyActivity : AppCompatActivity() {

    private var update: Boolean // 추후 삭제
    init {
        this.update = false
    }
    private lateinit var viewBinding: ActivityPremptyBinding

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_prempty)
        setFinishOnTouchOutside(false)

        viewBinding = ActivityPremptyBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        val receiverMessage = intent.getStringExtra(DeviceInfo.UDP_RECEIVER_MESSAGE)

        if (receiverMessage != null) if(receiverMessage.contains("INTERLOCKMANAGER"))
        {
            val new_receiverMessage = arrayOf(receiverMessage?.split("<Table diffgr:id=Table1 msdata:rowOrder=0>")) // receiverMessage 잘라서 배열에 담기

            for(data in 1 until new_receiverMessage[0].size)
            {
                val arry_receiverMessage = arrayOf(new_receiverMessage[0][data]?.split("</")) // receiverMessage 잘라서 배열에 담기

                val Time = arry_receiverMessage[0]!![0].substring(arry_receiverMessage[0]!![0].lastIndexOf(">")+1)
                if(Time > 0.toString())
                    viewBinding.txtPREMPTYTimeResult.append(Time.substring(0, Time.indexOf("+")).replace("T"," "))

                //알람
                val alarmLevel = arry_receiverMessage[0]!![2].substring(arry_receiverMessage[0]!![2].lastIndexOf(">")+1)
                if(alarmLevel > 0.toString())
                    viewBinding.txtPREMPTYLevelResult.append(alarmLevel)

                //EQPID
                val eqpidValue = arry_receiverMessage[0]!![3].substring(arry_receiverMessage[0]!![3].lastIndexOf(">")+1)
                if(eqpidValue > 0.toString())
                    viewBinding.txtPREMPTYMcahineResult.append(eqpidValue)

                //MODEL
                val modelValue = arry_receiverMessage[0]!![4].substring(arry_receiverMessage[0]!![4].lastIndexOf(">")+1)
                if(modelValue > 0.toString())
                    viewBinding.txtPREMPTYModelResult.append(modelValue)

                //Facility
                val facilityValue = arry_receiverMessage[0]!![5].substring(arry_receiverMessage[0]!![5].lastIndexOf(">")+1)
                if(facilityValue > 0.toString())
                    viewBinding.txtPREMPTYFacilityResult.append(facilityValue)

                //PumpID
                val pumpIDValue = arry_receiverMessage[0]!![8].substring(arry_receiverMessage[0]!![8].lastIndexOf(">")+1)
                if(pumpIDValue > 0.toString())
                    viewBinding.txtPREMPTYPumpidResult.append(pumpIDValue)

                //PumpName
                val pumpNameValue = arry_receiverMessage[0]!![9].substring(arry_receiverMessage[0]!![9].lastIndexOf(">")+1)
                if(pumpNameValue > 0.toString())
                    viewBinding.txtPREMPTYPumpnameResult.append(pumpNameValue)

                //Desc
                val descValue : String  = arry_receiverMessage[0]!![10].substring(arry_receiverMessage[0]!![10].lastIndexOf(">")+1)
                if(descValue.isNotEmpty() && (descValue.contains("[") || descValue.contains("]")))
                {
                    val pattern = "\\[(.*?)\\]".toRegex()  // "["와 "]" 사이의 값을 찾는 정규식
                    val result = pattern.find(descValue)?.groupValues?.get(1)
                    viewBinding.txtPREMPTYDescResult.append(result)
                }

            }
        }
        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                setData()
            }
        })
    }

    private fun setData(){
        lifecycleScope.launch {
            //CommonUtil.hideKeyboard(this@ESDMasterActivity, currentFocus)
            CommonUtil.hideKeyboard(this@PREmptyActivity, currentFocus)

            val sDeviceName = DeviceInfo.DEVICE_NAME; //PDA ID
            // 1. 화면에서 기존 값("2026-06-01 21:37:02.136")을 가져옴
            val originalTime = viewBinding.txtPREMPTYTimeResult.text.toString()


            val inputFormatter = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")
            val outputFormatter = java.time.format.DateTimeFormatter.ofPattern("yyyy/MM/dd_HH:mm:ss")


            val sMasterTime = try {
                val parsedDate = java.time.LocalDateTime.parse(originalTime, inputFormatter)
                parsedDate.format(outputFormatter) // 결과: "2026/06/01_21:37:02"
            } catch (e: Exception) {
                originalTime
            }

            val sEqpid = viewBinding.txtPREMPTYMcahineResult.text.toString()
            val sRecipe = "NULL";
            val sLotID = "NULL";
            val sSlot = "NULL";
            val sUsers = DeviceInfo.OPERATOR_ID

            val current = LocalDateTime.now()
            val formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd_HH:mm:ss")
            val sCurrentTime = current.format(formatter)

            val sendMessage = MessageFactoryUtil.intlkpopupcheck(
                sMasterTime, "PR_EMPTY", "POP-UP", sDeviceName, "PDA", sDeviceName,
                "http://::1:62011/InterlockClient.soap", "Y", sUsers, sCurrentTime,
                sEqpid, sRecipe, sLotID, sSlot
            )

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.SETGASUSAGE
            )
            finish()
        }
    }
}