package com.keyfoundry.hifos.config.service.dto

/*
* 모바일 서버로부터 받은 메시지를 담는 Class
* */
data class ResponseData(
    val result: String,
    val statusCode: Int
)
