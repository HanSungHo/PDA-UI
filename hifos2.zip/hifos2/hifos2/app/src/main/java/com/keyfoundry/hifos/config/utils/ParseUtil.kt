package com.keyfoundry.hifos.config.utils

class ParseUtil {
    companion object {
        fun stringTo2D(sStr: String): Array<Array<String>>? {
            var arrD: Array<Array<String>>? = null

            if (sStr.isNullOrEmpty()) {
                return arrD
            }

            val sLine = sStr.split("\n")
            if (sLine.isEmpty() || sLine.isNullOrEmpty()) {
                return arrD
            }

            arrD = Array(sLine.size) { Array(sLine.maxOf { it.split("\t").size }) { "" } }

            for (i in sLine.indices) {
                val sTab = sLine[i].split("\t")

                for (j in sTab.indices) {
                    arrD[i][j] = sTab[j]
                }
            }

            return arrD
        }
    }
}