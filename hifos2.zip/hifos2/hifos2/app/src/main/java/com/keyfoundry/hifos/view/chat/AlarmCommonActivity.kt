package com.keyfoundry.hifos.view.chat

import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.OnSingleClickListener

class AlarmCommonActivity : HFActivity() {
    init {
        this.update = false
    }

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AlarmRowAdapter
    private val list = mutableListOf<AlarmRowItem>()

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setFinishOnTouchOutside(false)

        setContentView(R.layout.activity_alarm_common_popup) // 🔥 이거 있어야 함

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerCommonView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = AlarmRowAdapter(list)
        recyclerView.adapter = adapter

        val receiverMessage = intent.getStringExtra(DeviceInfo.UDP_RECEIVER_MESSAGE).toString()
        val roomName = intent.getStringExtra("ROOMNAME").toString()


        val roomNameText: TextView = findViewById(R.id.title_receiver_message)
        roomNameText.text = roomName

        updateUI(receiverMessage)

        val btnOk: Button = findViewById(R.id.btn_ok)
        btnOk.setOnClickListener {
            finish()
        }
    }

    /**
     * 문자열 메시지 → RecyclerView 업데이트
     */
    private fun updateUI(message: String) {
        val parsedList = parseMessage(message)

        list.clear()
        list.addAll(parsedList)

        adapter.notifyDataSetChanged()
    }

    /**
     * 메시지 파싱
     * 예: LotID=ABC123;생산장비=EQ-01
     */
    private fun parseMessage(message: String): List<AlarmRowItem> {
        val result = mutableListOf<AlarmRowItem>()

        try {
            val pairs = message.split(";")

            for (pair in pairs) {
                val keyValue = pair.split("=")

                if (keyValue.size == 2) {
                    val key = keyValue[0].trim()
                    val value = keyValue[1].trim()

                    result.add(AlarmRowItem(key, value))
                } else {
                    Log.e("ParseError", "잘못된 데이터: $pair")
                }
            }

        } catch (e: Exception) {
            Log.e("ParseError", "파싱 실패", e)
        }

        return result
    }
}