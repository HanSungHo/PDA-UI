package com.keyfoundry.hifos.view.chat

import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo

class TreeAdapter(
    private var allItems: List<TreeItem>,
    private val onSelectionChanged: (selectedCount: Int) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val TYPE_AREA = 0
        const val TYPE_BAY = 1
        const val TYPE_DEVICE = 2
    }

    private val visibleItems = mutableListOf<TreeItem>().apply { addAll(allItems) }

    override fun getItemCount(): Int = visibleItems.size

    override fun getItemViewType(position: Int) = when (visibleItems[position]) {
        is TreeItem.AreaItem -> TYPE_AREA
        is TreeItem.BayItem -> TYPE_BAY
        else -> TYPE_DEVICE
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            TYPE_AREA -> AreaVH(inflater.inflate(R.layout.item_area, parent, false))
            TYPE_BAY -> BayVH(inflater.inflate(R.layout.item_bay, parent, false))
            else -> DeviceVH(inflater.inflate(R.layout.item_device, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = visibleItems[position]) {
            is TreeItem.AreaItem -> bindArea(holder as AreaVH, item)
            is TreeItem.BayItem -> bindBay(holder as BayVH, item)
            is TreeItem.DeviceItem -> bindDevice(holder as DeviceVH, item)
        }
    }

    /** 선택된 Device 반환 */
    fun getSelectedDevices(): List<Device> =
        allItems.filterIsInstance<TreeItem.DeviceItem>()
            .map { it.device }
            .filter { it.isSelected }

    /** 서버/외부 데이터 갱신 */
    fun updateTree(newTreeItems: List<TreeItem>) {
        // 5DP01만 펼치고 나머지는 접기
        newTreeItems.forEach { item ->
            when (item) {
                is TreeItem.AreaItem -> item.isExpanded = item.area.areaName == DeviceInfo.AREA
                is TreeItem.BayItem -> item.isExpanded = item.bay.bayName == DeviceInfo.BAY
                else -> {}
            }
        }
        allItems = newTreeItems
        rebuildVisibleItems()
    }

    /** 특정 Bay 위치 찾기 */
    fun getPositionOfBay(bayName: String): Int {
        visibleItems.forEachIndexed { index, item ->
            if (item is TreeItem.BayItem && item.bay.bayName == bayName) return index
        }
        return -1
    }

    /** Area 바인딩 */
    private fun bindArea(holder: AreaVH, item: TreeItem.AreaItem) {
        holder.name.text = item.area.areaName

        holder.check.setOnCheckedChangeListener(null)
        holder.check.isChecked = item.area.isSelected
        holder.check.setOnCheckedChangeListener { _, isChecked ->
            item.area.isSelected = isChecked
            item.area.bays.forEach { bay ->
                bay.isSelected = isChecked
                bay.devices.forEach { it.isSelected = isChecked }
            }
            rebuildVisibleItems()
            onSelectionChanged(getSelectedDevices().size)
        }

        holder.itemView.setOnClickListener {
            item.isExpanded = !item.isExpanded
            rebuildVisibleItems()
        }
    }

    /** Bay 바인딩 */
    private fun bindBay(holder: BayVH, item: TreeItem.BayItem) {
        holder.name.text = item.bay.bayName

        holder.check.setOnCheckedChangeListener(null)
        holder.check.isChecked = item.bay.isSelected
        holder.check.setOnCheckedChangeListener { _, isChecked ->
            item.bay.isSelected = isChecked
            item.bay.devices.forEach { it.isSelected = isChecked }
            rebuildVisibleItems()
            onSelectionChanged(getSelectedDevices().size)
        }

        holder.itemView.setOnClickListener {
            item.isExpanded = !item.isExpanded
            rebuildVisibleItems()
        }
    }

    /** Device 바인딩 */
    private fun bindDevice(holder: DeviceVH, item: TreeItem.DeviceItem) {
        holder.name.text = item.device.id + "(" + item.device.userName + ")"

        holder.check.setOnCheckedChangeListener(null)
        holder.check.isChecked = item.device.isSelected
        holder.check.setOnCheckedChangeListener { _, isChecked ->
            item.device.isSelected = isChecked
            onSelectionChanged(getSelectedDevices().size)
        }
    }

    /** 화면에 표시할 TreeItem 재생성 */
    private fun rebuildVisibleItems() {
        val newList = mutableListOf<TreeItem>()

        allItems.filterIsInstance<TreeItem.AreaItem>().forEach { areaItem ->
            newList.add(areaItem)
            if (!areaItem.isExpanded) return@forEach

            areaItem.area.bays.forEach { bay ->
                val bayItem = allItems.find { it is TreeItem.BayItem && it.bay == bay } as? TreeItem.BayItem
                if (bayItem != null) {
                    newList.add(bayItem)
                    if (!bayItem.isExpanded) return@forEach
                    bay.devices.forEach { device ->
                        newList.add(TreeItem.DeviceItem(device))
                    }
                }
            }
        }

        visibleItems.clear()
        visibleItems.addAll(newList)
        recyclerViewSafeNotify()
    }

    /** notifyDataSetChanged 안전하게 호출 */
    private fun recyclerViewSafeNotify() {
        try {
            notifyDataSetChanged()
        } catch (_: Exception) {
            Handler(Looper.getMainLooper()).post { notifyDataSetChanged() }
        }
    }

    /** ViewHolder */
    inner class AreaVH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.areaName)
        val check: CheckBox = v.findViewById(R.id.areaCheck)
    }

    inner class BayVH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.bayName)
        val check: CheckBox = v.findViewById(R.id.bayCheck)
    }

    inner class DeviceVH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.idText)
        val check: CheckBox = v.findViewById(R.id.checkBox)
    }
}