package com.keyfoundry.hifos.message

/*
* 모바일 서버에 보낼 Message를 만들어주는 Class
* */
class SendMessageManager {
    companion object {
        val startRootTag: String = "<AIFMSG>"
        val endRootTag: String = "</AIFMSG>"
        val startBodyTag: String = "<MSGBODY>"
        val endBodyTag: String = "</MSGBODY>"

        private fun makeSendMessageHeader(sendMessageHeader: SendMessageHeader): String {
            return """
                   |<MSGNAME>${sendMessageHeader.MSGNAME}</MSGNAME>
                   |<RECEIVER>${sendMessageHeader.RECEIVER}</RECEIVER>
                   |<SENDER>${sendMessageHeader.SENDER}</SENDER>
                   |<MSGTYPE>${sendMessageHeader.MSGTYPE}</MSGTYPE>
                   |<WITHREPLY>${sendMessageHeader.WITHREPLY}</WITHREPLY>
                   |<STATUS>${sendMessageHeader.STATUS}</STATUS>
                   |<ERRMSG>${sendMessageHeader.ERRMSG}</ERRMSG>
                   |<TID>${sendMessageHeader.TID}</TID>
                  """.trimMargin()
        }

        fun getSendMessage(sendMessageHeader: SendMessageHeader, sendMessageBody: String): String {
            return startRootTag + "\n" +
                    makeSendMessageHeader(sendMessageHeader) + "\n" +
                    startBodyTag + "\n" +
                    sendMessageBody + "\n" +
                    endBodyTag + "\n" +
                    endRootTag

        }

    }

}