package com.keyfoundry.hifos.view.chat

data class SendMessageRequest(
    val sType: String,
    val sArea: String,
    val sBay: String,
    val recieveIpAddress: String,
    val sMsg: String,
    val senderIpAddress: String,
    val senderId: String,
    val roomId: String,
    val sLevel: String
)