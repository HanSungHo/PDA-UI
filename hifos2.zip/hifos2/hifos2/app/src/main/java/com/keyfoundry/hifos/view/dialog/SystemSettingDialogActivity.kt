package com.keyfoundry.hifos.view.dialog

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.View
import android.view.Window
import android.widget.Toast
import androidx.core.content.FileProvider
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.ServerType
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.service.RetrofitSyncService
import com.keyfoundry.hifos.config.service.RetrofitUpdateService
import com.keyfoundry.hifos.config.service.room.ServerInfoService
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivitySystemSettingBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

import android.provider.Settings
import com.keyfoundry.hifos.config.service.update.DownloadService

class SystemSettingDialogActivity : HFActivity() {
    init {
        this.update = false
    }

    companion object {
        private const val TAG = "SystemSettingActivity"
        private const val REQUEST_INSTALL_PERMISSION = 1001
    }

    private lateinit var viewBinding: ActivitySystemSettingBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var serverInfoService: ServerInfoService

    private var pendingApkFile: File? = null

    override fun onBackPressed() {
        return;
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setFinishOnTouchOutside(false)

        viewBinding = ActivitySystemSettingBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        serverInfoService = ServerInfoService(applicationContext)

        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnClose.setOnClickListener(onSingleClickListener)
        viewBinding.btnPassword.setOnClickListener(onSingleClickListener)

        viewBinding.btnPmdmDown.setOnClickListener(onSingleClickListener)
        viewBinding.btnBatteryDown.setOnClickListener(onSingleClickListener)

        getServerInfo()
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it) {
                viewBinding.btnOk -> {
                    systemSettingOK()
                }
                viewBinding.btnClose -> {
                    finish()
                }
                viewBinding.btnPassword -> {
                    passwordCheck()
                }
                viewBinding.btnPmdmDown -> {
                    downLoadPmdm()
                }
                viewBinding.btnBatteryDown -> {
                    downLoadBatterMonitor()
                }
            }
        }
    }

    private fun passwordCheck() {
        if (viewBinding.editPassword.text.toString() == DeviceInfo.SystemSettingPW) {
            viewBinding.layoutServerInfo.visibility = View.VISIBLE
            viewBinding.btnOk.isEnabled = true
        } else {
            viewBinding.layoutServerInfo.visibility = View.GONE
            viewBinding.btnOk.isEnabled = false
            Toast.makeText(this, "비밀번호가 다릅니다", Toast.LENGTH_SHORT).show()
        }
    }

    private fun systemSettingOK() {
        ioScope.launch {
            val statusCode = 0
            //        statusCode = checkAliveServer()
            Log.d(TAG, "STATUS CODE : $statusCode")
            Log.d(TAG, "SUCCESS!")

            mainScope.launch {
                val returnCode = OkCancelDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_SYSTEMCONF,
                    GetString.TXTDIALOGMESSAGE_SYSTEMCONF, GetString.POSITIVEBTNSTR,
                    GetString.NEGATIVEBTNSTR
                )
                if (returnCode == OkCancelDialog.RETURN_CODE_OK) {
                    saveServerInfo()
                }
            }
        }
    }

    // check Alive Server
    private suspend fun checkAliveServer(checkUrl: String): Int {

        val originUrl = ServerType.MOBILE_SERVER_URL

        var statusCode = 0
        // check network
        RetrofitSyncService.reInit(checkUrl)
        val response = MessageSender.checkAPI(supportFragmentManager)
        statusCode = response.statusCode

        RetrofitSyncService.reInit(originUrl)
        return statusCode
    }

    fun getServerInfo() {
        ioScope.launch {
            val prodServerInfo = serverInfoService.selectServerInfo("PROD_SERVER")
            val devServerInfo = serverInfoService.selectServerInfo("DEV_SERVER")

            mainScope.launch {
                if (prodServerInfo != null) {
                    val prodServerUrl = prodServerInfo.serverUrl
                    viewBinding.editProdServer.setText(prodServerUrl)
                }

                if (devServerInfo != null) {
                    val devServerUrl = devServerInfo.serverUrl
                    viewBinding.editDevServer.setText(devServerUrl)
                }

                if (prodServerInfo.selectedServer) {
                    viewBinding.radioServer1.isChecked = true
                    viewBinding.radioServer2.isChecked = false
                } else {
                    viewBinding.radioServer1.isChecked = false
                    viewBinding.radioServer2.isChecked = true
                }

            }
        }
    }

    fun saveServerInfo() {
        ioScope.launch {
            val host = if (viewBinding.radioServer1.isChecked) {
                viewBinding.editProdServer.text.toString()
            } else {
                viewBinding.editDevServer.text.toString()
            }

            val checkUrl = "http://${host}:${ServerType.MOBILE_SERVER_PORT}"

            if (checkAliveServer(checkUrl) == 200) {
                serverInfoService.updateServerInfo(
                    viewBinding.editProdServer.text.toString(),
                    "PROD_SERVER",
                    viewBinding.radioServer1.isChecked
                )
                serverInfoService.updateServerInfo(
                    viewBinding.editDevServer.text.toString(),
                    "DEV_SERVER",
                    viewBinding.radioServer2.isChecked
                )

                ServerType.MOBILE_SERVER_URL =
                    "http://${host}:${ServerType.MOBILE_SERVER_PORT}"
                ServerType.UPDATE_SERVER_URL =
                    "http://${viewBinding.editProdServer.text}:${ServerType.UPDATE_SERVER_PORT}"

                RetrofitSyncService.reInit(ServerType.MOBILE_SERVER_URL)
                RetrofitUpdateService.reInit(ServerType.UPDATE_SERVER_URL)

                DeviceInfo.MOBILE_SERVER_NAME = serverInfoService.getSelectedServerInfo().serverName

                mainScope.launch {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_SYSTEMCONF,
                        "시스템 환경설정이 변경 되었습니다.", GetString.BTNOKSTR
                    )

                    finish()
                }
            }

        }

    }

//    private fun downLoadPdma() {
//        val apkPath =
//            File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS).toString() + File.separator + "DOWNLOADS").toString() + "/hifos.apk"
//    }

    private fun downLoadBatterMonitor() {
        val intent = Intent(this, DownloadService::class.java).apply {
            putExtra(DownloadService.EXTRA_FILE_URL, "upload/EmBatteryMonitor.apk")
            putExtra(DownloadService.EXTRA_FILE_NAME, "EmBatteryMonitor.apk")
        }
        startService(intent)
    }

    private fun downLoadPmdm() {
        val intent = Intent(this, DownloadService::class.java).apply {
            putExtra(DownloadService.EXTRA_FILE_URL, "upload/PMDMAgent.apk")
            putExtra(DownloadService.EXTRA_FILE_NAME, "PMDMAgent.apk")
        }
        startService(intent)
    }


    private fun downloadApk(url: String, destFile: File, onComplete: (Boolean) -> Unit) {
        Thread {
            try {
                val connection = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                connection.connect()

                val input = connection.inputStream
                val output = java.io.FileOutputStream(destFile)
                val buffer = ByteArray(4096)
                var bytesRead: Int

                while (input.read(buffer).also { bytesRead = it } != -1) {
                    output.write(buffer, 0, bytesRead)
                }

                output.flush()
                output.close()
                input.close()

                runOnUiThread { onComplete(true) }
            } catch (e: Exception) {
                e.printStackTrace()
                runOnUiThread { onComplete(false) }
            }
        }.start()
    }

    private fun installApk(apkFile: File) {
        if (!packageManager.canRequestPackageInstalls()) {
            // 출처를 알 수 없는 앱 설치 권한 요청
            pendingApkFile = apkFile
            val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivityForResult(intent, REQUEST_INSTALL_PERMISSION)
            return
        }
        triggerInstall(apkFile)
    }

    private fun triggerInstall(apkFile: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.provider", apkFile)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(intent)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_INSTALL_PERMISSION) {
            pendingApkFile?.let { apkFile ->
                if (packageManager.canRequestPackageInstalls()) {
                    triggerInstall(apkFile)
                } else {
                    Toast.makeText(this, "설치 권한이 필요합니다.", Toast.LENGTH_SHORT).show()
                }
            }
            pendingApkFile = null
        }
    }

}