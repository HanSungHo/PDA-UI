package com.keyfoundry.hifos.view.dialog

import android.os.Bundle
import android.view.View
import androidx.lifecycle.lifecycleScope
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.CommonUtil
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivityRecipeInterlockBinding
import com.keyfoundry.hifos.message.MessageSender
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter


class RecipeInterlockActivity : HFActivity() {
    init {
        this.update = false
    }

    private lateinit var viewBinding: ActivityRecipeInterlockBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipe_interlock)

        viewBinding = ActivityRecipeInterlockBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        val receiverMessage = intent.getStringExtra(DeviceInfo.UDP_RECEIVER_MESSAGE)

        //Interlock Msg에 (INTERLOCKMANAGER) 가 포함되어 있을때
        if (receiverMessage != null) if (receiverMessage.contains("INTERLOCKMANAGER")) {

            val new_receiverMessage =arrayOf(receiverMessage?.split("<Table diffgr:")) // receiverMessage 잘라서 배열에 담기

            for (data in 1 until new_receiverMessage[0].size) {
                val arry_receiverMessage =
                    arrayOf(new_receiverMessage[0][data]?.split("</")) // receiverMessage 잘라서 배열에 담기

                //viewBinding.titlereceivermessage.text = "#EQPSPC INTERLOCK#";

                val machine = arry_receiverMessage[0]!![4].substring(arry_receiverMessage[0]!![4].lastIndexOf(">") + 1)
                if (machine > 0.toString())
                    viewBinding.txtReceiverMACHINEValue.append(machine)

                val lotid = arry_receiverMessage[0]!![5].substring(arry_receiverMessage[0]!![5].lastIndexOf(">")+1)
                if(lotid > 0.toString())
                    viewBinding.txtReceiverLOTIDValue.append(lotid)

                val rRecipe = arry_receiverMessage[0]!![6].substring(arry_receiverMessage[0]!![6].lastIndexOf(">")+1)
                if(rRecipe > 0.toString())
                    viewBinding.txtReceiverRemoteRecipeValue.append(rRecipe)

                val pRecipe = arry_receiverMessage[0]!![7].substring(arry_receiverMessage[0]!![7].lastIndexOf(">")+1)
                if(pRecipe > 0.toString())
                    viewBinding.txtReceiverProcessRecipeValue.append(pRecipe)

                val time = arry_receiverMessage[0]!![0].substring(arry_receiverMessage[0]!![0].lastIndexOf(">")+1)
                if(time > 0.toString())
                    viewBinding.txtReceiverTIMEValue.append(time.substring(0, time.indexOf("+")).replace("T"," "))
            }
        }
        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                setData()
            }
        })
    }

    private fun setData(){
        lifecycleScope.launch {
            CommonUtil.hideKeyboard(this@RecipeInterlockActivity, currentFocus)

            val sDeviceName = DeviceInfo.DEVICE_NAME; //PDA ID
            val originalTime = viewBinding.txtReceiverTIMEValue.text.toString()
            val inputFormatter = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")
            val outputFormatter = java.time.format.DateTimeFormatter.ofPattern("yyyy/MM/dd_HH:mm:ss")

            val sMasterTime = try {
                val parsedDate = java.time.LocalDateTime.parse(originalTime, inputFormatter)
                parsedDate.format(outputFormatter) // 결과: "2026/06/01_21:37:02"
            } catch (e: Exception) {
                originalTime
            }


            val sEqpid = viewBinding.txtReceiverMACHINEValue.text.toString()
            val sRecipe = viewBinding.txtReceiverRemoteRecipeValue.text.toString()
            val sLotID = "NULL";
            val sSlot = "NULL";
            val sUsers = DeviceInfo.OPERATOR_ID

            val current = LocalDateTime.now()
            val formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd_HH:mm:ss")
            val sCurrentTime = current.format(formatter)

            val sendMessage = MessageFactoryUtil.intlkpopupcheck(
                sMasterTime, "RECIPE", "POP-UP", sDeviceName, "PDA", sDeviceName,
                "http://::1:62011/InterlockClient.soap", "Y", sUsers, sCurrentTime,
                sEqpid, sRecipe, sLotID, sSlot
            )

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.SETGASUSAGE
            )
            finish()
        }
    }
}

