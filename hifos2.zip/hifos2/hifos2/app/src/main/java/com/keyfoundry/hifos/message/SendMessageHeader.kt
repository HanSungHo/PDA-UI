package com.keyfoundry.hifos.message


/*
모바일 서버에 보낼 메시지 Header Class
<MSGNAME></MSGNAME>
<RECEIVER></RECEIVER>
<SENDER></SENDER>
<MSGTYPE></MSGTYPE>
<WITHREPLY></WITHREPLY>
<STATUS></STATUS>
<ERRMSG></ERRMSG>
<TID></TID>
*/
data class SendMessageHeader(
    var MSGNAME : String ,
    var RECEIVER : String ,
    var SENDER : String ,
    var MSGTYPE : String ,
    var WITHREPLY : String ,
    var STATUS : String ,
    var ERRMSG : String ,
    var TID : String
)
