package com.keyfoundry.hifos.view.chat

data class AlarmRowItem(
    val title: String,
    val value: String
)