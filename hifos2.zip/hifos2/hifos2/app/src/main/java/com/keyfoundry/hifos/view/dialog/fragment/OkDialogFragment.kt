package com.keyfoundry.hifos.view.dialog.fragment

import android.app.Dialog
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.utils.OnSingleClickListener

/*
* 비동기방식의 Dialog
* 다이얼로그가 뜨면서 뒤에 코드를 계속 진행한다.
* */
class OkDialogFragment : DialogFragment {

    private var txtDialogTitle: String = ""
    private var txtDialogContent: String = ""
    private var btnOkstr: String = ""

    companion object {
        private const val TAG = "OkDialogFragment"
    }

    constructor()

    constructor(txtDialogTitle: String, txtDialogContent: String, btnOkstr: String) : this() {
        this.txtDialogTitle = txtDialogTitle
        this.txtDialogContent = txtDialogContent
        this.btnOkstr = btnOkstr
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return object : Dialog(requireActivity(), theme) {
            override fun onBackPressed() {
                dialog?.dismiss()
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.d(TAG, "onCreateView")
        val view = inflater.inflate(R.layout.fragment_dialog_ok, container, false)

        dialog?.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog?.setCancelable(false)

        val dialogTitle = view.findViewById<TextView>(R.id.txt_dialog_title)
        val dialogContent = view.findViewById<TextView>(R.id.txt_dialog_content)
        val btnOk = view.findViewById<Button>(R.id.btn_ok)

        dialogTitle.text = txtDialogTitle
        dialogContent.text = txtDialogContent
        dialogContent.movementMethod = ScrollingMovementMethod()
        btnOk.text = btnOkstr

        btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                dialog?.dismiss()
            }
        })

        return view
    }
}