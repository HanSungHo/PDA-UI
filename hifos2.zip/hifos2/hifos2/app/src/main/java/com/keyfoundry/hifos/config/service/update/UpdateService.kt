package com.keyfoundry.hifos.config.service.update

import android.util.Log
import androidx.fragment.app.FragmentManager
import com.keyfoundry.hifos.BuildConfig
import com.keyfoundry.hifos.config.service.RetrofitUpdateService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class UpdateService : FragmentManager() {
    companion object {
        const val TAG = "VersionCheck"
        suspend fun checkVersion(): Boolean {
            var flag = false
            return withContext(Dispatchers.IO) {
                val applicationVersion = BuildConfig.VERSION_NAME
                try {
                    val serverVersion = RetrofitUpdateService.API.getVersion().execute().body()!!.elements[0].versionName

                    Log.d("Application Version" , applicationVersion)
                    Log.d("Server Version" , serverVersion)
                    if(applicationVersion!=serverVersion){
                        flag = true
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                //        Toast.makeText(this@withContext, "UPDATE서버 오류", Toast.LENGTH_SHORT).show()
                    }
                }
                flag
            }
        }
    }

}