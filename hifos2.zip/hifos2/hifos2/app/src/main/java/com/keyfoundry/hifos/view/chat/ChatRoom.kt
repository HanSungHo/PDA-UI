package com.keyfoundry.hifos.view.chat

data class ChatRoom(
    val roomId: String,
    val roomName: String,
    var lastMessage: String,
    var time: String,
    var unReadCount: String
)