package com.keyfoundry.hifos.view.esheet.moveout

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.TextView
import androidx.core.view.children
import androidx.core.view.size
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityBatchMoveOutBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.LoadingBar
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.comment.CommentListActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class BatchMoveOutActivity : HFActivity() {
    init {
        this.update = false
    }

    companion object {
        private const val TAG = "BatchMoveOutActivity"
    }

    //test
    private lateinit var viewBinding : ActivityBatchMoveOutBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var gridService: GridService

    private lateinit var m_sSkip: String

    private lateinit var selectedRow: CTRowLayout
    private lateinit var gridList :CTMainLayout

    private var m_sThickComment = ""
    private var gsTranport = "";

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityBatchMoveOutBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        gridService = GridService(applicationContext)

        val batId = intent.getStringExtra("BATCHID").toString()
        val lotId = intent.getStringExtra("LOTID").toString()
        val eqpId = intent.getStringExtra("EQPID").toString()
        val recipe = intent.getStringExtra("RECIPE").toString()
        val comment = intent.getStringExtra("COMMENT").toString()
        val Tranport = intent.getStringExtra("TRANSPORT").toString()

        viewBinding.txtBatId.text = batId
        viewBinding.txtEqpId.text = eqpId
        viewBinding.txtRecipe.text = recipe
        viewBinding.txtComment.text = comment
        gsTranport = Tranport

        viewBinding.btnExecuteMoveOut.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                if(::selectedRow.isInitialized) {
                    moveOut()
                }
            }
        })

        viewBinding.btnReadComment.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                commentRead()
            }
        })

        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                if (::gridList.isInitialized) {
                    val mainTable = gridList.mainTable
                    for (row in 0 until mainTable.size) {
                        val lotIdIndex = gridService.getColumnIndex(gridList, "LOTID")
                        val statusIndex = gridService.getColumnIndex(gridList, "STATUS")
                        val tableRow = mainTable.getChildAt(row) as CTRowLayout

                        val lotId = (tableRow.getChildAt(lotIdIndex) as TextView).text
                        val status = (tableRow.getChildAt(statusIndex) as TextView).text

                        if (lotId != "D/W" && lotId != "" && status != "WAIT") {
                            OkDialog.show(
                                supportFragmentManager,
                                GetString.TXTDIALOGTITLE_ERROR,
                                "[$lotId]는 $status 상태 입니다.",
                                GetString.BTNOKSTR
                            )
                            return
                        }
                    }
                }

                val returnIntent = Intent()
                setResult(Activity.RESULT_OK, returnIntent)
                finish()
            }
        })

        viewBinding.btnClose.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
            }
        })

        getBatchListByLot(lotId)
    }

    private fun getBatchListByLot(lotId: String) {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.batchListByLotMoveOut(
                lotId,
                viewBinding.txtBatId.text.toString(),
                viewBinding.txtEqpId.text.toString(),
                DeviceInfo.FACILITY,
                "MVOU"
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.BATCHLISTBYLOT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            Log.d(TAG, "getbatchlistbylot : ${result}")

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sBatchID = messageBody.optString("BATCHID")
                val sEqpID = messageBody.optString("EQPID")
                val sBatchType = messageBody.optString("BATCHTYPE")
                val sMonitorWaferCount = messageBody.optString("MWCOUNT")
                val sCheckParameter = messageBody.optString("CHECKPARAMETER") // 추가  2014.05.22
                m_sThickComment = ""

                if (sCheckParameter == "N") {
                    OkDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_ERROR,
                        "해당 Batch에 입력된 계측 \n" +
                                "Parameter값이 없습니다.\n" +
                                "계측 Parameter 입력 후,\n" +
                                "다시 수행 하시기 바랍니다.",
                        GetString.BTNOKSTR
                    )
                    finish()
                    return@launch
                }

                var nWCommentCnt = 0

                val itemList = ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "BATCHITEMS")

                val batchItemList = JSONArray()
                for (i in 0 until itemList.length()) {

                    val item = itemList[i] as JSONObject

                    val sWCommentCnt = item.optString("NWCOMMENTQTY")
                    val sthick = item.optString("THICKAREA")

                    if(!(item.optString("PROCESSNAME")=="MW_TEST"||item.optString("LOTID").isEmpty())){
                        batchItemList.put(item)
                    }

                    if (m_sThickComment != "") {
                        m_sThickComment = m_sThickComment + "\n" + sthick
                    } else {
                        m_sThickComment = sthick;
                    }

                    nWCommentCnt += sWCommentCnt.toIntOrNull() ?: 0
                }

                val columnData = linkedMapOf(
                    "LOTID" to ColumnProperty("LOTNO", Gravity.CENTER, false),
                    "COMMENTQTY" to ColumnProperty("C", Gravity.CENTER, false),
                    "STATUS" to ColumnProperty("상태", Gravity.CENTER, false, 100),
                    "PROCESSSTEP" to ColumnProperty("공정명", Gravity.CENTER, false),
                    "PRODUCT" to ColumnProperty("제품명", Gravity.CENTER, false),
                    "QUANTITY" to ColumnProperty("수량", Gravity.CENTER, false),
                    "ERRORMESSAGE" to ColumnProperty("에러메시지", Gravity.CENTER, false, 500),
                    "OPERATION" to ColumnProperty("OPERATION", Gravity.CENTER, false),
                    "SUBOPERATION" to ColumnProperty("SUBOPERATION", Gravity.CENTER, false),
                    "LOTSTATE" to ColumnProperty("STATE", Gravity.CENTER, false),
                    "NWCOMMENTQTY" to ColumnProperty("WCOMMENTCNT", Gravity.CENTER, false),
                    "OPERSEQUENCE" to ColumnProperty("OPERSEQUENCE", Gravity.CENTER, false),
                    "BAYNAME" to ColumnProperty("BAYNAME",Gravity.CENTER,false ),
                    "DEFAULTSTOCKERNAME" to ColumnProperty("STOKERNAME",Gravity.CENTER,false)
                )

                // sProcessName == "MW_TEST" 이면 그리드에서 뺴야됨

                if (batchItemList.length() != 0) {
                    gridList = gridService.setGridPropData(columnData, batchItemList)
                    selectMoveOut(gridList)
                    viewBinding.baseLayout.addView(gridList)

                    if (nWCommentCnt > 0) {
                        OkDialog.show(
                            supportFragmentManager,
                            "정보",
                            "작업성 COMMENT가 있습니다.\n읽은후 진행하세요",
                            GetString.BTNOKSTR
                        )

                        return@launch
                    }

                    moveOutAll()
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )
            }

        }
    }

    private fun moveOut() {
        val sLotNo = (selectedRow.tag as GridService.RowData).rowDataList["LOTID"].toString()
        val sState = (selectedRow.tag as GridService.RowData).rowDataList["LOTSTATE"].toString()
        val sStatus = (selectedRow.tag as GridService.RowData).rowDataList["STATUS"].toString()
        val sOperation =
            (selectedRow.tag as GridService.RowData).rowDataList["OPERATION"].toString()
        val sSubOperation =
            (selectedRow.tag as GridService.RowData).rowDataList["SUBOPERATION"].toString()
        val sQty = (selectedRow.tag as GridService.RowData).rowDataList["QUANTITY"].toString()

        val sOpType = (selectedRow.tag as GridService.RowData).rowDataList["OPTYPE"].toString()

        var sCarry = ""
        var sBayname = ""
        var sStockername = ""

        if (gsTranport =="Y"){
            sCarry = "Y"
            sBayname = (selectedRow.tag as GridService.RowData).rowDataList["BAYNAME"].toString()
            sStockername = (selectedRow.tag as GridService.RowData).rowDataList["DEFAULTSTOCKERNAME"].toString()
        }
        else {
            sCarry = "N"
            sBayname = ""
            sStockername = ""
        }


        if (sLotNo == "D/W") {
            OkDialog.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_ERROR,
                "DUMMY LOT은 MOVE OUT할 수 없습니다.",
                GetString.BTNOKSTR
            )
            return
        }

        if (sLotNo.isEmpty()) {
            OkDialog.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_ERROR,
                "빈 LOT은 MOVE OUT할 수 없습니다.",
                GetString.BTNOKSTR
            )
            return
        }

        if (sState != "WIP") {
            OkDialog.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_ERROR,
                "[$sLotNo]는 [$sState]상태로\nMOVE OUT할수 없습니다.",
                GetString.BTNOKSTR
            )
            return
        }

        if (sStatus != "RUN" && sStatus != "FAIL") {
            OkDialog.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_ERROR,
                "[$sLotNo]는 RUN상태가 아닙니다.\nMOVE OUT할수 없습니다.",
                GetString.BTNOKSTR
            )
            return
        }

        val returnCode = OkCancelDialog.show(
            supportFragmentManager,
            GetString.TXTDIALOGTITLE_OK,
            "[$sLotNo] LOT을 개별 MOVE OUT하려합니다.\n하시겠습니까?",
            GetString.BTNYESSTR,
            GetString.BTNNOSTR
        )

        if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
            return
        }

        val sendMessage = MessageFactoryUtil.moveOut(
            sLotNo,
            DeviceInfo.FACILITY,
            viewBinding.txtEqpId.text.toString(),
            sOperation,
            sSubOperation,
            viewBinding.txtRecipe.text.toString(),
            sOpType,
            "N",
            DeviceInfo.OPERATOR_ID,
            viewBinding.txtComment.text.toString(),
            sCarry,
            sBayname,
            sStockername,
            sQty,
            "",
            ""
        )

        mainScope.launch {
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MOVEOUT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val statusView = selectedRow.getChildAt(2) as TextView
                statusView.text = "WAIT"
                selectedRow.setBackgroundColor(Color.BLUE)
                viewBinding.btnExecuteMoveOut.isEnabled = false

                getFqcSamplingInfo(sLotNo ,sOpType, sOperation, sSubOperation)

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)

                val statusView = selectedRow.getChildAt(2) as TextView
                statusView.text = "FAIL"

                val errorMessageView = selectedRow.getChildAt(6) as TextView
                errorMessageView.text = errorMessage
                selectedRow.setBackgroundColor(Color.RED)

                OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )

            }
        }
    }

    private suspend fun moveOutAll() {
        var nCount = 0
        viewBinding.btnOk.isEnabled = false
        val mainTable = gridList.mainTable
        for (row in 0 until mainTable.size) {
            val tableRow = mainTable.getChildAt(row) as CTRowLayout
            val sLotNo = (tableRow.tag as GridService.RowData).rowDataList["LOTID"].toString()
            val sState = (tableRow.tag as GridService.RowData).rowDataList["LOTSTATE"].toString()
            val sStatus = (tableRow.tag as GridService.RowData).rowDataList["STATUS"].toString()
            if (sLotNo != "D/W" && sLotNo != "") {
                if (sState != "WIP") {
                    OkDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_ERROR,
                        "[$sLotNo]는 [$sState]상태로\nMOVE OUT할수 없습니다.",
                        GetString.BTNOKSTR
                    )
                    viewBinding.btnOk.isEnabled = true
                    return
                }
                if (sStatus != "RUN") {
                    OkDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_ERROR,
                        "[$sLotNo]는 RUN상태가 아닙니다.\nMOVE OUT할수 없습니다.",
                        GetString.BTNOKSTR
                    )
                    viewBinding.btnOk.isEnabled = true
                    return
                }
                nCount++
            }
        }

        if (nCount <= 0) {
            OkDialog.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_ERROR,
                "MOVE OUT할 LOT이 없습니다.",
                GetString.BTNOKSTR
            )
            viewBinding.btnOk.isEnabled = true
            return
        }
        var errorCount = 0
        LoadingBar.show(supportFragmentManager)
        for (row in 0 until mainTable.size) {
            val tableRow = mainTable.getChildAt(row) as CTRowLayout

            val sLotNo = (tableRow.tag as GridService.RowData).rowDataList["LOTID"].toString()
            val sState =
                (tableRow.tag as GridService.RowData).rowDataList["LOTSTATE"].toString()
            val sStatus = (tableRow.tag as GridService.RowData).rowDataList["STATUS"].toString()
            val sOperation =
                (tableRow.tag as GridService.RowData).rowDataList["OPERATION"].toString()
            val sSubOperation =
                (tableRow.tag as GridService.RowData).rowDataList["SUBOPERATION"].toString()
            val sQty = (tableRow.tag as GridService.RowData).rowDataList["QUANTITY"].toString()

            val sOpType = (tableRow.tag as GridService.RowData).rowDataList["OPTYPE"].toString()

            var sCarry = ""
            var sBayname = ""
            var sStockername = ""

            if (gsTranport =="Y"){
                sCarry = "Y"
                sBayname = (tableRow.tag as GridService.RowData).rowDataList["BAYNAME"].toString()
                sStockername = (tableRow.tag as GridService.RowData).rowDataList["DEFAULTSTOCKERNAME"].toString()
            }
            else {
                sCarry = "N"
                sBayname = ""
                sStockername = ""
            }

            sBayname = (tableRow.tag as GridService.RowData).rowDataList["BAYNAME"].toString()
             sStockername = (tableRow.tag as GridService.RowData).rowDataList["DEFAULTSTOCKERNAME"].toString()

            if (sLotNo == "D/W" || sLotNo.isEmpty()) {
                continue
            }

            val sendMessage = MessageFactoryUtil.moveOut(
                sLotNo,
                DeviceInfo.FACILITY,
                viewBinding.txtEqpId.text.toString(),
                sOperation,
                sSubOperation,
                viewBinding.txtRecipe.text.toString(),
                sOpType,
                "N",
                DeviceInfo.OPERATOR_ID,
                viewBinding.txtComment.text.toString(),
                sCarry,
                sBayname,
                sStockername,
                sQty,
                "",
                ""
            )
            mainScope.launch {
                val message =
                    MessageSender.send(supportFragmentManager,sendMessage, MessageName.MOVEOUT)
                val isSuccessFul = message.isSuccessFul
                val result = message.result
                if (isSuccessFul) {

                    val statusView = tableRow.getChildAt(2) as TextView
                    statusView.text = "WAIT"
                    tableRow.setBackgroundColor(Color.BLUE)

                    getFqcSamplingInfo(sLotNo, sOpType, sOperation, sSubOperation)

                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    val statusView = tableRow.getChildAt(2) as TextView
                    statusView.text = "FAIL"

                    val errorMessageView = tableRow.getChildAt(6) as TextView
                    errorMessageView.text = errorMessage
                    tableRow.setBackgroundColor(Color.RED)

                    errorCount++
                }

                for (col in 0 until tableRow.childCount) {
                    val rowText = tableRow.getChildAt(col) as TextView
                    rowText.setTextColor(Color.WHITE)
                }
            }
            //  progressBar 필요하면 주석 해제(Layout도 같이)
            //  progressBar.incrementProgressBy(100/nCount)
            delay(500L)
        }
        LoadingBar.hide(supportFragmentManager)

        if (errorCount > 0) {
            OkDialog.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_ERROR,
                "BATCH MOVE OUT처리 도중 [$errorCount]개의 에러가 발생하였습니다.",
                GetString.BTNOKSTR
            )
            viewBinding.btnOk.isEnabled = true
            return
        }

        if (m_sThickComment != "") {
            if (m_sThickComment.contains("UV")) {
                OkDialog.show(
                    supportFragmentManager,
                    "UV검사 대상",
                    m_sThickComment,
                    GetString.BTNOKSTR
                )
            } else {
                OkDialog.show(
                    supportFragmentManager,
                    "두께 계측 대상",
                    m_sThickComment,
                    GetString.BTNOKSTR
                )
            }
        }
        /* 2022.01.27에 diff요청으로 인해 완료 메세지 삭제
        OkDialog.show(
            supportFragmentManager,
            GetString.TXTDIALOGTITLE_OK,
            "BATCH MOVE OUT처리를 완료 하였습니다.",
            GetString.BTNOKSTR
        )
        */

        checkBatchCount()

       /* val returnIntent = Intent()
        setResult(Activity.RESULT_OK, returnIntent)
        finish()*/
    }

    private fun commentRead(){
        val sLotNo = (selectedRow.tag as GridService.RowData).rowDataList["LOTID"].toString()
        val sOperation = (selectedRow.tag as GridService.RowData).rowDataList["OPERATION"].toString()
        val sSubOperation = (selectedRow.tag as GridService.RowData).rowDataList["SUBOPERATION"].toString()
        val sProcessStep = (selectedRow.tag as GridService.RowData).rowDataList["PROCESSSTEP"].toString()
        val sOperSeq = (selectedRow.tag as GridService.RowData).rowDataList["OPERSEQUENCE"].toString()

        val commentReadIntent = Intent(applicationContext, CommentListActivity::class.java)

        commentReadIntent.putExtra("LOTID", sLotNo)
        commentReadIntent.putExtra("OPERATION", sOperation)
        commentReadIntent.putExtra("SUBOPERATION", sSubOperation)
        commentReadIntent.putExtra("PROCESSSTEP", sProcessStep)
        commentReadIntent.putExtra("OPERSEQUENCE",sOperSeq )

        startActivity(commentReadIntent)
    }


    private fun selectMoveOut(gridData: CTMainLayout) {
        for (row in gridData.mainTable.children) {
            row.setOnTouchListener { v, event ->
                for (row in gridData.mainTable.children) {
                    if (((row as CTRowLayout).getChildAt(2) as TextView).text == "FAIL") {
                        row.setBackgroundColor(Color.RED)
                        for (col in 0 until (row as CTRowLayout).childCount) {
                            val rowText = row.getChildAt(col) as TextView
                            rowText.setTextColor(Color.WHITE)
                        }

                    } else if (((row as CTRowLayout).getChildAt(2) as TextView).text == "WAIT") {
                        row.setBackgroundColor(Color.BLUE)
                        for (col in 0 until (row as CTRowLayout).childCount) {
                            val rowText = row.getChildAt(col) as TextView
                            rowText.setTextColor(Color.WHITE)
                        }
                    }

                    else {
                        row.setBackgroundColor(Color.parseColor("#00FFFFFF"))
                        for (col in 0 until (row as CTRowLayout).childCount) {
                            val rowText = row.getChildAt(col) as TextView
                            rowText.setTextColor(Color.BLACK)
                        }
                    }
                }

                selectedRow = v as CTRowLayout
                selectedRow.setBackgroundColor(Color.rgb(37,197,223))
                for (col in 0 until selectedRow.childCount) {
                    val rowText = selectedRow.getChildAt(col) as TextView
                    rowText.setTextColor(Color.WHITE)
                }

                val selectedRowComment = (selectedRow.getChildAt(1) as TextView).text.toString().toIntOrNull() ?: 0

                val selectedRowStatus = (selectedRow.getChildAt(2) as TextView).text.toString()

                viewBinding.btnReadComment.isEnabled = selectedRowComment!=0


                viewBinding.btnExecuteMoveOut.isEnabled = selectedRowStatus != "WAIT"
                true
            }
        }
    }

    private fun  getFqcSamplingInfo(lotId: String, opType: String, operation : String, subOperation : String ) {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.fqcSampling(lotId, opType, viewBinding.txtEqpId.text.toString(), operation, subOperation)

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.FQCSAMPLING)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sCycleComment = messageBody.optString("CYCLECOMMENT")
                val sRecipeComment = messageBody.optString("RECIPECOMMENT")
                val sDeleteCode = messageBody.optString("DELETECODE")
                val sUpdateCode = messageBody.optString("UPDATECODE")

                if(sCycleComment != ""){
                    OkDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        sCycleComment,
                        GetString.BTNOKSTR
                    )
                }
                if(sRecipeComment != ""){
                    OkDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        sRecipeComment,
                        GetString.BTNOKSTR
                    )
                }
                if(sUpdateCode != "") {
                    OkDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        sUpdateCode,
                        GetString.BTNOKSTR
                    )
                }
                if(sDeleteCode != "") {
                    OkDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        sDeleteCode,
                        GetString.BTNOKSTR
                    )
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )

            }
        }
    }

    private fun checkBatchCount(){

        val sendMessage = MessageFactoryUtil.checkBatchCount(
            DeviceInfo.FACILITY,viewBinding.txtEqpId.text.toString(),DeviceInfo.OPERATOR_ID
        )
        mainScope.launch {
            val message =
                MessageSender.send(supportFragmentManager,sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                if(messageBody.optString("BATCHDOWN")=="Y"){
                    OkDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        messageBody.optString("DOWNMESSAGE"),
                        GetString.BTNOKSTR
                    )
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )
            }

            val returnIntent = Intent()
            setResult(Activity.RESULT_OK, returnIntent)
            finish()

        }

    }

}
