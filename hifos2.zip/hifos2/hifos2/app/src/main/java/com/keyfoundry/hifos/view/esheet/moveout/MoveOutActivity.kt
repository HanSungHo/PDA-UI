package com.keyfoundry.hifos.view.esheet.moveout

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Vibrator
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.isGone
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.service.dto.ResponseData
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityMoveOutBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.cmm.BatchLotListActivity
import com.keyfoundry.hifos.view.cmm.WaferSelectActivity
import com.keyfoundry.hifos.view.dialog.MoveOutEqpDownDialogActivity
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDailogAlram
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.diff.DiffInstParameterActivity
import com.keyfoundry.hifos.view.esheet.comment.CommentListActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray

class MoveOutActivity : HFActivity(){

    companion object {
        private const val TAG = "MoveOutActivity"
    }

    private lateinit var viewBinding : ActivityMoveOutBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    //lot정보 조회결과 저장하여 전역으로 사용하기 위하여 추가
    private var spinnerBayItems = arrayListOf<String>()
    private var spinnerStockerItems = arrayListOf<String>()

    private val moveOutData = MoveOutData()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityMoveOutBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        viewBinding.txtProduct.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtCurrentOperation.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtNextOperation.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtMaskTag.movementMethod = ScrollingMovementMethod.getInstance()

        viewBinding.spinnerBay.isEnabled = false
        viewBinding.spinnerStk.isEnabled = false

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {

            val lotId = intent.getStringExtra("LOTID").toString()
            viewBinding.txtLotNo.text = lotId
            getLotInfo()
        }

        viewBinding.btnInputScope.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val inputScopeIntent = Intent(applicationContext, InputScopeDataActivity::class.java)

                inputScopeIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                inputScopeActivityResultLauncher.launch(inputScopeIntent)
            }
        })

        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
            }
        })

        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {

                if(moveOutData.bibuha == "Y") {
                    val eqpDownIntent =
                        Intent(applicationContext, MoveOutEqpDownDialogActivity::class.java)
                    eqpDownIntent.putExtra("MACHINE", moveOutData.sWorkedEqpId)
                    eqpDownIntent.putExtra("CHAMBERLIST", moveOutData.chamberList)

                    moveOutEqpDownActivityResultLauncher.launch(eqpDownIntent)
                } else {
                    onOk()
                }


            /*    if(bibuha == "Y") {
                    val returnCode = OkCancelDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        "${moveOutData.sWorkedEqpId} 장비\n비부하 DOWN 시키겠습니까?",
                        GetString.POSITIVEBTNSTR,
                        GetString.NEGATIVEBTNSTR
                    )
                    if (returnCode == OkCancelDialog.RETURN_CODE_OK) {
                        downEqp()
                    } else {
                        onOk()
                    }
                } else {
                    onOk()
                }*/

            }
        })

        viewBinding.checkboxTransfer.setOnCheckedChangeListener { compoundButton, b ->
            if (b) {
                viewBinding.spinnerBay.isEnabled = true
                viewBinding.spinnerStk.isEnabled = true
                moveOutData.m_oCarry = true
                getAreaBayInfo()
            } else {
                viewBinding.spinnerBay.isEnabled = false
                viewBinding.spinnerStk.isEnabled = false
                moveOutData.m_oCarry = false
            }
        }

        viewBinding.checkboxNextProcessSkip.setOnCheckedChangeListener { compoundButton, b ->
            moveOutData.m_oSkip = b
        }

        viewBinding.checkboxWFInterlockCancel.setOnCheckedChangeListener { compoundButton, b ->
            moveOutData.m_oWaferinterlock = b
        }

        viewBinding.btnBatId.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val batchLotListIntent = Intent(applicationContext, BatchLotListActivity::class.java)

                Log.d("BATID", viewBinding.txtBatId.text.toString())
                batchLotListIntent.putExtra("BATID", viewBinding.txtBatId.text.toString())
                //        batchLotListIntent.putExtra("SLOTID", "slotId?")
                batchActivityResultLauncher.launch(batchLotListIntent)
            }
        })

        viewBinding.btnPara.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val diffParaIntent = Intent(applicationContext, DiffInstParameterActivity::class.java)

                Log.d("LOTID", viewBinding.txtLotNo.text.toString())
                diffParaIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())

                startActivity(diffParaIntent)
            }
        })

        viewBinding.btnRead.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val commentReadIntent = Intent(applicationContext, CommentListActivity::class.java)

                Log.d("LOTID", viewBinding.txtLotNo.text.toString())
                commentReadIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                commentReadIntent.putExtra("OPERATION", moveOutData.m_sOperation)
                commentReadIntent.putExtra("SUBOPERATION", moveOutData.m_sSubOperation)
                commentReadIntent.putExtra("PROCESSSTEP", moveOutData.m_sProcessStep)
                commentReadIntent.putExtra("OPERSEQUENCE", moveOutData.m_sOperSeq)

                startActivity(commentReadIntent)
            }
        })

        viewBinding.btnWH.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                executeWaferSel()
            }
        })
    }

    private val waferSkipActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->
                    val skipWafer = intent.getStringExtra("SKIPWAFER").toString()
                    val reason = intent.getStringExtra("REASON").toString()
                    val sMinus = intent.getStringExtra("SMINUS").toString()
                    //val sMachineName = intent.getStringExtra("SMACHINENAME").toString() //2023.10.25
                    //val sRecipeName = intent.getStringExtra("SMACHINENAME").toString() //2023.10.25
                    updateSkipWafer(skipWafer, reason, sMinus)
                }
            }
        }

    private val batchActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->
                    val lotId = intent.getStringExtra("LOTID").toString()
                    viewBinding.txtLotNo.text = lotId
                    getLotInfo()
                }
            }
        }

    private val inputScopeActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->
                    if(intent.getStringExtra("WAFERLIST")?.isNotEmpty() == true) {
                        viewBinding.editComment.setText("; W/H:#" + intent.getStringExtra("WAFERLIST").toString())
                    }

                    if(intent.getStringExtra("LOGO")?.isNotEmpty() == true){
                        viewBinding.editMaskLogo.setText(intent.getStringExtra("LOGO"))
                    }
                }
            }
        }

    private val moveOutEqpDownActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->
                    onOk()
                }
            }
        }

    private fun checkSkipWafer() {

        val sWaferQty = moveOutData.sWaferQty
        val sMachinQty = moveOutData.sMachinQty
        val reasonList = moveOutData.reasonList
        val sWaferRecipe = moveOutData.sCheckSkipWaferRecipe
        val sWaferMachine = moveOutData.sCheckSkipWaferMachine

        viewBinding.btnOk.isEnabled = false

        val waferSkipIntent = Intent(applicationContext, WaferSkipActivity::class.java)
        waferSkipIntent.putExtra("WAFERQTY", sWaferQty)
        waferSkipIntent.putExtra("MACHINEQTY", sMachinQty)
        waferSkipIntent.putExtra("REASONLIST", reasonList)
        //waferSkipIntent.putExtra("CHECKSKIPWAFERMACHINE", sWaferMachine)
        //waferSkipIntent.putExtra("CHECKSKIPWAFERRECIPE", sWaferRecipe)
        waferSkipActivityResultLauncher.launch(waferSkipIntent)

    }

    private fun lotInfoEtcCheck() {
        val sOwner = moveOutData.sOwner
        val sCreateCategory = moveOutData.sCreateCategory
        val sLasteventcomment = moveOutData.sLasteventcomment
        val sProductQuantity = moveOutData.sProductQuantity
        val sCheckEtch = moveOutData.sCheckEtch
        val sCheckInterlock = moveOutData.sCheckInterlock
        val sLampMessge = moveOutData.sLampMessge
        val sAramMessge = moveOutData.sAramMessge
        val sHoldCode_out = moveOutData.sHoldCode_out
        val sHoldComment_out = moveOutData.sHoldComment_out
        val sThickNessMEssge = moveOutData.sThickNessMEssge

        if (DeviceInfo.AREA == "ETCH" && sOwner == "GF3P" && sCreateCategory == "SLOT") {
            var nWfcount = 0
            var nProductQuantity = Integer.parseInt(sProductQuantity)

//            val nEOS = sLasteventcomment.length
//            var nEnd = 0
//            var nStart = 0;
//            while (nEOS > nStart) {
//                nEnd = sTempComment.Find(",", nStart);
//
//                if (nEnd > 0) {
//                    nWfcount += 1;
//                    nStart = nEnd + 1;
//                } else {
//                    break;
//                }
//            }

            //위에 알고리즘 이걸로 대체.. 확인 필요 2021-08-27
            if(sLasteventcomment.isNotEmpty()){
                val tmpCommentList = sLasteventcomment.split(',')
                nWfcount = tmpCommentList.count()
            }

            if (sCheckEtch != "") {
                viewBinding.btnOk.isEnabled = nProductQuantity == nWfcount
            }
        }

        if (sCheckInterlock != "") {
            OkDailogAlram.show(supportFragmentManager, GetString.TXTDIALOGTITLE_OK, sCheckInterlock, GetString.POSITIVEBTNSTR,applicationContext,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
        }
        if (sLampMessge != "") {
            OkDailogAlram.show(supportFragmentManager, "자주 검사 알림", sLampMessge, GetString.POSITIVEBTNSTR,applicationContext,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
        }

        if(sThickNessMEssge != ""){
            OkDailogAlram.show(supportFragmentManager, "두께 측정 알림", sThickNessMEssge, GetString.POSITIVEBTNSTR,applicationContext,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
        }

        if (sAramMessge != "") {
            OkDailogAlram.show(
                supportFragmentManager,
                "이상연락 조치내용",
                sAramMessge,
                GetString.POSITIVEBTNSTR,
                applicationContext,
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            )
        } else if (sHoldCode_out != "") {
            OkDailogAlram.show(
                supportFragmentManager,
                "HOLD 해제 COMMENTS",
                "[$sHoldCode_out]\n$sHoldComment_out",
                GetString.POSITIVEBTNSTR,
                applicationContext,
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            )
        }
    }

    private fun getLotInfo() {
        mainScope.launch{
            val lotId = viewBinding.txtLotNo.text.toString()

            val sendMessage = MessageFactoryUtil.lotInfo(lotId, DeviceInfo.FACILITY, "MVOU", DeviceInfo.OPERATOR_ID)
            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.LOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                // init value
                moveOutData.setLotInfoDataList(result)

                setGlobalData()
                setComponent(lotId)
                checkValue()

            } else {
                viewBinding.btnOk.isEnabled = false
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )
            }
        }
    }

    private fun checkValue() {
        if (moveOutData.sEtcMsg != "") {
            OkDailogAlram.show(
                supportFragmentManager,
                "정보",
                moveOutData.sEtcMsg,
                GetString.POSITIVEBTNSTR,
                applicationContext,
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            )
        }

        if (moveOutData.sStatus == "WAIT") {
            OkDailogAlram.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_ERROR,
                "이미 MOVE OUT된 LOT입니다.",
                GetString.POSITIVEBTNSTR,
                applicationContext,
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            )
        }

        if (moveOutData.sState != "WIP") {
            OkDailogAlram.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_ERROR,
                "${moveOutData.sState} 상태 입니다. MOVE OUT할수 없습니다.",
                GetString.POSITIVEBTNSTR,
                applicationContext,
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            )
            return
        }

        if (moveOutData.sHoldStatus == "ONHOLD") {
            OkDailogAlram.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_ERROR,
                "HOLD된 LOT입니다. MOVE OUT할수 없습니다.",
                GetString.POSITIVEBTNSTR,
                applicationContext,
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            )
            return
        }

        if (moveOutData.sRemoteCheck == "Y") {
            viewBinding.btnOk.isEnabled = false
            OkDailogAlram.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_ERROR,
                "매뉴얼 Move Out이 불가한 장치입니다. 자동화 진행 이력을 확인 하세요.",
                GetString.POSITIVEBTNSTR,
                applicationContext,
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            )
            return
        }



        // batch lot일경우 Down된 장비일 경우, 알림 메시지 Pop-Up2020.05.25
        if (moveOutData.sBatchId != "") {
            if (moveOutData.sMachineState != "" && moveOutData.sMachineCode != "") {
                OkDailogAlram.show(
                    supportFragmentManager,
                    "장비 DOWN 알림",
                    "${moveOutData.sWorkedEqpId} 호기 ${moveOutData.sMachineState} \n(${moveOutData.sMachineCode}) Down 중!.",
                    GetString.POSITIVEBTNSTR,
                    applicationContext,
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                )
            }
        }

        val nNwCommentCnt = Integer.parseInt(moveOutData.sNWCommentQty)
        if (nNwCommentCnt > 0) {
            OkDailogAlram.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_OK,
                "읽지 않은 작업성 COMMENT가 [$nNwCommentCnt]가 있습니다.\n읽은 후 진행 하세요.",
                GetString.POSITIVEBTNSTR,
                applicationContext,
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            )
        }

        if (moveOutData.sWaferskipinter == "N") {
            viewBinding.checkboxWFInterlockCancel.isEnabled = false
        }


        if (moveOutData.sCheckSkipWafer == "N") {
            checkSkipWafer()
        } else {
            lotInfoEtcCheck()
        }

        if(moveOutData.sPcmCheck == "N"){
            viewBinding.btnOk.isEnabled = false
            OkDailogAlram.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_ERROR,
                "PCM 재작업이 미완료된 Lot 입니다.\n재작업 완료 후 Move Out 하시기 바랍니다.",
                GetString.POSITIVEBTNSTR,
                applicationContext,
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            )
            return
        }

        if(moveOutData.sMvinWaferCheckMSG !=""){
            viewBinding.btnOk.isEnabled = false
            OkDailogAlram.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_ERROR,
                moveOutData.sMvinWaferCheckMSG,
                GetString.POSITIVEBTNSTR,
                applicationContext,
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            )
            return
        }

        if(moveOutData.sBTAMsg !=""){
            OkDailogAlram.show(
                supportFragmentManager,
                "Boat/Tube/APC 누적막 Warning",
                moveOutData.sBTAMsg,
                GetString.POSITIVEBTNSTR,
                applicationContext,
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            )
        }

        if(moveOutData.sChildBatchID != ""){
            val returnCode = OkCancelDialog.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_OK,
                " 자 Batch 구성 Lot 입니다.\n 자 Batch Wafer 분리 하셨나요? ",
                GetString.POSITIVEBTNSTR,
                GetString.NEGATIVEBTNSTR
            )
            if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                viewBinding.btnOk.isEnabled = false
                return
            }
        }

        //---[Addition] 2024.05.29 By Sunggil Hwang, PQC 검사 유형별 진행 여부 학인 Interlock
        if(moveOutData.checkGateInspMsg != ""){
            OkDailogAlram.show(
                supportFragmentManager,
                "PQC검사 입력 확인",
                moveOutData.checkGateInspMsg+ "\n" +"DATA 확인 후 실적 입력 바랍니다.",
                GetString.POSITIVEBTNSTR,
                applicationContext,
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            )
            viewBinding.btnOk.isEnabled = false
            return
        }
    }

    private fun setComponent(lotId: String) {
        viewBinding.txtLotNo.text = lotId
        viewBinding.txtBatId.text = moveOutData.sBatchId
        viewBinding.txtRecipe.text = moveOutData.sWorkedRecipe
        viewBinding.txtMachine.text = moveOutData.sWorkedEqpId
        viewBinding.txtMaskTag.text = moveOutData.sWorkedReticle
        viewBinding.txtProduct.text = "${moveOutData.sProduct}(${moveOutData.sJobCode})"
        viewBinding.txtCurrentOperation.text =
            "${moveOutData.sProcessStep}(${moveOutData.sOperation}${moveOutData.sSubOperation})"
        viewBinding.txtNextOperation.text =
            "${moveOutData.sNextProcessStep}(${moveOutData.sNextOperation}${moveOutData.sNextSubOperation})"
        viewBinding.txtQty.text = moveOutData.sQty
        viewBinding.txtGoodChips.text = moveOutData.sGoodChips
        viewBinding.txtCommentSize.setText(moveOutData.sCommentQty)

        spinnerBayItems.add(moveOutData.sNextBay)
        spinnerStockerItems.add(moveOutData.sNextStocker)

        setBaySpinner(spinnerBayItems, true)
        setStockerSpinner(spinnerStockerItems, true)

        // 다음 공정이 Main공정이면 즉 Sub공정 = "00"이면 Skip하지 않도록 한다.(Jan 07, 2004. I. H. Lee)
        // 또한 Eng'r가 아닌이상 SKip처리 할 수 없도록 한다.
        //if(GL_PERMISSION == L"B" || GL_PERMISSION == L"C" || GL_PERMISSION == L"H")
        // 무조건 다음공정 SKIP 은 Disable (2005. 4. 21 Delta8988)
        viewBinding.checkboxNextProcessSkip.isEnabled = false
        viewBinding.checkboxTransfer.isEnabled = true

        viewBinding.btnBatId.isEnabled = moveOutData.sBatchId != ""
        viewBinding.btnOk.isEnabled = true
        viewBinding.btnInputScope.isEnabled = moveOutData.sPhotoOperType == "VI"


        // Added by C.S Leigh (18. Mar, 2005)
        // DI나 Inline 공정에서는 다음공정 Skip을 하지 못하게한다.
        //if(sPhotoType == L"DI" || sPhotoType == L"DI2" || sPhotoType == "PH" || sPhotoType == "PH2")
        //{
        //    GetDlgItem(IDC_CHECK_SKIP)->EnableWindow(FALSE);
        //}

        // Added by I. H. Lee (24 Feb, 2004)
        // Rework중일 경우 다음 공정 Skip을 하지 못하도록 막는다.
        //if(sReworkYesNo == L"R")
        //	GetDlgItem(IDC_CHECK_SKIP)->EnableWindow(FALSE);

        if (viewBinding.txtCommentSize.text.toString().toInt() <= 0) {
            viewBinding.btnRead.isEnabled = false
            viewBinding.btnRead.setBackgroundColor(Color.GRAY)
        } else {
            viewBinding.btnRead.isEnabled = true
            viewBinding.btnRead.setBackgroundColor(Color.rgb(19, 0, 103))
        }

        if(viewBinding.txtBatId.text.toString() != "") //2022.03.
        {
            viewBinding.checkboxTransfer.isChecked = true
        }
    }

    private fun setGlobalData() {
        if (moveOutData.sCreateCategory == "COUNT") {
            viewBinding.btnWH.setText("COUNT")
            moveOutData.m_CreateCategory = "COUNT";
            moveOutData.m_sComment = moveOutData.sLasteventcomment;
        } else if (moveOutData.sCreateCategory == "SLOT") {
            viewBinding.btnWH.setText("SLOT")
            moveOutData.m_CreateCategory = "SLOT";
            moveOutData.m_sComment = moveOutData.sLasteventcomment;
        } else {
            viewBinding.btnWH.setText("W/H")
        }

        moveOutData.m_sOperation = moveOutData.sOperation
        moveOutData.m_sSubOperation = moveOutData.sSubOperation
        moveOutData.m_sProcessStep = moveOutData.sProcessStep
        moveOutData.m_sOperSeq = moveOutData.sOperSeq
        moveOutData.m_sOpType = moveOutData.sOpType
        moveOutData.m_ProcessType = moveOutData.sProcessType

    }

    private fun getAreaBayInfo() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.areaBayInfo(DeviceInfo.FACILITY)

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.AREABAYINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val areaListJSON =
                    ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "BAYS")
                val selectedBay = viewBinding.spinnerBay.selectedItem?.toString()
                var selectedIndex = 0
                spinnerBayItems.clear()
                for (i in 0 until areaListJSON.length()) {
                    val area = areaListJSON.getJSONObject(i)
                    if (!selectedBay.isNullOrEmpty()) {
                        if (area.getString("BAY").equals(selectedBay)) {
                            selectedIndex = i+1
                        }
                    }
                    spinnerBayItems.add(area.getString("BAY"))
                }
                Log.e("BAY", selectedIndex.toString())
                setBaySpinner(spinnerBayItems, false)
                if (spinnerBayItems.size > 0)
                    viewBinding.spinnerBay.setSelection(selectedIndex)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )
            }

        }
    }

    private fun getStockerInfo() {
        mainScope.launch {
            if(viewBinding.spinnerBay.selectedItem == null || viewBinding.spinnerBay.selectedItem == "")
                return@launch

            val sendMessage = MessageFactoryUtil.bayStockerInfo(viewBinding.spinnerBay.selectedItem.toString(), DeviceInfo.FACILITY)

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.BAYSTOCKERINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {

                val stockerListJSON =
                    ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "STOCKERS")

                var selectedStocker = ""
                if (!viewBinding.spinnerStk.selectedItem?.toString().isNullOrEmpty()) {
                    selectedStocker = viewBinding.spinnerStk.selectedItem.toString()
                }
                var selectedIndex = 0
                spinnerStockerItems.clear()
                for (i in 0 until stockerListJSON.length()) {
                    val stocker = stockerListJSON.getJSONObject(i)
                    if (stocker.getString("STOCKER").equals(selectedStocker)) {
                        selectedIndex = i+1
                    }
                    spinnerStockerItems.add(stocker.getString("STOCKER"))
                }
                setStockerSpinner(spinnerStockerItems, false)

                if(spinnerStockerItems.size==1) {
                    viewBinding.spinnerStk.setSelection(1)
                } else if(spinnerStockerItems.size>0) {
                    viewBinding.spinnerStk.setSelection(selectedIndex)
                }
            } else {
                spinnerStockerItems.clear()
                setStockerSpinner(spinnerStockerItems, false)

                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )
            }
        }
    }

    private suspend fun moveOut() {
        var isSkip = ""
        if (moveOutData.m_oSkip) {
            isSkip = "Y"
        } else {
            isSkip = "N"
        }

        var isCarry = ""
        if (moveOutData.m_oCarry) {
            isCarry = "Y"
        } else {
            isCarry = "N"
        }

        var wfInterLock = ""
        if (moveOutData.m_oWaferinterlock) {
            wfInterLock = "Y"
        } else {
            wfInterLock = "N"
        }

        val lotId = viewBinding.txtLotNo.text.toString()
        val eqpId = viewBinding.txtMachine.text.toString()
        val operation = ""
        val subOperation = ""
        val recipe = viewBinding.txtRecipe.text.toString()
        //     val opType = ""
        //    val isSkip = ""
        val comment = viewBinding.editComment.text.toString()
        //    val isCarry = ""
        val bay = viewBinding.spinnerBay.selectedItem?.toString() ?: ""
        val stocker = viewBinding.spinnerStk.selectedItem?.toString() ?: ""
        val quantity = viewBinding.txtQty.text.toString()
        val inputMaskLogo = viewBinding.editMaskLogo.text.toString()
        //       val wfInterLock = ""

        val sendMessage = MessageFactoryUtil.moveOut(
            lotId,
            DeviceInfo.FACILITY,
            eqpId,
            moveOutData.m_sOperation,
            moveOutData.m_sSubOperation,
            recipe,
            moveOutData.m_sOpType,
            isSkip,
            DeviceInfo.OPERATOR_ID,
            comment,
            isCarry,
            bay,
            stocker,
            quantity,
            inputMaskLogo,
            wfInterLock
        )

        val message = MessageSender.send(supportFragmentManager, sendMessage, MessageName.MOVEOUT)
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

            val sTanpi = messageBody.optString("TANPI")
            val sampleResult = messageBody.optString("SAMPLERESULT")

            if(sTanpi!=""){
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
                    sTanpi, GetString.BTNOKSTR
                )
            }

            if(sampleResult!=""){
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
                    sampleResult, GetString.BTNOKSTR
                )
            }

            getFqcSamplingInfo()

            if (moveOutData.sProcessType == "WT" || moveOutData.sProcessType == "PCM") {
                setProbeCardHistory()
            }


        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            val returnCode = OkDailogAlram.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_ERROR,
                errorMessage,
                GetString.BTNOKSTR,
                applicationContext,
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            )
            viewBinding.btnOk.isEnabled = false
        }
    }

    private fun setProbeCardHistory(){
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.setProbeCardHistory(
                viewBinding.txtLotNo.text.toString(),
                DeviceInfo.FACILITY,
                viewBinding.txtQty.text.toString(),
                "",
                moveOutData.m_sOperation,
                moveOutData.m_sSubOperation,
                viewBinding.txtCurrentOperation.text.toString(),
                DeviceInfo.OPERATOR_ID,
                "", "",
                "MOVEOUT","",""
            )
            val message =  MessageSender.send(supportFragmentManager, sendMessage, MessageName.PROBECARDSET)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {

            }
            else
            {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDailogAlram.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR ,applicationContext
                    ,getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
            }

        }
    }


    private suspend fun getFqcSamplingInfo() {
        val sendMessage = MessageFactoryUtil.fqcSampling(
            viewBinding.txtLotNo.text.toString(),
            moveOutData.m_sOpType,
            viewBinding.txtMachine.text.toString(),
            moveOutData.m_sOperation,
            moveOutData.m_sSubOperation
        )

        val message =
            MessageSender.send(supportFragmentManager, sendMessage, MessageName.FQCSAMPLING)
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

            val sCycleComment = messageBody.optString("CYCLECOMMENT")
            val sRecipeComment = messageBody.optString("RECIPECOMMENT")
            val sDeleteCode = messageBody.optString("DELETECODE")
            val sUpdateCode = messageBody.optString("UPDATECODE")

            if (sCycleComment != "") {
                OkDailogAlram.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_OK,
                    sCycleComment,
                    GetString.BTNOKSTR,
                    applicationContext,
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                )
            }
            if (sRecipeComment != "") {
                OkDailogAlram.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_OK,
                    sRecipeComment,
                    GetString.BTNOKSTR,
                    applicationContext,
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                )
            }
            if (sUpdateCode != "") {
                OkDailogAlram.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_OK,
                    sUpdateCode,
                    GetString.BTNOKSTR,
                    applicationContext,
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                )
            }
            if (sDeleteCode != "") {
                OkDailogAlram.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_OK,
                    sDeleteCode,
                    GetString.BTNOKSTR,
                    applicationContext,
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                )
            }

        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDailogAlram.show(
                supportFragmentManager,
                GetString.TXTDIALOGTITLE_ERROR,
                errorMessage,
                GetString.BTNOKSTR,
                applicationContext,
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            )

        }

        val returnIntent = Intent()
        returnIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
        setResult(Activity.RESULT_OK, returnIntent)
        finish()

    }

    private fun onOk() {

        mainScope.launch {
            val sendMessage = MessageFactoryUtil.loginUserCheck(DeviceInfo.OPERATOR_ID, viewBinding.txtMachine.text.toString(), moveOutData.autoMotiveFlag)
            val message = MessageSender.send(supportFragmentManager, sendMessage,MessageName.LOGINUSERCHECK)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val sUserAreaFlag = messageBody.optString("AREACHECK");

                if (sUserAreaFlag == "N" || sUserAreaFlag == "") {
                     OkDailogAlram.show(
                         supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                         "로그인한 사용자가 진행할 수 없는 장비 입니다.", GetString.POSITIVEBTNSTR,
                         applicationContext,
                         getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                     )
                     viewBinding.btnOk.isEnabled = false
                     return@launch
                 }

                if (moveOutData.m_oSkip) {
                    var nextOperation = viewBinding.txtNextOperation.text.toString()
                    val returnCode = OkCancelDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        "아래와 같이 다음공정을 SKIP하시겠습니까?\n$nextOperation",
                        GetString.POSITIVEBTNSTR,
                        GetString.NEGATIVEBTNSTR
                    )
                    if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                        return@launch
                    }
                }


                if (moveOutData.m_oCarry) {
                    if (viewBinding.spinnerBay.selectedItem?.toString().isNullOrBlank()) {
                        OkDailogAlram.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            "BAY를 선택하세요.", GetString.POSITIVEBTNSTR,
                            applicationContext,
                            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                        )
                        return@launch
                    }

                    if (viewBinding.spinnerStk.selectedItem?.toString().isNullOrBlank()) {
                        OkDailogAlram.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            "STOCKER를 선택하세요.", GetString.POSITIVEBTNSTR,
                            applicationContext,
                            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                        )
                        return@launch
                    }
                }

                if (viewBinding.txtBatId.text.toString() != "") {
                    val batchMoveOutIntent =
                        Intent(applicationContext, BatchMoveOutActivity::class.java)

                    batchMoveOutIntent.putExtra("BATCHID", viewBinding.txtBatId.text.toString())
                    batchMoveOutIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                    batchMoveOutIntent.putExtra("EQPID", viewBinding.txtMachine.text.toString())
                    batchMoveOutIntent.putExtra("RECIPE", viewBinding.txtRecipe.text.toString())
                    batchMoveOutIntent.putExtra("COMMENT", viewBinding.editComment.text.toString())
                    if (moveOutData.m_oCarry) {
                        batchMoveOutIntent.putExtra("TRANSPORT", "Y")
                    } else {
                        batchMoveOutIntent.putExtra("TRANSPORT", "N")
                    }

                    batchMoveOutActivityResultLauncher.launch(batchMoveOutIntent)

                    return@launch

                } else {
                    moveOut()
                }
            } else {
                spinnerStockerItems.clear()
                setStockerSpinner(spinnerStockerItems, false)
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setBaySpinner(items: ArrayList<String>, selFirst: Boolean) {
        //1. set spinner
        val spinnerAdapter = ArrayAdapter(this, R.layout.contact_spinner_row_init, items)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerBay.adapter =
            InitSpinnerAdapter(spinnerAdapter, R.layout.contact_spinner_row_init, this)
        if (selFirst)
            viewBinding.spinnerBay.setSelection(1, false)
        viewBinding.spinnerBay.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View,
                position: Int,
                id: Long
            ) {
                getStockerInfo()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }
    }

    private fun updateSkipWafer(skipWafer: String, skipReason: String, sMinus: String) {
        mainScope.launch {
            val lotId = viewBinding.txtLotNo.text.toString()
            val machineName = moveOutData.sCheckSkipWaferMachine //viewBinding.txtMachine.text.toString()
            val recipeName = moveOutData.sCheckSkipWaferRecipe // viewBinding.txtRecipe.text.toString()

            val sendMessage = MessageFactoryUtil.updateSkipWafer(
                lotId,
                machineName,
                recipeName,
                skipWafer,
                DeviceInfo.OPERATOR_ID,
                skipReason,
                sMinus
            )

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.UPDATESKIPWAFER)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sUpdateFlag = messageBody.optString("UPDATEFLAG")
                if (sUpdateFlag == "Y") {
                    viewBinding.btnOk.isEnabled = true

                    OkDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        "수량 보정이 완료되었습니다.",
                        GetString.BTNOKSTR)
                }
                lotInfoEtcCheck()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )
            }

        }
    }

    private fun setStockerSpinner(items: ArrayList<String>, selFirst: Boolean) {
        //1. set spinner
        val spinnerAdapter = ArrayAdapter(this, R.layout.contact_spinner_row_init, items)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerStk.adapter =
            InitSpinnerAdapter(spinnerAdapter, R.layout.contact_spinner_row_init, this)
        if (selFirst)
            viewBinding.spinnerStk.setSelection(1, false)
    }

    private fun executeWaferSel() {
        mainScope.launch {
            val lotId = viewBinding.txtLotNo.text.toString()

            val sendMessage = MessageFactoryUtil.slotInfo(lotId, DeviceInfo.FACILITY, DeviceInfo.OPERATOR_ID)
            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.SLOTINFO)
            val isSuccessFul = message.isSuccessFul

            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val enableWaferList = messageBody.optString("WAFERLIST")
                moveOutData.slotWh = messageBody.optString("QUANTITY")
                moveOutData.checkEtch = messageBody.optString("CHECKETCH")

                val waferSelectIntent = Intent(applicationContext, WaferSelectActivity::class.java)
                waferSelectIntent.putExtra("LOTID", lotId)
                waferSelectIntent.putExtra("EXISTWAFERLIST", enableWaferList)
                waferSelectIntent.putExtra("FIXEDCOUNT", enableWaferList.split(",").count().toString())
                waferSelectIntent.putExtra("CATEGORY", moveOutData.m_CreateCategory)
                waferSelectIntent.putExtra("SELECTEDMACHINE", moveOutData.m_sComment)
                waferSelectActivityResultLauncher.launch(waferSelectIntent)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )
            }

        }
    }


    private fun downEqp(){
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.changeEQPStatus(
                viewBinding.txtMachine.text.toString(),
                DeviceInfo.FACILITY,
                "C  비부하(LOAD DOWN)",
                "CA001",
                "PDA_MVOUT_DOWN",
                DeviceInfo.OPERATOR_ID,
                DeviceInfo.OPERATOR_NAME,
                ""
            )

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.CHANGEEQPSTATUS)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val returnCode = OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_OK,
                    "장비상태가 변경되었습니다.",
                    GetString.BTNOKSTR,
                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)
            }

            onOk()
        }
    }

    private val waferSelectActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            var selectedWaferList = ""
            var selectedMachine = ""
            if (it.resultCode == RESULT_OK) {
                it.data?.let { intent ->
                    selectedWaferList = intent.getStringExtra("SELECTEDWAFERLIST").toString()
                        .replace(viewBinding.txtLotNo.text.toString() + ".", "")
                    selectedMachine = intent.getStringExtra("SELECTEDMACHINE").toString()

                }
            }

            Log.e(TAG, selectedWaferList)
            Log.e(TAG, selectedMachine)
            Log.e(TAG, moveOutData.m_CreateCategory)

            if (moveOutData.m_CreateCategory.isEmpty()) {
                viewBinding.editComment.setText("; W/H:#$selectedWaferList")
            } else {
                viewBinding.editComment.setText(selectedMachine)
            }

            if (moveOutData.m_CreateCategory == "SLOT" && DeviceInfo.AREA == "ETCH") {

                var nWfcount = 0
                val nProductQuantity = moveOutData.slotWh.toIntOrNull() ?: 0

                if(selectedMachine.isNotEmpty()){
                    val tmpCommentList = selectedMachine.split(',')
                    nWfcount = tmpCommentList.count()
                }

                if (moveOutData.checkEtch.isNotEmpty()) {
                    if (nProductQuantity != nWfcount) {
                        mainScope.launch {
                            OkDailogAlram.show(
                                supportFragmentManager,
                                "Move Out Interlock",
                                "Etch Dummy/Test Lot은 모든 W/F Handling 이후에  Move Out이 가능 합니다. ",
                                GetString.BTNOKSTR,
                                applicationContext,
                                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                            )
                        }
                        viewBinding.btnOk.isEnabled = false
                    } else {
                        viewBinding.btnOk.isEnabled = true
                    }
                }

            }
        }

    private val batchMoveOutActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                it.data?.let { intent ->
                    val returnIntent = Intent()
                    returnIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                    setResult(Activity.RESULT_OK, returnIntent)
                    finish()
                }
            }
        }

    inner class MoveOutData {
        // 전역 변수
        var m_CreateCategory : String = ""
        var m_sComment : String = ""
        var m_sOperation : String = ""
        var m_sSubOperation : String = ""
        var m_sProcessStep : String = ""
        var m_sOperSeq : String = ""
        var m_sOpType : String = ""
        var m_oSkip = false
        var m_oCarry = false
        var m_oWaferinterlock = false
        var m_ProcessType : String = ""

        var slotWh : String = ""
        var checkEtch : String= ""

        // LotInfo
        var sProduct : String = "" // PRODUCT
        var sFacility : String = "" // FACILITY
        var sOperation : String = "" // OPERATION
        var sCustomer : String = "" // CUSTOMER
        var sCategory : String = "" // CATEGORY
        var sEngineer : String = "" // ENGINEER
        var sPacking : String = "" // PACKING
        var sQty : String = "" // QUANTITY
        var sGoodChips : String = "" // GOODCHIPS
        var sRecipe : String = "" // RECIPE
        var sEqpGroup : String = "" // EQPGROUP
        var sCommentQty : String = "" // COMMENTQTY
        var sNWCommentQty : String = "" // NWCOMMENTQTY
        var sBatchId : String = "" // BATCHID
        var sArea : String = "" // AREA
        var sWorkedEqpId : String = "" // WORKEDEQPID
        var sWorkedRecipe : String = "" // WORKEDRECIPE
        var sWorkedReticle : String = "" // WORKEDRETICLE
        var sJobCode : String = "" // JOBCODE
        var sProcessStep : String = "" // PROCESSSTEP
        var sSubOperation : String = "" // SUBOPERATION
        var sOpType : String = "" // OPTYPE
        var sStatus : String = "" // STATUS
        var sState : String = "" // STATE
        var sHoldStatus : String = "" // HOLDSTATUS
        var sNextOperation : String = "" // NEXTOPERATION
        var sNextSubOperation : String = "" // NEXTSUBOPERATION
        var sNextProcessStep : String = "" // NEXTPROCESSSTEP
        var sEtcMsg : String = "" // ETCMSG
        var sNextBay : String = "" // NEXTBAY
        var sNextStocker : String = "" // NEXTSTOCKER
        var sOperSeq : String = "" // OPERSEQUENCE
        var sPhotoType : String = "" // PHOTOTYPE
        var sPhotoOperType : String = "" // PHOTOOPERTYPE
        // Added by I. H. Lee (24 Feb, 2004
        // Rework중일 경우 다음 공정 Skip을 하지 못하도록 막는다.
        var sReworkYesNo : String = "" // REWORKINFO
        // Added by jy.Lim(2014.07.07)
        var sCheckSkipWafer : String = "" // CHECKSKIPWAFER
        var sCheckSkipWaferMachine : String = "" // CHECKSKIPWAFERMACHINE
        var sCheckSkipWaferRecipe : String = "" // CHECKSKIPWAFERRecipe
        // Added by jy.Lim(2015.03.04)
        var sWaferskipinter : String = "" // PQCSKIPUSER
        //---[Addition] 2015.06.04 Dummay Count category 구분 jy.Lim
        var sCreateCategory : String = "" // CREATECATEGORY
        //---[Addition] 2015.06.04 Dummay Count category 구분 jy.Lim
        var sLasteventcomment : String = "" // LASTEVENTCOMMENT
        //---[Addition] 2015.06.08 Dummay Count category 구분 jy.Lim
        var sProductQuantity : String = "" // PRODUCTQUANTITY
        //---[Addition] 2015.06.08 Dummay Count category 구분 jy.Lim
        var sOwner : String = "" // OWNER
        //---[Addition] 2015.06.18 Dummay Count etch 구분 jy.Lim
        var sCheckEtch : String = "" // CHECKETCH
        //---[Addition] 2019.07.12 암기사항 관련 Move Out추가
        var sCheckInterlock : String = "" // CHECKINTERLOCK
        //---[Addition] 2019.12.23 짜증 짜증
        var sLampMessge : String = "" // LAMPCOMMENT
        //---[Addition] 2020.01.20
        var sAramMessge : String = "" // ARAMCOMMENT
        //---[Addition] 2020.05.26
        var sMachineState : String = "" // MACHINESTATE
        //---[Addition] 2020.05.26
        var sMachineCode : String = "" // MACHINECODE
        //---[Addition] 2021.02.16
        var sHoldCode_out : String = "" // HOLDCODE_OUT
        //---[Addition] 2021.02.16
        var sHoldComment_out : String = "" // HOLDCOMMENT_OUT
        var sProcessType : String= "";

        var sWaferQty : String = ""
        var sMachinQty : String = ""
        var reasonList : String = ""

        var sRemoteCheck : String = ""
        var sPcmCheck : String = ""
        //--[Addition] 2023.03.17
        var sThickNessMEssge : String = "" //THICKNESSCHECK
        var sMvinWaferCheckMSG : String = ""
        var sBTAMsg : String = ""
        var sChildBatchID : String = ""

        var bibuha = "N"
        var chamberList :  String = "" // 2024.03.20 비부하 Down ChamberList
        var checkGateInspMsg = ""
        var autoMotiveFlag = ""

        fun setLotInfoDataList(responseData: ResponseData){
            val messageBody = ResponseDataToJsonUtil.getMessageBody(responseData)

            this.sProduct = messageBody.optString("PRODUCT")
            this.sFacility = messageBody.optString("FACILITY")
            this.sOperation = messageBody.optString("OPERATION")
            this.sCustomer = messageBody.optString("CUSTOMER")
            this.sCategory = messageBody.optString("CATEGORY")
            this.sEngineer = messageBody.optString("ENGINEER")
            this.sPacking = messageBody.optString("PACKING")
            this.sQty = messageBody.optString("QUANTITY")
            this.sGoodChips = messageBody.optString("GOODCHIPS")
            this.sRecipe = messageBody.optString("RECIPE")
            this.sEqpGroup = messageBody.optString("EQPGROUP")
            this.sCommentQty = messageBody.optString("COMMENTQTY")
            this.sNWCommentQty = messageBody.optString("NWCOMMENTQTY")
            this.sBatchId = messageBody.optString("BATCHID")
            this.sArea = messageBody.optString("AREA")
            this.sWorkedEqpId = messageBody.optString("WORKEDEQPID")
            this.sWorkedRecipe = messageBody.optString("WORKEDRECIPE")
            this.sWorkedReticle = messageBody.optString("WORKEDRETICLE")
            this.sJobCode = messageBody.optString("JOBCODE")
            this.sProcessStep = messageBody.optString("PROCESSSTEP")
            this.sSubOperation = messageBody.optString("SUBOPERATION")
            this.sOpType = messageBody.optString("OPTYPE")
            this.sStatus = messageBody.optString("STATUS")
            this.sState = messageBody.optString("STATE")
            this.sHoldStatus = messageBody.optString("HOLDSTATUS")
            this.sNextOperation = messageBody.optString("NEXTOPERATION")
            this.sNextSubOperation = messageBody.optString("NEXTSUBOPERATION")
            this.sNextProcessStep = messageBody.optString("NEXTPROCESSSTEP")
            this.sEtcMsg = messageBody.optString("ETCMSG")
            this.sNextBay = messageBody.optString("NEXTBAY")
            this.sNextStocker = messageBody.optString("NEXTSTOCKER")
            this.sOperSeq = messageBody.optString("OPERSEQUENCE")
            this.sPhotoType = messageBody.optString("PHOTOTYPE")
            this.sPhotoOperType = messageBody.optString("PHOTOOPERTYPE")
            this.sReworkYesNo = messageBody.optString("REWORKINFO")
            this.sCheckSkipWafer = messageBody.optString("CHECKSKIPWAFER")
            this.sWaferskipinter = messageBody.optString("PQCSKIPUSER")
            this.sCreateCategory = messageBody.optString("CREATECATEGORY")
            this.sLasteventcomment = messageBody.optString("LASTEVENTCOMMENT")
            this.sProductQuantity = messageBody.optString("PRODUCTQUANTITY")
            this.sOwner = messageBody.optString("OWNER")
            this.sCheckEtch = messageBody.optString("CHECKETCH")
            this.sCheckInterlock = messageBody.optString("CHECKINTERLOCK")
            this.sLampMessge = messageBody.optString("LAMPCOMMENT")
            this.sAramMessge = messageBody.optString("ARAMCOMMENT")
            this.sMachineState = messageBody.optString("MACHINESTATE")
            this.sMachineCode = messageBody.optString("MACHINECODE")
            this.sHoldCode_out = messageBody.optString("HOLDCODE_OUT")
            this.sHoldComment_out = messageBody.optString("HOLDCOMMENT_OUT")
            this.sRemoteCheck = messageBody.optString("REMOTECHECK")
            this.sWaferQty = messageBody.optString("WAFERQTY")
            this.sMachinQty = messageBody.optString("MACHAINQTY")
            this.sProcessType = messageBody.optString("PROCESSTYPE")
            this.sPcmCheck = messageBody.optString("PCMCHECK")
            this.sThickNessMEssge = messageBody.optString("THICKNESSCHECK")
            this.sMvinWaferCheckMSG = messageBody.optString("MVINWAFERCHECK")
            this.sBTAMsg = messageBody.optString("BTAWARNING")
            this.sChildBatchID = messageBody.optString(("CHILDBATCHID"))
            this.sCheckSkipWaferMachine = messageBody.optString(("CHECKSKIPWAFERMACHINE"))
            this.sCheckSkipWaferRecipe = messageBody.optString(("CHECKSKIPWAFERRECIPE"))

            this.reasonList = ResponseDataToJsonUtil
                .getMessageBodyNullCheckList(responseData, "TYPEVALUES")
                .toString()

            this.chamberList = ResponseDataToJsonUtil.getMessageBodyInValueNullCheckList(responseData, "CHAMBER", "CHAMBERS").toString()

            this.bibuha = messageBody.optString("BIBUHADOWN")
            this.checkGateInspMsg = messageBody.optString("CHECKGATEINSPMSG")
            this.autoMotiveFlag = messageBody.optString("AUTOMOTIVEFLAG")
        }
    }
}