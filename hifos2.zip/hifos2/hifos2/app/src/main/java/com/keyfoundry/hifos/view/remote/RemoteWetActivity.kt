package com.keyfoundry.hifos.view.remote

import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CompoundButton
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityRemoteWetBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.RemoteRecipeDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.comment.CommentListActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RemoteWetActivity : HFActivity() {
    companion object {
        private const val TAG = "RemoteWetActivity"
    }

    lateinit var viewBinding: ActivityRemoteWetBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var searchMainEqpID = ""
    private var searchEqpType = ""
    private var searchEqpArea = ""
    private var searchJobID = ""

    private var searchOperSeqFront = ""
    private var searchOperationFront = ""
    private var searchSubOperationFront = ""
    private var searchProcessStepFront = ""
    private var searchOpTypeFront = ""

    private var searchOperSeqRear = ""
    private var searchOperationRear = ""
    private var searchSubOperationRear = ""
    private var searchOpTypeRear = ""
    private var searchProcessStepRear = ""

    private var oriBay = ""
    private var oriStk = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityRemoteWetBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editLotNoFront.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editLotNoRear.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        initDisable()

        viewBinding.editMachine.setOnEditorActionListener(onEditorActionListener)
        viewBinding.editLotNoFront.setOnEditorActionListener(onEditorActionListener)
        viewBinding.editLotNoRear.setOnEditorActionListener(onEditorActionListener)

        viewBinding.btnSearchMachine.setOnClickListener(onSingleClickListener)
        viewBinding.btnSearchLotFront.setOnClickListener(onSingleClickListener)
        viewBinding.btnSearchLotRear.setOnClickListener(onSingleClickListener)
        viewBinding.btnReadCommentFront.setOnClickListener(onSingleClickListener)
        viewBinding.btnReadCommentRear.setOnClickListener(onSingleClickListener)
        viewBinding.btnStart.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)

        viewBinding.chkCarry.setOnCheckedChangeListener(onCheckedChangeListener)

        viewBinding.spinnerBay.onItemSelectedListener = onItemSelectedListener
    }

    private fun initDisable() {
        viewBinding.chkCarry.isEnabled = false
        viewBinding.btnReadCommentFront.isEnabled = false
        viewBinding.btnReadCommentRear.isEnabled = false
        viewBinding.editLotNoFront.isEnabled = false
        viewBinding.editLotNoRear.isEnabled = false
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchMachine.id -> {
                    setEqpInfo()
                }
                viewBinding.btnSearchLotFront.id -> {
                    setLotInfoFront()
                }
                viewBinding.btnSearchLotRear.id -> {
                    setLotInfoRear()
                }
                viewBinding.btnReadCommentFront.id -> {
                    readCommentFront()
                }
                viewBinding.btnReadCommentRear.id -> {
                    readCommentRear()
                }
                viewBinding.btnStart.id -> {
                    executeRemoteStart()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    private val onEditorActionListener = TextView.OnEditorActionListener { v, actionId, event ->
        when (v.id) {
            viewBinding.editMachine.id -> {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val check = BarcodeStyle(this).eqpId(viewBinding.editMachine)

                    if (check)
                        setEqpInfo()
                } else if (event != null) {
                    if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                        val check = BarcodeStyle(this).eqpId(viewBinding.editMachine)

                        if (check)
                            setEqpInfo()
                    }
                }
            }
            viewBinding.editLotNoFront.id -> {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val check = BarcodeStyle(this).lotId(viewBinding.editLotNoFront)

                    if (check)
                        setLotInfoFront()
                } else if (event != null) {
                    if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                        val check = BarcodeStyle(this).lotId(viewBinding.editLotNoFront)

                        if (check)
                            setLotInfoFront()
                    }
                }
            }
            viewBinding.editLotNoRear.id -> {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val check = BarcodeStyle(this).lotId(viewBinding.editLotNoRear)

                    if (check)
                        setLotInfoRear()
                } else if (event != null) {
                    if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                        val check = BarcodeStyle(this).lotId(viewBinding.editLotNoRear)

                        if (check)
                            setLotInfoRear()
                    }
                }
            }
        }

        true
    }

    private val onCheckedChangeListener =
        CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                viewBinding.spinnerBay.isEnabled = true
                viewBinding.spinnerStk.isEnabled = true

                setBayInfo()
            } else {
                clearSpinnerInfo()
            }
        }

    private val onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerBay.id -> {
                        setStkInfo()
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private fun clearSpinnerInfo() {
        if (viewBinding.spinnerBay.selectedItem != null)
            oriBay = viewBinding.spinnerBay.selectedItem.toString()

        if (viewBinding.spinnerStk.selectedItem != null)
            oriStk = viewBinding.spinnerStk.selectedItem.toString()

        viewBinding.spinnerBay.adapter = null
        viewBinding.spinnerStk.adapter = null

        viewBinding.spinnerBay.isEnabled = false
        viewBinding.spinnerStk.isEnabled = false
    }

    private fun readCommentFront() {
        val nextIntent = Intent(this, CommentListActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.editLotNoFront.text.toString())
        nextIntent.putExtra("OPERATION", searchOperationFront)
        nextIntent.putExtra("SUBOPERATION", searchSubOperationFront)
        nextIntent.putExtra("PROCESSSTEP", searchProcessStepFront)
        nextIntent.putExtra("OPERSEQUENCE", searchOperSeqFront)
        startActivity(nextIntent)
    }

    private fun readCommentRear() {
        val nextIntent = Intent(this, CommentListActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.editLotNoRear.text.toString())
        nextIntent.putExtra("OPERATION", searchOperationRear)
        nextIntent.putExtra("SUBOPERATION", searchSubOperationRear)
        nextIntent.putExtra("PROCESSSTEP", searchProcessStepRear)
        nextIntent.putExtra("OPERSEQUENCE", searchOperSeqRear)
        startActivity(nextIntent)
    }

    private fun clearAll() {
        clearEqpInfo()
        clearLotInfoFront()
        clearLotInfoRear()

        viewBinding.editLotNoFront.setText("")
        viewBinding.editLotNoRear.setText("")
    }

    private fun clearEqpInfo() {
        searchMainEqpID = ""
        searchEqpType = ""
        searchEqpArea = ""
        searchJobID = ""

        viewBinding.txtReservationTime.text = ""
    }

    private fun setEqpInfo() {
        mainScope.launch {
            clearAll()

            if (viewBinding.editMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "장비명을 입력하여 주세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage =
                MessageFactoryUtil.wetRemoteEqpInfo(viewBinding.editMachine.text.toString())
            val message =
                MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.WETREMOTEEQPINFO
                )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val mainEqpId = messageBody.optString("MAINEQPID")
                val jobId = messageBody.optString("JOBID")
                val pCount = messageBody.optString("PCOUNT")
                // [ uk 201805 ]
                val eqpType = messageBody.optString("EQPTYPE")
                val eqpArea = messageBody.optString("EQPAREA")
                //2015.06.01 장비 PM 주기 체크 수정
                val pmMessage = messageBody.optString("PMMESSAGE")

                searchMainEqpID = mainEqpId
                searchEqpType = eqpType
                searchEqpArea = eqpArea
                searchJobID = jobId

                viewBinding.txtReservationTime.text = jobId

                if (pmMessage.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, "PM주기 경고", pmMessage, GetString.BTNOKSTR
                    )
                }

                if (pCount == "N") {
                    OkDialog.show(
                        supportFragmentManager, GetString.ERRMSG,
                        "진행가능한 JOB 수량을 초과하여 진행이 불가합니다.", GetString.BTNOKSTR
                    )
                }

                viewBinding.editLotNoFront.isEnabled = true
                //GetDlgItem(IDC_EDIT_LOT_NO2)->EnableWindow(TRUE);
                viewBinding.chkCarry.isEnabled = true
                viewBinding.editLotNoFront.requestFocus()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editLotNoRear.isEnabled = false
            }
        }
    }

    private fun clearLotInfoFront() {
        viewBinding.txtProductFront.text = ""
        viewBinding.txtOperationFront.text = ""
        viewBinding.txtQtyFront.text = ""

        searchOperSeqFront = ""
        searchOperationFront = ""
        searchSubOperationFront = ""
        searchProcessStepFront = ""
        searchOpTypeFront = ""

        viewBinding.txtRecipe.text = ""
    }

    private fun setLotInfoFront() {
        mainScope.launch {
            clearLotInfoFront()

            val frontLot = viewBinding.editLotNoFront.text.toString()
            val rearLot = viewBinding.editLotNoRear.text.toString()

            if (frontLot == rearLot) {
                val lotMsg = """
                    |동일 LOT으로 조회가 불가합니다.
                    |LOTNAME을 다시 확인해 주시기 바랍니다.
                """.trimMargin()
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    lotMsg, GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.lotInfo("MVIN", frontLot, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val product = messageBody.optString("PRODUCT")
                val operation = messageBody.optString("OPERATION")
                val engineer = messageBody.optString("ENGINEER")
                val qty = messageBody.optString("QUANTITY")
                val recipe = messageBody.optString("RECIPE")
                val changeRecipe = messageBody.optString("CHANGERECIPE")
                val commentQty = messageBody.optString("COMMENTQTY")
                val nwCommentQty = messageBody.optString("NWCOMMENTQTY")
                val batchId = messageBody.optString("BATCHID")
                val area = messageBody.optString("AREA")
                val workedEqpId = messageBody.optString("WORKEDEQPID")
                val workedRecipe = messageBody.optString("WORKEDRECIPE")
                val jobCode = messageBody.optString("JOBCODE")
                val processStep = messageBody.optString("PROCESSSTEP")
                val subOperation = messageBody.optString("SUBOPERATION")
                val opType = messageBody.optString("OPTYPE")
                val status = messageBody.optString("STATUS")
                val state = messageBody.optString("STATE")
                val holdStatus = messageBody.optString("HOLDSTATUS")
                val operSeq = messageBody.optString("OPERSEQUENCE")
                val etcMsg = messageBody.optString("ETCMSG")
                val machineName = messageBody.optString("MACHINENAME")
                val portName = messageBody.optString("PORTNAME")
                val machineRecipeName = messageBody.optString("MACHINERECIPENAME")
                val lotResUser = messageBody.optString("LOTRESUSER")
                val skipAllowFlag = messageBody.optString("SKIPALLOWFLAG")

                if (status == "RUN") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 MOVE IN된 LOT입니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (state != "WIP") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "$state 상태 입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (holdStatus == "ONHOLD") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "HOLD된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (batchId.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "BATCHID가 설정된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (area == "PHOTO") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "PHOTO진행 LOT입니다. PHOTO 자동화 기능을 이용해 주세요.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (lotResUser.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 작업 예약되었거나 진행중인 LOT입니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                val prodFront = "$product ($jobCode)"
                val operFront = "$operation-$subOperation"

                viewBinding.txtProductFront.text = prodFront
                viewBinding.txtOperationFront.text = operFront
                viewBinding.txtQtyFront.text = qty

                searchOperSeqFront = operSeq
                searchOperationFront = operation
                searchSubOperationFront = subOperation
                searchProcessStepFront = processStep
                searchOpTypeFront = opType

                viewBinding.btnReadCommentFront.isEnabled = true
                viewBinding.btnStart.isEnabled = true

                if (nwCommentQty.isNotEmpty() && nwCommentQty.toInt() > 0) {
                    val commentMsg = """
                        |읽지 않은 작업성 COMMENT가 [$nwCommentQty]가 있습니다.
                        |읽은후 진행하세요.
                    """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        commentMsg, GetString.BTNOKSTR
                    )
                }

                setRecipeInfo()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private suspend fun setRecipeInfo() {
        viewBinding.txtRecipe.text = ""

        val lotId = viewBinding.editLotNoFront.text.toString()
        val operation = searchOperationFront
        val subOperation = searchSubOperationFront
        val product = viewBinding.txtProductFront.text.toString()
        val eqpId = searchMainEqpID
        val opType = searchOpTypeFront

        val sendMessage = MessageFactoryUtil.recipeInfo(
            "N", lotId, operation, subOperation, product, eqpId, opType, DeviceInfo.FACILITY
        )
        val message = MessageSender.send(
            supportFragmentManager, sendMessage, MessageName.RECIPEINFO
        )
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val searchRecipe = messageBody.optString("RECIPE")

            val index = searchRecipe.lastIndexOf("(")
            var recipe = searchRecipe

            if (index > -1)
                recipe = searchRecipe.substring(0, index)

            viewBinding.txtRecipe.text = recipe

            viewBinding.editLotNoRear.isEnabled = true
            viewBinding.editLotNoRear.requestFocus()
            viewBinding.btnStart.isEnabled = true

        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )

            viewBinding.txtProductFront.text = ""
            viewBinding.txtOperationFront.text = ""
            viewBinding.txtQtyFront.text = ""

            viewBinding.btnStart.isEnabled = false
            viewBinding.editLotNoFront.requestFocus()
        }
    }

    private fun clearLotInfoRear() {
        viewBinding.txtProductRear.text = ""
        viewBinding.txtOperationRear.text = ""
        viewBinding.txtQtyRear.text = ""

        searchOperSeqRear = ""
        searchOperationRear = ""
        searchSubOperationRear = ""
        searchOpTypeRear = ""
        searchProcessStepRear = ""
    }

    private fun setLotInfoRear() {
        mainScope.launch {
            clearLotInfoRear()

            if (viewBinding.editLotNoFront.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "FRONT 진행 LOT 부터 순서대로 조회하시기 바랍니다.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.editLotNoRear.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT ID를 입력하세요", GetString.BTNOKSTR
                )
                return@launch
            }

            val frontLot = viewBinding.editLotNoFront.text.toString()
            val rearLot = viewBinding.editLotNoRear.text.toString()

            if (frontLot == rearLot) {
                val lotMsg = """
                    |동일 LOT으로 조회가 불가합니다.
                    |LOTNAME을 다시 확인해 주시기 바랍니다.
                """.trimMargin()
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    lotMsg, GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.lotInfo("MVIN", rearLot, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val product = messageBody.optString("PRODUCT")
                val operation = messageBody.optString("OPERATION")
                val engineer = messageBody.optString("ENGINEER")
                val qty = messageBody.optString("QUANTITY")
                val recipe = messageBody.optString("RECIPE")
                val changeRecipe = messageBody.optString("CHANGERECIPE")
                val commentQty = messageBody.optString("COMMENTQTY")
                val nwCommentQty = messageBody.optString("NWCOMMENTQTY")
                val batchId = messageBody.optString("BATCHID")
                val area = messageBody.optString("AREA")
                val workedEqpId = messageBody.optString("WORKEDEQPID")
                val workedRecipe = messageBody.optString("WORKEDRECIPE")
                val jobCode = messageBody.optString("JOBCODE")
                val processStep = messageBody.optString("PROCESSSTEP")
                val subOperation = messageBody.optString("SUBOPERATION")
                val opType = messageBody.optString("OPTYPE")
                val status = messageBody.optString("STATUS")
                val state = messageBody.optString("STATE")
                val holdStatus = messageBody.optString("HOLDSTATUS")
                val operSeq = messageBody.optString("OPERSEQUENCE")
                val etcMsg = messageBody.optString("ETCMSG")
                val machineName = messageBody.optString("MACHINENAME")
                val portName = messageBody.optString("PORTNAME")
                val machineRecipeName = messageBody.optString("MACHINERECIPENAME")
                val lotResUser = messageBody.optString("LOTRESUSER")
                val skipAllowFlag =
                    messageBody.optString("SKIPALLOWFLAG") //---[Addition] Nov 22, 2007. by I. H. Lee

                if (status == "RUN") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 MOVE IN된 LOT입니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (state != "WIP") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "$state 상태 입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (holdStatus == "ONHOLD") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "HOLD된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (batchId.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "BATCHID가 설정된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (area == "PHOTO") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "PHOTO진행 LOT입니다. PHOTO 자동화 기능을 이용해 주세요.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (lotResUser.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 작업 예약되었거나 진행중인 LOT입니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                val prodRear = "$product ($jobCode)"
                val operRear = "$operation-$subOperation"

                //m_sCommentCnt = sCommentQty;
                //m_sArea = sArea;
                //m_sOpType = sOpType;
                viewBinding.txtProductRear.text = prodRear
                viewBinding.txtOperationRear.text = operRear
                viewBinding.txtQtyRear.text = qty

                searchOperSeqRear = operSeq
                searchOperationRear = operation
                searchSubOperationRear = subOperation
                searchOpTypeRear = opType
                searchProcessStepRear = processStep

                viewBinding.btnReadCommentRear.isEnabled = true
                viewBinding.btnStart.isEnabled = true

                if (nwCommentQty.isNotEmpty() && nwCommentQty.toInt() > 0) {
                    val commentMsg = """
                        |읽지 않은 작업성 COMMENT가 [$nwCommentQty]가 있습니다.
                        |읽은후 진행하세요.
                    """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        commentMsg, GetString.BTNOKSTR
                    )
                }

                if (!checkRecipe())
                    return@launch

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private suspend fun checkRecipe(): Boolean {
        val lotId = viewBinding.editLotNoRear.text.toString()
        val operation = searchOperationRear
        val subOperation = searchSubOperationRear
        val product = viewBinding.txtProductRear.text.toString()
        val eqpId = viewBinding.editMachine.text.toString()
        val opType = searchOpTypeRear

        val sendMessage = MessageFactoryUtil.recipeInfo(
            "N", lotId, operation, subOperation, product, eqpId, opType, DeviceInfo.FACILITY
        )
        val message =
            MessageSender.send(supportFragmentManager, sendMessage, MessageName.RECIPEINFO)
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val searchRecipe = messageBody.optString("RECIPE")

            val index = searchRecipe.lastIndexOf("(")
            var recipe = searchRecipe
            if (index > -1)
                recipe = searchRecipe.substring(0, index)

            if (viewBinding.txtRecipe.text != recipe) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "RECIPE가 다른 LOT입니다.", GetString.BTNOKSTR
                )

                viewBinding.txtProductRear.text = ""
                viewBinding.txtOperationRear.text = ""
                viewBinding.txtQtyRear.text = ""
                viewBinding.editLotNoRear.requestFocus()
                viewBinding.editLotNoRear.selectAll()
                viewBinding.btnStart.isEnabled = false

                return false
            }

            return true
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )

            viewBinding.txtProductRear.text = ""
            viewBinding.txtOperationRear.text = ""
            viewBinding.txtQtyRear.text = ""
            viewBinding.editLotNoRear.requestFocus()
            viewBinding.editLotNoRear.selectAll()
            viewBinding.btnStart.isEnabled = false

            return false
        }
    }

    private fun setBayInfo() {
        mainScope.launch {
            viewBinding.spinnerBay.adapter = null

            val sendMessage = MessageFactoryUtil.areaBayInfo(DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.AREABAYINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val bays = ResponseDataToJsonUtil.getMessageBodyList(result, "BAYS")
                val itemList = arrayListOf<String>()
                for (count in 0 until bays.length())
                    itemList.add(bays.getJSONObject(count).optString("BAY"))

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerBay.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                if (oriBay.isNotEmpty()) {
                    val index = spinnerAdapter.getPosition(oriBay)

                    if (index > -1)
                        viewBinding.spinnerBay.setSelection(index + 1, false)
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setStkInfo() {
        mainScope.launch {
            viewBinding.spinnerStk.adapter = null

            if (viewBinding.spinnerBay.selectedItem == null)
                return@launch

            val bay = viewBinding.spinnerBay.selectedItem.toString()
            val sendMessage = MessageFactoryUtil.bayStockerInfo(bay, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.BAYSTOCKERINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val bays = ResponseDataToJsonUtil.getMessageBodyList(result, "STOCKERS")
                val itemList = arrayListOf<String>()
                for (count in 0 until bays.length())
                    itemList.add(bays.getJSONObject(count).optString("STOCKER"))

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerStk.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                if (oriStk.isNotEmpty()) {
                    val index = spinnerAdapter.getPosition(oriStk)

                    if (index > -1)
                        viewBinding.spinnerStk.setSelection(index + 1, false)
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun executeRemoteStart() {
        mainScope.launch {
            if (viewBinding.editMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행장비를 입력하세요.", GetString.BTNOKSTR
                )

                return@launch
            }
            if (viewBinding.txtRecipe.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행Rcp가 조회되지 않았습니다.", GetString.BTNOKSTR
                )

                return@launch
            }
            if ((viewBinding.editLotNoFront.text.isNotEmpty() && viewBinding.txtOperationFront.text.isEmpty())
                || (viewBinding.editLotNoRear.text.isNotEmpty() && viewBinding.txtOperationRear.text.isEmpty())
            ) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT 조회가 정상적으로 이루어 지지 않았습니다.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.chkCarry.isChecked) {
                if (viewBinding.spinnerBay.selectedItem == null) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "BAY를 선택하세요.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (viewBinding.spinnerStk.selectedItem == null) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "STOCKER를 선택하세요.", GetString.BTNOKSTR
                    )

                    return@launch
                }
            }

            if (viewBinding.editLotNoFront.text.isNotEmpty()) {
                if (!checkComment(viewBinding.editLotNoFront.text.toString()))
                    return@launch
            }

            if (viewBinding.editLotNoRear.text.isNotEmpty()) {
                if (!checkComment(viewBinding.editLotNoRear.text.toString()))
                    return@launch
            }

            val recipeIntent = Intent(this@RemoteWetActivity, RemoteRecipeDialog::class.java)
            recipeIntent.putExtra(
                RemoteRecipeDialog.RECIPE_LIST,
                viewBinding.txtRecipe.text.toString()
            )

            activityRecipeResultLauncher.launch(recipeIntent)
        }
    }

    private suspend fun checkComment(lotId: String): Boolean {
        val sendMessage = MessageFactoryUtil.lotInfo("MVIN", lotId, DeviceInfo.FACILITY)
        val message =
            MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val nwCommentCnt = messageBody.optString("NWCOMMENTQTY")

            if (nwCommentCnt.isNotEmpty() && nwCommentCnt.toInt() > 0) {
                OkDialog.show(
                    supportFragmentManager, "읽은후 진행하세요.",
                    "LOT[ $lotId]에 읽지 않은 작업성 COMMENT가 [$nwCommentCnt]가 있습니다.", GetString.BTNOKSTR
                )

                return false
            }

            return true
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )

            return false
        }
    }

    private val activityRecipeResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                execute()
            }
        }

    private fun execute() {
        mainScope.launch {
            val machineName = searchMainEqpID
            val machineName2 = viewBinding.editMachine.text.toString()
            val machineType = searchEqpType
            val areaName = searchEqpArea
            val numCass = if (viewBinding.editLotNoRear.text.isNotEmpty())
                "2"
            else
                "1"
            val lotName = viewBinding.editLotNoFront.text.toString()
            val lotName2 = viewBinding.editLotNoRear.text.toString()
            val recipeName = viewBinding.txtRecipe.text.toString()
            val jobName = searchJobID
            val productQty = viewBinding.txtQtyFront.text.toString()
            val productQty2 = viewBinding.txtQtyRear.text.toString()
            val operation = viewBinding.txtOperationFront.text.toString()
            val operation2 = viewBinding.txtOperationRear.text.toString()
            val eventUser = DeviceInfo.OPERATOR_ID
            var isCarry = "N"
            var bay = ""
            var stocker = ""

            if (viewBinding.chkCarry.isChecked) {
                isCarry = "Y"
                bay = viewBinding.spinnerBay.selectedItem.toString()
                stocker = viewBinding.spinnerStk.selectedItem.toString()
            }

            val sendMessage = MessageFactoryUtil.wetRemoteStart(
                machineName, machineName2, machineType, areaName, numCass,
                lotName, lotName2, recipeName, jobName, productQty,
                productQty2, operation, operation2, eventUser, isCarry,
                bay, stocker
            )
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.WETREMOTESTART)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                setResult(RESULT_OK)
                finish()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }
}
