package com.keyfoundry.hifos.view.remote

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputFilter
import android.view.ContextMenu
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.GestureDetectorCompat
import androidx.core.view.children
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.BarcodeStyle
import com.keyfoundry.hifos.config.utils.GridService
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityRemoteXrfBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class RemoteXrfActivity : HFActivity() {
    companion object {
        private const val TAG = "RemoteXrfActivity"
    }

    lateinit var viewBinding: ActivityRemoteXrfBinding
    private lateinit var gridService: GridService

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var mainEqpId = "";
    private var mainModel = "";
    private lateinit var slotlist: CTMainLayout
    private lateinit var SlotlistJSON: JSONArray
    private var selectSlot = ""

    private var startEqp = ""
    private var startEqpType = "XRF"
    private var startPort = ""
    private var startSlot = ""
    private var startRecipe = ""
    private var startProdeqp = ""
    private var startSample = ""
    private var startItem = ""
    private var startPara = ""
    private var startThick = ""
    private var startTable = ""

    private var CopyRowData = JSONObject()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityRemoteXrfBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        gridService = GridService(applicationContext)

        viewBinding.btnStart.isEnabled = false;
        //소문자 -> 대문자
        viewBinding.txtMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.txtMachine.setOnEditorActionListener(editorActionListener)


        viewBinding.spinnerPort.onItemSelectedListener = itemSelectedListener
        viewBinding.spinnerLoadTable.onItemSelectedListener = itemSelectedListener


        viewBinding.btnClearPort.setOnClickListener(onSingleClickListener)
        viewBinding.btnStart.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
        viewBinding.btnSearchIngMachine.setOnClickListener(onSingleClickListener)


        registerForContextMenu(viewBinding.LotInfo)

        if(intent.getStringExtra("Eqpid").toString() != "NULL")
            mainEqpId = intent.getStringExtra("Eqpid").toString()

        viewBinding.txtMachine.setText(mainEqpId)

        //setEqpInfo()

    }

    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        val inflater = menuInflater
        inflater.inflate(R.menu.xrf_remote_context, menu)
        //super.onCreateContextMenu(menu, v, menuInfo)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.menu1 -> {
                GridCopy(selectSlot)
            }
            R.id.menu2 -> {
                GridPaste(selectSlot)
            }
            R.id.menu3 -> {
                GridPasteAll()
            }
        }
        return super.onContextItemSelected(item)
    }

    private val editorActionListener =
        TextView.OnEditorActionListener { v, actionId, event ->
            when (v.id) {
                viewBinding.txtMachine.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        val check = BarcodeStyle(this).eqpId(viewBinding.txtMachine)

                        if (check)
                            setEqpInfo()
                    } else if (event != null) {
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            val check = BarcodeStyle(this).eqpId(viewBinding.txtMachine)

                            if (check)
                                setEqpInfo()
                        }
                    }
                }
            }

            true
        }

    private fun setEqpInfo() {
        mainScope.launch {
            clearEqpInfo()

            if (viewBinding.txtMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "장비명을 입력하여 주세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage =
                MessageFactoryUtil.remoteEqpInfo(viewBinding.txtMachine.text.toString())

            val message =
                MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.REMOTEEQPINFO
                )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val pCount = messageBody.optString("PCOUNT")
                val portname = messageBody.optString("PORTNAME")
                val pmMessage = messageBody.optString("PMMESSAGE")
                mainEqpId = messageBody.optString("MAINEQPID")

                if (pmMessage.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, "PM주기 경고", pmMessage, GetString.BTNOKSTR
                    )
                }
                if (pCount == "N") {
                    OkDialog.show(
                        supportFragmentManager, GetString.ERRMSG,
                        "진행중인 LOT이 있어 진행이 불가합니다.", GetString.BTNOKSTR
                    )
                    return@launch
                }

                val portList = portname.split(",")
                val spinnerAdapter =
                    ArrayAdapter(
                        applicationContext,
                        R.layout.contact_spinner_row_init,
                        portList
                    )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerPort.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )



                //viewBinding.spinnerPort.requestFocus()

                viewBinding.spinnerPort.setSelection(1)
                //setPortState()

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearEqpInfo() {
        viewBinding.spinnerPort.adapter = null
        viewBinding.LotInfo.removeAllViews()
        mainEqpId = ""
        mainModel = ""
    }

    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerPort.id -> {
                        setPortState()
                        setTableList()
                    }
                    viewBinding.spinnerLoadTable.id -> {
                        getTableinfo();
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {

                viewBinding.btnSearchIngMachine.id -> {
                    setEqpInfo()
                }
                viewBinding.btnClearPort.id -> {
                    executeClearPort()
                }
                viewBinding.btnStart.id -> {
                    executeStart()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    // PORT EVENT ST
    private fun executeClearPort() {
        mainScope.launch {
            if (viewBinding.spinnerPort.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Port를 먼저 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val portName = viewBinding.spinnerPort.selectedItem.toString()

            val checkCode = OkCancelDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                "PORT [$portName]을(를) 초기화 하고 [IDLE]상태로 바꾸시겠습니까?",
                GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
            )

            if (checkCode == OkCancelDialog.RETURN_CODE_CANCEL)
                return@launch

            val sendMessage = MessageFactoryUtil.machinePortClean(mainEqpId, portName)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MACHINEPORTCLEAR
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager, "PORT 초기화",
                    "해당 PORT 초기화 명령을 전송하였습니다.", GetString.BTNOKSTR
                )

                setPortState()
                setTableList()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearPortState() {
        viewBinding.txtPortState.text = ""
        viewBinding.txtPortState.background = null
    }

    private fun setPortColor(portState: String) {
        when (portState) {
            "INIT" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.RED)
                viewBinding.txtPortState.setTextColor(Color.WHITE)
            }
            "RUN" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.BLUE)
                viewBinding.txtPortState.setTextColor(Color.WHITE)
            }
            "PENDING" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portPending))
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "READY" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.GREEN)
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "RESERVED" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.YELLOW)
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "COMPLETE" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portCompleted))
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "IDLE" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portIdle))
                viewBinding.txtPortState.setTextColor(Color.WHITE)
            }
        }
    }

    private fun setTableList() {
        mainScope.launch {

            val sendMessage =
                MessageFactoryUtil.XrfTableLoad(viewBinding.txtMachine.text.toString())
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.XRFTABLEINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val bayListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "BAYS")

                val spinnerTABLEItems = arrayListOf<String>()

                for (i in 0 until bayListJSON.length()) {
                    val bay = bayListJSON.getJSONObject(i)
                    spinnerTABLEItems.add(bay.getString("BAY"))
                }

                val spinnerAdapter = ArrayAdapter(
                    applicationContext, R.layout.contact_spinner_row_init, spinnerTABLEItems
                )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerLoadTable.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }

    }

    private fun setPortState() {
        mainScope.launch {
            clearPortState()

            if (viewBinding.spinnerPort.selectedItem == null)
                return@launch

            viewBinding.btnClearPort.isEnabled = false

            val portId = viewBinding.spinnerPort.selectedItem.toString()

            val sendMessage =
                MessageFactoryUtil.machinePortStatus(viewBinding.txtMachine.text.toString(), portId)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.XRFREMOTESTART
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val portState = messageBody.optString("PORTSTATENAME")
                val ackMsg = messageBody.optString("ACKMSG")

                viewBinding.txtPortState.text = portState

                setPortColor(portState)

                if (portState == "RUN" || portState == "PENDING" || portState == "RESERVED") {
                    val portMsg = """
                    |해당 PORT가 진행중입니다.
                    |장비 및 진행할 LOT을 다시 확인 바랍니다.
                    |""".trimMargin()
                    OkDialog.show(
                        supportFragmentManager,
                        "장비 MASSAGE",
                        portMsg,
                        GetString.BTNOKSTR
                    )
                    viewBinding.btnClearPort.isEnabled = true
                    viewBinding.btnStart.isEnabled = false

                    if (ackMsg.isNotEmpty()) {
                        OkDialog.show(
                            supportFragmentManager, "PORT WORNING", ackMsg, GetString.BTNOKSTR
                        )
                    }
                } else if (portState.isEmpty()) {
                    val portMsg = """
                    |PORT 정보를 가져올 수 없습니다.
                    |잠시후 다시 확인 바랍니다.
                    |""".trimMargin()
                    OkDialog.show(
                        supportFragmentManager,
                        "장비 MASSAGE",
                        portMsg,
                        GetString.BTNOKSTR
                    )
                    viewBinding.btnStart.isEnabled = false
                    viewBinding.btnClearPort.isEnabled = false
                } else if (portState == "READY") {
                    viewBinding.btnStart.isEnabled = true
                    viewBinding.btnClearPort.isEnabled = true

                    getLotinfo()
                } else
                    viewBinding.btnStart.isEnabled = false
                viewBinding.btnClearPort.isEnabled = true
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }
    // PORT EVENT END


    private fun getTableinfo() {
        mainScope.launch {
            if (viewBinding.spinnerLoadTable.selectedItem == null)
                return@launch

            clearData()

            val sendMessage = MessageFactoryUtil.XrfTableLotInfo(
                DeviceInfo.FACILITY, mainEqpId,
                viewBinding.spinnerLoadTable.selectedItem.toString()
            )
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.XRFTABLELOTINFO
            )
            //val isSuccessFul = true
            val isSuccessFul = message.isSuccessFul
            val result = message.result


            if (isSuccessFul) {
                val messageListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "ITEMS")


                val slotcol = linkedMapOf(
                    "SLOT" to ColumnProperty("SLOT", Gravity.CENTER, false),
                    "ITEM" to ColumnProperty("ITEM", Gravity.CENTER, false),
                    "PRODEQP" to ColumnProperty("PRODEQP", Gravity.CENTER, false),
                    "CATEGORY" to ColumnProperty("CATEGORY", Gravity.CENTER, false),
                    "SAMPLE" to ColumnProperty("SAMPLE", Gravity.CENTER, false),
                    "PARA" to ColumnProperty("PARA", Gravity.CENTER, false),
                    "RECIPE" to ColumnProperty("RECIPE", Gravity.CENTER, false),
                    "THICK" to ColumnProperty("THICK", Gravity.CENTER, false)
                )

                SlotlistJSON = JSONArray()
                for(i in 0 until messageListJSON.length() ){
                    val messageBody = messageListJSON.getJSONObject(i)
                    val slotinfo = messageBody.optString("SLOT")
                    val iteminfo = messageBody.optString("MDSITEM")
                    val eqpinfo = messageBody.optString("MEASEQPID")
                    val categoryinfo = messageBody.optString("CATEGORY")
                    val sampleinfo = messageBody.optString("SAMPLE")
                    val parainfo = messageBody.optString("PARAMETER")
                    val recipeinfo = messageBody.optString("RECIPE")
                    val thickinfo = messageBody.optString("THICK")

                    val newRowData = JSONObject()
                    newRowData.put("SLOT", slotinfo)
                    newRowData.put("ITEM", iteminfo)
                    newRowData.put("PRODEQP", eqpinfo)
                    newRowData.put("CATEGORY", categoryinfo)
                    newRowData.put("SAMPLE", sampleinfo)
                    newRowData.put("PARA", parainfo)
                    newRowData.put("RECIPE", recipeinfo)
                    newRowData.put("THICK", thickinfo)
                    SlotlistJSON.put(newRowData)


                }
                slotlist = gridService.setGridPropData(slotcol, SlotlistJSON)

                setGridTouchEvent(slotlist)
                viewBinding.LotInfo.addView(slotlist)

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun getLotinfo() {
        mainScope.launch {
            if (viewBinding.spinnerPort.selectedItem == null)
                return@launch

            clearData()

            val sendMessage = MessageFactoryUtil.MeasLotInfo(
                DeviceInfo.FACILITY, mainEqpId,
                viewBinding.spinnerPort.selectedItem.toString()
            )
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MEASLOTINFO
            )
            //val isSuccessFul = true
            val isSuccessFul = message.isSuccessFul
            val result = message.result


            if (isSuccessFul) {
                val messageListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "ITEMS")
                val messageBody = messageListJSON.getJSONObject(0)
                val slotinfo = messageBody.optString("RANDOMFLAG")

                val slotcol = linkedMapOf(

                    "SLOT" to ColumnProperty("SLOT", Gravity.CENTER, false),
                    "ITEM" to ColumnProperty("ITEM", Gravity.CENTER, false),
                    "PRODEQP" to ColumnProperty("PRODEQP", Gravity.CENTER, false),
                    "CATEGORY" to ColumnProperty("CATEGORY", Gravity.CENTER, false),
                    "SAMPLE" to ColumnProperty("SAMPLE", Gravity.CENTER, false),
                    "PARA" to ColumnProperty("PARA", Gravity.CENTER, false),
                    "RECIPE" to ColumnProperty("RECIPE", Gravity.CENTER, false),
                    "THICK" to ColumnProperty("THICK", Gravity.CENTER, false)
                )

                SlotlistJSON = JSONArray()
                if (slotinfo != "") {
                    for (a in slotinfo.indices) {
                        if (slotinfo[a] == 'Y') {
                            val newRowData = JSONObject()
                            newRowData.put("SLOT", (a + 1).toString())
                            newRowData.put("ITEM", "")
                            newRowData.put("PRODEQP", "")
                            newRowData.put("CATEGORY", "")
                            newRowData.put("SAMPLE", "")
                            newRowData.put("PARA", "")
                            newRowData.put("RECIPE", "")
                            newRowData.put("THICK", "")
                            SlotlistJSON.put(newRowData)
                            //slotinfo.put
                        }
                    }

                    slotlist = gridService.setGridPropData(slotcol, SlotlistJSON)

                    setGridTouchEvent(slotlist)
                    viewBinding.LotInfo.addView(slotlist)
                }




            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearData() {
        viewBinding.LotInfo.removeAllViews()
    }

    private fun setGridTouchEvent(slotlist: CTMainLayout) {
        for (mainRow in slotlist.mainTable.children) {
            val slot = gridService.getCellValue(mainRow, "SLOT")

            val mDetector =
                GestureDetectorCompat(this, MachineGestureListener(slot))
            mainRow.setOnTouchListener { v, event ->
                mDetector.onTouchEvent(event)
                v.performClick()
            }
        }
    }

    private val activityFactoryResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                //setEQPList()
            }
        }

    //RECIPE 선택창으로 넘어감
    private fun showDetailMachine(selSlot : String) {

        val machineStatusDialogIntent = Intent(this, RemoteXrfRecipeActivity::class.java)


        machineStatusDialogIntent.putExtra("SLOT", selSlot)
        for (mainRow in slotlist.mainTable.children) {
            val rowslot = gridService.getCellValue(mainRow, "SLOT")
            if(rowslot==selSlot){
                machineStatusDialogIntent.putExtra("ITEM", gridService.getCellValue(mainRow, "ITEM"))
                machineStatusDialogIntent.putExtra("PRODEQP", gridService.getCellValue(mainRow, "PRODEQP"))
                machineStatusDialogIntent.putExtra("CATEGORY", gridService.getCellValue(mainRow, "CATEGORY"))
                machineStatusDialogIntent.putExtra("SAMPLE", gridService.getCellValue(mainRow, "SAMPLE"))
                machineStatusDialogIntent.putExtra("PARA", gridService.getCellValue(mainRow, "PARA"))
            }
        }
        activityFactoryResultLauncher.launch(machineStatusDialogIntent)
    }

    private fun showDetailMachine2(selSlot : String) {

        val machineStatusDialogIntent = Intent(this, RemoteXrfRecipeActivity2::class.java)
        machineStatusDialogIntent.putExtra("SLOT", selSlot)

        activityFactoryResultLauncher.launch(machineStatusDialogIntent)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        //RECIPE 창 종료 후 이벤트처리
        if (resultCode == RESULT_OK) {
            var SLOT = data?.getStringExtra("SLOT")!!
            var ITEM = data?.getStringExtra("ITEM")!!
            var PRODEQP = data?.getStringExtra("PRODEQP")!!
            var CATEGORY = data?.getStringExtra("CATEGORY")!!
            var SAMPLE = data?.getStringExtra("SAMPLE")!!
            var PARA = data?.getStringExtra("PARA")!!
            var RECIPE = data?.getStringExtra("RECIPE")!!
            var THICK = data?.getStringExtra("THICK")!!

            var rowidx = 0
            for (mainRow in slotlist.mainTable.children) {
                val rowslot = gridService.getCellValue(mainRow, "SLOT")
                if(rowslot==SLOT){
                    val newRowData = JSONObject()
                    newRowData.put("SLOT", SLOT)
                    newRowData.put("ITEM", ITEM)
                    newRowData.put("PRODEQP", PRODEQP)
                    newRowData.put("CATEGORY", CATEGORY)
                    newRowData.put("SAMPLE", SAMPLE)
                    newRowData.put("PARA", PARA)
                    newRowData.put("RECIPE", RECIPE)
                    newRowData.put("THICK", THICK)
                    SlotlistJSON.put(rowidx,newRowData)
                }
                rowidx = rowidx + 1
            }
            val slotcol = linkedMapOf(

                "SLOT" to ColumnProperty("SLOT", Gravity.CENTER, false),
                "ITEM" to ColumnProperty("ITEM", Gravity.CENTER, false),
                "PRODEQP" to ColumnProperty("PRODEQP", Gravity.CENTER, false),
                "CATEGORY" to ColumnProperty("CATEGORY", Gravity.CENTER, false),
                "SAMPLE" to ColumnProperty("SAMPLE", Gravity.CENTER, false),
                "PARA" to ColumnProperty("PARA", Gravity.CENTER, false),
                "RECIPE" to ColumnProperty("RECIPE", Gravity.CENTER, false),
                "THICK" to ColumnProperty("THICK", Gravity.CENTER, false)
            )
            slotlist = gridService.setGridPropData(slotcol, SlotlistJSON)
            setGridTouchEvent(slotlist)
            viewBinding.LotInfo.removeAllViews()
            viewBinding.LotInfo.addView(slotlist)
        }
    }

    /* *
    * Start Event 처리
    * */

    fun concat(s1: String, s2: String): String {
        if(s1 != "")
            return "$s1$$s2"
        else
            return "$s2"
    }

    //THICK은 NULL일 수 있음
    fun concat_THICK(s1: String, s2: String): String {
        if(s1 != "")
            return "$s1$$s2"
        else
            return "$s2"
    }



    private fun executeStart()    {
        mainScope.launch {

            startSlot = ""
            startProdeqp = ""
            startSample = ""
            startRecipe = ""
            startItem= ""
            startPara= ""
            startThick = ""
            startTable = ""

            startEqp = viewBinding.txtMachine.text.toString()
            startPort = viewBinding.spinnerPort.selectedItem.toString()
            if(viewBinding.spinnerLoadTable.selectedItem != null)
                startTable = viewBinding.spinnerLoadTable.selectedItem.toString()

            for (mainRow in slotlist.mainTable.children) {
                //val rowslot = rowslot + gridService.getCellValue(mainRow, "SLOT")
                    if(gridService.getCellValue(mainRow, "ITEM") != "") {
                        startSlot = concat(startSlot, gridService.getCellValue(mainRow, "SLOT"))
                        startProdeqp = concat(startProdeqp, gridService.getCellValue(mainRow, "PRODEQP"))
                        startSample = concat(startSample, gridService.getCellValue(mainRow, "SAMPLE"))
                        startRecipe = concat(startRecipe, gridService.getCellValue(mainRow, "RECIPE"))
                        startItem = concat(startItem, gridService.getCellValue(mainRow, "ITEM"))
                        startPara = concat(startPara, gridService.getCellValue(mainRow, "PARA"))
                        if(gridService.getCellValue(mainRow, "THICK") != "")
                            startThick = concat_THICK(startThick, gridService.getCellValue(mainRow, "THICK"))
                        else
                            startThick = concat_THICK(startThick, "NULL")

                    }
            }

            val sendMessage =
                MessageFactoryUtil.XrfRemoteStart(startEqp,startEqpType,startPort,startSlot,startProdeqp,startRecipe,startSample,
                    DeviceInfo.OPERATOR_ID,DeviceInfo.OPERATOR_NAME, startItem, startPara, startThick,startTable)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.XRFREMOTESTART
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul){
                OkDialog.show(
                    supportFragmentManager, "전송 성공",
                    "성공적으로 START 명령을 전송하였습니다.", GetString.BTNOKSTR
                )
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portPending))
                viewBinding.txtPortState.setText("PENDING")
                viewBinding.txtPortState.setTextColor(Color.BLACK)
                viewBinding.LotInfo.removeAllViews()
            }
            else{
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }


        }

    }



    private fun GridCopy(selSlot : String) {
        CopyRowData = JSONObject()
        for (mainRow in slotlist.mainTable.children) {
            val rowslot = gridService.getCellValue(mainRow, "SLOT")
            if(rowslot==selSlot){
                CopyRowData.put("SLOT", rowslot)
                CopyRowData.put("ITEM", gridService.getCellValue(mainRow, "ITEM"))
                CopyRowData.put("PRODEQP", gridService.getCellValue(mainRow, "PRODEQP"))
                CopyRowData.put("CATEGORY", gridService.getCellValue(mainRow, "CATEGORY"))
                CopyRowData.put("SAMPLE", gridService.getCellValue(mainRow, "SAMPLE"))
                CopyRowData.put("PARA", gridService.getCellValue(mainRow, "PARA"))
                CopyRowData.put("RECIPE", gridService.getCellValue(mainRow, "RECIPE"))
                CopyRowData.put("THICK", gridService.getCellValue(mainRow, "THICK"))
            }
        }
    }

    fun GridPaste(selSlot : String) {

        if(selSlot == "")
            return

        var SLOT = CopyRowData.getString("SLOT")
        var ITEM = CopyRowData.getString("ITEM")
        var PRODEQP = CopyRowData.getString("PRODEQP")
        var CATEGORY = CopyRowData.getString("CATEGORY")
        var SAMPLE = CopyRowData.getString("SAMPLE")
        var PARA = CopyRowData.getString("PARA")
        var RECIPE = CopyRowData.getString("RECIPE")
        var THICK = CopyRowData.getString("THICK")

        var rowidx = 0
        for (mainRow in slotlist.mainTable.children) {
            val rowslot = gridService.getCellValue(mainRow, "SLOT")
            if(rowslot == selSlot)           {
                val newRowData = JSONObject()
                newRowData.put("SLOT", rowslot)
                newRowData.put("ITEM", ITEM)
                newRowData.put("PRODEQP", PRODEQP)
                newRowData.put("CATEGORY", CATEGORY)
                newRowData.put("SAMPLE", SAMPLE)
                newRowData.put("PARA", PARA)
                newRowData.put("RECIPE", RECIPE)
                newRowData.put("THICK", THICK)
                SlotlistJSON.put(rowidx,newRowData)
            }

            rowidx = rowidx + 1
        }
        val slotcol = linkedMapOf(

            "SLOT" to ColumnProperty("SLOT", Gravity.CENTER, false),
            "ITEM" to ColumnProperty("ITEM", Gravity.CENTER, false),
            "PRODEQP" to ColumnProperty("PRODEQP", Gravity.CENTER, false),
            "CATEGORY" to ColumnProperty("CATEGORY", Gravity.CENTER, false),
            "SAMPLE" to ColumnProperty("SAMPLE", Gravity.CENTER, false),
            "PARA" to ColumnProperty("PARA", Gravity.CENTER, false),
            "RECIPE" to ColumnProperty("RECIPE", Gravity.CENTER, false),
            "THICK" to ColumnProperty("THICK", Gravity.CENTER, false)
        )
        slotlist = gridService.setGridPropData(slotcol, SlotlistJSON)
        setGridTouchEvent(slotlist)
        viewBinding.LotInfo.removeAllViews()
        viewBinding.LotInfo.addView(slotlist)
    }

    fun GridPasteAll() {

        if(CopyRowData==null)
            return

        var SLOT = CopyRowData.optString("SLOT")
        var ITEM = CopyRowData.optString("ITEM")
        var PRODEQP = CopyRowData.optString("PRODEQP")
        var CATEGORY = CopyRowData.optString("CATEGORY")
        var SAMPLE = CopyRowData.optString("SAMPLE")
        var PARA = CopyRowData.optString("PARA")
        var RECIPE = CopyRowData.optString("RECIPE")
        var THICK = CopyRowData.optString("THICK")

        var rowidx = 0
        for (mainRow in slotlist.mainTable.children) {
            val rowslot = gridService.getCellValue(mainRow, "SLOT")
            val rowitem = gridService.getCellValue(mainRow, "ITEM")
            if(rowitem == "")           {
                val newRowData = JSONObject()
                newRowData.put("SLOT", rowslot)
                newRowData.put("ITEM", ITEM)
                newRowData.put("PRODEQP", PRODEQP)
                newRowData.put("CATEGORY", CATEGORY)
                newRowData.put("SAMPLE", SAMPLE)
                newRowData.put("PARA", PARA)
                newRowData.put("RECIPE", RECIPE)
                newRowData.put("THICK", THICK)
                SlotlistJSON.put(rowidx,newRowData)
            }

            rowidx = rowidx + 1
        }
        val slotcol = linkedMapOf(

            "SLOT" to ColumnProperty("SLOT", Gravity.CENTER, false),
            "ITEM" to ColumnProperty("ITEM", Gravity.CENTER, false),
            "PRODEQP" to ColumnProperty("PRODEQP", Gravity.CENTER, false),
            "CATEGORY" to ColumnProperty("CATEGORY", Gravity.CENTER, false),
            "SAMPLE" to ColumnProperty("SAMPLE", Gravity.CENTER, false),
            "PARA" to ColumnProperty("PARA", Gravity.CENTER, false),
            "RECIPE" to ColumnProperty("RECIPE", Gravity.CENTER, false),
            "THICK" to ColumnProperty("THICK", Gravity.CENTER, false)
        )
        slotlist = gridService.setGridPropData(slotcol, SlotlistJSON)
        setGridTouchEvent(slotlist)
        viewBinding.LotInfo.removeAllViews()
        viewBinding.LotInfo.addView(slotlist)
    }


    inner class MachineGestureListener(private val eqpId: String) :
        GestureDetector.SimpleOnGestureListener() {
        /*
            override fun onSingleTapUp(e: MotionEvent?): Boolean {
                viewBinding.editEqpId.setText("")
                viewBinding.editEqpId.setText(eqpId)

                return super.onSingleTapUp(e)
            }

         */
        override fun onSingleTapUp(e: MotionEvent?): Boolean {
            // RECIPE 선택 화면으로 넘어가기
            showDetailMachine(eqpId)
//            if(eqpId=="3")
//                showDetailMachine(eqpId)
//            else
//                showDetailMachine2(eqpId)

            return super.onSingleTapUp(e)
        }

        override fun onLongPress(e: MotionEvent?) {
            selectSlot = eqpId
            GridCopy(selectSlot)
            openContextMenu(viewBinding.LotInfo)
//            for (mainRow in slotlist.mainTable.children) {
//                val rowslot = gridService.getCellValue(mainRow, "SLOT")
//                if(eqpId == rowslot) {
//                    startSlot = concat(startSlot, gridService.getCellValue(mainRow, "SLOT"))
//                    startProdeqp = concat(startProdeqp, gridService.getCellValue(mainRow, "PRODEQP"))
//                    startSample = concat(startSample, gridService.getCellValue(mainRow, "SAMPLE"))
//                    startRecipe = concat(startRecipe, gridService.getCellValue(mainRow, "RECIPE"))
//                    startItem = concat(startItem, gridService.getCellValue(mainRow, "ITEM"))
//                    startPara = concat(startPara, gridService.getCellValue(mainRow, "PARA"))
//                }
//            }
        }

        override fun onDoubleTap(e: MotionEvent?): Boolean {

            return super.onDoubleTap(e)
        }
    }
}