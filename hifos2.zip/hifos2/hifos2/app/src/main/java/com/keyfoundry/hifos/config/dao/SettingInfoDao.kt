package com.keyfoundry.hifos.config.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy.REPLACE
import androidx.room.Query
import com.keyfoundry.hifos.config.domain.SettingInfo

/*
* 안드로이드 내부 DB 환경설정 관련 쿼리
* */
@Dao
interface SettingInfoDao {
    @Query("select * from setting_info")
    fun getAll(): List<SettingInfo>

    @Query("select * from setting_info limit 1")
    fun getSettingInfo(): SettingInfo

    @Insert(onConflict = REPLACE)
    fun insert(settingInfo: SettingInfo)

    @Query("delete from setting_info")
    fun deleteAll()
}