package com.keyfoundry.hifos.view.dialog

import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.Window
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.CommonUtil
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityMdsspcactivityBinding
import com.keyfoundry.hifos.message.MessageSender
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class MDSspcActivity : HFActivity() {
    init {
        this.update = false
    }

    private lateinit var viewBinding: ActivityMdsspcactivityBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)
    private var sCreateTime: String = ""


    fun concat(s1: String, s2: String): String {
        if(s1 != "")
            return "$s1$$s2"
        else
            return "$s2"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setFinishOnTouchOutside(false)

        viewBinding = ActivityMdsspcactivityBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.btnSave.setOnClickListener(onSingleClickListener)
        viewBinding.btnOk.setOnClickListener(onSingleClickListener)



        val receiverMessage = intent.getStringExtra(DeviceInfo.UDP_RECEIVER_MESSAGE)

        /*2026.03.27 MDSSPC INTLK Pop-up 개선 Start */
        //val spinner_Measure = findViewById<Spinner>(R.id.spinner_Measure)
        //val spinner_Action = findViewById<Spinner>(R.id.spinner_Action)

        // 임의 데이터
        //val items = listOf(
        //    "외관 검사",
        //    "치수 측정",
        //    "기능 테스트",
        //    "전기 검사",
        //    "포장 상태 확인"
        //)

        //val adapter = ArrayAdapter(
        //    this,
        //    android.R.layout.simple_spinner_item,
        //    items
        //)

        //adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        //spinner_Measure.adapter = adapter
        //spinner_Action.adapter = adapter
        /*2026.03.27 MDSSPC INTLK Pop-up 개선 End */

        if (receiverMessage != null) if(receiverMessage.contains("INTERLOCKMANAGER"))
        {
            val new_receiverMessage = arrayOf(receiverMessage?.split("<Table diffgr:")) // receiverMessage 잘라서 배열에 담기

            for(data in 1 until new_receiverMessage[0].size)
            {
                val arry_receiverMessage = arrayOf(new_receiverMessage[0][data]?.split("</")) // receiverMessage 잘라서 배열에 담기

                viewBinding.titleReceiverMessage.text = "#MDSSPC INTERLOCK#";

                val Time = arry_receiverMessage[0]!![0].substring(arry_receiverMessage[0]!![0].lastIndexOf(">")+1)
                if(Time > 0.toString())
                {
                    viewBinding.txtReceiverTimeResult.append(Time.substring(0, Time.indexOf("+")).replace("T"," "))
                }

                val Eqpid = arry_receiverMessage[0]!![1].substring(arry_receiverMessage[0]!![1].lastIndexOf(">")+1)
                if(Eqpid > 0.toString())
                    viewBinding.txtReceiverEqpidResult.append(Eqpid)

                val MEASEqpid = arry_receiverMessage[0]!![3].substring(arry_receiverMessage[0]!![3].lastIndexOf(">")+1)
                if(MEASEqpid > 0.toString())
                    viewBinding.txtReceiverMeaseqpidResult.append(MEASEqpid)

                val Lotid = arry_receiverMessage[0]!![4].substring(arry_receiverMessage[0]!![4].lastIndexOf(">")+1)
                if(Lotid > 0.toString())
                    viewBinding.txtReceiverAreaResult.append(Lotid)

                val Item = arry_receiverMessage[0]!![5].substring(arry_receiverMessage[0]!![5].lastIndexOf(">")+1)
                if(Item > 0.toString())
                    viewBinding.txtReceiverItemResult.append(Item)

                val Proctype = arry_receiverMessage[0]!![6].substring(arry_receiverMessage[0]!![6].lastIndexOf(">")+1)
                if(Proctype > 0.toString())
                    viewBinding.txtReceiverProctypeResult.append(Proctype)

                val Sample = arry_receiverMessage[0]!![7].substring(arry_receiverMessage[0]!![7].lastIndexOf(">")+1)
                if(Sample > 0.toString())
                    viewBinding.txtReceiverSampleResult.append(Sample)

                val Slot = arry_receiverMessage[0]!![9].substring(arry_receiverMessage[0]!![9].lastIndexOf(">")+1)
                if(Slot > 0.toString())
                    viewBinding.txtReceiverSlotResult.append(Slot)

                val SPCResult = arry_receiverMessage[0]!![10].substring(arry_receiverMessage[0]!![10].lastIndexOf(">")+1)
                if(SPCResult > 0.toString())
                {
                    var ruleCnt = 0

                    var str = ""
                    val list_spc = arrayListOf<String>()
                    var tempStr = "";
                    for(i in 1 until SPCResult.length) {
                        //list_spc.add("TT");
                        if(SPCResult.toString().substring(ruleCnt until ruleCnt+1) == "F") {
                            //tempStr = SPCResult.toString().substring(ruleCnt until  ruleCnt+1).toString()
                            tempStr = (ruleCnt+1).toString()
                            list_spc.add(tempStr)
                        }
                        //str = concat(str,ruleCnt.toString())
                        //viewBinding.txtReceiverSpcResult.append(SPCResult.toString().substring(ruleCnt,1))
                        //viewBinding.txtReceiverSpcResult.append(str)
                        ruleCnt++
                    }
                    viewBinding.txtReceiverSpcResult.append(list_spc.toString())
                    //viewBinding.txtReceiverSpcResult.append(list_spc.toString())
                    //viewBinding.txtReceiverSpcResult.append((SPCResult.indexOf("F")+1).toString())
                }

                val Para = arry_receiverMessage[0]!![13].substring(arry_receiverMessage[0]!![13].lastIndexOf(">")+1)
                if(Para > 0.toString())
                    viewBinding.txtReceiverParaResult.append(Para)

                val AVG = arry_receiverMessage[0]!![16].substring(arry_receiverMessage[0]!![16].lastIndexOf(">")+1)
                if(AVG > 0.toString())
                    viewBinding.txtReceiverAvgResult.append(AVG)

                val MIN = arry_receiverMessage[0]!![17].substring(arry_receiverMessage[0]!![17].lastIndexOf(">")+1)
                if(MIN > 0.toString())
                    viewBinding.txtReceiverMinResult.append(MIN)

                val MAX = arry_receiverMessage[0]!![18].substring(arry_receiverMessage[0]!![18].lastIndexOf(">")+1)
                if(MAX > 0.toString())
                    viewBinding.txtReceiverMaxResult.append(MAX)

                val UNIF = arry_receiverMessage[0]!![20].substring(arry_receiverMessage[0]!![20].lastIndexOf(">")+1)
                if(UNIF > 0.toString())
                    viewBinding.txtReceiverUnifResult.append(UNIF)

                val STD = arry_receiverMessage[0]!![19].substring(arry_receiverMessage[0]!![19].lastIndexOf(">")+1)
                if(STD > 0.toString())
                    viewBinding.txtReceiverStdResult.append(STD)

                val SUL = arry_receiverMessage[0]!![26].substring(arry_receiverMessage[0]!![26].lastIndexOf(">")+1)
                if(SUL > 0.toString())
                    viewBinding.txtReceiverSulResult.append(SUL)

                val SCL = arry_receiverMessage[0]!![27].substring(arry_receiverMessage[0]!![27].lastIndexOf(">")+1)
                if(SCL > 0.toString())
                    viewBinding.txtReceiverSclResult.append(SCL)

                val SLL = arry_receiverMessage[0]!![28].substring(arry_receiverMessage[0]!![28].lastIndexOf(">")+1)
                if(SLL > 0.toString())
                    viewBinding.txtReceiverSllResult.append(SLL)

                val UCL = arry_receiverMessage[0]!![29].substring(arry_receiverMessage[0]!![29].lastIndexOf(">")+1)
                if(UCL > 0.toString())
                    viewBinding.txtReceiverUclResult.append(UCL)

                val LCL = arry_receiverMessage[0]!![31].substring(arry_receiverMessage[0]!![31].lastIndexOf(">")+1)
                if(LCL > 0.toString())
                    viewBinding.txtReceiverLclResult.append(LCL)

                val SUCL = arry_receiverMessage[0]!![33].substring(arry_receiverMessage[0]!![33].lastIndexOf(">")+1)
                if(SUCL > 0.toString())
                    viewBinding.txtReceiverSuclResult.append(SUCL)

                sCreateTime = arry_receiverMessage[0]!![21].substring(arry_receiverMessage[0]!![21].lastIndexOf(">") + 1)
            }
            CheckData()
        }
        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
                setData()
            }
        })
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSave.id -> {
                    InsertData()
                }
                viewBinding.btnOk.id -> {
                    finish()
                }
            }
        }
    }

    private fun CheckData(){
        mainScope.launch {
            CommonUtil.hideKeyboard(this@MDSspcActivity, currentFocus)
            val current = viewBinding.txtReceiverTimeResult.text.toString() // "2026-04-02 08:59:20.67"
            val sAREANAME = viewBinding.txtReceiverAreaResult.text.toString();
            val sPROCTYPE = viewBinding.txtReceiverProctypeResult.text.toString();
            val sMACHINENAME = viewBinding.txtReceiverEqpidResult.text.toString();
            val sPARAMETER = viewBinding.txtReceiverParaResult.text.toString();
            val sSAMPLE = viewBinding.txtReceiverSampleResult.text.toString();

            val sMasterTime = current.replace("-", "/")
                .replace(" ", "_")
                .substring(0, 19) // "2026/04/02_08:59:20" 까지만 자름

            val sendMessage = MessageFactoryUtil.mdscontent(sMasterTime,sAREANAME,sPROCTYPE,sMACHINENAME,sPARAMETER,sSAMPLE,sCreateTime)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MDSCONTENT
            )

            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                if (messageBody.has("COMMENTS") && !messageBody.optString("COMMENTS").isNullOrEmpty()) {
                    val rawComments = messageBody.optString("COMMENTS")
                    Log.d("MDS_LOG", "받은 COMMENTS 값: $rawComments")

                    //val commentList = rawComments.split("/").map { it.trim() }
                    //val commentList = rawComments.split(Regex("[/→]")).map { it.trim() }
                    val commentList = rawComments.split("/", "→").map { it.trim() }

                    if (commentList.isNotEmpty()) {

                        //val listMeasure = mutableListOf("NULL")
                        val listMeasure = if (commentList.isNotEmpty()) listOf(commentList[0]) else emptyList()

                        val adapterMeasure = ArrayAdapter<String>(
                            this@MDSspcActivity,
                            android.R.layout.simple_spinner_item,
                            listMeasure
                        )

                        //val listAction = mutableListOf("NULL")
                        val listAction = if (commentList.size >= 2) listOf(commentList[1]) else emptyList()

                        val adapterAction = ArrayAdapter<String>(
                            this@MDSspcActivity,
                            android.R.layout.simple_spinner_item,
                            listAction
                        )

                        // 리소스 및 어댑터 설정
                        adapterMeasure.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        adapterAction.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

                        viewBinding.spinnerMeasure.adapter = adapterMeasure
                        viewBinding.spinnerAction.adapter = adapterAction
                    }
                }
                else
                {
                    val rawDescription = messageBody.optString("DESCRIPTION")
                    if (!rawDescription.isNullOrEmpty()) {
                        // 1. "/"를 기준으로 리스트 생성 및 공백 제거
                        val totalList = rawDescription.split("|").map { it.trim() }

                        val spinner_A = findViewById<Spinner>(R.id.spinner_Action)
                        val spinner_B = findViewById<Spinner>(R.id.spinner_Measure)

                        val listA = mutableListOf("NULL") // 첫 번째 아이템에 "NULL" 삽입
                        if (totalList.size >= 11) {
                            listA.addAll(totalList.subList(0, 11))
                        } else {
                            listA.addAll(totalList)
                        }

                        val listB = mutableListOf("NULL")
                        if (totalList.size > 11) {
                            listB.addAll(totalList.subList(11, totalList.size))
                        }

                        val adapterA = ArrayAdapter<String>(
                            this@MDSspcActivity,
                            android.R.layout.simple_spinner_item,
                            listA
                        )
                        adapterA.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        spinner_A.adapter = adapterA

                        val adapterB = ArrayAdapter<String>(
                            this@MDSspcActivity,
                            android.R.layout.simple_spinner_item,
                            listB
                        )
                        adapterB.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        spinner_B.adapter = adapterB
                    }
                }
            }
            else
            {
                if (result != null) {
                    try {
                        val rawJson = result.result  // 데이터 클래스의 result 필드 추출

                        if (rawJson == null) {
                            Log.e("MDS_DEBUG", "JSON 필드가 비어있습니다.")
                        }

                        val rootObject = JSONObject(rawJson)
                        val errArray = rootObject.optJSONArray("ERRMSG") // JSONObject 대신 JSONArray 사용
                        if (errArray != null) {
                            for (i in 0 until errArray.length()) {
                                val item = errArray.getJSONObject(i)
                                val desc = item.optString("DESCRIPTION")
                            }
                        }

                    } catch (e: Exception) {
                        Log.e("MDS_DEBUG", "파싱 에러 상세: ${e.message}")
                        Log.e("MDS_DEBUG", "실제 들어온 값: ${result.result}")
                    }
                } else {
                    Log.e("MDS_DEBUG", "result 객체 자체가 null입니다.")
                }
            }
        }
    }

    private fun InsertData() {
        mainScope.launch {
            val currentMeasure = viewBinding.spinnerMeasure.selectedItem?.toString() ?: ""
            val currentAction = viewBinding.spinnerAction.selectedItem?.toString() ?: ""

            val countMeasure = viewBinding.spinnerMeasure.adapter?.count ?: 0
            val countAction = viewBinding.spinnerAction.adapter?.count ?: 0

            if (countMeasure == 1 && countAction == 1) {
                Toast.makeText(this@MDSspcActivity, "이미 입력된 Data 입니다.", Toast.LENGTH_SHORT).show()
                return@launch
            }

            if (currentMeasure.isEmpty() || currentAction.isEmpty()) {
                Toast.makeText(this@MDSspcActivity, "항목을 모두 선택해주세요.", Toast.LENGTH_SHORT).show()
                return@launch
            }

            try {
                // 데이터 저장/전송 로직 시작
                val sINSPECT_COMMENT = viewBinding.spinnerMeasure.selectedItem.toString();
                val sACT_COMMENT = viewBinding.spinnerAction.selectedItem.toString();
                val sUSER_ID = DeviceInfo.OPERATOR_ID
                val sACTION_TIMESTAMP = viewBinding.txtReceiverTimeResult.text.toString();
                val sAREANAME = viewBinding.txtReceiverAreaResult.text.toString();
                val sPROCTYPE = viewBinding.txtReceiverProctypeResult.text.toString();
                val sMACHINENAME = viewBinding.txtReceiverEqpidResult.text.toString();
                val sPARAMETER = viewBinding.txtReceiverParaResult.text.toString();
                val sSAMPLE = viewBinding.txtReceiverSampleResult.text.toString();

                val sendMessage = MessageFactoryUtil.mdsinsert(sINSPECT_COMMENT, sACT_COMMENT, sUSER_ID, sACTION_TIMESTAMP, sAREANAME,sPROCTYPE,sMACHINENAME,sPARAMETER,sSAMPLE,sCreateTime)
                val message = MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.MDSINSERT
                )
                Log.d("INSERT_DATA", "Measure: $currentMeasure, Action: $currentAction")
            } catch (e: Exception) {
                Log.e("INSERT_DATA", "저장 실패: ${e.message}")
            }
        }
    }

    private fun setData(){
        lifecycleScope.launch {

            CommonUtil.hideKeyboard(this@MDSspcActivity, currentFocus)

            val sDeviceName = DeviceInfo.DEVICE_NAME; //PDA ID

            val inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")
            // 출력 포맷: 2026/04/16_16:32:47
            val outputFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd_HH:mm:ss")


            val rawMasterTime = viewBinding.txtReceiverTimeResult.text.toString() // "2026-04-16 16:32:47.495"
            val sMasterTime = try {
                val parsedDate = LocalDateTime.parse(rawMasterTime, inputFormatter)
                parsedDate.format(outputFormatter)
            } catch (e: Exception) {
                rawMasterTime
            }

            val sEqpid = viewBinding.txtReceiverMeaseqpidResult.text.toString()
            val sRecipe = "NULL"
            val sLotID = "NULL"
            val sSlot = viewBinding.txtReceiverSlotResult.text.toString()
            val sUsers = DeviceInfo.OPERATOR_ID
            val current = LocalDateTime.now()
            val formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd_HH:mm:ss")
            val sCurrentTime = current.format(formatter)
            //내꺼에 맞게 수정
            val sendMessage = MessageFactoryUtil.intlkpopupcheck(sMasterTime,"MDSSPC","POP-UP",sDeviceName,"PDA",sDeviceName,"http://::1:62011/InterlockClient.soap"
                ,"Y",sUsers,sCurrentTime,sEqpid,sRecipe,sLotID,sSlot)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.SETGASUSAGE
            )
        }
        finish()
    }
}