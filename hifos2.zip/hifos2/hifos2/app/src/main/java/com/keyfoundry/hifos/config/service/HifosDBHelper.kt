package com.keyfoundry.hifos.config.service

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.keyfoundry.hifos.config.dao.SettingInfoDao
import com.keyfoundry.hifos.config.dao.UserInfoDao
import com.keyfoundry.hifos.config.dao.ServerInfoDao
import com.keyfoundry.hifos.config.domain.SettingInfo
import com.keyfoundry.hifos.config.domain.UserInfo
import com.keyfoundry.hifos.config.domain.ServerInfo


/*
* 내부 DB설정
* 내부 DB Table의 수정이 있을 시 version을 수정하지 않으면 업데이트 후 오류가 날 수 있다.
* version이 변경 되면 기존에 있던 Database는 초기화 된다.
* */
@Database(entities = arrayOf(UserInfo::class, SettingInfo::class, ServerInfo::class), version = 3, exportSchema = false)
abstract class HifosDBHelper : RoomDatabase() {
    abstract  fun userInfoDao(): UserInfoDao
    abstract  fun settingInfoDao () : SettingInfoDao
    abstract  fun serverInfoDao () : ServerInfoDao
  //  abstract  fun timeOutDao () : TimeOutDao

    companion object{

        private var INSTANCE : HifosDBHelper? = null
        private const val DB_NAME = "HIFOS-Database_v1.db"

        fun getInstance(context : Context) : HifosDBHelper?{
            if(INSTANCE == null){
                synchronized(HifosDBHelper::class){
                    INSTANCE = Room.databaseBuilder(
                        context.applicationContext,
                        HifosDBHelper::class.java,
                        DB_NAME
                    )
                        .fallbackToDestructiveMigration()
                        .build()
                }
            }
            return INSTANCE
        }
    }
}