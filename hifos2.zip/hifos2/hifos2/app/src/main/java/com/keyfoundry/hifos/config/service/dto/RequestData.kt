package com.keyfoundry.hifos.config.service.dto

/*
* 모바일 서버 PMS에 보낼 메시지를 담는 Class
* */
data class RequestData(
    val sMsg: String
)

/*
* Exception이 발생 하였을 때 모바일서버에 보낼 메시지를 담는 Class
* */
data class ErrorData(
    val sDeviceName : String,
    val sMsg: String
)
