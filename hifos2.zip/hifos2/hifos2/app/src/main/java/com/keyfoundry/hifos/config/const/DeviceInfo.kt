package com.keyfoundry.hifos.config.const

interface DeviceInfo {
    companion object { // static 처럼 공유객체로 사용가능함. 모든 인스턴스가 공유하는 객체로서 동작함.
        // Mobile Server Name  운영 L4-DEVICE, 개발 DEV-SERVER로 지정
        var MOBILE_SERVER_NAME = ServerType.MOBILE_SERVER_NAME

        // PDA명.  앱이 실행 되면 Bluetooth 이름으로 초기화 해준다.
        var DEVICE_NAME = "ANDROID_000"

        // 환경 설정 화면에서 설정한 값으로 초기화 해준다.
        var FACILITY = "FACILITY"
        var AREA = "AREA"
        var BAY = "BAY"
        var HISTORY_COUNT = "0"
        var FORWARD_COUNT = "0"

        // Login 한 아이디로 초기화 해준다.
        var OPERATOR_ID = "OPERATOR_ID"
        var OPERATOR_NAME = "OPERATOR_NAME"
        var PERMISSION = "PERMISSION"
        var GASINPUT = "N"


        // 메시지 알림 관련 상수 값
        const val UDP_SERVICE_PORT = 9999
        const val UDP_RECEIVER_FILTER = "UDP_RECEIVER_FILTER"
        const val UDP_RECEIVER_LEVEL = "UDP_RECEIVER_LEVEL"
        const val UDP_RECEIVER_MESSAGE = "UDP_RECEIVER_MESSAGE"

        const val UDP_SERVICE_CHANEL_ID = "UDP_SERVICE_CHANEL"
        const val UDP_SERVICE_CHANEL_NAME = "UDP Service"
        const val UDP_NOTI_CHANEL_ID = "UDP_NOTI_CHANEL"
        const val UDP_NOTI_CHANEL_NAME = "UDP Message"
        const val UDP_NOTI_CONTENT_TITLE = "알림"

        // 모바일서버 변경 비밀번호
        const val SystemSettingPW = "hifos"
       //test
    }
}