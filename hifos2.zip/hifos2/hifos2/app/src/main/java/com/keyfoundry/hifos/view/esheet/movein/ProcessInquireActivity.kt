package com.keyfoundry.hifos.view.esheet.movein

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Vibrator
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.GestureDetectorCompat
import androidx.core.view.children
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.service.RetrofitSyncService
import com.keyfoundry.hifos.config.service.dto.RequestData
import com.keyfoundry.hifos.config.utils.GridService
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityProcessInquireBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.cmm.WaferSelectActivity
import com.keyfoundry.hifos.view.dialog.RecipeDialogActivity
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDailogAlram
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

//sh26947 로 테스트
class ProcessInquireActivity : HFActivity() {
    init {
        this.update = false
    }

    companion object {
        private const val TAG = "ProcessInquireActivity"
    }

    private lateinit var viewBinding : ActivityProcessInquireBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var gridService: GridService
    private lateinit var gridData: CTMainLayout

    private var m_sOperation = ""
    private var m_sSubOperation = ""
    private var m_sMulitOperation = ""

    //move in 으로 return 할 값
    private var m_sRecipe = ""
    private var m_sEqpGroup = ""
    private var m_sChangeEqpGroup = ""
    private var m_sProcessStep = ""
    private var m_sCommentQty = ""
    private var m_sWorkedCommentQty = ""

    private var m_isSkip = "N" // 2024.07.10 Skip 가능 여부 확인
    private var m_reworkSkip = "N" // 2024.07.10

    private var m_moveInIng = false // Move In 진행 중에 Grid 선택 불가 하도록 flag 생성 //2024.07.26

    var slotEnabledWaferList = ""

    val slotList  = "Slot.01,Slot.02,Slot.03,Slot.04,Slot.05,Slot.06,Slot.07,Slot.08,Slot.09,Slot.10,Slot.11,Slot.12,Slot.13,Slot.14,Slot.15,Slot.16,Slot.17,Slot.18,Slot.19,Slot.20,Slot.21,Slot.22,Slot.23,Slot.24,Slot.25"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityProcessInquireBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        gridService = GridService(applicationContext)

        viewBinding.txtCurrentPr.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtProductName.movementMethod = ScrollingMovementMethod.getInstance()

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            viewBinding.txtLotNo.text = intent.getStringExtra("LOTID")
            m_sOperation = intent.getStringExtra("OPERATION").toString()
            m_isSkip= intent.getStringExtra("ISSKIP").toString()
            m_reworkSkip= intent.getStringExtra("REWORKSKIP").toString()

            if(m_isSkip=="N"){
                viewBinding.checkCurrentOperationSkip.isEnabled = false
            }
        }

        viewBinding.btnSlot.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val waferSelectIntent = Intent(applicationContext, WaferSelectActivity::class.java)
                waferSelectIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                waferSelectIntent.putExtra("EXISTWAFERLIST", slotList)
                waferSelectIntent.putExtra("FIXEDCOUNT", slotList.split(",").count().toString())
                //     waferSelectIntent.putExtra("OPERATION", m_sOperation)
                slotSelectActivityResultLauncher.launch(waferSelectIntent)
            }
        })

        viewBinding.btnWafer.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val waferSelectIntent = Intent(applicationContext, WaferSelectActivity::class.java)
                waferSelectIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                waferSelectIntent.putExtra("EXISTWAFERLIST", slotEnabledWaferList)
                waferSelectIntent.putExtra(
                    "FIXEDCOUNT",
                    slotEnabledWaferList.split(",").count().toString()
                )
                //     waferSelectIntent.putExtra("OPERATION", m_sOperation)
                waferSelectActivityResultLauncher.launch(waferSelectIntent)
            }
        })

        viewBinding.btnSemSlot.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val waferSelectIntent = Intent(applicationContext, WaferSelectActivity::class.java)
                waferSelectIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                waferSelectIntent.putExtra("EXISTWAFERLIST", slotList)
                waferSelectIntent.putExtra("FIXEDCOUNT", slotList.split(",").count().toString())

                semSlotSelectActivityResultLauncher.launch(waferSelectIntent)
            }
        })

        viewBinding.btnSemWafer.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val waferSelectIntent = Intent(applicationContext, WaferSelectActivity::class.java)
                waferSelectIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
                waferSelectIntent.putExtra("EXISTWAFERLIST", slotEnabledWaferList)
                waferSelectIntent.putExtra(
                    "FIXEDCOUNT",
                    slotEnabledWaferList.split(",").count().toString()
                )
                //     waferSelectIntent.putExtra("OPERATION", m_sOperation)
                semWaferSelectActivityResultLauncher.launch(waferSelectIntent)
            }
        })

        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {

                if(m_moveInIng) {
                    return
                }

                var selectedCount = 0

                for (row in gridData.mainTable.children) {
                    val ilColumnIndex = gridService.getColumnIndex(gridData, "ISCOMPLETE")
                    val ilTextView = (row as CTRowLayout).getChildAt(ilColumnIndex) as TextView
                    if(ilTextView.text == "Y" ){
                        selectedCount++
                    }
                }

                if (selectedCount==0) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "계측할 공정을 선택하세요.", GetString.BTNOKSTR
                    )
                    return
                }


                if(viewBinding.checkCurrentOperationSkip.isChecked){
                    checkDiCycle()
                } else {
                    if(selectedCount>1){
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            "계측할 공정을 하나만 선택하세요.", GetString.BTNOKSTR
                        )
                        return
                    }
                    measuerSet()

                }

            }
        })


        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val returnIntent = Intent()
                setResult(Activity.RESULT_CANCELED, returnIntent)
                finish()
            }
        })

        getMeasureInfo()
        getSlotInfo()
    }


    private val slotSelectActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->
      //              Log.d(TAG, intent.getStringExtra("SEQUENCE").toString() )
                    Log.d(TAG, intent.getStringExtra("SELECTEDWAFERLIST").toString() )
      //              Log.d(TAG, intent.getStringExtra("SELECTEDMACHINE").toString() )
                    val selectedWaferList = intent.getStringExtra("SELECTEDWAFERLIST").toString()
                    viewBinding.editPresentSlot.setText(selectedWaferList.replace("Slot.", ""))
                }
            } else if (it.resultCode == Activity.RESULT_CANCELED){
                viewBinding.editPresentSlot.setText("")
            }
        }

    private val waferSelectActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->
                    val selectedWaferList = intent.getStringExtra("SELECTEDWAFERLIST").toString()
                    viewBinding.editPresentWf.setText(selectedWaferList.replace(viewBinding.txtLotNo.text.toString()+"." , ""))
                }
            } else if (it.resultCode == Activity.RESULT_CANCELED){
                viewBinding.editPresentWf.setText("")
            }
        }

    private val semSlotSelectActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->
                    val selectedWaferList = intent.getStringExtra("SELECTEDWAFERLIST").toString()
                    viewBinding.editSemSlot.setText(selectedWaferList.replace("Slot.", ""))
                }
            } else if (it.resultCode == Activity.RESULT_CANCELED){
                viewBinding.editSemSlot.setText("")
            }
        }

    private val semWaferSelectActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->
                    val selectedWaferList = intent.getStringExtra("SELECTEDWAFERLIST").toString()
                    viewBinding.editSemWf.setText(selectedWaferList.replace(viewBinding.txtLotNo.text.toString()+"." , ""))
                }
            } else if (it.resultCode == Activity.RESULT_CANCELED){
                viewBinding.editSemWf.setText("")
            }
        }


    private fun moveIn() {

        m_moveInIng = true

        viewBinding.btnOk.isEnabled = false

        var subOperation = ""
        var completedFlag = true
        for (row in gridData.mainTable.children) {
            val ilColumnIndex = gridService.getColumnIndex(gridData, "ISCOMPLETE")
            val subOperationColumnIndex = gridService.getColumnIndex(gridData, "SUBOPERATION")

            val ilTextView = (row as CTRowLayout).getChildAt(ilColumnIndex) as TextView
            val subOperationTextView = row.getChildAt(subOperationColumnIndex) as TextView

            if(ilTextView.text != "C") {
                completedFlag = false
            }

            if(subOperation == "" && ilTextView.text == "Y" ){
                subOperation = subOperationTextView.text.toString()
            }
        }

        if(completedFlag){
            val returnIntent = Intent()
            returnIntent.putExtra("FINISH","Y")
            setResult(Activity.RESULT_OK, returnIntent)
            finish()
            return
        }

        if(subOperation==""){
            viewBinding.btnOk.isEnabled = true
            m_moveInIng = false
            getMeasureInfo()
            return
        }

        mainScope.launch {

            val sendMessage = MessageFactoryUtil.moveIn(
                viewBinding.txtLotNo.text.toString(),
                DeviceInfo.FACILITY,
                "",
                "",
                m_sOperation,
                subOperation,
                "Y",
                DeviceInfo.OPERATOR_ID,
                "N",
                "",
                "",
                viewBinding.txtQty.text.toString(),
                "",
                m_reworkSkip
            )

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.MOVEIN)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {

                val columnIndex = gridService.getColumnIndex(gridData, "ISCOMPLETE")
                val subOperationColumnIndex = gridService.getColumnIndex(gridData, "SUBOPERATION")

                for(row in gridData.mainTable.children){
                    val rowData = row as CTRowLayout
                    val cellData = rowData.getChildAt(columnIndex) as TextView
                    val sSubOper = rowData.getChildAt(subOperationColumnIndex) as TextView

                    if(sSubOper.text == subOperation) {
                        row.setBackgroundColor(Color.BLACK)

                        for(cell in rowData.children)
                            (cell as TextView).setTextColor(Color.RED)

                        val rowData = (row.tag) as GridService.RowData
                        (rowData.rowDataList)["ISCOMPLETE"] = "C"
                        cellData.text = "C"
                    }
                }

                delay(1000L)
                moveIn()

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)

                if (errorMessage == "-1") {
                    val returnCode = OkDailogAlram.show(
                        supportFragmentManager,
                        "MOVE IN 실패",
                        "MOVE IN요청에 실패하였습니다.($errorMessage)\n RF Tag를 다시 읽고 시도 하십시오.",
                        GetString.BTNOKSTR,
                        applicationContext,
                        getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    )

                } else {
                    val returnCode = OkDailogAlram.show(
                        supportFragmentManager, "MOVE IN 실패", errorMessage, GetString.BTNOKSTR,applicationContext,getSystemService(
                            Context.VIBRATOR_SERVICE) as Vibrator
                    )

                }
                viewBinding.btnOk.isEnabled = true
                m_moveInIng = false
            }
        }
    }

    private fun measuerSet(){

        var sSubOperation = ""
        for (row in gridData.mainTable.children) {
            val ilColumnIndex = gridService.getColumnIndex(gridData, "ISCOMPLETE")
            val subOperationColumnIndex = gridService.getColumnIndex(gridData, "SUBOPERATION")

            val ilTextView = (row as CTRowLayout).getChildAt(ilColumnIndex) as TextView
            val subOperationTextView = row.getChildAt(subOperationColumnIndex) as TextView

            if(ilTextView.text == "Y"){
                sSubOperation = subOperationTextView.text.toString()
            }
        }

        mainScope.launch {
            val lotId = viewBinding.txtLotNo.text.toString()
            val qty = viewBinding.txtQty.text.toString()
            val sLotList = viewBinding.editPresentSlot.text.toString()
            val waferList = viewBinding.editPresentWf.text.toString()
            val semSLotList = viewBinding.editSemSlot.text.toString()
            val semWaferList = viewBinding.editSemWf.text.toString()

            val sendMessage = MessageFactoryUtil.measureSet(lotId, DeviceInfo.FACILITY, m_sOperation,sSubOperation, DeviceInfo.OPERATOR_ID, qty, sLotList, waferList, semSLotList, semWaferList)

            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.MEASURESET)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sRecipe = messageBody.optString("RECIPE")
                val sEqpGroup = messageBody.optString("EQPGROUP")
                val sChangeEqpGroup = messageBody.optString("CHANGEEQPGROUP")
                val sProcessStep = messageBody.optString("PROCESSSTEP")
                val sCommentQty = messageBody.optString("COMMENTQTY")
                val sWorkedCommentQty = messageBody.optString("NRWCOMMENTQTY")

                val sCurrentStep = "$m_sProcessStep($m_sOperation$sSubOperation)"

                val returnIntent = Intent()

                returnIntent.putExtra("CURRENTSTEP",sCurrentStep)
                returnIntent.putExtra("RECIPE",sRecipe)
                returnIntent.putExtra("EQPGROUP",sEqpGroup)
                returnIntent.putExtra("CHANGEEQPGROUP",sChangeEqpGroup)
                returnIntent.putExtra("PROCESSSTEP",sProcessStep)
                returnIntent.putExtra("COMMENTQTY",sCommentQty)
                returnIntent.putExtra("NRWCOMMENTQTY", sWorkedCommentQty)
                returnIntent.putExtra("SUBOPERATION",sSubOperation)

                if(m_sProcessStep=="VI"&&viewBinding.checkScopeSubstitute.isChecked){
                    returnIntent.putExtra("SCOPESUB","Y")   //2024.09.11 VI공정이면서 Scope대체 Check 시 로그시트에 표시 해주기 위해
                }

             //

                setResult(Activity.RESULT_OK, returnIntent)
                finish()

            }
            else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

            }
        }
    }

    private fun getMeasureInfo(){
        viewBinding.baseLayout.removeAllViews()
        viewBinding.checkCurrentOperationSkip.isChecked = false

        mainScope.launch {
            val lotId = viewBinding.txtLotNo.text.toString()

            val sendMessage = MessageFactoryUtil.measureInfo(lotId, DeviceInfo.FACILITY, m_sOperation)

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.MEASUREINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val measureList = ResponseDataToJsonUtil.getMessageBodyInValueNullCheckList(result, "MEASUREITEM", "MEASUREITEMS" )

                val sProduct = messageBody.optString("PRODUCT");
                val sOperation = messageBody.optString("OPERATION");
                val sSubOperation = messageBody.optString("SUBOPERATION");
          //      m_sSubOperation = messageBody.optString("SUBOPERATION");
                val sPhotoJobCode = messageBody.optString("PHOTOJOBCODE");
                val sProcesStep = messageBody.optString("PROCESSSTEP");
                val sQty = messageBody.optString("QUANTITY");

                //---[Addition] Dec 12, 2005. by I. H. Lee (Begin)
                val sSlotList = messageBody.optString("SLOTLIST");
                val sWaferList = messageBody.optString("WAFERLIST");
                val sSEMSlotList = messageBody.optString("SEMSLOTLIST");
                val sSEMWaferList = messageBody.optString("SEMWAFERLIST");
                //---[Addition] Dec 12, 2005. by I. H. Lee (End)

                viewBinding.txtJob.text = sPhotoJobCode
                viewBinding.txtCurrentPr.text = "$sProcesStep($sOperation$sSubOperation)"
                viewBinding.txtProductName.text = sProduct
                viewBinding.txtQty.text = sQty

                viewBinding.editPresentSlot.setText(sSlotList)
                viewBinding.editPresentWf.setText(sWaferList)
                viewBinding.editSemSlot.setText(sSEMSlotList)
                viewBinding.editSemWf.setText(sSEMWaferList)

//                val columnData = linkedMapOf(
//                    "SUBOPERATION" to "No.",
//                    "SUBPROCESSSTEP" to "공정명",
//                    "ISCOMPLETE" to "S",
//                    "DESCRIPTION" to "DESCRIPTION"
//                )
//                gridData = setGridData(columnData, measureList)

                val columnData = linkedMapOf(
                    "SUBOPERATION" to ColumnProperty("No.", Gravity.CENTER, false, 0),
                    "SUBPROCESSSTEP" to ColumnProperty("공정명", Gravity.CENTER, false, 100),
                    "ISCOMPLETE" to ColumnProperty("S", Gravity.CENTER, false, 100 ),
                    "DESCRIPTION" to ColumnProperty("DESCRIPTION", Gravity.START, false,520)
                )
                gridData = gridService.setGridPropData(columnData, measureList)

                val columnIndex = gridService.getColumnIndex(gridData, "ISCOMPLETE")
                for(row in gridData.mainTable.children){
                    val rowData = row as CTRowLayout
                    val cellData = rowData.getChildAt(columnIndex) as TextView

                    if(cellData.text == "Y") {
                        row.setBackgroundColor(Color.BLACK)

                        for(cell in rowData.children)
                            (cell as TextView).setTextColor(Color.RED)

                        val rowData = (row.tag) as GridService.RowData
                        (rowData.rowDataList)["ISCOMPLETE"] = "C"
                        cellData.text = "C"
                    }
                }
                viewBinding.baseLayout.addView(gridData)
                selectMeasure(gridData)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                if(errorMessage.contains("검색한 MEASURE")){

                    val returnIntent = Intent()
                    returnIntent.putExtra("FINISH","Y")
                    setResult(Activity.RESULT_OK, returnIntent)
                    finish()

                    return@launch
                }
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)
            }
        }
    }

    private fun getSlotInfo(){

        mainScope.launch {
            val lotId = viewBinding.txtLotNo.text.toString()

            val sendMessage = MessageFactoryUtil.slotInfo(lotId, DeviceInfo.FACILITY)

    //        val message = MessageSender.sendBlocking(sendMessage,MessageName.SLOTINFO)
            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.SLOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                slotEnabledWaferList = messageBody.optString("WAFERLIST")

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)
            }
        }
    }

    private fun selectMeasure(gridData: CTMainLayout) {
        for(row in gridData.mainTable.children){

            val isComplete = gridService.getCellValue(row, "ISCOMPLETE")

            val mDetector = GestureDetectorCompat(this, MeasureGestureListener(isComplete, row as CTRowLayout, gridData))

            row.setOnTouchListener { v, event ->
                mDetector.onTouchEvent(event)

                true
            }
        }
    }

    private fun checkDiCycle() {

        var sOperation = ""
        for (row in gridData.mainTable.children) {
            val ilColumnIndex = gridService.getColumnIndex(gridData, "ISCOMPLETE")
            val subOperationColumnIndex = gridService.getColumnIndex(gridData, "SUBOPERATION")

            val ilTextView = (row as CTRowLayout).getChildAt(ilColumnIndex) as TextView
            val subOperationTextView = row.getChildAt(subOperationColumnIndex) as TextView

            if(ilTextView.text == "Y"){
                sOperation += "'" + m_sOperation + "-" +subOperationTextView.text.toString() + "',"
            }
        }
        sOperation = sOperation.substring(0, sOperation.length - 1)

        mainScope.launch {
            val sendMessage =
                MessageFactoryUtil.checkDiCycle(
                    viewBinding.txtLotNo.text.toString(),
                    DeviceInfo.FACILITY,
                    sOperation,
                    "MULTI"
                )

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)


                val sDICYCLE = messageBody.optString("DICYCLE")
                //---[Modification] 2016.11.28 by jy.Lim (End)

                if (sDICYCLE == "Y") {
                    var photoOperType = ""
                    val itemList = ResponseDataToJsonUtil.getMessageBodyList(result, "ITEMS")
                    for (count in 0 until itemList.length()) {
                        photoOperType +=  itemList.getJSONObject(count).optString("PHOTOOPERTYPE") + " "
                    }

                    val returnCode = OkCancelDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_WARNING,
                        "계측 대상 LOT 입니다.($photoOperType)\n측정 없이 SKIP 하시겠습니까?",
                        GetString.BTNYESSTR,
                        GetString.BTNNOSTR
                    )

                    if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                        return@launch
                    }

                } else {
                    val returnCode = OkCancelDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        "선택한 공정을 SKIP 하시겠습니까?",
                        GetString.BTNYESSTR,
                        GetString.BTNNOSTR
                    )
                    if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                        return@launch
                    }
                }

//                for (row in gridData.mainTable.children) {
//                    val ilColumnIndex = gridService.getColumnIndex(gridData, "ISCOMPLETE")
//                    val subOperationColumnIndex = gridService.getColumnIndex(gridData, "SUBOPERATION")
//
//                    val ilTextView = (row as CTRowLayout).getChildAt(ilColumnIndex) as TextView
//                    val subOperationTextView = row.getChildAt(subOperationColumnIndex) as TextView
//
//                    if(ilTextView.text == "Y"){
//                        moveIn(subOperationTextView.text.toString())
//                    }
//
//                }
                moveIn()

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )

            }
        }
    }

    inner class MeasureGestureListener(
        private val isComplete: String,
        private val selectedRow: CTRowLayout,
        private val gridData: CTMainLayout,
    ) : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(e: MotionEvent?): Boolean {

            val ilColumnIndex = gridService.getColumnIndex(gridData, "ISCOMPLETE")
            val subOperationColumnIndex = gridService.getColumnIndex(gridData, "SUBOPERATION")
            val processNameIndex = gridService.getColumnIndex(gridData, "SUBPROCESSSTEP")

            val ilTextView = selectedRow.getChildAt(ilColumnIndex) as TextView
            val subOperationTextView = selectedRow.getChildAt(subOperationColumnIndex) as TextView
            val processNameTextView = selectedRow.getChildAt(processNameIndex) as TextView

            if(ilTextView.text == "N" && !m_moveInIng) {
               /* for (i in 0 until gridData.mainTable.children.count()) {
                    val row: CTRowLayout =
                        gridData.mainTable.children.elementAt(i) as CTRowLayout

                    if ((row.getChildAt(ilColumnIndex) as TextView).text == "Y") {
                        (row.getChildAt(ilColumnIndex) as TextView).text = "N"
                        row.setBackgroundColor(Color.parseColor("#00FFFFFF"))

                        for (col in 0 until row.childCount) {
                            val rowText = row.getChildAt(col) as TextView
                            rowText.setTextColor(Color.BLACK)
                        }
                    }

                }*/

                selectedRow.setBackgroundColor(Color.RED)
                ilTextView.text = "Y"

           //     m_sSubOperation = subOperationTextView.text.toString()
                m_sProcessStep = processNameTextView.text.toString()

                for (col in 0 until selectedRow.childCount) {
                    val rowText = selectedRow.getChildAt(col) as TextView
                    rowText.setTextColor(Color.WHITE)
                }
            } else if (ilTextView.text == "Y") {
                (selectedRow.getChildAt(ilColumnIndex) as TextView).text = "N"
                selectedRow.setBackgroundColor(Color.parseColor("#FFFFFFFF"))

                for (col in 0 until selectedRow.childCount) {
                    val rowText = selectedRow.getChildAt(col) as TextView
                    rowText.setTextColor(Color.parseColor("#808080"))
                }
            }

            return super.onSingleTapUp(e)
        }
    }

}