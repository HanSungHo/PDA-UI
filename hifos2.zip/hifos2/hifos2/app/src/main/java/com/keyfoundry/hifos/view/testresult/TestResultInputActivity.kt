package com.keyfoundry.hifos.view.testresult

import android.os.Bundle
import android.text.InputFilter
import android.util.Log
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityTestResultInuptBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TestResultInputActivity : HFActivity() {

    companion object {
        private const val TAG = "TestResultInputActivity"
    }

    private lateinit var viewBinding : ActivityTestResultInuptBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var fabInDate : String

    private var spinnerEqpItems = arrayListOf<String>()
    private var spinnerInspTypesItems = arrayListOf<String>()
    private var spinnerInspResultItems = arrayListOf<String>()
    private var spinnerInspContentItems = arrayListOf<String>()

    private var m_sSerialno = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityTestResultInuptBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        viewBinding.editMaskTag.requestFocus()
        viewBinding.editMaskTag.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        setEventSpinner()

        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
            }
        })

        viewBinding.editMaskTag.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                if (getBarcodeReticleId(viewBinding.editMaskTag)) {
                    getMaskInfo()
                }
            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    if (getBarcodeReticleId(viewBinding.editMaskTag)) {
                        getMaskInfo()
                    }
                }
            }

            true
        }

        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val eqpId = viewBinding.spinnerEqp.selectedItem?.toString()
                val inspType = viewBinding.spinnerTestTypes.selectedItem?.toString()
                val inspType2 = viewBinding.spinnerTestContent.selectedItem?.toString()
                val inspResult = viewBinding.spinnerTestResult.selectedItem?.toString()
                val inspText = viewBinding.editTestContent2.text.toString()
                val holdText = viewBinding.editHoldReason.text.toString()


                if(viewBinding.editSerialNo.text.toString().isEmpty())
                {
                    val returnCode = OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_ERROR
                        ,"Serial No를 입력하세요."
                        , GetString.BTNOKSTR)
                    return
                }


                if(m_sSerialno != viewBinding.editSerialNo.text.toString())
                {
                    val returnCode = OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_ERROR
                        ,"올바른 Serial No를 입력하세요."
                        , GetString.BTNOKSTR)
                    return
                }

                if (eqpId == null) {
                    val returnCode = OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_ERROR
                        ,"검사 장비를 선택하세요."
                        , GetString.BTNOKSTR)
                    return
                }
                if (inspType == null) {
                    val returnCode = OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_ERROR
                        ,"검사 구분을 선택해주세요"
                        , GetString.BTNOKSTR)
                    return
                }
                if (inspType2 == null) {
                    val returnCode = OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_ERROR
                        ,"검사 방법을 선택해주세요"
                        , GetString.BTNOKSTR)
                    return
                }
                if (inspResult == null) {
                    val returnCode = OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_ERROR
                        ,"검사 결과를 선택해주세요"
                        , GetString.BTNOKSTR)
                    return
                }
                if (inspResult.equals("사용불가") && inspType.equals("입고 검사")&& holdText.replace(" ","").length == 0) {
                    val returnCode = OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_ERROR
                        ,"Hold 사유를 입력하세요"
                        , GetString.BTNOKSTR)
                    return
                }
                if (!inspType.equals("입고 검사")&& fabInDate.replace(" ","").length == 0) {
                    val returnCode = OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_ERROR
                        ,"입고일이 설정되지 않은 MASK입니다.\n" +
                                "입고일을 설정하시거나 입고검사를 진행해 주시기 바랍니다."
                        , GetString.BTNOKSTR)
                    return
                }
                inspMaskStatCheck()
            }
        })
    }

    private fun getBarcodeReticleId(editReticleId: EditText): Boolean {
        val reticleId = editReticleId.text.toString()
        if(reticleId.length<=1){
            mainScope.launch {
                OkDialog.show(
                    supportFragmentManager,
                    "READING ERROR",
                    "조회하실 MASK TAG를 읽어주세요.",
                    GetString.BTNOKSTR
                )
            }
            editReticleId.setText("")
            return false
        }
        var returnReticleId = ""
        returnReticleId = reticleId.substring(0, reticleId.length-1)

        editReticleId.setText(returnReticleId)
        return true
    }

    private fun getMaskInfo(){
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.inspMaskInfo(viewBinding.editMaskTag.text.toString())

            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.INSPMASKINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                m_sSerialno =  messageBody.optString("SERIALNO")

                viewBinding.txtPellicle.text = messageBody.optString("PELLICLE")
                viewBinding.txtTestDay.text = messageBody.optString("TODATE")

                if(m_sSerialno.length<5){
                    viewBinding.editSerialNo.setText(m_sSerialno)
                } else {
                    viewBinding.editSerialNo.setText(m_sSerialno.substring(0, 5))
                }
                fabInDate=messageBody.optString("FABINDATE")

                spinnerEqpItems.clear()
                spinnerEqpItems.add("ALL")

                val eqpListJSON = ResponseDataToJsonUtil.getMessageBodyInValueNullCheckList(result, "EQPID", "EQPIDS")
                for (i in 0 until eqpListJSON.length()) {
                    val eqp = eqpListJSON.getJSONObject(i)
                    spinnerEqpItems.add(eqp.getString("ITEM1"))
                }
                //      setEqpSpinner(spinnerEqpItems)

                spinnerInspTypesItems.clear()
                val inspTypesListJSON = ResponseDataToJsonUtil.getMessageBodyInValueNullCheckList(result, "INSPTYPE", "INSPTYPES")
                for (i in 0 until inspTypesListJSON.length()) {
                    val bay = inspTypesListJSON.getJSONObject(i)
                    spinnerInspTypesItems.add(bay.getString("ITEM1"))
                }
                //       setInspTypesSpinner(spinnerInspTypesItems)

                spinnerInspResultItems.clear()
                val inspResultListJSON = ResponseDataToJsonUtil.getMessageBodyInValueNullCheckList(result, "INSPRESULT", "INSPRESULTS")
                for (i in 0 until inspResultListJSON.length()) {
                    val bay = inspResultListJSON.getJSONObject(i)
                    spinnerInspResultItems.add(bay.getString("ITEM1"))
                }
        //        setInspResultSpinner(spinnerInspResultItems)

                spinnerInspContentItems.clear()

                val inspContentListJSON = ResponseDataToJsonUtil.getMessageBodyInValueNullCheckList(result, "INSPTYPE2", "INSPTYPE2S")
                for (i in 0 until inspContentListJSON.length()) {
                    val bay = inspContentListJSON.getJSONObject(i)
                    spinnerInspContentItems.add(bay.getString("ITEM1"))
                }
        //        setInspContentSpinner(spinnerInspContentItems)

                viewBinding.btnOk.isEnabled = true
                viewBinding.editMaskTag.isEnabled = false

            }
            else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)
            }

        }
    }


    private fun inspMaskStatCheck(){
        mainScope.launch {
            //1. set Message
            val reticleSeq = viewBinding.editMaskTag.text.toString()

            val sendMessage = MessageFactoryUtil.inspMaskStatCheck(reticleSeq)
            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.INSPMASKSTATCHECK)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sStat = messageBody.optString("STATUS")
                val sMasktag = messageBody.optString("MASK_TAG")

                // 변경 불가 조건
                if(sStat.equals("RUN") && !sMasktag.equals("RUN"))
                {
                    val returnCode = OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_ERROR
                        ,"MASK는 RUN 상태이므로 변경할 수 없습니다"
                        , GetString.BTNOKSTR)
                    return@launch
                }
                setInspResult()

            }
            else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)
            }
        }
    }

    private fun setInspResult(){
        mainScope.launch {
            val reticleSeq = viewBinding.editMaskTag.text.toString()
            val eqpId = viewBinding.spinnerEqp.selectedItem.toString()
            val inspType = viewBinding.spinnerTestTypes.selectedItem.toString()
            val inspType2 = viewBinding.spinnerTestContent.selectedItem.toString()
            val inspResult = viewBinding.spinnerTestResult.selectedItem.toString()
            val inspText = viewBinding.editTestContent2.text.toString()
            val holdText = viewBinding.editHoldReason.text.toString()

            val sendMessage = MessageFactoryUtil.inspMaskInsert(reticleSeq,eqpId,inspType,inspType2,inspResult,inspText,holdText,DeviceInfo.OPERATOR_ID,DeviceInfo.OPERATOR_NAME, fabInDate)

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.INSPMASKINSERT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                viewBinding.btnOk.isEnabled = false
                viewBinding.editMaskTag.isEnabled = true
                clearData()

                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_OK
                    , "검사결과 입력완료"
                    , GetString.BTNOKSTR)

            }
            else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)
            }

        }
    }

    private fun setEqpSpinner(items : ArrayList<String>){
        val myAdapter = ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, items)
        myAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerEqp.adapter = InitSpinnerAdapter(myAdapter, R.layout.contact_spinner_row_init, applicationContext)
    }

    private fun setInspTypesSpinner(items : ArrayList<String>){
        val myAdapter = ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, items)
        myAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerTestTypes.adapter = InitSpinnerAdapter(myAdapter, R.layout.contact_spinner_row_init, applicationContext)
    }

    private fun setInspResultSpinner(items : ArrayList<String>){
        val myAdapter = ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, items)
        myAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerTestResult.adapter = InitSpinnerAdapter(myAdapter, R.layout.contact_spinner_row_init, applicationContext)
    }

    private fun setInspContentSpinner(items : ArrayList<String>){
        val myAdapter = ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, items)
        myAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerTestContent.adapter = InitSpinnerAdapter(myAdapter, R.layout.contact_spinner_row_init, applicationContext)
    }

    private fun setEventSpinner(){
        viewBinding.spinnerEqp.setOnTouchListener(SpinnerTouchEvent("EQP"))
        viewBinding.spinnerTestTypes.setOnTouchListener(SpinnerTouchEvent("TYPES"))
        viewBinding.spinnerTestContent.setOnTouchListener(SpinnerTouchEvent("CONTENT"))
        viewBinding.spinnerTestResult.setOnTouchListener(SpinnerTouchEvent("RESULT"))
    }

    private inner class SpinnerTouchEvent : View.OnTouchListener {
        var eventName: String

        constructor(eventName : String ){
            this.eventName = eventName
        }

        override fun onTouch(v: View?, event: MotionEvent?): Boolean {
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    //on Touch
                    when(eventName){
                        "EQP" -> {
                            setEqpSpinner(spinnerEqpItems)
                        }
                        "TYPES" ->  {
                            setInspTypesSpinner(spinnerInspTypesItems)
                        }
                        "CONTENT" -> {
                            setInspContentSpinner(spinnerInspContentItems)
                        }
                        "RESULT" -> {
                            setInspResultSpinner(spinnerInspResultItems)
                        }
                    }
                }
            }
            return false
        }
    }

    private fun clearData(){
        spinnerEqpItems.clear()
        spinnerInspTypesItems.clear()
        spinnerInspResultItems.clear()
        spinnerInspContentItems.clear()

        setEqpSpinner(spinnerEqpItems)
        setInspTypesSpinner(spinnerInspTypesItems)
        setInspResultSpinner(spinnerInspResultItems)
        setInspContentSpinner(spinnerInspContentItems)

        viewBinding.editMaskTag.setText("")
        viewBinding.txtPellicle.setText("")
        viewBinding.txtTestDay.setText("")
        viewBinding.editTestContent2.setText("")
        viewBinding.editHoldReason.setText("")
        viewBinding.editSerialNo.setText("")

        viewBinding.editMaskTag.requestFocus()
    }
}