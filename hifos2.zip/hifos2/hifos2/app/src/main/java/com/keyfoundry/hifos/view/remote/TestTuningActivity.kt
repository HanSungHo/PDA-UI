package com.keyfoundry.hifos.view.remote

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ShapeDrawable
import android.os.Bundle
import android.text.InputFilter
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewTreeObserver
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.core.view.children
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityTestTuningBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.MachineSelectDialogActivity
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class TestTuningActivity : HFActivity() {
    companion object {
        private const val TAG = "TestTuningActivity"
    }

    private lateinit var viewBinding: ActivityTestTuningBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    lateinit var gridService: GridService
    private var baseWidth = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityTestTuningBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editEqpId.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        val base = viewBinding.mainBody
        val vto: ViewTreeObserver = base.viewTreeObserver

        vto.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                base.viewTreeObserver.removeOnGlobalLayoutListener(this)
                baseWidth = base.width
            }
        })

        gridService = GridService(this)

        viewBinding.editEqpId.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                if(viewBinding.editEqpId.text.contains("EQP-")) {
                    val check = BarcodeStyle(this).eqpId(viewBinding.editEqpId)

                    if (check) {
                        mainScope.launch {
                            getMainInfo()
                        }
                    }
                }
                else{
                    mainScope.launch {
                        getMainInfo()
                    }
                }

            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    if(viewBinding.editEqpId.text.contains("EQP-")) {
                        val check = BarcodeStyle(this).eqpId(viewBinding.editEqpId)

                        if (check) {
                            mainScope.launch {
                                getMainInfo()
                            }
                        }
                    }
                    else{
                        mainScope.launch {
                            getMainInfo()
                        }
                    }
                }
            }

            true
        }

        viewBinding.btnSearch.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)

        viewBinding.spinnerMain.onItemSelectedListener = itemSelectedListener
        viewBinding.spinnerSub.onItemSelectedListener = itemSelectedListener

        viewBinding.radioTest.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                mainScope.launch {
                    getMainInfo()
                }
            }
        }
        viewBinding.radioRcp.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                mainScope.launch {
                    getMainInfo()
                }
            }
        }
    }


    private suspend fun getMainInfo() {
        val valEqpId = viewBinding.editEqpId.text.toString()
        val sendMessage = MessageFactoryUtil.cvdTestMainInfo(valEqpId)
        viewBinding.mainBody.removeAllViews()
        viewBinding.txtLot.text = "";

        val message = MessageSender.send(
            supportFragmentManager, sendMessage, MessageName.CVDTESTMAININFO
        )
        val isSuccessFul = message.isSuccessFul
        val result = message.result
        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val RCP_GROUP = messageBody.optString("RCP_GROUP")

            viewBinding.spinnerMain.adapter = null
            viewBinding.spinnerSub.adapter = null
            val spinnerAdapter = ArrayAdapter(
                applicationContext, R.layout.contact_spinner_row_init, RCP_GROUP.split('|')
            )
            spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
            viewBinding.spinnerMain.adapter = InitSpinnerAdapter(
                spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
            )
        }
        else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )

            //End
            viewBinding.editEqpId.setText("")
            viewBinding.editEqpId.requestFocus()

        }
    }

    private fun  getSubInfo() {
        mainScope.launch {

            if (viewBinding.spinnerMain.selectedItem == null) {
                return@launch
            }
            viewBinding.txtLot.text = "";
            val valEqpId = viewBinding.editEqpId.text.toString()
            val valMainId = viewBinding.spinnerMain.selectedItem.toString()
            var varTypeId = ""
            if(viewBinding.radioTest.isChecked())
                varTypeId = "TEST"
            else
                varTypeId = "TUNING"

            val sendMessage = MessageFactoryUtil.cvdTestSubInfo(valEqpId,valMainId, varTypeId )

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.CVDTESTSUBINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val sSUBID = messageBody.optString("SUBID")

                viewBinding.spinnerSub.adapter = null
                val spinnerAdapter = ArrayAdapter(
                    applicationContext, R.layout.contact_spinner_row_init, sSUBID.split('|')
                )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerSub.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )


            }
        }
    }

    private fun  getBodyInfo() {
        mainScope.launch {

            if (viewBinding.spinnerMain.selectedItem == null) {
                return@launch
            }
            if (viewBinding.spinnerSub.selectedItem == null) {
                return@launch
            }
            viewBinding.txtLot.text = "";
            viewBinding.mainBody.removeAllViews()
            val valEqpId = viewBinding.editEqpId.text.toString()
            val valMainId = viewBinding.spinnerMain.selectedItem.toString()
            val valSubId = viewBinding.spinnerSub.selectedItem.toString()
            var varTypeId = ""
            if(valMainId == "" || valSubId == "")
                return@launch

            if(viewBinding.radioTest.isChecked())
                varTypeId = "TEST"
            else
                varTypeId = "TUNING"

            val sendMessage = MessageFactoryUtil.cvdTestBodyInfo(valEqpId,valMainId, valSubId, varTypeId )

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.CVDTESTBODYINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            viewBinding.mainBody.removeAllViews()
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val sBODY = ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "BODY")


                if(varTypeId == "TEST" )
                {
                    val columnList = linkedMapOf(
                        "SLOT" to ColumnProperty("SLOT", Gravity.CENTER, false, baseWidth / 24*2),
                        "RECIPE" to ColumnProperty(
                            "RECIPE",
                            Gravity.CENTER,
                            false,
                            baseWidth / 24*9
                        ),
                        "CHAMBER" to ColumnProperty(
                            "CH",
                            Gravity.CENTER,
                            false,
                            baseWidth / 24*2
                        ),
                        "MEAS_RECIPE" to ColumnProperty(
                            "계측 Recipe", Gravity.RIGHT, false, baseWidth / 24*11
                        )
                    )

                    val mainGrid = gridService.setGridPropData(columnList, sBODY)
                    viewBinding.mainBody.addView(mainGrid)

                    viewBinding.txtLot.text = messageBody.optString("LOTID")
                }
                else {

                    val columnList = linkedMapOf(
                        "PROD_RCP" to ColumnProperty("RECIPE", Gravity.LEFT, false, baseWidth / 6*3),
                        "CHAM_STEP" to ColumnProperty(
                            "CH",
                            Gravity.CENTER,
                            false,
                            baseWidth / 6
                        ),
                        "BE_TIME" to ColumnProperty(
                            "전",
                            Gravity.CENTER,
                            false,
                            baseWidth / 6
                        ),
                        "AF_TIME" to ColumnProperty(
                            "후", Gravity.CENTER, false, baseWidth / 6,
                            Color.parseColor("#b3ffe0de"), Color.BLACK
                        )
                    )

                    val mainGrid = gridService.setGridPropData(columnList, sBODY)
                    viewBinding.mainBody.addView(mainGrid)

                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerMain.id -> {
                        getSubInfo()
                    }
                    viewBinding.spinnerSub.id -> {
                        getBodyInfo();
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearch.id -> {
                    mainScope.launch {
                        getMainInfo()
                    }
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }
}

