package com.keyfoundry.hifos.view.remote

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Vibrator
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.GestureDetectorCompat
import androidx.core.view.children
import androidx.core.view.size
import androidx.viewbinding.ViewBinding
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityRemoteFurnaceBinding
import com.keyfoundry.hifos.databinding.ActivityRemoteFurnaceInitBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.message.MessageSenderAuto
import com.keyfoundry.hifos.view.dialog.RemoteRecipeDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDailogAlram
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.comment.CommentListActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class RemoteFurnaceInitActivity : HFActivity() {

    companion object {
        private const val TAG = "RemoteFurnaceInitActivity"
    }


    private lateinit var viewBinding: ActivityRemoteFurnaceInitBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var spinnerRecipeItems = arrayListOf<String>()

    private lateinit var gridService: GridService
    private lateinit var selectedRow: CTRowLayout
    private lateinit var gridList: CTMainLayout

    private var lsChangeRecipe = false
    private var lsChangeEqpGroup = false
    private var isMainEqp = ""
    private var searchArea = ""
    private var searchOpType = ""
    private var searchOperation = ""
    private var searchSubOperation = ""
    private var searchProcessStep = ""
    private var searchOperSeq = ""
    private var searchSuperEqpId = ""
    private var searchEqpArea = ""
    private var searchEqpType = ""
    private var scrubber = ""
    private var KJ_TYPE = ""

    private var m_sNRWCmtCount = 0

    private var m_sArea = ""
    private var m_sOpType = ""
    private var m_sProduct = ""

    private var m_sProcessStep = ""
    private var m_sOperation = ""
    private var m_sSubOperation = ""

    // Comment Read에 넘길 파라미터
    private var m_sOperSeq = ""

    private var m_dummy = "F"   // F: 양산, T: BATCH 생성 DUMMY, NONLOT : BATCH 미생성
    private var m_restart = "F" // F: START, T: RESTART


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityRemoteFurnaceInitBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)
        gridService = GridService(applicationContext)

        viewBinding.editIngMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        viewBinding.btnRestart.isEnabled = false;
        viewBinding.btnStart.isEnabled = false;
        viewBinding.btnRebatch.isEnabled = false;
        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()
            viewBinding.txtLotNo.setText( lotId )
            viewBinding.txtStandardMachine.setTextColor(Color.BLACK)
            viewBinding.txtLotNo.isEnabled = false;

            mainScope.launch {
                getLotInfo()
                viewBinding.editIngMachine.requestFocus()
            }
        } else {
            // lot 조회 하도록 유도
            //viewBinding.txtLotNo.isEnabled = false;
            viewBinding.editIngMachine.requestFocus()
            m_dummy = "NONLOT"
            viewBinding.btnRestart.text = "온도설정";
            viewBinding.btnStart.text = "NO BATCH";
        }


        viewBinding.txtLotNo.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE)
            {
                val check = BarcodeStyle(this).lotId(viewBinding.txtLotNo)
                //getAbortRecipe()
            }
            else if (event != null)
            {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER)
                {
                    val check = BarcodeStyle(this).lotId(viewBinding.txtLotNo)
                    //getAbortRecipe()
                }
            }
            true
        }

        viewBinding.editIngMachine.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                val check = BarcodeStyle(this).eqpId(viewBinding.editIngMachine)
                if (check) {
                    mainScope.launch {
                        getMachineInfo(viewBinding.editIngMachine.text.toString())
                    }
                }
            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).eqpId(viewBinding.editIngMachine)
                    if (check) {
                        mainScope.launch {
                            getMachineInfo(viewBinding.editIngMachine.text.toString())
                        }
                    }
                }
            }
            true
        }

        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
        viewBinding.btnStart.setOnClickListener(onSingleClickListener)
        viewBinding.btnRestart.setOnClickListener(onSingleClickListener)
        viewBinding.btnClearPort.setOnClickListener(onSingleClickListener)
        viewBinding.btnRebatch.setOnClickListener(onSingleClickListener)
        viewBinding.btnReManual.setOnClickListener(onSingleClickListener)

        viewBinding.spinnerPort.onItemSelectedListener = itemSelectedListener
        viewBinding.spinnerIngRcp.onItemSelectedListener = itemSelectedListener
    }



    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerPort.id -> {
                        setPortState()
                    }
                    viewBinding.spinnerIngRcp.id -> {
                        getINLKChk()
                    }
                }
            }
        }
        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private fun getAbortRecipe()
    {
        mainScope.launch {
            val sAbortLOT = viewBinding.txtLotNo.text.toString()
            val sendMessage = MessageFactoryUtil.FurnaceAbortRecipe( sAbortLOT )
            val message = MessageSender.send( supportFragmentManager, sendMessage, MessageName.FURNACEABORTRECIPE )
            val isSuccessFul = message.isSuccessFul
            var result = message.result
            if(isSuccessFul)
            {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val sAbortRCP = messageBody.optString("MACHINERECIPENAME")
                if(sAbortRCP.isEmpty()) {
                    OkDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_ERROR,
                        "Move in recipe를 찾을 수 없습니다.",
                        GetString.POSITIVEBTNSTR
                    )
                    return@launch
                }
                if (viewBinding.spinnerIngRcp.adapter != null) {
                    val rcpAdapter = viewBinding.spinnerIngRcp.adapter

                    for (count in 0 until rcpAdapter.count)
                    {
                        if (rcpAdapter.getItem(count) == sAbortRCP) {
                            viewBinding.spinnerIngRcp.setSelection(count, false)
                            OkDialog.show(
                                supportFragmentManager,
                                GetString.TXTDIALOGTITLE_INFORM,
                                "Move in recipe를 설정하였습니다.",
                                GetString.BTNOKSTR
                            )
                            break;
                        }
                    }
                }
            }
            else
            {
                OkDialog.show(supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR, "Move in recipe를 찾을 수 없습니다.", GetString.POSITIVEBTNSTR)
            }
        }
    }

    private fun getINLKChk()
    {
        mainScope.launch {
            if(m_dummy == "T" || m_dummy == "NONLOT" || m_restart == "T")
            {
                if(viewBinding.spinnerIngRcp.selectedItem == null)
                    return@launch

                val dummymachineName = viewBinding.editIngMachine.text.toString()
                val dummyrecipeName = viewBinding.spinnerIngRcp.selectedItem.toString()

                val sendMessage = MessageFactoryUtil.FurnacerDummyRCPCheck(
                    dummymachineName,
                    dummyrecipeName
                )

                val message = MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.FURNACEDUMMYRCPCHECK
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result
                if (isSuccessFul) {
                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                    val sRET = messageBody.optString("RET")
                    if(sRET.isEmpty() == false) {
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            sRET, GetString.POSITIVEBTNSTR
                        )
                    }
                }
                else {
                }
            }
            else
            {
                var sLotList = ""

                if (::gridList.isInitialized) {
                    val mainTable = gridList.mainTable
                    for (row in 0 until mainTable.size) {
                        val tableRow = mainTable.getChildAt(row) as CTRowLayout
                        if (sLotList.isEmpty() == false)
                            sLotList += ","
                        sLotList += (tableRow.tag as GridService.RowData).rowDataList["LOTID"].toString()
                    }
                }

                val machineName = viewBinding.editIngMachine.text.toString()
                val recipeName = viewBinding.spinnerIngRcp.selectedItem.toString()
                val remoteBatch = viewBinding.txtBatId.text.toString()

                val sendMessage = MessageFactoryUtil.FurnacerINTLKCheck(
                    machineName,
                    remoteBatch,
                    recipeName,
                    sLotList
                )

                val message = MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.FURNACEINTLKCHECK
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result
                if (isSuccessFul) {
                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                    val sRET = messageBody.optString("RET")
                    val sINTLK =messageBody.optString("INTLK")
                    if(sRET.isEmpty() == false) {
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            sRET, GetString.POSITIVEBTNSTR
                        )
                    }
                    if(sINTLK == "Y")
                    {
                        viewBinding.btnStart.isEnabled = false
                        viewBinding.btnRestart.isEnabled = false
                        viewBinding.btnRebatch.isEnabled = false
                    }
                }
                else {
                }
            }
        }
    }

    private suspend fun getMachineInfo(eqpId: String) {

        var isMachineName = eqpId
        isMainEqp = eqpId

        val valEqpId = viewBinding.txtStandardMachine.text.toString()
        if (searchOpType != "M" && valEqpId != "FAB2" && valEqpId != "FAB5" && valEqpId != "FAB7" && searchArea != "PQC") {
            val sendMessage = MessageFactoryUtil.remoteEqpInfo(isMachineName)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.REMOTEEQPINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val mainEqp = messageBody.optString("MAINEQPID")
                val procEqp = messageBody.optString("PROCEQPID")
                val eqpArea = messageBody.optString("EQPAREA")
                val eqpType = messageBody.optString("EQPTYPE")
                val isDoorOpen = messageBody.optString("ISDOOROPEN")
                //2015.06.01 장비 PM 주기 체크 수정
                val pmMessage = messageBody.optString("PMMESSAGE")
                val portName = messageBody.optString("PORTNAME")
                //2016.12.21 장비 TEST 주기 알림
                val cycleMessage = messageBody.optString("CYCLE_MESSAGE")
                KJ_TYPE = messageBody.optString("FURNACE")

                if (pmMessage.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, "PM주기 경고", pmMessage, GetString.BTNOKSTR
                    )
                }

                val portList = portName.split(",")
                val spinnerAdapter = ArrayAdapter(
                    applicationContext, R.layout.contact_spinner_row_init, portList
                )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerPort.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                viewBinding.spinnerPort.setSelection(1, false)

                if (cycleMessage.isNotEmpty()) {
                    val cycleList = cycleMessage.split("/")
                    for (cycle in cycleList) {
                        OkDialog.show(
                            supportFragmentManager, "계측 주기 알림", cycle, GetString.BTNOKSTR
                        )
                    }
                }


                isMainEqp = procEqp
                isMachineName = procEqp
                searchSuperEqpId = mainEqp
                searchEqpArea = eqpArea
                searchEqpType = eqpType

                if(m_dummy == "F") {
                    val check = ValidateCheck(this@RemoteFurnaceInitActivity).equipment(
                        viewBinding.txtStandardMachine.text.toString(), isMachineName
                    )

                    if (!check) {
                        //    OkDialog.show(
                        //        supportFragmentManager, "계측 주기 알림",
                        //        "[$isMachineName]장비가 기준장비에 존재하지 않습니다.", GetString.BTNOKSTR
                        //   )

                        viewBinding.editIngMachine.setText("")
                        viewBinding.editIngMachine.requestFocus()
                        return
                    }
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
                //실패시 Global 변수 초기화
                //Add By wj.Kim
                searchSuperEqpId = ""
                searchEqpArea = ""
                searchEqpType = ""
                //End
                viewBinding.editIngMachine.setText("")
                viewBinding.editIngMachine.requestFocus()
                return
            }
        }

        viewBinding.editIngMachine.setText(isMachineName)
        if( m_dummy == "F" )
            getRecipeInfo()
        else
            getDummyRecipeInfo()

        viewBinding.editIngMachine.requestFocus()
        viewBinding.editIngMachine.selectAll()
    }

    private fun changeEQPStatus() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.changeEQPStatus(
                searchSuperEqpId,
                DeviceInfo.FACILITY,
                "R  가동중",
                "RR001",
                "PDA_MVIN_UP",
                DeviceInfo.OPERATOR_ID,
                DeviceInfo.OPERATOR_NAME,
                ""
            )

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.CHANGEEQPSTATUS)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                Log.d("recieve changeEQPStatus", messageBody.toString())

                val returnCode = OkCancelDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_OK,
                    "장비상태가 변경되었습니다.\n" +
                            "진행장비의 RECIPE를 다시 요청 하시겠습니까?",
                    GetString.BTNYESSTR,
                    GetString.BTNNOSTR
                )
                if (returnCode == OkCancelDialog.RETURN_CODE_OK) {
                    getRecipeInfo()
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

            }
        }
    }


    /* *
    * Recipe 조회 Event 처리
    * */
    private suspend fun getRecipeInfo() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.recipeInfoDiff(
                "N",
                viewBinding.txtLotNo.text.toString(),
                m_sOperation,
                m_sSubOperation,
                m_sProduct,
                searchSuperEqpId,
                m_sOpType,
                DeviceInfo.FACILITY,
                m_dummy
            )

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.RECIPEINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                Log.d("recieve recipeinfo", messageBody.toString())

                val sEtchMessge = messageBody.optString("ETCHMESSAGE")

                //---[Addition] 2015.03.23 jy.Lim(Begin)
                //입력한 Lot별, 사전 Photo 진행 장비가 다른지 Check
                if (sEtchMessge != "") {
                    val returnCode = OkCancelDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        sEtchMessge,
                        GetString.BTNYESSTR,
                        GetString.BTNNOSTR
                    )
                    if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                        viewBinding.editIngMachine.setText("")
                        viewBinding.editIngMachine.requestFocus()
                        return@launch
                    }

                }

                val sMultiMoveinM = messageBody.optString("MULTIMOVEINACTION") //[Addition] 2019.09.16
                // ---[Addition] 2015.03.23 jy.Lim(Begin)
                val sRecipeID = messageBody.optString("RECIPE")

                //---[Addition] 2019.09.16 by jY.Lim (Begin)
                if (sMultiMoveinM != "") {
                    val returnCode = OkDialog.show(supportFragmentManager
                        , "WARNING"
                        , sMultiMoveinM
                        , GetString.BTNOKSTR)
                }
                viewBinding.txtRecipe.setText( sRecipeID )
                //        viewBinding.btnModify.isEnabled = true

                spinnerRecipeItems.clear()
                spinnerRecipeItems.add(sRecipeID)
                setRecipeSpinner(spinnerRecipeItems)
                if(sRecipeID!="") {
                    viewBinding.spinnerIngRcp.setSelection(1)
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                if (errorMessage == "현재 장비 상태가 비부하DOWN 입니다." ||
                    errorMessage == "현재 장비 상태가 가동중(RUN)이 아닙니다." ) {
                    val returnCode = OkCancelDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        "현재 장비 상태가 가동중(RUN)이 아닙니다.\n장비 상태를 가동중(RUN)으로 변경 하시겠습니까?",
                        GetString.BTNYESSTR,
                        GetString.BTNNOSTR
                    )
                    if (returnCode == OkCancelDialog.RETURN_CODE_OK) {
                        changeEQPStatus()
                    }
                } else {
                    val returnCode = OkDialog.show(supportFragmentManager
                        , GetString.TXTDIALOGTITLE_ERROR
                        , errorMessage
                        , GetString.BTNOKSTR)
                }
            }
        }
    }

    private suspend fun getDummyRecipeInfo()    {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.FurnaceDummyRCP(
                searchSuperEqpId
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.FURNACEDUMMYRCP)
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {

                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val sRecipeID = messageBody.optString("RECIPE")
                val tempRecipeList = sRecipeID.split(",")
                val sStepRemv = messageBody.optString("STEP_REMOVE");
                viewBinding.chkStepRemove.isChecked = false

                if(sStepRemv == "Y" )
                    viewBinding.chkStepRemove.isEnabled = true
                else
                    viewBinding.chkStepRemove.isEnabled = false

                spinnerRecipeItems.clear()
                for (tempRecipe in tempRecipeList) {
                    spinnerRecipeItems.add(tempRecipe)
                }
                setRecipeSpinner(spinnerRecipeItems)
            }
            else
            {
                OkDialog.show(supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR, "진행 가능한 Recipe가 없어 작업예약을 할 수 없습니다.", GetString.POSITIVEBTNSTR)
            }
        }
    }

    private fun setRecipeSpinner(items : ArrayList<String>){
        val myAdapter = ArrayAdapter(this, R.layout.contact_spinner_row_init, items)
        myAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerIngRcp.adapter = InitSpinnerAdapter(myAdapter, R.layout.contact_spinner_row_init, applicationContext)
    }





    /* *
    * lot 조회 Event 처리
    * */
    private suspend fun getLotInfo() {
        mainScope.launch {
            val lotId = viewBinding.txtLotNo.text.toString()

            val sendMessage = MessageFactoryUtil.lotInfo(lotId, DeviceInfo.FACILITY, "MVIN", DeviceInfo.OPERATOR_ID)

            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.LOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sProduct = messageBody.optString("PRODUCT")
                val sFacility = messageBody.optString("FACILITY")
                val sOperation = messageBody.optString("OPERATION")
                val sCustomer = messageBody.optString("CUSTOMER")
                val sCategory = messageBody.optString("CATEGORY")
                val sEngineer = messageBody.optString("ENGINEER")
                val sPacking = messageBody.optString("PACKING")
                val sQty = messageBody.optString("QUANTITY")
                val sGoodChips = messageBody.optString("GOODCHIPS")
                val sRecipe = messageBody.optString("RECIPE")
                val sChangeRecipe = messageBody.optString("CHANGERECIPE")
                val sEqpGroup = messageBody.optString("EQPGROUP")
                val sChangeEqpGroup = messageBody.optString("CHANGEEQPGROUP")
                val sCommentQty = messageBody.optString("COMMENTQTY")
                val sBatchId = messageBody.optString("BATCHID")
                val sArea = messageBody.optString("AREA")
                val sWorkedEqpId = messageBody.optString("WORKEDEQPID")
                val sWorkedRecipe = messageBody.optString("WORKEDRECIPE")
                val sWorkedReticle = messageBody.optString("WORKEDRETICLE")
                val sJobCode = messageBody.optString("JOBCODE")
                val sProcessStep = messageBody.optString("PROCESSSTEP")
                val sSubOperation = messageBody.optString("SUBOPERATION")
                val sOpType = messageBody.optString("OPTYPE")
                val sStatus = messageBody.optString("STATUS")
                val sState = messageBody.optString("STATE")
                val sHoldStatus = messageBody.optString("HOLDSTATUS")
                val sOperSeq = messageBody.optString("OPERSEQUENCE")
                val sEtcMsg = messageBody.optString("ETCMSG")

                val sSkipAllowFlag =
                    messageBody.optString("SKIPALLOWFLAG")    //---[Addition] Nov 22, 2007. by I. H. Lee
                val sAutoSkip =
                    messageBody.optString("AUTOSKIP")            //---[Addition] 2011.09.09. by kck
                val sMeasOper =
                    messageBody.optString("MEASOPERATIONNAME")    //---[Addition] 2011.09.09. by kck
                val sFqcLot =
                    messageBody.optString("FQCLOTNAME")            //---[Addition] 2011.09.09. by kck
                val sReworkSkipFlag =
                    messageBody.optString("REWORKSKIPFLAG") //2013.11.13 Rework Skip Flag 추가 jy.Lim
                val sPhotoType =
                    messageBody.optString("PHOTOTYPE")    //2015.02.10 HV Asher공정 Photo 진행 관련 PhotoType 추가 wjKim
                val sPqcSkip =
                    messageBody.optString("PQCSKIPUSER") // 2015.03.03 PQCSKIP가능 판단 유무
                val sInlineSample =
                    messageBody.optString("INLINESAMPLEMESSGE") //---[Addition] 2015.03.18 Inline Sampling Messge 추가 메세지가 있다면  POP_up  jy.Lim
                val sCreateCategory =
                    messageBody.optString("CREATECATEGORY") //---[Addition] 2015.05.13 Dummay Count category 구분 jy.Lim
                val sLasteventcomment =
                    messageBody.optString("LASTEVENTCOMMENT") //---[Addition] 2015.05.13 Dummay Count category 구분 jy.Lim
                val sProcessName =
                    messageBody.optString("PROCESSNAME")//---[Addition] 2015.06.22 Dummay Wafer의 bach Movein못하도록 interlock
                val sOXcmpMachine =
                    messageBody.optString("OXMACHINE")        // 2016.04.06 사전 장비 확인 관련 하여
                val sFICDLot =
                    messageBody.optString("FICDLOT") // 2017.01.09 FICD SamplingLot jy.Lim
                val sMeastype =
                    messageBody.optString("MEASTYPE") // 2018.02.26 SamplingLot jy.Lim
                val sSortingSkipFlag =
                    messageBody.optString("SORTINGSKIP") // 2020.03.19 이미 Sorting 장비로 진행한 경우, default로 Skip에 Check가 되어야 하는 상태 jy.Lim
                val sMeastypeSampling =
                    messageBody.optString("SAMPLINGREASON") // 2021.04.12 UV CHECK를 위해
                val sSamplingMsg =
                    messageBody.optString("SAMPLINGMSG") // 2021.04.12 BATCH SAMPLINGMSG 확인을 위해 추가

                val machineName = messageBody.optString("MACHINENAME")
                val portName = messageBody.optString("PORTNAME")
                val machineRecipeName = messageBody.optString("MACHINERECIPENAME")
                val lotResUser = messageBody.optString("LOTRESUSER")

                m_sNRWCmtCount = messageBody.optString("NWCOMMENTQTY").toIntOrNull() ?: 0

                viewBinding.txtBatId.setText(sBatchId.replace(" ", ""))

                if (sChangeRecipe != "" && sRecipe != sChangeRecipe) {
                    viewBinding.txtRecipe.setTextColor(Color.RED)
                }

                if (sChangeEqpGroup != "" && sChangeEqpGroup!=viewBinding.txtStandardMachine.text.toString()) {
                    viewBinding.txtStandardMachine.text = sChangeEqpGroup
                    viewBinding.txtStandardMachine.setTextColor(Color.RED)
                }
                else {
                    viewBinding.txtStandardMachine.text = sEqpGroup
                }

                m_sOperation = sOperation
                m_sSubOperation = sSubOperation
                m_sProduct = sProduct
                m_sProcessStep = sProcessStep


                m_sOperSeq = sOperSeq;

                m_sArea = sArea;
                m_sOpType = sOpType;

                viewBinding.txtBatId.text = sBatchId

                viewBinding.txtExMachine.text = sOXcmpMachine


                if (sMeastype != "") {
                    if (sSamplingMsg == "") {
                        if (sMeastypeSampling == "Y") {
                            OkDialog.show(supportFragmentManager, "검사대상", "UV검사 대상 Lot 입니다.",  GetString.POSITIVEBTNSTR)
                        } else {
                            OkDialog.show(supportFragmentManager, "검사대상", "$sMeastype 검사 대상 Lot 입니다.",  GetString.POSITIVEBTNSTR)
                        }
                    } else {
                        OkDialog.show(supportFragmentManager, "검사대상", "동일한 Batch에 검사대상 Lot이 있습니다.\n$sSamplingMsg",  GetString.POSITIVEBTNSTR)
                    }
                }

                if (sMeasOper != "" && sFqcLot != "") {
                    OkDialog.show(supportFragmentManager, "검사대상", "$sFqcLot 은 공정이물 검사 대상 Lot 입니다.",  GetString.POSITIVEBTNSTR)
                }

                if (sMeasOper != "" && sFICDLot != "") {
                    OkDialog.show(supportFragmentManager, "검사대상", "$sFICDLot 은 FICD검사 대상 Lot 입니다.",  GetString.POSITIVEBTNSTR)
                }

                if (sEtcMsg != "") {
                    OkDialog.show(supportFragmentManager, "정보", sEtcMsg,  GetString.POSITIVEBTNSTR)
                }

                if (sStatus == "RUN") {
                    OkDialog.show(supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR, "이미 MOVE IN된 LOT입니다.", GetString.POSITIVEBTNSTR)
                    viewBinding.btnStart.isEnabled = false
                    return@launch
                }

                if (sState != "WIP") {
                    OkDialog.show(supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR, "$sState 상태 입니다. 작업예약을 할 수 없습니다.", GetString.POSITIVEBTNSTR)
                    viewBinding.btnStart.isEnabled = false
                    return@launch
                }

                if (sHoldStatus == "ONHOLD") {
                    OkDialog.show(supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR, "HOLD된 LOT입니다. 작업예약을 할 수 없습니다.", GetString.POSITIVEBTNSTR)
                    viewBinding.btnStart.isEnabled = false
                    return@launch
                }

                if(sInlineSample.isNotEmpty()){
                    OkDialog.show(supportFragmentManager, GetString.TXTDIALOGTITLE_OK, sInlineSample, GetString.POSITIVEBTNSTR)
                }

                if ( sProcessName == "MW_TEST" && sBatchId !="")
                {
                    m_dummy = "T"
                    // Dummy 작업 예약 용

                    //OkDialog.show(supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR, "BATCH로 묶인 Dummy/Test LOT으로 \n" +
//                            "작업예약을 할 수 없습니다.", GetString.POSITIVEBTNSTR)
                    //                  viewBinding.btnStart.isEnabled = false
                    //                return@launch
                }

                if (sBatchId.isEmpty() == true) {
                    val errorMessage = "Batch 생성 후 LOT을 다시 조회하여 주세요"
                    val returnCode = OkDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_OK,
                        errorMessage,
                        GetString.BTNOKSTR
                    )
                    return@launch
                } else {
                    // Batch 정보 조회
                    getBatchListByLot(lotId)
                }

                // 예약 상태인 경우 재작업 예약 유도
                if (lotResUser.isNotEmpty()) {
                    m_restart = "T"
                    viewBinding.editIngMachine.isEnabled = false
                    viewBinding.spinnerIngRcp.isEnabled = false
                    viewBinding.spinnerPort.isEnabled = false
                    viewBinding.btnStart.isEnabled = false
                    viewBinding.editIngMachine.setText(machineName)

                    getMachineInfo(machineName)

                    if (viewBinding.spinnerPort.adapter != null) {
                        val portAdapter = viewBinding.spinnerPort.adapter
                        for (count in 0 until portAdapter.count) {
                            if (portAdapter.getItem(count) == portName) {
                                viewBinding.spinnerPort.setSelection(count, false)
                                break
                            }
                        }
                    }

                    viewBinding.spinnerIngRcp.adapter = null
                    val itemList = arrayListOf(machineRecipeName)
                    val spinnerAdapter = ArrayAdapter(
                        applicationContext, R.layout.contact_spinner_row_init, itemList
                    )
                    spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                    viewBinding.spinnerIngRcp.adapter = InitSpinnerAdapter(
                        spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                    )

                    viewBinding.spinnerIngRcp.setSelection(1, false)
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

                viewBinding.btnStart.isEnabled = false
            }
        }
    }

    private suspend fun getBatchListByLot(lotId: String) {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.batchListByLotMoveIn(
                lotId,
                DeviceInfo.FACILITY,
                viewBinding.txtRecipe.text.toString()
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.BATCHLISTBYLOT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            Log.d(RemoteFurnaceInitActivity.TAG, "getbatchlistbylot : ${result}")

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sWCommentCnt = messageBody.optString("NWCOMMENTQTY")

                val itemList =
                    ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "BATCHITEMS")

                val batchItemList = JSONArray()

                for (i in 0 until itemList.length()) {

                    var item = itemList[i] as JSONObject
                    if(m_dummy == "F") {
                        if (!(item.optString("PROCESSNAME") == "MW_TEST" || item.optString("LOTID")
                                .isEmpty())
                        ) {
                            batchItemList.put(item)
                        }
                    }
                    else
                    {
                        if( messageBody.optString("LOT"+ (i+1).toString()).isEmpty() == false) {
                            item.put("LOTID", messageBody.optString("LOT"+(i+1).toString()))
                            item.put("PRODUCT", "")
                            item.put("STATUS", "")
                            batchItemList.put(item)
                        }
                    }
                }

                val columnData = linkedMapOf(
                    "LOTID" to ColumnProperty("LOTNO", Gravity.CENTER, false),
                    "COMMENTQTY" to ColumnProperty("C", Gravity.CENTER, false),
                    "STATUS" to ColumnProperty("상태", Gravity.CENTER, false),
                    "PROCESSSTEP" to ColumnProperty("공정명", Gravity.CENTER, false),
                    "PRODUCT" to ColumnProperty("제품명", Gravity.CENTER, false),
                    "QUANTITY" to ColumnProperty("수량", Gravity.CENTER, false),
                    "ERRORMESSAGE" to ColumnProperty("에러메시지", Gravity.CENTER, false, 500),
                    "OPERATION" to ColumnProperty("OPERATION", Gravity.CENTER, false),
                    "SUBOPERATION" to ColumnProperty("SUBOPERATION", Gravity.CENTER, false),
                    "LOTSTATE" to ColumnProperty("STATE", Gravity.CENTER, false),
                    "NWCOMMENTQTY" to ColumnProperty("WCOMMENTCNT", Gravity.CENTER, false),
                    "OPERSEQUENCE" to ColumnProperty("OPERSEQUENCE", Gravity.CENTER, false)
                )

                // sProcessName == "MW_TEST" 이면 그리드에서 뺴야됨

                if (batchItemList.length() != 0) {
                    gridList = gridService.setGridPropData(columnData, batchItemList)
                    viewBinding.baseLayout.addView(gridList)
                    selectMoveIn(gridList)
                    if (sWCommentCnt.toIntOrNull() ?: 0 > 0) {
                        val returnCode = OkDialog.show(
                            supportFragmentManager,
                            "정보",
                            "작업성 COMMENT가 있습니다.\n읽은후 진행하세요",
                            GetString.BTNOKSTR
                        )
                        return@launch
                    }
                } else {
                    OkDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_ERROR,
                        "MOVE IN할 LOT이 없습니다.",
                        GetString.BTNOKSTR
                    )
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )
            }
        }
    }

    private fun selectMoveIn(gridData: CTMainLayout) {
        for (row in gridData.mainTable.children) {
            row.setOnTouchListener { v, event ->
                for (row in gridData.mainTable.children) {
                    if (((row as CTRowLayout).getChildAt(2) as TextView).text == "FAIL") {
                        row.setBackgroundColor(Color.RED)
                        for (col in 0 until (row as CTRowLayout).childCount) {
                            val rowText = row.getChildAt(col) as TextView
                            rowText.setTextColor(Color.WHITE)
                        }
                    } else if (((row as CTRowLayout).getChildAt(2) as TextView).text == "RUN") {
                        row.setBackgroundColor(Color.BLUE)
                        for (col in 0 until (row as CTRowLayout).childCount) {
                            val rowText = row.getChildAt(col) as TextView
                            rowText.setTextColor(Color.WHITE)
                        }
                    }
                    else {
                        row.setBackgroundColor(Color.parseColor("#00FFFFFF"))
                        for (col in 0 until (row as CTRowLayout).childCount) {
                            val rowText = row.getChildAt(col) as TextView
                            rowText.setTextColor(Color.BLACK)
                        }
                    }
                }

                selectedRow = v as CTRowLayout
                selectedRow.setBackgroundColor(Color.rgb(37,197,223))
                for (col in 0 until selectedRow.childCount) {
                    val rowText = selectedRow.getChildAt(col) as TextView
                    rowText.setTextColor(Color.WHITE)
                }

                val selectedRowComment = (selectedRow.getChildAt(1) as TextView).text.toString().toIntOrNull() ?: 0
                val selectedRowStatus = (selectedRow.getChildAt(2) as TextView).text.toString()
                //if(selectedRowComment != 0)
                if(event.action == 1 && selectedRowComment != 0)
                    commentRead()
                //viewBinding.btnReadComment.isEnabled = selectedRowComment!=0
                //viewBinding.btnStart.isEnabled = selectedRowStatus != "RUN"
                true
            }

        }
    }

    private fun commentRead() {
        if(m_dummy == "T" || m_dummy == "NONLOT")
            return;

        val sLotNo = (selectedRow.tag as GridService.RowData).rowDataList["LOTID"].toString()
        val sOperation = (selectedRow.tag as GridService.RowData).rowDataList["OPERATION"].toString()
        val sSubOperation = (selectedRow.tag as GridService.RowData).rowDataList["SUBOPERATION"].toString()
        val sProcessStep = (selectedRow.tag as GridService.RowData).rowDataList["PROCESSSTEP"].toString()
        val sOperSeq = (selectedRow.tag as GridService.RowData).rowDataList["OPERSEQUENCE"].toString()

        val commentReadIntent = Intent(applicationContext, CommentListActivity::class.java)

        commentReadIntent.putExtra("LOTID", sLotNo)
        commentReadIntent.putExtra("OPERATION", sOperation)
        commentReadIntent.putExtra("SUBOPERATION", sSubOperation)
        commentReadIntent.putExtra("PROCESSSTEP", sProcessStep)
        commentReadIntent.putExtra("OPERSEQUENCE",sOperSeq )

        startActivity(commentReadIntent)
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {

                viewBinding.btnCancel.id -> {
                    finish()
                }
                viewBinding.btnClearPort.id -> {
                    executeClearPort()
                }
                viewBinding.btnStart.id -> {
                    executeStart()
                }

                viewBinding.btnRestart.id -> {
                    executeReStart()
                }

                viewBinding.btnRebatch.id -> {
                    executeReBatch();
                }

                viewBinding.btnReManual.id -> {
                    val newIntent = Intent(applicationContext, ManualAbortBatchActivity::class.java)
                    activityResultLauncher.launch(newIntent)
                }
            }
        }
    }

    private val activityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                finish()
            }
        }

    private suspend fun checkComment(paraLOT :String ): Boolean {

        val sendMessage = MessageFactoryUtil.lotInfo("MVIN", paraLOT, DeviceInfo.FACILITY)
        val message = MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
        val isSuccessFul = message.isSuccessFul
        val result = message.result
        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val nwCommentQty = messageBody.optString("NWCOMMENTQTY")

            return if (nwCommentQty.isNotEmpty() && nwCommentQty.toInt() > 0) {
                val commentMsg = """
                            |[$paraLOT] 읽지 않은 작업성 COMMENT가 [$nwCommentQty]가 있습니다.
                            |읽은후 진행하세요.
                        """.trimMargin()
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    commentMsg, GetString.BTNOKSTR
                )

                false
            } else {
                true
            }
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )

            return false
        }
    }




    /* *
    * Start Event 처리
    * */
    private fun executeStart()
    {
        mainScope.launch {
            if (viewBinding.editIngMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행장비를 입력하세요.", GetString.BTNOKSTR
                )
                return@launch
            }
            if (!viewBinding.txtLotNo.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "No batch는 LOT 입력 불가", GetString.BTNOKSTR
                )
                viewBinding.txtLotNo.text.clear()
                return@launch
            }
            if (viewBinding.spinnerIngRcp.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Rcp를 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (m_dummy == "F") {
                // EEN CHECK 기능 추가 필요
                var nCount = 0
                viewBinding.btnStart.isEnabled = false

                val mainTable = gridList.mainTable

                for (row in 0 until mainTable.size) {
                    val tableRow = mainTable.getChildAt(row) as CTRowLayout

                    val sLotNo =
                        (tableRow.tag as GridService.RowData).rowDataList["LOTID"].toString()
                    val sState =
                        (tableRow.tag as GridService.RowData).rowDataList["LOTSTATE"].toString()
                    val sStatus =
                        (tableRow.tag as GridService.RowData).rowDataList["STATUS"].toString()

                    if (!checkComment(sLotNo))
                        return@launch

                    if (sLotNo != "D/W" && sLotNo != "") {
                        if (sState != "WIP") {
                            OkDialog.show(
                                supportFragmentManager,
                                GetString.TXTDIALOGTITLE_ERROR,
                                "[$sLotNo]는 [$sState]상태로\nMOVE IN할수 없습니다.",
                                GetString.BTNOKSTR
                            )
                            viewBinding.btnStart.isEnabled = true
                            return@launch
                        }
                        if (sStatus != "WAIT") {
                            OkDialog.show(
                                supportFragmentManager,
                                GetString.TXTDIALOGTITLE_ERROR,
                                "[$sLotNo]는 WAIT상태가 아닙니다.\nMOVE IN할수 없습니다.",
                                GetString.BTNOKSTR
                            )
                            viewBinding.btnStart.isEnabled = true
                            return@launch
                        }
                        nCount++
                    }
                }

                if (nCount <= 0) {
                    OkDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_ERROR,
                        "MOVE IN할 LOT이 없습니다.",
                        GetString.BTNOKSTR
                    )
                    viewBinding.btnStart.isEnabled = true
                    return@launch
                }
            }

            val recipeName = viewBinding.spinnerIngRcp.selectedItem.toString()
            //val recipeName = "TEST"
            val recipeIntent = Intent(this@RemoteFurnaceInitActivity, RemoteRecipeDialog::class.java)
            recipeIntent.putExtra(RemoteRecipeDialog.RECIPE_LIST, recipeName)
            recipeIntent.putExtra(RemoteRecipeDialog.LOT_NO, viewBinding.txtLotNo.text.toString())
            startLauncher.launch(recipeIntent)
        }
    }

    private fun executeReBatch()
    {
        mainScope.launch {
            if (viewBinding.editIngMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행장비를 입력하세요.", GetString.BTNOKSTR
                )
                return@launch
            }
            if (viewBinding.txtLotNo.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "Abort LOT 입력하여 주세요", GetString.BTNOKSTR
                )
                viewBinding.txtLotNo.requestFocus()
                return@launch
            }
            if (viewBinding.spinnerIngRcp.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Rcp를 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (m_dummy == "F") {
                // EEN CHECK 기능 추가 필요
                var nCount = 0
                viewBinding.btnStart.isEnabled = false

                val mainTable = gridList.mainTable

                for (row in 0 until mainTable.size) {
                    val tableRow = mainTable.getChildAt(row) as CTRowLayout

                    val sLotNo =
                        (tableRow.tag as GridService.RowData).rowDataList["LOTID"].toString()
                    val sState =
                        (tableRow.tag as GridService.RowData).rowDataList["LOTSTATE"].toString()
                    val sStatus =
                        (tableRow.tag as GridService.RowData).rowDataList["STATUS"].toString()

                    if (!checkComment(sLotNo))
                        return@launch

                    if (sLotNo != "D/W" && sLotNo != "") {
                        if (sState != "WIP") {
                            OkDialog.show(
                                supportFragmentManager,
                                GetString.TXTDIALOGTITLE_ERROR,
                                "[$sLotNo]는 [$sState]상태로\nMOVE IN할수 없습니다.",
                                GetString.BTNOKSTR
                            )
                            viewBinding.btnStart.isEnabled = true
                            return@launch
                        }
                        if (sStatus != "WAIT") {
                            OkDialog.show(
                                supportFragmentManager,
                                GetString.TXTDIALOGTITLE_ERROR,
                                "[$sLotNo]는 WAIT상태가 아닙니다.\nMOVE IN할수 없습니다.",
                                GetString.BTNOKSTR
                            )
                            viewBinding.btnStart.isEnabled = true
                            return@launch
                        }
                        nCount++
                    }
                }

                if (nCount <= 0) {
                    OkDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_ERROR,
                        "MOVE IN할 LOT이 없습니다.",
                        GetString.BTNOKSTR
                    )
                    viewBinding.btnStart.isEnabled = true
                    return@launch
                }
            }

            val recipeName = viewBinding.spinnerIngRcp.selectedItem.toString()
            //val recipeName = "TEST"
            val recipeIntent = Intent(this@RemoteFurnaceInitActivity, RemoteRecipeDialog::class.java)
            recipeIntent.putExtra(RemoteRecipeDialog.RECIPE_LIST, recipeName)
            recipeIntent.putExtra(RemoteRecipeDialog.LOT_NO, viewBinding.txtLotNo.text.toString())
            startLauncher.launch(recipeIntent)
        }
    }

    private val startLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                remoteStart()
            }
        }

    private fun remoteStart() {
        mainScope.launch {

            val machineName = viewBinding.editIngMachine.text.toString()
            val portName = viewBinding.spinnerPort.selectedItem.toString()
            val recipeName = viewBinding.spinnerIngRcp.selectedItem.toString()
            val remoteBatch = viewBinding.txtBatId.text.toString()
            val eventUser = DeviceInfo.OPERATOR_ID
            val cmdType = "S";
            var lotList  = "";
            val tmpLotName = viewBinding.txtLotNo.text.toString()
            var sChkNoBatch = "F"
            if( viewBinding.chkDummy.isChecked == true )
                sChkNoBatch = "T"
            val sStepRemove = "F"

            if(m_dummy != "NONLOT") {
                val mainTable = gridList.mainTable
                for (row in 0 until mainTable.size) {
                    val tableRow = mainTable.getChildAt(row) as CTRowLayout
                    if (lotList.isEmpty() == false)
                        lotList += ","
                    lotList += "'" + (tableRow.tag as GridService.RowData).rowDataList["LOTID"].toString() + "'"
                }
            }

            if(KJ_TYPE == "KEC")
            {
                val sendMessage = MessageFactoryUtil.FurnaceremoteStart_KEC(
                    machineName,
                    remoteBatch,
                    recipeName,
                    eventUser,
                    portName,
                    cmdType,
                    lotList,
                    m_dummy,
                    tmpLotName,
                    sChkNoBatch,
                    sStepRemove,
                    ""
                )
                val message = MessageSenderAuto.send(
                    supportFragmentManager, sendMessage, MessageName.FURNACEREMOTESTART_KEC
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result
                if (isSuccessFul) {
                    setResult(RESULT_OK)
                    finish()
                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    OkDailogAlram.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR, applicationContext,
                        getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    )
                }
            }
            else {
                val sendMessage = MessageFactoryUtil.FurnaceremoteStart(
                    machineName,
                    remoteBatch,
                    recipeName,
                    eventUser,
                    portName,
                    cmdType,
                    lotList,
                    m_dummy,
                    tmpLotName,
                    sChkNoBatch,
                    sStepRemove
                )
                val message = MessageSenderAuto.send(
                    supportFragmentManager, sendMessage, MessageName.FURNACEREMOTESTART
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result
                if (isSuccessFul) {
                    setResult(RESULT_OK)
                    finish()
                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    OkDailogAlram.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR, applicationContext,
                        getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    )
                }
            }
        }
    }



    /* *
    * Restart Event 처리
    * */
    private fun executeReStart()
    {
        mainScope.launch {
            if (viewBinding.editIngMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행장비를 입력하세요.", GetString.BTNOKSTR
                )
                return@launch
            }
            if (viewBinding.spinnerIngRcp.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Rcp를 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val recipeName = viewBinding.spinnerIngRcp.selectedItem.toString()
            //val recipeName = "TEST"
            val recipeIntent = Intent(this@RemoteFurnaceInitActivity, RemoteRecipeDialog::class.java)
            recipeIntent.putExtra(RemoteRecipeDialog.RECIPE_LIST, recipeName)
            recipeIntent.putExtra(RemoteRecipeDialog.LOT_NO, viewBinding.txtLotNo.text.toString())
            restartLauncher.launch(recipeIntent)
        }
    }

    private val restartLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                remoteReStart()
            }
        }

    private fun remoteReStart() {
        mainScope.launch {

            val machineName = viewBinding.editIngMachine.text.toString()
            val portName = viewBinding.spinnerPort.selectedItem.toString()
            val recipeName = viewBinding.spinnerIngRcp.selectedItem.toString()
            val remoteBatch = viewBinding.txtBatId.text.toString()
            val eventUser = DeviceInfo.OPERATOR_ID
            val cmdType = "R";
            var lotList  = "";
            val tmpLotName = viewBinding.txtLotNo.text.toString()
            val sChkNoBatch = "F"
            var sStepRemove ="F"
            if( viewBinding.chkStepRemove.isChecked == true )
                sStepRemove = "T"

            if(m_dummy != "NONLOT") {
                val mainTable = gridList.mainTable
                for (row in 0 until mainTable.size) {
                    val tableRow = mainTable.getChildAt(row) as CTRowLayout
                    if (lotList.isEmpty() == false)
                        lotList += ","
                    lotList += "'" + (tableRow.tag as GridService.RowData).rowDataList["LOTID"].toString() + "'"
                }
            }

            if( KJ_TYPE == "KJ")
            {
                val sendMessage = MessageFactoryUtil.FurnaceremoteStart_KJ(
                    machineName,
                    remoteBatch,
                    recipeName,
                    eventUser,
                    portName,
                    cmdType,
                    lotList,
                    m_dummy,
                    tmpLotName,
                    sChkNoBatch
                )
                val message = MessageSenderAuto.send(
                    supportFragmentManager, sendMessage, MessageName.FURNACEREMOTESTART_KJ
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result
                if (isSuccessFul) {
                    setResult(RESULT_OK)
                    finish()
                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    OkDailogAlram.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR, applicationContext,
                        getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    )
                }
            }
            else if(KJ_TYPE == "KEC")
            {
                val sendMessage = MessageFactoryUtil.FurnaceremoteStart_KEC(
                    machineName,
                    remoteBatch,
                    recipeName,
                    eventUser,
                    portName,
                    cmdType,
                    lotList,
                    m_dummy,
                    tmpLotName,
                    sChkNoBatch,
                    sStepRemove,
                    ""
                )
                val message = MessageSenderAuto.send(
                    supportFragmentManager, sendMessage, MessageName.FURNACEREMOTESTART_KEC
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result
                if (isSuccessFul) {
                    setResult(RESULT_OK)
                    finish()
                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    OkDailogAlram.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR, applicationContext,
                        getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    )
                }
            }
            else {
                val sendMessage = MessageFactoryUtil.FurnaceremoteStart(
                    machineName,
                    remoteBatch,
                    recipeName,
                    eventUser,
                    portName,
                    cmdType,
                    lotList,
                    m_dummy,
                    tmpLotName,
                    sChkNoBatch,
                    sStepRemove
                )
                val message = MessageSenderAuto.send(
                    supportFragmentManager, sendMessage, MessageName.FURNACEREMOTESTART
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result
                if (isSuccessFul) {
                    setResult(RESULT_OK)
                    finish()
                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    OkDailogAlram.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR, applicationContext,
                        getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    )
                }
            }
        }
    }


    /* *
    * Port Event 처리
    * */
    private fun executeClearPort() {
        mainScope.launch {
            if (viewBinding.spinnerPort.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Port를 먼저 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val portName = viewBinding.spinnerPort.selectedItem.toString()

            val checkCode = OkCancelDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                "PORT [$portName]을(를) 초기화 하고 [IDLE]상태로 바꾸시겠습니까?",
                GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
            )

            if (checkCode == OkCancelDialog.RETURN_CODE_CANCEL)
                return@launch

            val sendMessage =
                MessageFactoryUtil.machinePortClean(searchSuperEqpId, portName)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MACHINEPORTCLEAR
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager, "PORT 초기화",
                    "해당 PORT 초기화 명령을 전송하였습니다.", GetString.BTNOKSTR
                )

                setPortState()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearPortState() {
        viewBinding.txtPortState.text = ""
        viewBinding.txtPortState.background = null
    }

    private fun setPortColor(portState: String) {
        when (portState) {
            "INIT" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.RED)
                viewBinding.txtPortState.setTextColor(Color.WHITE)
            }
            "RUN" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.BLUE)
                viewBinding.txtPortState.setTextColor(Color.WHITE)
            }
            "PENDING" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portPending))
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "READY" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.GREEN)
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "RESERVED" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.YELLOW)
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "COMPLETE" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portCompleted))
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "IDLE" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portIdle))
                viewBinding.txtPortState.setTextColor(Color.WHITE)
            }
        }
    }

    private fun setPortState() {
        mainScope.launch {
            clearPortState()

            if (viewBinding.spinnerPort.selectedItem == null)
                return@launch

            viewBinding.btnClearPort.isEnabled = false

            val portId = viewBinding.spinnerPort.selectedItem.toString()
            val lotId = viewBinding.txtLotNo.text.toString()

            var recipe = ""
            if (viewBinding.spinnerIngRcp.selectedItem != null)
                recipe = viewBinding.spinnerIngRcp.selectedItem.toString()

            if( KJ_TYPE == "KJ")
            {
                val sendMessage =
                    MessageFactoryUtil.machinePortStatus_KJ(searchSuperEqpId, portId, lotId, recipe)
                val message = MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.MACHINEPORTSTATUS_KJ
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result
                if (isSuccessFul) {
                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                    val portSat1 = messageBody.optString("PORTSTATENAME1")
                    val portSat2 = messageBody.optString("PORTSTATENAME2")


                    if(portId == "1")
                    {
                        viewBinding.txtPortState.text = portSat1
                        setPortColor(portSat1)
                        viewBinding.btnStart.isEnabled = false
                        viewBinding.btnRebatch.isEnabled = false
                        viewBinding.btnReManual.isEnabled = false

                        if( portSat1 == "COMPLETE" || portSat1 == "IDLE" )
                        {// 작업 예약 가능
                            viewBinding.btnStart.isEnabled = true
                            viewBinding.btnRestart.isEnabled = true
                            viewBinding.btnClearPort.isEnabled = false
                        }
                        else
                        {
                            viewBinding.btnRestart.isEnabled = false
                            viewBinding.btnClearPort.isEnabled = true
                        }
                    }
                    else
                    {
                        viewBinding.txtPortState.text = portSat2
                        setPortColor(portSat2)

                        viewBinding.btnStart.isEnabled = false
                        viewBinding.btnRestart.isEnabled = false
                        viewBinding.btnClearPort.isEnabled = false
                    }
                }
                else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR
                    )
                }
            }
            else
            {

                val sendMessage =
                    MessageFactoryUtil.machinePortStatus(searchSuperEqpId, portId, lotId, recipe)
                val message = MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.MACHINEPORTSTATUS
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result
                if (isSuccessFul) {
                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                    val chma_ret = messageBody.optString("CHMA_RET")
                    val chmb_ret = messageBody.optString("CHMB_RET")
                    val portState = messageBody.optString("PORTSTATENAME")
                    val portLotName = messageBody.optString("PORTLOTNAME")
                    val ackMsg = messageBody.optString("ACKMSG")

                    viewBinding.txtPortState.text = portState
                    setPortColor(portState)


                    if (portState == "RUN" || portState == "RESERVED") {
                        val portMsg = """
                        |해당 PORT가 진행중입니다.
                        |장비 및 진행할 LOT을 다시 확인 바랍니다.
                    """.trimMargin()
                        OkDialog.show(
                            supportFragmentManager,
                            "장비 MASSAGE",
                            portMsg,
                            GetString.BTNOKSTR
                        )
                        viewBinding.btnClearPort.isEnabled = true
                        viewBinding.btnStart.isEnabled = false
                        viewBinding.btnRestart.isEnabled = false
                        viewBinding.btnRebatch.isEnabled = false
                        //if (viewBinding.txtBatId.text.toString() != portLotName)
                        //    viewBinding.btnClearPort.isEnabled = true

                        if (ackMsg.isNotEmpty()) {
                            OkDialog.show(
                                supportFragmentManager, "PORT WORNING", ackMsg, GetString.BTNOKSTR
                            )
                        }
                    } else if (portState.isEmpty()) {
                        val portMsg = """
                        |PORT 정보를 가져올 수 없습니다.   
                        |잠시후 다시 확인 바랍니다.
                    """.trimMargin()
                        OkDialog.show(
                            supportFragmentManager,
                            "장비 MASSAGE",
                            portMsg,
                            GetString.BTNOKSTR
                        )

                        viewBinding.btnStart.isEnabled = false
                        viewBinding.btnRestart.isEnabled = false
                        viewBinding.btnRebatch.isEnabled = false
                        viewBinding.btnClearPort.isEnabled = false
                    } else if (portState == "PENDING") {
                        // 양산, DUMMY는 동일 BATCH인 경우 RESTART 활성화
                        viewBinding.btnClearPort.isEnabled = true
                        if (m_dummy == "NONLOT") {
                            viewBinding.btnStart.isEnabled = true
                            viewBinding.btnRestart.isEnabled = true
                            viewBinding.btnRebatch.isEnabled = true
                        } else {
                            viewBinding.btnStart.isEnabled = false
                            if (viewBinding.txtBatId.text.toString() == portLotName)
                                viewBinding.btnRestart.isEnabled = true
                            else
                                viewBinding.btnRestart.isEnabled = false
                        }
                    } else if (portState == "INIT") {
                        //
                        if (m_dummy == "NONLOT") {
                            viewBinding.btnRestart.isEnabled = true

                        } else {
                            viewBinding.btnRestart.isEnabled = false
                        }
                        viewBinding.btnStart.isEnabled = false
                        viewBinding.btnRebatch.isEnabled = false
                        viewBinding.btnClearPort.isEnabled = true
                    } else {
                        viewBinding.btnClearPort.isEnabled = true
                        viewBinding.btnStart.isEnabled = true
                        if (m_dummy == "NONLOT") {
                            viewBinding.btnRestart.isEnabled = true
                            viewBinding.btnRebatch.isEnabled = true
                        } else
                            viewBinding.btnRestart.isEnabled = false
                    }
                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR
                    )
                }
            }
        }
    }



}