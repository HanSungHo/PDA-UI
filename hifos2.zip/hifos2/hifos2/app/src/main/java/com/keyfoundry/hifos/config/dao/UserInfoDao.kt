package com.keyfoundry.hifos.config.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy.REPLACE
import androidx.room.Query
import com.keyfoundry.hifos.config.domain.UserInfo

/*
* 안드로이드 내부 DB 사용자정보 관련 쿼리
* */
@Dao
interface UserInfoDao {
    @Query("select * from user_info")
    fun getAll(): List<UserInfo>

    @Query("select * from user_info limit 1")
    fun getUserInfo(): UserInfo

    @Insert(onConflict = REPLACE)
    fun insert(userInfo: UserInfo)

    @Query("delete from user_info")
    fun deleteAll()

    @Query("select loginState from user_info limit 1")
    fun checkLoginState(): Boolean

    @Query("update user_info set operName = '', permission = '', loginState = 0 where loginState = 1")
    fun logOut()

}