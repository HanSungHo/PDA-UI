package com.keyfoundry.hifos.view.rework

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.spinner.SpinnerItem
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityReworkBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.moveout.LossActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReworkActivity : HFActivity() {
    companion object {
        private const val TAG = "ReworkActivity"
    }

    private lateinit var viewBinding: ActivityReworkBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var spinnerBayFirst = 0
    private var searchOperation = ""
    private var searchSubOperation = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityReworkBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        viewBinding.spinnerBay.isEnabled = false
        viewBinding.spinnerStk.isEnabled = false

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()
            viewBinding.txtLotNo.text = lotId
            setData(lotId)
        }

        viewBinding.chkCarry.setOnCheckedChangeListener(checkChangeListener)
        viewBinding.spinnerBay.onItemSelectedListener = selectItemListener

        viewBinding.editComment.setOnEditorActionListener(onEditorActionListener)

//        btn_loss.setOnClickListener(onSingleClickListener)
        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
    }

    private fun clearInfo() {
        viewBinding.txtEqpId.text = ""
        viewBinding.txtProduct.text = ""
        viewBinding.txtCurrentOperation.text = ""
        viewBinding.txtQty.text = ""
        viewBinding.txtOperator.text = ""

        searchOperation = ""
        searchSubOperation = ""

        viewBinding.spinnerReworkCode.adapter = null

        viewBinding.chkCarry.isEnabled = false
//        btn_loss.isEnabled = false
        viewBinding.btnOk.isEnabled = false
    }

    private fun setData(lotId: String) {
        mainScope.launch {
            clearInfo()

            val sendMessage = MessageFactoryUtil.reworkInfo(lotId, DeviceInfo.FACILITY)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.REWORKINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val product = messageBody.optString("PRODUCT")
                val operation = messageBody.optString("OPERATION")
                val subOperation = messageBody.optString("SUBOPERATION")
                val processStep = messageBody.optString("PROCESSSTEP")
                val eqpID = messageBody.optString("EQPID")
                val state = messageBody.optString("STATE")
                val status = messageBody.optString("STATUS")
                val holdStatus = messageBody.optString("HOLDSTATUS")
                val qty = messageBody.optString("QUANTITY")
                val currentStep = "$processStep($operation$subOperation)"

                viewBinding.txtEqpId.text = eqpID
                viewBinding.txtProduct.text = product
                viewBinding.txtCurrentOperation.text = currentStep
                viewBinding.txtQty.text = qty

                val operator = "${DeviceInfo.OPERATOR_NAME}(${DeviceInfo.OPERATOR_ID})"
                viewBinding.txtOperator.text = operator

                searchOperation = operation
                searchSubOperation = subOperation

                val reworkItemList =
                    ResponseDataToJsonUtil.getMessageBodyList(result, "REWORKITEMS")

                val reworkCodeList = arrayListOf<SpinnerItem>()
                for (count in 0 until reworkItemList.length()) {
                    val reworkCode = reworkItemList.getJSONObject(count).optString("REWORKCODE")
                    val reworkDesc = reworkItemList.getJSONObject(count).optString("RWDESCRIPTION")

                    reworkCodeList.add(SpinnerItem(reworkCode, "$reworkCode  $reworkDesc"))
                }

                val spinnerAdapter = ArrayAdapter(
                    applicationContext, R.layout.contact_spinner_row_init, reworkCodeList
                )
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerReworkCode.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                if (state != "WIP") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "$state 입니다. REWORK할 수 없습니다.", GetString.BTNOKSTR
                    )
                    return@launch
                }

                if (holdStatus == "ONHOLD") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "HOLD된 LOT입니다. REWORK할 수 없습니다.", GetString.BTNOKSTR
                    )
                    return@launch
                }

                viewBinding.chkCarry.isEnabled = true
//                        btn_loss.isEnabled = true
                viewBinding.btnOk.isEnabled = true
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }

        }
    }

    private val checkChangeListener =
        CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                viewBinding.spinnerBay.isEnabled = true
                viewBinding.spinnerStk.isEnabled = true

                setBayList()
            } else {
                viewBinding.spinnerBay.isEnabled = false
                viewBinding.spinnerStk.isEnabled = false

                viewBinding.spinnerBay.adapter = null
                viewBinding.spinnerStk.adapter = null

                spinnerBayFirst = 0
            }
        }

    private fun setBayList() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.areaBayInfo(DeviceInfo.FACILITY)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.AREABAYINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val jsonBayList = ResponseDataToJsonUtil.getMessageBodyList(result, "BAYS")

                val bayList = arrayListOf<String>()
                for (count in 0 until jsonBayList.length())
                    bayList.add(jsonBayList.getJSONObject(count).optString("BAY"))

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, bayList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerBay.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

            }
        }
    }

    private val selectItemListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerBay.id -> {
                        if (++spinnerBayFirst > 1)
                            setSTKList()
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private fun setSTKList() {
        mainScope.launch {
            viewBinding.spinnerStk.adapter = null

            if (viewBinding.spinnerBay.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "BAY를 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.bayStockerInfo(
                viewBinding.spinnerBay.selectedItem.toString(), DeviceInfo.FACILITY
            )
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.BAYSTOCKERINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val jsonSTKList = ResponseDataToJsonUtil.getMessageBodyList(result, "STOCKERS")

                val stkList = arrayListOf<String>()
                for (count in 0 until jsonSTKList.length())
                    stkList.add(jsonSTKList.getJSONObject(count).optString("STOCKER"))

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, stkList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerStk.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

            }

        }
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnOk.id -> {
                    executeRework()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }

    }

    private fun setLossActivity() {
        val nextIntent = Intent(this, LossActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
        nextIntent.putExtra("OPERATION", searchOperation)
        nextIntent.putExtra("SUBOPERATION", searchSubOperation)

        activityFactoryResultLauncher.launch(nextIntent)
    }

    private fun executeRework() {
        mainScope.launch {
        //    if (viewBinding.txtEqpId.text.isNullOrEmpty()) {
        //        OkDialog.show(
        //            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
        //            "진행장비를 입력하세요.", GetString.BTNOKSTR
         //       )
         //       return@launch

            if (viewBinding.spinnerReworkCode.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "REWORK코드를 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.chkCarry.isChecked) {
                if (viewBinding.spinnerBay.selectedItem == null) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "BAY를 선택하세요.", GetString.BTNOKSTR
                    )
                    return@launch
                }

                if (viewBinding.spinnerStk.selectedItem == null) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "STOCKER를 선택하세요.", GetString.BTNOKSTR
                    )
                    return@launch
                }
            }

            val lotId = viewBinding.txtLotNo.text.toString()
            val eqpId = viewBinding.txtEqpId.text.toString()

            val reworkItem = viewBinding.spinnerReworkCode.selectedItem as SpinnerItem
            val reworkCode = reworkItem.key

            val comment = viewBinding.editComment.text.toString()
            val qty = viewBinding.txtQty.text.toString()
            val isCarry = if (viewBinding.chkCarry.isChecked)
                "Y"
            else
                "N"

            val bay = if (isCarry == "Y")
                viewBinding.spinnerBay.selectedItem.toString()
            else
                ""

            val stocker = if (isCarry == "Y")
                viewBinding.spinnerStk.selectedItem.toString()
            else
                ""

            val sendMessage = MessageFactoryUtil.rework(
                lotId, DeviceInfo.FACILITY, eqpId, reworkCode, comment, DeviceInfo.OPERATOR_ID,
                searchOperation, searchSubOperation, isCarry, bay, stocker, qty
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.REWORK)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                setResult(RESULT_OK)
                finish()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private val onEditorActionListener =
        TextView.OnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                CommonUtil.hideKeyboard(this, currentFocus)
            }
            true
        }

    private val activityFactoryResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                it.data?.let { intent ->
                    viewBinding.txtQty.text = intent.getStringExtra("QTY")
                }
            }
        }
}