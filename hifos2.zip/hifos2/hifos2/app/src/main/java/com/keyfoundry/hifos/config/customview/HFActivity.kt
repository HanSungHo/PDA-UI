package com.keyfoundry.hifos.config.customview

import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.service.room.SettingInfoService
import com.keyfoundry.hifos.config.service.room.UserInfoService
import com.keyfoundry.hifos.config.service.update.UpdateService
import com.keyfoundry.hifos.config.utils.ExceptionHandler
import com.keyfoundry.hifos.view.patch.PatchActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*

/*
* Activity의 공통적인 기능을 상속 하기 위한 Class
* Update 체크,
* Exception 발생 체크
* 로그인 정보, 환경설정 정보, 블루트스 설정 */
open class HFActivity : AppCompatActivity() {
    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val io = CoroutineScope(Dispatchers.IO)

    private lateinit var userInfoService: UserInfoService
    private lateinit var settingInfoService: SettingInfoService

    protected var update = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        userInfoService = UserInfoService(applicationContext)
        settingInfoService = SettingInfoService(applicationContext)

        mainScope.launch {
            if (update && UpdateService.checkVersion()) {
                val intent = Intent(applicationContext, PatchActivity::class.java)
                startActivity(intent)
            }
        }


        checkLoginInfo()
        setSettingInfo()
        disableBluetooth()
    }

    override fun onResume() {
        super.onResume()

        Thread.setDefaultUncaughtExceptionHandler(ExceptionHandler(javaClass.simpleName))

        checkLoginInfo()
        setSettingInfo()
        disableBluetooth()
    }

    private fun checkLoginInfo() {
        io.launch {
            if (userInfoService.checkLoginState()) {
                val userInfo = userInfoService.selectUserInfo()

                if (userInfo != null) {
                    DeviceInfo.OPERATOR_ID = userInfo.operId
                    DeviceInfo.OPERATOR_NAME = userInfo.operName
                    DeviceInfo.PERMISSION = userInfo.permission
                }
            }
        }
    }

    private fun setSettingInfo() {
        io.launch {
            val settingInfo = settingInfoService.selectSettingInfo()

            if (settingInfo != null) {
                // set DeviceInfo
                DeviceInfo.FACILITY = settingInfo.facility
                DeviceInfo.AREA = settingInfo.area
                DeviceInfo.BAY = settingInfo.bay
                DeviceInfo.HISTORY_COUNT = settingInfo.historyCount.toString()
                DeviceInfo.FORWARD_COUNT = settingInfo.forwardCount.toString()
            }

            val bluetoothName = BluetoothAdapter.getDefaultAdapter()?.name.toString()
            DeviceInfo.DEVICE_NAME = bluetoothName.toUpperCase(Locale.ROOT)
        }
    }

    private fun disableBluetooth() {
        val mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if (mBluetoothAdapter != null && mBluetoothAdapter.isEnabled)
            mBluetoothAdapter.disable()
    }
}