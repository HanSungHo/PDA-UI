package com.keyfoundry.hifos.view.remote

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CompoundButton
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.widget.addTextChangedListener
import androidx.core.widget.doAfterTextChanged
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityRemoteImpBatchBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.RemoteRecipeDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.comment.CommentListActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RemoteImpBatchActivity : HFActivity() {
    private lateinit var viewBinding: ActivityRemoteImpBatchBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var searchOperation1 = ""
    private var searchSubOperation1 = ""
    private var searchOpType1 = ""
    private var searchProcessStep1 = ""
    private var searchOperSeq1 = ""

    private var searchOperation2 = ""
    private var searchSubOperation2 = ""
    private var searchOpType2 = ""
    private var searchProcessStep2 = ""
    private var searchOperSeq2 = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityRemoteImpBatchBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editLot2.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        initDisable()

        var lotId = ""
        var eqpId = ""

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true)
            lotId = intent.getStringExtra("LOTID").toString()

        if (intent.getStringExtra("EQPID")?.isNotEmpty() == true)
            eqpId = intent.getStringExtra("EQPID").toString()

        if (lotId.isNotEmpty() && eqpId.isNotEmpty()) {
            viewBinding.txtLot1.text = lotId
            viewBinding.txtIngMachine.text = eqpId
            setLotData1()
        }

        viewBinding.editLot2.requestFocus()
        viewBinding.editLot2.setOnEditorActionListener(editorActionListener)

        viewBinding.btnSearchPort1.setOnClickListener(onSingleClickListener)
        viewBinding.btnCommentRead1.setOnClickListener(onSingleClickListener)
        viewBinding.btnSearchPort2.setOnClickListener(onSingleClickListener)
        viewBinding.btnCommentRead2.setOnClickListener(onSingleClickListener)
        viewBinding.btnStart.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)

        viewBinding.chkCarry.setOnCheckedChangeListener(checkChangeListener)

        viewBinding.spinnerBay.onItemSelectedListener = itemSelectedListener

        // TxtEdit Event
        viewBinding.txtRecipe.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {}
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                memorizationRecipe()
            }
        })
    }

    private fun memorizationRecipe() {
        mainScope.launch {
            if (viewBinding.txtRecipe.text.isEmpty())
                return@launch

            val recipe = viewBinding.txtRecipe.text.toString()
            val lotId = viewBinding.txtLot1.text.toString()

            var portId = ""

            // 20210907 추가
            val chEqpId = viewBinding.txtIngMachine.text.toString()

            val sendMessage =
                MessageFactoryUtil.memorization(chEqpId, recipe, lotId, portId, chEqpId, "", "IMP")
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MEMORIZATION)
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val popUp = messageBody.optString("POPUP")

                if (popUp.isNotEmpty())
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
                        popUp, GetString.BTNOKSTR
                    )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)

                if (errorMessage == MessageSender.ERRORMSG_MSGBODY) {

                } else {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR
                    )
                    viewBinding.btnStart.isEnabled = false
                }
            }
        }
    }

    private fun initDisable() {
        viewBinding.btnCommentRead1.isEnabled = false
        viewBinding.btnCommentRead2.isEnabled = false
        viewBinding.spinnerBay.isEnabled = false
        viewBinding.spinnerStk.isEnabled = false
        viewBinding.btnStart.isEnabled = false
        viewBinding.btnSearchPort1.isEnabled = false
    }

    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerBay.id -> {
                        setStk()
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private val checkChangeListener =
        CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                viewBinding.spinnerBay.isEnabled = true
                viewBinding.spinnerStk.isEnabled = true

                setBay()
            } else {
                viewBinding.spinnerBay.adapter = null
                viewBinding.spinnerStk.adapter = null

                viewBinding.spinnerBay.isEnabled = false
                viewBinding.spinnerStk.isEnabled = false
            }
        }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchPort1.id -> {
                    setLotData1()
                }
                viewBinding.btnCommentRead1.id -> {
                    readComment1()
                }
                viewBinding.btnSearchPort2.id -> {
                    setLotData2()
                }
                viewBinding.btnCommentRead2.id -> {
                    readComment2()
                }
                viewBinding.btnStart.id -> {
                    executeRemoteStart()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    private val editorActionListener =
        TextView.OnEditorActionListener { v, actionId, event ->
            when (v.id) {
                viewBinding.editLot2.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        val check = BarcodeStyle(this).lotId(viewBinding.editLot2)

                        if (check)
                            setLotData2()
                    } else if (event != null) {
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            val check = BarcodeStyle(this).lotId(viewBinding.editLot2)

                            if (check)
                                setLotData2()
                        }
                    }
                }
            }

            true
        }

    private fun readComment1() {
        val nextIntent = Intent(this, CommentListActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.txtLot1.text.toString())
        nextIntent.putExtra("OPERATION", searchOperation1)
        nextIntent.putExtra("SUBOPERATION", searchSubOperation1)
        nextIntent.putExtra("PROCESSSTEP", searchProcessStep1)
        nextIntent.putExtra("OPERSEQUENCE", searchOperSeq1)
        startActivity(nextIntent)
    }

    private fun readComment2() {
        val nextIntent = Intent(this, CommentListActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.editLot2.text.toString())
        nextIntent.putExtra("OPERATION", searchOperation2)
        nextIntent.putExtra("SUBOPERATION", searchSubOperation2)
        nextIntent.putExtra("PROCESSSTEP", searchProcessStep2)
        nextIntent.putExtra("OPERSEQUENCE", searchOperSeq2)
        startActivity(nextIntent)
    }

    private fun setBay() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.areaBayInfo(DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.AREABAYINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val bays = ResponseDataToJsonUtil.getMessageBodyList(result, "BAYS")

                val bayList = arrayListOf<String>()
                for (count in 0 until bays.length())
                    bayList.add(bays.getJSONObject(count).optString("BAY"))

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, bayList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerBay.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setStk() {
        mainScope.launch {
            if (viewBinding.spinnerBay.selectedItem == null)
                return@launch

            val bay = viewBinding.spinnerBay.selectedItem.toString()
            val sendMessage = MessageFactoryUtil.bayStockerInfo(bay, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.BAYSTOCKERINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val bays = ResponseDataToJsonUtil.getMessageBodyList(result, "STOCKERS")

                val stkList = arrayListOf<String>()
                for (count in 0 until bays.length())
                    stkList.add(bays.getJSONObject(count).optString("STOCKER"))

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, stkList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerStk.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearLotData1() {
        viewBinding.txtProduct1.text = ""
        viewBinding.txtJobCode1.text = ""
        viewBinding.txtOperation1.text = ""
        viewBinding.txtQty1.text = ""

        viewBinding.btnCommentRead1.isEnabled = false
        viewBinding.btnStart.isEnabled = false

        searchOperation1 = ""
        searchSubOperation1 = ""
        searchProcessStep1 = ""
        searchOperSeq1 = ""
        searchOpType1 = ""

        viewBinding.txtRecipe.text = ""
    }

    private fun setLotData1() {
        mainScope.launch {
            clearLotData1()

            val lot1 = viewBinding.txtLot1.text.toString()
            val lot2 = viewBinding.editLot2.text.toString()

            if (lot1 == lot2) {
                val lotMsg = """
                    |동일 LOT으로 조회가 불가합니다.
                    |LOTNAME을 다시 확인해 주시기 바랍니다.
                """.trimMargin()
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    lotMsg, GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.lotInfo("MVIN", lot1, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val product = messageBody.optString("PRODUCT")
                val operation = messageBody.optString("OPERATION")
                val engineer = messageBody.optString("ENGINEER")
                val qty = messageBody.optString("QUANTITY")
                val recipe = messageBody.optString("RECIPE")
                val changeRecipe = messageBody.optString("CHANGERECIPE")
                val commentQty = messageBody.optString("COMMENTQTY")
                val nwCommentQty = messageBody.optString("NWCOMMENTQTY")
                val batchId = messageBody.optString("BATCHID")
                val area = messageBody.optString("AREA")
                val workedEqpId = messageBody.optString("WORKEDEQPID")
                val workedRecipe = messageBody.optString("WORKEDRECIPE")
                val jobCode = messageBody.optString("JOBCODE")
                val processStep = messageBody.optString("PROCESSSTEP")
                val subOperation = messageBody.optString("SUBOPERATION")
                val opType = messageBody.optString("OPTYPE")
                val status = messageBody.optString("STATUS")
                val state = messageBody.optString("STATE")
                val holdStatus = messageBody.optString("HOLDSTATUS")
                val operSeq = messageBody.optString("OPERSEQUENCE")
                val etcMsg = messageBody.optString("ETCMSG")
                val machineName = messageBody.optString("MACHINENAME")
                val portName = messageBody.optString("PORTNAME")
                val machineRecipeName = messageBody.optString("MACHINERECIPENAME")
                val lotResUser = messageBody.optString("LOTRESUSER")
                val skipAllowFlag =
                    messageBody.optString("SKIPALLOWFLAG")//---[Addition] Nov 22, 2007. by I. H. Lee

                if (status == "RUN") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 MOVE IN된 LOT입니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (state != "WIP") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "$state 상태 입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (holdStatus == "ONHOLD") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "HOLD된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (batchId.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "BATCHID가 설정된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (area != "IMP") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "IMP공정이 아닙니다. LOT을 확인 후 진행 바랍니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (lotResUser.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 작업 예약되었거나 진행중인 LOT입니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                val operationValue = "$operation-$subOperation"

                viewBinding.txtProduct1.text = product
                viewBinding.txtJobCode1.text = jobCode
                viewBinding.txtOperation1.text = operationValue
                viewBinding.txtQty1.text = qty

                viewBinding.btnCommentRead1.isEnabled = true
                viewBinding.btnStart.isEnabled = true

                searchOperation1 = operation
                searchSubOperation1 = subOperation
                searchProcessStep1 = processStep
                searchOperSeq1 = operSeq
                searchOpType1 = opType

                if (nwCommentQty.isNotEmpty() && nwCommentQty.toInt() > 0) {
                    val commentMsg = """
                        |읽지 않은 작업성 COMMENT가 [$nwCommentQty]가 있습니다.
                        |읽은후 진행하세요.
                    """.trimMargin()
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                        commentMsg, GetString.BTNOKSTR
                    )
                }

                getRecipeInfo()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private suspend fun getRecipeInfo() {
        val lotId = viewBinding.txtLot1.text.toString()
        val operation = searchOperation1
        val subOperation = searchSubOperation1
        val product = viewBinding.txtProduct1.text.toString()
        val eqpId = viewBinding.txtIngMachine.text.toString()
        val opType = searchOpType1

        val sendMessage = MessageFactoryUtil.recipeInfo(
            "N", lotId, operation, subOperation, product, eqpId, opType, DeviceInfo.FACILITY
        )
        val message =
            MessageSender.send(supportFragmentManager, sendMessage, MessageName.RECIPEINFO)
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val recipe = messageBody.optString("RECIPE")

            viewBinding.txtRecipe.text = recipe

            viewBinding.editLot2.requestFocus()
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )
        }
    }

    private fun clearLotData2() {
        viewBinding.txtProduct2.text = ""
        viewBinding.txtJobCode2.text = ""
        viewBinding.txtOperation2.text = ""
        viewBinding.txtQty2.text = ""

        viewBinding.btnCommentRead2.isEnabled = false
        viewBinding.btnStart.isEnabled = false

        searchOperation2 = ""
        searchSubOperation2 = ""
        searchProcessStep2 = ""
        searchOperSeq2 = ""
        searchOpType2 = ""
    }

    private fun setLotData2() {
        mainScope.launch {
            clearLotData2()

            if (viewBinding.editLot2.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT ID를 입력하세요", GetString.BTNOKSTR
                )
                return@launch
            }

            val lot1 = viewBinding.txtLot1.text.toString()
            val lot2 = viewBinding.editLot2.text.toString()

            if (lot1 == lot2) {
                val errorMsg = """
                    |동일 LOT으로 조회가 불가합니다.
                    |LOTNAME을 다시 확인해 주시기 바랍니다.
                """.trimMargin()
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMsg, GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.lotInfo("MVIN", lot2, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val product = messageBody.optString("PRODUCT")
                val operation = messageBody.optString("OPERATION")
                val engineer = messageBody.optString("ENGINEER")
                val qty = messageBody.optString("QUANTITY")
                val recipe = messageBody.optString("RECIPE")
                val changeRecipe = messageBody.optString("CHANGERECIPE")
                val commentQty = messageBody.optString("COMMENTQTY")
                val nwCommentQty = messageBody.optString("NWCOMMENTQTY")
                val batchId = messageBody.optString("BATCHID")
                val area = messageBody.optString("AREA")
                val workedEqpId = messageBody.optString("WORKEDEQPID")
                val workedRecipe = messageBody.optString("WORKEDRECIPE")
                val jobCode = messageBody.optString("JOBCODE")
                val processStep = messageBody.optString("PROCESSSTEP")
                val subOperation = messageBody.optString("SUBOPERATION")
                val opType = messageBody.optString("OPTYPE")
                val status = messageBody.optString("STATUS")
                val state = messageBody.optString("STATE")
                val holdStatus = messageBody.optString("HOLDSTATUS")
                val operSeq = messageBody.optString("OPERSEQUENCE")
                val etcMsg = messageBody.optString("ETCMSG")
                val machineName = messageBody.optString("MACHINENAME")
                val portName = messageBody.optString("PORTNAME")
                val machineRecipeName = messageBody.optString("MACHINERECIPENAME")
                val lotResUser = messageBody.optString("LOTRESUSER")
                val skipAllowFlag =
                    messageBody.optString("SKIPALLOWFLAG")//---[Addition] Nov 22, 2007. by I. H. Lee

                if (status == "RUN") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 MOVE IN된 LOT입니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (state != "WIP") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "$state 상태 입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (holdStatus == "ONHOLD") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "HOLD된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (batchId.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "BATCHID가 설정된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (area != "IMP") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "IMP공정이 아닙니다. LOT을 확인 후 진행 바랍니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (lotResUser.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 작업 예약되었거나 진행중인 LOT입니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                val operationValue = "$operation-$subOperation"

                //m_sCommentCnt = sCommentQty;
                //m_sArea = sArea;
                //m_sOpType = sOpType;

                viewBinding.txtProduct2.text = product
                viewBinding.txtJobCode2.text = jobCode
                viewBinding.txtOperation2.text = operationValue
                viewBinding.txtQty2.text = qty

                viewBinding.btnCommentRead2.isEnabled = true
                viewBinding.btnStart.isEnabled = true

                searchOperation2 = operation
                searchSubOperation2 = subOperation
                searchProcessStep2 = processStep
                searchOperSeq2 = operSeq
                searchOpType2 = opType

                if (nwCommentQty.isNotEmpty() && nwCommentQty.toInt() > 0) {
                    val commentMsg = """
                        |읽지 않은 작업성 COMMENT가 [$nwCommentQty]가 있습니다.
                        |읽은후 진행하세요.
                    """.trimMargin()
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                        commentMsg, GetString.BTNOKSTR
                    )
                }

                checkRecipeInfo()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editLot2.setText("")
                viewBinding.txtProduct2.text = ""
                viewBinding.txtJobCode2.text = ""
                viewBinding.txtOperation2.text = ""
                viewBinding.txtQty2.text = ""
                viewBinding.btnCommentRead2.isEnabled = false
            }
        }
    }

    private suspend fun checkRecipeInfo() {
        val lotId = viewBinding.editLot2.text.toString()
        val operation = searchOperation2
        val subOperation = searchSubOperation2
        val product = viewBinding.txtProduct2.text.toString()
        val eqpId = viewBinding.txtIngMachine.text.toString()
        val opType = searchOpType2

        val sendMessage = MessageFactoryUtil.recipeInfo(
            "N", lotId, operation, subOperation, product, eqpId, opType, DeviceInfo.FACILITY
        )
        val message =
            MessageSender.send(supportFragmentManager, sendMessage, MessageName.RECIPEINFO)
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val recipe = messageBody.optString("RECIPE")

            if (viewBinding.txtRecipe.text.toString() != recipe) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "RECIPE가 다른 LOT입니다.", GetString.BTNOKSTR
                )

                viewBinding.txtProduct2.text = ""
                viewBinding.txtJobCode2.text = ""
                viewBinding.txtOperation2.text = ""
                viewBinding.txtQty2.text = ""
                viewBinding.btnStart.isEnabled = false
                viewBinding.btnCommentRead2.isEnabled = false
                viewBinding.editLot2.requestFocus()
            }
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )

            viewBinding.txtProduct2.text = ""
            viewBinding.txtJobCode2.text = ""
            viewBinding.txtOperation2.text = ""
            viewBinding.txtQty2.text = ""
            viewBinding.btnStart.isEnabled = false
            viewBinding.btnCommentRead2.isEnabled = false
            viewBinding.editLot2.requestFocus()
        }
    }

    private fun executeRemoteStart() {
        mainScope.launch {
            if (viewBinding.txtIngMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행장비를 입력하세요.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.txtRecipe.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행Rcp가 조회되지 않았습니다.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.txtLot1.text.isEmpty() || viewBinding.editLot2.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행할 LOT을 다시 조회 바랍니다.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.txtOperation1.text.isEmpty() || viewBinding.txtOperation2.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT 조회가 정상적으로 이루어 지지 않았습니다.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.chkCarry.isChecked) {
                if (viewBinding.spinnerBay.selectedItem == null) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "BAY를 선택하세요.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (viewBinding.spinnerStk.selectedItem == null) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "STOCKER를 선택하세요.", GetString.BTNOKSTR
                    )

                    return@launch
                }
            }

            if (!checkComment(viewBinding.txtLot1.text.toString()))
                return@launch

            if (!checkComment(viewBinding.editLot2.text.toString()))
                return@launch

            val recipeIntent = Intent(this@RemoteImpBatchActivity, RemoteRecipeDialog::class.java)
            recipeIntent.putExtra(
                RemoteRecipeDialog.RECIPE_LIST, viewBinding.txtRecipe.text.toString()
            )
            activityRecipeResultLauncher.launch(recipeIntent)
        }
    }

    private val activityRecipeResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                execute()
            }
        }

    private fun execute() {
        mainScope.launch {
            val lotName1 = viewBinding.txtLot1.text.toString()
            val lotName2 = viewBinding.editLot2.text.toString()
            val machineName = viewBinding.txtIngMachine.text.toString()
            val machineType = ""
            val recipeName = viewBinding.txtRecipe.text.toString()

            val isCarry: String
            val bay: String
            val stocker: String

            if (viewBinding.chkCarry.isChecked) {
                isCarry = "Y"
                bay = viewBinding.spinnerBay.selectedItem.toString()
                stocker = viewBinding.spinnerStk.selectedItem.toString()
            } else {
                isCarry = "N"
                bay = ""
                stocker = ""
            }

            //m_sCommentCnt = sCommentQty;
            //m_sArea = sArea;
            //m_sOpType = sOpType;

            val eventUser = DeviceInfo.OPERATOR_ID
            val productName1 = viewBinding.txtProduct1.text.toString()
            val productName2 = viewBinding.txtProduct2.text.toString()
            val operation1 = viewBinding.txtOperation1.text.toString()
            val operation2 = viewBinding.txtOperation2.text.toString()
            val jobCode1 = viewBinding.txtJobCode1.text.toString()
            val jobCode2 = viewBinding.txtJobCode2.text.toString()

            val sendMessage = MessageFactoryUtil.impBatchRemoteStart(
                lotName1, lotName2, machineName, machineType,
                recipeName, isCarry, bay, stocker,
                eventUser, productName1, productName2, operation1,
                operation2, jobCode1, jobCode2
            )
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.IMPBATCHREMOTESTART
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                setResult(RESULT_OK)
                finish()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private suspend fun checkComment(lotId: String): Boolean {
        val sendMessage = MessageFactoryUtil.lotInfo("MVIN", lotId, DeviceInfo.FACILITY)
        val message = MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val nwCommentQty = messageBody.optString("NWCOMMENTQTY")

            if (nwCommentQty.isNotEmpty() && nwCommentQty.toInt() > 0) {
                val commentMsg = """
                    |LOT[$lotId]에 읽지 않은 작업성 COMMENT가 [$nwCommentQty]가 있습니다.
                    |읽은후 진행하세요.
                """.trimMargin()
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    commentMsg, GetString.BTNOKSTR
                )

                return false
            } else {
                return true
            }

        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )

            return false
        }
    }
}