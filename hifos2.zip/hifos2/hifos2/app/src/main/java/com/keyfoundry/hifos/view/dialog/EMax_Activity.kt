package com.keyfoundry.hifos.view.dialog

import android.os.Bundle
import android.view.View
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivityEmaxBinding

class EMax_Activity : HFActivity() {
    init {
        this.update = false
    }

    private lateinit var viewBinding: ActivityEmaxBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_emax)

        viewBinding = ActivityEmaxBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        val receiverMessage = intent.getStringExtra(DeviceInfo.UDP_RECEIVER_MESSAGE)

        if (receiverMessage != null) if (receiverMessage.contains("INTERLOCKMANAGER")) {
            val new_receiverMessage = arrayOf(receiverMessage?.split("<Table diffgr:")) // receiverMessage 잘라서 배열에 담기

            for (data in 1 until new_receiverMessage[0].size)
            {
                val arry_receiverMessage = arrayOf(new_receiverMessage[0][data]?.split("</")) // receiverMessage 잘라서 배열에 담기
                val sTime = arry_receiverMessage[0]!![0].substring(arry_receiverMessage[0]!![0].lastIndexOf(">") + 1)
                val sDesc = arry_receiverMessage[0]!![23].substring(arry_receiverMessage[0]!![23].lastIndexOf(">") + 1)

                if (sTime > 0.toString())
                {
                    val sTime = sTime.substringBefore("+").replace("T"," ")
                    viewBinding.txtReceiverTimeResult.append("$sTime")
                }


                if (sDesc > 0.toString())
                    viewBinding.txtReceiverComment.append("\n$sDesc\n")
            }
        }

        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
            }
        })
    }
}