package com.keyfoundry.hifos.view.remote

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Vibrator
import android.text.InputFilter
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityRemoteRamcoBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.RemoteRecipeDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDailogAlram
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.comment.CommentListActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RemoteRamcoActivity : HFActivity() {
    companion object {
        private const val TAG = "AutomationActivity"
    }

    lateinit var viewBinding: ActivityRemoteRamcoBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var searchOperSeqFront = ""
    private var searchOperationFront = ""
    private var searchSubOperationFront = ""
    private var searchProcessStepFront = ""
    private var searchOpTypeFront = ""

    private var searchOperSeqRear = ""
    private var searchOperationRear = ""
    private var searchSubOperationRear = ""
    private var searchProcessStepRear = ""
    private var searchOpTypeRear = ""

    private var searchJobID = ""
    private var searchMainEqpID = ""
    private var searchEqpType = ""
    private var searchEqpArea = ""
    private var searchIngRCP = ""
    private var searchIngRCP2 = ""
    private var searchNumCst = ""

    private var job1 = ""
    private var job2 = ""
    private var scrubber = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityRemoteRamcoBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        initDisable()

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()

            viewBinding.txtLotNoFront.text = lotId
            setLotInfoFront()
        }

        //소문자 -> 대문자
        viewBinding.editMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editLotNoRear.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        viewBinding.editMachine.setOnEditorActionListener(editorActionListener)
        viewBinding.editLotNoRear.setOnEditorActionListener(editorActionListener)

        viewBinding.btnClearPort.setOnClickListener(onSingleClickListener)
        viewBinding.btnSearchIngMachine.setOnClickListener(onSingleClickListener)
        viewBinding.btnDeleteJobCode.setOnClickListener(onSingleClickListener)
        viewBinding.btnSearchLotFront.setOnClickListener(onSingleClickListener)
        viewBinding.btnReadCommentFront.setOnClickListener(onSingleClickListener)
        viewBinding.btnSearchLotRear.setOnClickListener(onSingleClickListener)
        viewBinding.btnReadCommentRear.setOnClickListener(onSingleClickListener)
        viewBinding.btnStart.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)

        viewBinding.spinnerPort.onItemSelectedListener = itemSelectedListener
    }

    private fun initDisable() {
        viewBinding.btnReadCommentFront.isEnabled = false
        viewBinding.btnReadCommentRear.isEnabled = false
        viewBinding.editLotNoRear.isEnabled = false
        viewBinding.btnStart.isEnabled = false

        viewBinding.layoutIng.visibility = View.GONE
        viewBinding.layoutLu.visibility = View.GONE
    }

    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerPort.id -> {
                        setPortState()
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchIngMachine.id -> {
                    secondCheck(viewBinding.editMachine.text.toString())
                    setEqpInfo()
                }
                viewBinding.btnDeleteJobCode.id -> {
                    deleteJobCode()
                }
                viewBinding.btnSearchLotFront.id -> {
                    setLotInfoFront()
                }
                viewBinding.btnReadCommentFront.id -> {
                    readCommentFront()
                }
                viewBinding.btnSearchLotRear.id -> {
                    setLotInfoRear()
                }
                viewBinding.btnReadCommentRear.id -> {
                    readCommentRear()
                }
                viewBinding.btnStart.id -> {
                    executeRemoteStart()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
                viewBinding.btnClearPort.id -> {
                    executeClearPort()
                }
            }
        }
    }

    private val editorActionListener =
        TextView.OnEditorActionListener { v, actionId, event ->
            when (v.id) {
                viewBinding.editMachine.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        val check = BarcodeStyle(this).eqpId(viewBinding.editMachine)

                        if (check) {
                            secondCheck(viewBinding.editMachine.text.toString())
                            setEqpInfo()
                        }
                    } else if (event != null) {
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            val check = BarcodeStyle(this).eqpId(viewBinding.editMachine)

                            if (check) {
                                secondCheck(viewBinding.editMachine.text.toString())
                                setEqpInfo()
                            }
                        }
                    }
                }
                viewBinding.editLotNoRear.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        val check = BarcodeStyle(this).lotId(viewBinding.editLotNoRear)

                        if (check)
                            setLotInfoRear()
                    } else if (event != null) {
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            val check = BarcodeStyle(this).lotId(viewBinding.editLotNoRear)

                            if (check)
                                setLotInfoRear()
                        }
                    }
                }
            }

            true
        }

    private fun clearEqpInfo() {
        searchMainEqpID = ""
        searchEqpType = ""
        searchEqpArea = ""
        searchJobID = ""
        searchNumCst = ""
        searchIngRCP = ""
        searchIngRCP2 = ""

        viewBinding.txtIngRcpL.text = ""
        viewBinding.txtIngRcpU.text = ""
        viewBinding.txtDateL.text = ""
        viewBinding.txtDateU.text = ""
        //viewBinding.txtRecipe.text = ""
        viewBinding.spinnerRecipe.adapter = null

        viewBinding.layoutIng.visibility = View.GONE
        viewBinding.layoutLu.visibility = View.GONE
    }

    private fun secondCheck(eqpId: String) {
        var checkCount = 0
        scrubber = ""

        for (count in eqpId.indices) {
            if (eqpId[count] == '-')
                checkCount++
        }

        if (checkCount == 2 && eqpId != "RD-51-05" && eqpId != "R-6-1" && eqpId != "R-67-1") {
            scrubber = eqpId.substring(eqpId.length - 1, eqpId.length)
            val tempEqpId = eqpId.substring(0, eqpId.length - 2)
            viewBinding.editMachine.setText(tempEqpId)
        }
    }

    private fun setEqpInfo() {
        mainScope.launch {
            clearEqpInfo()

            if (viewBinding.editMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "장비명을 입력하여 주세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage =
                MessageFactoryUtil.wetRemoteEqpInfo(viewBinding.editMachine.text.toString())
            val message =
                MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.WETREMOTEEQPINFO
                )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val mainEqpId = messageBody.optString("MAINEQPID")
                val jobId = messageBody.optString("JOBID")
                val pCount = messageBody.optString("PCOUNT")
                val jobCnt = messageBody.optString("CNT")
                // [ uk 201805 ]
                val eqpType = messageBody.optString("EQPTYPE")
                val eqpArea = messageBody.optString("EQPAREA")
                val ingRCP = messageBody.optString("INGRCP")
                val ingRCP2 = messageBody.optString("INGRCP2")
                val endL = messageBody.optString("COM_TIME1")
                val endU = messageBody.optString("COM_TIME2")
                val numCst = messageBody.optString("NUMCST")
                //2015.06.01 장비 PM 주기 체크 수정
                val pmMessage = messageBody.optString("PMMESSAGE")
                val reComm3 = messageBody.optString("RECOMM3")

                searchMainEqpID = mainEqpId
                searchEqpType = eqpType
                searchEqpArea = eqpArea
                searchJobID = jobId
                searchNumCst = numCst
                searchIngRCP = ingRCP
                searchIngRCP2 = ingRCP2

                if (pmMessage.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, "경고", pmMessage, GetString.BTNOKSTR
                    )
                }

                setRecipeInfo()

                if (eqpType == "ULTIMA3") {
                    viewBinding.layoutIng.visibility = View.GONE
                    viewBinding.layoutLu.visibility = View.VISIBLE
                    viewBinding.layoutLu1.visibility = View.GONE
                    viewBinding.layoutLu2.visibility = View.GONE
                    viewBinding.spinnerPort.isEnabled = true
                    val sPORTNAME = messageBody.optString("PORTNAME")

                    var portList = sPORTNAME.split(",")
                    val spinnerAdapter = ArrayAdapter(
                        applicationContext, R.layout.contact_spinner_row_init, portList
                    )
                    spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                    viewBinding.spinnerPort.adapter = InitSpinnerAdapter(
                        spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                    )

                    if (scrubber.isNotEmpty()) {
                        if (portList.contains(scrubber)) {
                            val position = portList.indexOf(scrubber)
                            viewBinding.spinnerPort.setSelection(position + 1, false)
                        }
                    }
                    else {
                        viewBinding.spinnerPort.setSelection(1, false)
                    }
                    viewBinding.txtIngRcp.text = ingRCP
                    viewBinding.txtIngRcpL.text = ingRCP
                    viewBinding.txtIngRcpU.text = ingRCP2
                    viewBinding.txtDateL.text = endL
                    viewBinding.txtDateU.text = endU

                    if (reComm3.isNotEmpty()) {
                        OkDialog.show(
                            supportFragmentManager, "추천", reComm3, GetString.BTNOKSTR
                        )
                    }
                }
                else if (eqpType == "RAM8500z") {
                    val sPORTNAME = messageBody.optString("PORTNAME")
                    if(!sPORTNAME.isEmpty()) {
                        viewBinding.layoutLu.visibility = View.VISIBLE
                        viewBinding.layoutLu1.visibility = View.GONE
                        viewBinding.layoutLu2.visibility = View.GONE

                        var portList = sPORTNAME.split(",")
                        val spinnerAdapter = ArrayAdapter(
                            applicationContext, R.layout.contact_spinner_row_init, portList
                        )
                        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                        viewBinding.spinnerPort.adapter = InitSpinnerAdapter(
                            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                        )
                        viewBinding.spinnerPort.setSelection(1, false)
                    }

                    if (ingRCP.isNullOrEmpty()) {
                        viewBinding.layoutIng.visibility = View.GONE
                    } else {
                        viewBinding.layoutIng.visibility = View.VISIBLE
                        viewBinding.txtIngRcp.text = ingRCP
                    }
                }
                else {
                    viewBinding.layoutLu.visibility = View.GONE

                    if (ingRCP.isNullOrEmpty()) {
                        viewBinding.layoutIng.visibility = View.GONE
                    } else {
                        viewBinding.layoutIng.visibility = View.VISIBLE
                        viewBinding.txtIngRcp.text = ingRCP
                    }
                }

                if (pCount == "N") {
                    OkDialog.show(
                        supportFragmentManager, GetString.ERRMSG,
                        "진행중인 LOT이 있어 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editLotNoRear.isEnabled = false
            }
        }
    }

    private suspend fun setRecipeInfo() {
        //viewBinding.txtRecipe.text = ""

        val lotId = viewBinding.txtLotNoFront.text.toString()
        val operation = searchOperationFront
        val subOperation = searchSubOperationFront
        val product = viewBinding.txtProductFront.text.toString().split("(")[0].trim()
        val eqpId = searchMainEqpID
        val opType = searchOpTypeFront
        val chmEqpIdC =viewBinding.editMachine.text.toString()

        val sendMessage = MessageFactoryUtil.recipeInfo_ASH(
            "N", lotId, operation, subOperation, product, eqpId, opType, DeviceInfo.FACILITY,chmEqpIdC
        )
        val message =
            MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.RECIPEINFO
            )
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val searchRecipe = messageBody.optString("RECIPE")
            val sPOP_MSG = messageBody.optString("POP_MSG")
            val qTimeFlag = messageBody.optString("QTIME_FLAG")
            val qTimeFlag_W = messageBody.optString("QTIME_FLAG_W")

            if (sPOP_MSG.isNotEmpty()) {
                OkDialog.show(
                    supportFragmentManager, "경고", sPOP_MSG, GetString.BTNOKSTR
                )
            }

            val index = searchRecipe.lastIndexOf("(")
            var recipe = searchRecipe

            if(searchEqpType == "KAIJO" ||searchEqpType == "UW8000" )
            {}
            else {
                if (index > -1)
                    recipe = searchRecipe.substring(0, index)
                if (searchEqpType == "DES220" && recipe.replace("#", "").length == 1)
                    recipe = "#0" + recipe.replace("#", "");
            }

            if(recipe.contains(":"))
            {
                val headRecipeName: String
                var tempRecipeName: String
                val checkIdx: Int
                val lastIndex = recipe.lastIndexOf(":")
                checkIdx = recipe.lastIndexOf(":")

                headRecipeName = recipe.substring(0, lastIndex + 1)
                tempRecipeName = recipe.substring(lastIndex + 1, recipe.length)

                recipe = "";
                val tempRecipeList = tempRecipeName.split(",")
                for (tempRecipe in tempRecipeList) {
                    if(!recipe.isEmpty())
                        recipe += ";"
                    recipe += headRecipeName + tempRecipe
                }
            }
            //viewBinding.txtRecipe.text = recipe

            val spinnerAdapter = ArrayAdapter(
                applicationContext, R.layout.contact_spinner_row_init,
                recipe.split(";")
            )
            spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
            viewBinding.spinnerRecipe.adapter = InitSpinnerAdapter(
                spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
            )
            viewBinding.spinnerRecipe.setSelection(1, false)

            //GetDlgItem(IDC_EDIT_LOT_NO1)->EnableWindow(TRUE);
            viewBinding.editLotNoRear.isEnabled = true
            viewBinding.editLotNoRear.requestFocus()
            if(searchEqpType != "RAM8500z")
                viewBinding.btnStart.isEnabled = true

            if(qTimeFlag.isNotEmpty())
            {   // 26.09.23 q-time over 시 팝업 문구 후 처리
                OkDialog.show(
                    supportFragmentManager, "Q-Time Over",
                    "Q-Time 초과 대상 Lot 입니다", GetString.BTNOKSTR
                )
            }
            else if(qTimeFlag_W.isNotEmpty())
            {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_WARNING,
                    "Q-Time 2hr 이내 근접 Lot 입니다", GetString.BTNOKSTR
                )
            }

        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )
        }
    }

    private fun clearLotInfoFront() {
        viewBinding.txtProductFront.text = ""
        viewBinding.txtOperationFront.text = ""
        viewBinding.txtQtyFront.text = ""

        searchOperSeqFront = ""
        searchOperationFront = ""
        searchSubOperationFront = ""
        searchProcessStepFront = ""
        searchOpTypeFront = ""

        viewBinding.btnReadCommentFront.isEnabled = false
        viewBinding.btnStart.isEnabled = false
    }

    private fun setLotInfoFront() {
        mainScope.launch {
            clearLotInfoFront()

            val frontLot = viewBinding.txtLotNoFront.text.toString()
            val rearLot = viewBinding.editLotNoRear.text.toString()

            if (frontLot == rearLot) {
                val lotMsg = """
                    |동일 LOT으로 조회가 불가합니다.
                    |LOTNAME을 다시 확인해 주시기 바랍니다.
                """.trimMargin()
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    lotMsg, GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.lotInfo("MVIN", frontLot, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val product = messageBody.optString("PRODUCT")
                val operation = messageBody.optString("OPERATION")
                val engineer = messageBody.optString("ENGINEER")
                val qty = messageBody.optString("QUANTITY")
                val recipe = messageBody.optString("RECIPE")
                val changeRecipe = messageBody.optString("CHANGERECIPE")
                val commentQty = messageBody.optString("COMMENTQTY")
                val nwCommentQty = messageBody.optString("NWCOMMENTQTY")
                val batchId = messageBody.optString("BATCHID")
                val area = messageBody.optString("AREA")
                val workedEqpId = messageBody.optString("WORKEDEQPID")
                val workedRecipe = messageBody.optString("WORKEDRECIPE")
                val jobCode = messageBody.optString("JOBCODE")
                val processStep = messageBody.optString("PROCESSSTEP")
                val subOperation = messageBody.optString("SUBOPERATION")
                val opType = messageBody.optString("OPTYPE")
                val status = messageBody.optString("STATUS")
                val state = messageBody.optString("STATE")
                val holdStatus = messageBody.optString("HOLDSTATUS")
                val operSeq = messageBody.optString("OPERSEQUENCE")
                val etcMsg = messageBody.optString("ETCMSG")
                val machineName = messageBody.optString("MACHINENAME")
                val portName = messageBody.optString("PORTNAME")
                val machineRecipeName = messageBody.optString("MACHINERECIPENAME")
                val lotResUser = messageBody.optString("LOTRESUSER")
                val skipAllowFlag =
                    messageBody.optString("SKIPALLOWFLAG")//---[Addition] Nov 22, 2007. by I. H. Lee

                if (status == "RUN") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 MOVE IN된 LOT입니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (state != "WIP") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "$state 상태 입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (holdStatus == "ONHOLD") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "HOLD된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (batchId.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "BATCHID가 설정된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (area == "PHOTO") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "PHOTO진행 LOT입니다. PHOTO 자동화 기능을 이용해 주세요.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (lotResUser.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 작업 예약되었거나 진행중인 LOT입니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                val prodFront = "$product ($jobCode)"
                val operFront = "$operation-$subOperation"

                //m_sCommentCnt = sCommentQty;
                //m_sArea = sArea;
                //m_sOpType = sOpType;

                viewBinding.txtProductFront.text = prodFront
//                viewBinding.txtOperationFront.text = operFront
                viewBinding.txtOperationFront.text = operFront + "("+processStep+")"
                viewBinding.txtQtyFront.text = qty

                searchOperSeqFront = operSeq
                searchOperationFront = operation
                searchSubOperationFront = subOperation
                searchProcessStepFront = processStep
                searchOpTypeFront = opType

                viewBinding.btnReadCommentFront.isEnabled = true
                if(searchEqpType != "RAM8500z")
                    viewBinding.btnStart.isEnabled = true

                if (nwCommentQty.isNotEmpty() && nwCommentQty.toInt() > 0) {
                    val commentMsg = """
                        |읽지 않은 작업성 COMMENT가 [$nwCommentQty]가 있습니다.
                        |읽은후 진행하세요.
                    """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        commentMsg, GetString.BTNOKSTR
                    )
                }

                viewBinding.editLotNoRear.isEnabled = true
                viewBinding.editMachine.requestFocus()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearLotInfoRear() {
        viewBinding.txtProductRear.text = ""
        viewBinding.txtOperationRear.text = ""
        viewBinding.txtQtyRear.text = ""

        searchOperSeqRear = ""
        searchOperationRear = ""
        searchSubOperationRear = ""
        searchOpTypeRear = ""
        searchProcessStepRear = ""

        viewBinding.btnReadCommentRear.isEnabled = false
        if(searchEqpType != "RAM8500z")
            viewBinding.btnStart.isEnabled = false
    }

    private fun setLotInfoRear() {
        mainScope.launch {
            clearLotInfoRear()

            if (viewBinding.txtLotNoFront.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "FRONT 진행 LOT 부터 순서대로 조회하시기 바랍니다.", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.editLotNoRear.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT ID를 입력하세요", GetString.BTNOKSTR
                )
                return@launch
            }

            val frontLot = viewBinding.txtLotNoFront.text.toString()
            val rearLot = viewBinding.editLotNoRear.text.toString()

            if (frontLot == rearLot) {
                val lotMsg = """
                    |동일 LOT으로 조회가 불가합니다.
                    |LOTNAME을 다시 확인해 주시기 바랍니다.
                """.trimMargin()
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    lotMsg, GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.lotInfo("MVIN", rearLot, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val product = messageBody.optString("PRODUCT")
                val operation = messageBody.optString("OPERATION")
                val engineer = messageBody.optString("ENGINEER")
                val qty = messageBody.optString("QUANTITY")
                val recipe = messageBody.optString("RECIPE")
                val changeRecipe = messageBody.optString("CHANGERECIPE")
                val commentQty = messageBody.optString("COMMENTQTY")
                val nwCommentQty = messageBody.optString("NWCOMMENTQTY")
                val batchId = messageBody.optString("BATCHID")
                val area = messageBody.optString("AREA")
                val workedEqpId = messageBody.optString("WORKEDEQPID")
                val workedRecipe = messageBody.optString("WORKEDRECIPE")
                val jobCode = messageBody.optString("JOBCODE")
                val processStep = messageBody.optString("PROCESSSTEP")
                val subOperation = messageBody.optString("SUBOPERATION")
                val opType = messageBody.optString("OPTYPE")
                val status = messageBody.optString("STATUS")
                val state = messageBody.optString("STATE")
                val holdStatus = messageBody.optString("HOLDSTATUS")
                val operSeq = messageBody.optString("OPERSEQUENCE")
                val etcMsg = messageBody.optString("ETCMSG")
                val machineName = messageBody.optString("MACHINENAME")
                val portName = messageBody.optString("PORTNAME")
                val machineRecipeName = messageBody.optString("MACHINERECIPENAME")
                val lotResUser = messageBody.optString("LOTRESUSER")
                val skipAllowFlag =
                    messageBody.optString("SKIPALLOWFLAG")//---[Addition] Nov 22, 2007. by I. H. Lee

                if (status == "RUN") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 MOVE IN된 LOT입니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (state != "WIP") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "$state 상태 입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (holdStatus == "ONHOLD") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "HOLD된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (batchId.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "BATCHID가 설정된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (area == "PHOTO") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "PHOTO진행 LOT입니다. PHOTO 자동화 기능을 이용해 주세요.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (lotResUser.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 작업 예약되었거나 진행중인 LOT입니다.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                val prodRear = "$product ($jobCode)"
                val operRear = "$operation-$subOperation"

                viewBinding.txtProductRear.text = prodRear
                //viewBinding.txtOperationRear.text = operRear
                viewBinding.txtOperationRear.text = operRear + "("+processStep+")"
                viewBinding.txtQtyRear.text = qty

                searchOperSeqRear = operSeq
                searchOperationRear = operation
                searchSubOperationRear = subOperation
                searchOpTypeRear = opType
                searchProcessStepRear = processStep

                viewBinding.btnReadCommentRear.isEnabled = true
                if(searchEqpType != "RAM8500z")
                    viewBinding.btnStart.isEnabled = true

                if (nwCommentQty.isNotEmpty() && nwCommentQty.toInt() > 0) {
                    val commentMsg = """
                        |읽지 않은 작업성 COMMENT가 [$nwCommentQty]가 있습니다.
                        |읽은후 진행하세요.
                    """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        commentMsg, GetString.BTNOKSTR
                    )
                }

                if (!checkRecipe())
                    return@launch

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.txtProductRear.text = ""
                viewBinding.txtOperationRear.text = ""
                viewBinding.txtQtyRear.text = ""
                viewBinding.editLotNoRear.requestFocus()
                viewBinding.editLotNoRear.selectAll()
                viewBinding.btnReadCommentRear.isEnabled = false
                viewBinding.btnStart.isEnabled = false
            }
        }
    }

    private suspend fun checkRecipe(): Boolean {
        val lotId = viewBinding.editLotNoRear.text.toString()
        val operation = searchOperationRear
        val subOperation = searchSubOperationRear
        val product = viewBinding.txtProductRear.text.toString().split("(")[0].trim()
        val eqpId = searchMainEqpID
        val opType = searchOpTypeRear

        val sendMessage = MessageFactoryUtil.recipeInfo(
            "N", lotId, operation, subOperation, product, eqpId, opType, DeviceInfo.FACILITY
        )
        val message =
            MessageSender.send(supportFragmentManager, sendMessage, MessageName.RECIPEINFO)
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val searchRecipe = messageBody.optString("RECIPE")
            val qTimeFlag = messageBody.optString("QTIME_FLAG")
            val qTimeFlag_W = messageBody.optString("QTIME_FLAG_W")
            var recipe = searchRecipe

            if(searchEqpType == "KAIJO" ||searchEqpType == "UW8000"  )
            {}
            else {
                val index = searchRecipe.lastIndexOf("(")

                if (index > -1)
                    recipe = searchRecipe.substring(0, index)
                if (searchEqpType == "DES220" && recipe.replace("#", "").length == 1)
                    recipe = "#0" + recipe.replace("#", "");
            }
//            if (viewBinding.txtRecipe.text != recipe) {

            if(!viewBinding.spinnerRecipe.selectedItem.toString().contains(":")) {
                if (viewBinding.spinnerRecipe.selectedItem.toString() != recipe) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "RECIPE가 다른 LOT입니다.", GetString.BTNOKSTR
                    )

                    viewBinding.txtProductRear.text = ""
                    viewBinding.txtOperationRear.text = ""
                    viewBinding.txtQtyRear.text = ""
                    viewBinding.editLotNoRear.requestFocus()
                    viewBinding.editLotNoRear.selectAll()
                    viewBinding.btnReadCommentRear.isEnabled = false
                    viewBinding.btnStart.isEnabled = false
                    return false
                }
            }

            if(qTimeFlag.isNotEmpty())
            {   // 26.09.23 q-time over 시 팝업 문구 후 처리
                OkDialog.show(
                    supportFragmentManager, "Q-Time Over",
                    "Q-Time 초과 대상 Lot 입니다", GetString.BTNOKSTR
                )
            }
            else if(qTimeFlag_W.isNotEmpty())
            {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_WARNING,
                    "Q-Time 2hr 이내 근접 Lot 입니다", GetString.BTNOKSTR
                )
            }
            return true
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )

            viewBinding.txtProductRear.text = ""
            viewBinding.txtOperationRear.text = ""
            viewBinding.txtQtyRear.text = ""
            viewBinding.editLotNoRear.requestFocus()
            viewBinding.editLotNoRear.selectAll()
            viewBinding.btnReadCommentRear.isEnabled = false
            viewBinding.btnStart.isEnabled = false

            return false
        }
    }

    private fun readCommentFront() {
        val nextIntent = Intent(this, CommentListActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.txtLotNoFront.text.toString())
        nextIntent.putExtra("OPERATION", searchOperationFront)
        nextIntent.putExtra("SUBOPERATION", searchSubOperationFront)
        nextIntent.putExtra("PROCESSSTEP", searchProcessStepFront)
        nextIntent.putExtra("OPERSEQUENCE", searchOperSeqFront)
        startActivity(nextIntent)
    }

    private fun readCommentRear() {
        val nextIntent = Intent(this, CommentListActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.editLotNoRear.text.toString())
        nextIntent.putExtra("OPERATION", searchOperationRear)
        nextIntent.putExtra("SUBOPERATION", searchSubOperationRear)
        nextIntent.putExtra("PROCESSSTEP", searchProcessStepRear)
        nextIntent.putExtra("OPERSEQUENCE", searchOperSeqRear)
        startActivity(nextIntent)
    }

    private fun deleteJobCode() {
        mainScope.launch {
            job1 = ""
            job2 = ""

            if (viewBinding.editMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                    "장비명를 선택하여 주세요.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (searchEqpType == "ULTIMA3") {
                //val batchCancelIntent =
                //    Intent(this@RemoteRamcoActivity, RemoteBatchCancelActivity::class.java)
                //batchCancelIntent.putExtra("EQPID", viewBinding.editMachine.text.toString())
                //batchCancelResultLauncher.launch(batchCancelIntent)
            } else {
                executeBatchCancel()
            }
        }
    }

    private val batchCancelResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                it.data?.let { intent ->
                    if (intent.getStringExtra("JOB1")?.isNotEmpty() == true)
                        job1 = intent.getStringExtra("JOB1").toString()

                    if (intent.getStringExtra("JOB2")?.isNotEmpty() == true)
                        job2 = intent.getStringExtra("JOB2").toString()

                    if (job1.isEmpty() && job2.isEmpty()) {
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            "선택된 JOB이 없습니다.", GetString.BTNOKSTR
                        )

                        return@let
                    }

                    executeBatchCancel()
                }
            }
        }

    private fun executeBatchCancel() {
        mainScope.launch {
            val check = OkCancelDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_OK, "장치의 Job을 삭제하시겠습니까?",
                GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
            )

            if (check == OkCancelDialog.RETURN_CODE_CANCEL)
                return@launch

            val machineName2 = viewBinding.editMachine.text.toString()
            val sendMessage = MessageFactoryUtil.ramJobCancel(
                searchEqpType, searchMainEqpID, machineName2, DeviceInfo.OPERATOR_ID, job1, job2
            )
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.RAMJOBCANCEL
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val ret = messageBody.optString("RET")

                if (ret == "0") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "Job 삭제 요청하였습니다.", GetString.BTNOKSTR
                    )
                } else {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "Job 삭제 요청에 실패하였습니다.", GetString.BTNOKSTR
                    )
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun executeRemoteStart() {
        mainScope.launch {
            if (viewBinding.editMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행장비를 입력하세요.", GetString.BTNOKSTR
                )

                return@launch
            }
            //if (viewBinding.txtRecipe.text.isEmpty()) {
            if (viewBinding.spinnerRecipe.selectedItem != null && viewBinding.spinnerRecipe.selectedItem.toString().isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행Rcp가 조회되지 않았습니다.", GetString.BTNOKSTR
                )

                return@launch
            }
            if ((viewBinding.txtLotNoFront.text.isNotEmpty() && viewBinding.txtOperationFront.text.isEmpty())
                || (viewBinding.editLotNoRear.text.isNotEmpty() && viewBinding.txtOperationRear.text.isEmpty())
                || (viewBinding.editLotNoRear.text.isEmpty() && viewBinding.txtOperationRear.text.isNotEmpty())
            ) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT 조회가 정상적으로 이루어 지지 않았습니다.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.txtLotNoFront.text.isNotEmpty()) {
                if (!checkComment(viewBinding.txtLotNoFront.text.toString()))
                    return@launch
            }

            if (viewBinding.editLotNoRear.text.isNotEmpty()) {
                if (!checkComment(viewBinding.editLotNoRear.text.toString()))
                    return@launch
            }

            val recipeIntent = Intent(this@RemoteRamcoActivity, RemoteRecipeDialog::class.java)
            recipeIntent.putExtra(
                RemoteRecipeDialog.RECIPE_LIST,
                viewBinding.spinnerRecipe.selectedItem.toString()//viewBinding.txtRecipe.text.toString()
            )

            activityRecipeResultLauncher.launch(recipeIntent)
        }
    }

    private val activityRecipeResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                execute()
            }
        }

    private fun execute() {
        mainScope.launch {
            var value = ""
            if (searchEqpType == "RAM8500z") {
                if(viewBinding.layoutLu.visibility == View.VISIBLE)
                {
                    if( viewBinding.spinnerPort.selectedItem.toString()=="1" ||  viewBinding.spinnerPort.selectedItem.toString()=="2")
                        value = "PORT12"
                    else
                        value = "PORT34"
                }
                else {
                    if (viewBinding.editLotNoRear.text.isEmpty()) {
                        value = searchNumCst
                    } else {
                        when (searchNumCst) {
                            "1" -> value = searchNumCst + "2"
                            "3" -> value = searchNumCst + "4"
                            "5" -> value = searchNumCst + "6"
                            "7" -> value = searchNumCst + "8"
                        }
                    }
                }
            } else if (searchEqpType == "ULTIMA3" )
            {
                value = viewBinding.spinnerPort.selectedItem.toString()
            }
            else if (searchEqpType == "DES220") {
                value = searchNumCst
            }
            else {
                value = if (viewBinding.editLotNoRear.text.isNotEmpty())
                    "3"
                else
                    "1"
            }

            val machineName = searchMainEqpID
            val machineName2 = viewBinding.editMachine.text.toString()
            val machineType = searchEqpType
            val areaName = searchEqpArea
            val numCass = value
            val lotName = viewBinding.txtLotNoFront.text.toString()
            val lotName2 = viewBinding.editLotNoRear.text.toString()
            //val recipeName = viewBinding.txtRecipe.text.toString()
            val recipeName = viewBinding.spinnerRecipe.selectedItem.toString()
            val jobName = searchJobID
            val productQty = viewBinding.txtQtyFront.text.toString()
            val productQty2 = viewBinding.txtQtyRear.text.toString()
            //val operation = viewBinding.txtOperationFront.text.toString()
            //val operation2 = viewBinding.txtOperationRear.text.toString()
            val operation = searchOperationFront + "-"+ searchSubOperationFront
            val operation2 =searchOperationRear + "-" + searchSubOperationRear
            val eventUser = DeviceInfo.OPERATOR_ID
            val isCarry = ""
            val bay = ""
            val stocker = ""

            val sendMessage = MessageFactoryUtil.wetRemoteStart(
                machineName, machineName2, machineType, areaName, numCass,
                lotName, lotName2, recipeName, jobName, productQty,
                productQty2, operation, operation2, eventUser, isCarry,
                bay, stocker
            )
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.WETREMOTESTART)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                setResult(RESULT_OK)
                finish()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDailogAlram.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR, applicationContext,
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                )
            }
        }
    }

    private fun executeClearPort() {
        mainScope.launch {
            if (viewBinding.spinnerPort.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Port를 먼저 선택하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val portName = viewBinding.spinnerPort.selectedItem.toString()

            val checkCode = OkCancelDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                "PORT [$portName]을(를) 초기화 하고 [IDLE]상태로 바꾸시겠습니까?",
                GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
            )

            if (checkCode == OkCancelDialog.RETURN_CODE_CANCEL)
                return@launch

            val sendMessage =
                MessageFactoryUtil.machinePortClean(searchMainEqpID, portName)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MACHINEPORTCLEAR
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager, "PORT 초기화",
                    "해당 PORT 초기화 명령을 전송하였습니다.", GetString.BTNOKSTR
                )

                setPortState()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearPortState() {
        viewBinding.txtPortState.text = ""
        viewBinding.txtPortState.background = null
    }

    private fun setPortColor(portState: String) {
        when (portState) {
            "RUN" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.BLUE)
                viewBinding.txtPortState.setTextColor(Color.WHITE)
            }
            "PENDING" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portPending))
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "READY" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.GREEN)
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "RESERVED" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.YELLOW)
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "COMPLETE" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portCompleted))
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "IDLE" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portIdle))
                viewBinding.txtPortState.setTextColor(Color.WHITE)
            }
        }
    }

    private fun setPortState() {
        mainScope.launch {
            clearPortState()

            if (viewBinding.spinnerPort.selectedItem == null)
                return@launch

            viewBinding.btnClearPort.isEnabled = false

            val portId = viewBinding.spinnerPort.selectedItem.toString()
            val lotId = viewBinding.txtLotNoFront.text.toString()

//            var recipe = viewBinding.txtRecipe.text.toString()
            //viewBinding.spinnerRecipe.selectedItem.toString()
            var recipe = ""
            var eqpidinfo = ""
            if(searchEqpType == "ULTIMA3")
                eqpidinfo = searchMainEqpID
            else
                eqpidinfo = viewBinding.editMachine.text.toString()

            val sendMessage =
                MessageFactoryUtil.machinePortStatus(eqpidinfo, portId, lotId, recipe)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MACHINEPORTSTATUS
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val portState = messageBody.optString("PORTSTATENAME")
                val ackMsg = messageBody.optString("ACKMSG")

                viewBinding.txtPortState.text = portState
                setPortColor(portState)
                if(searchEqpType == "ULTIMA3") {
                    if (portState == "RUN" || portState == "RESERVED") {
                        val portMsg = """
                        |해당 PORT가 진행중입니다.
                        |장비 및 진행할 LOT을 다시 확인 바랍니다.
                    """.trimMargin()
                        OkDialog.show(
                            supportFragmentManager,
                            "장비 MESSAGE",
                            portMsg,
                            GetString.BTNOKSTR
                        )
                        viewBinding.btnClearPort.isEnabled = true
                        viewBinding.btnStart.isEnabled = false

                        if (ackMsg.isNotEmpty()) {
                            OkDialog.show(
                                supportFragmentManager, "PORT WORNING", ackMsg, GetString.BTNOKSTR
                            )
                        }
                    } else if (portState.isEmpty()) {
                        val portMsg = """
                        |PORT 정보를 가져올 수 없습니다.
                        |잠시후 다시 확인 바랍니다.
                    """.trimMargin()
                        OkDialog.show(
                            supportFragmentManager,
                            "장비 MESSAGE",
                            portMsg,
                            GetString.BTNOKSTR
                        )

                        viewBinding.btnStart.isEnabled = false
                        viewBinding.btnClearPort.isEnabled = true
                    } else {
                        viewBinding.btnStart.isEnabled = true
                    }
                }
                else if(searchEqpType == "RAM8500z") {
                    if (portState == "READY" ) {
                        viewBinding.btnStart.isEnabled = true
                    } else if (portState.isEmpty()) {
                        val portMsg = """
                        |PORT 정보를 가져올 수 없습니다.
                        |잠시후 다시 확인 바랍니다.
                    """.trimMargin()
                        OkDialog.show(
                            supportFragmentManager,
                            "장비 MESSAGE",
                            portMsg,
                            GetString.BTNOKSTR
                        )

                        viewBinding.btnStart.isEnabled = false
                        viewBinding.btnClearPort.isEnabled = false
                    } else {
                        val portMsg = """
                        |해당 PORT가 작업 예약 불가.
                        |PORT상태를 확인하세요.
                    """.trimMargin()
                        OkDialog.show(
                            supportFragmentManager,
                            "장비 MESSAGE",
                            portMsg,
                            GetString.BTNOKSTR
                        )
                        viewBinding.btnClearPort.isEnabled = false
                        viewBinding.btnStart.isEnabled = false

                        if (ackMsg.isNotEmpty()) {
                            OkDialog.show(
                                supportFragmentManager, "PORT WORNING", ackMsg, GetString.BTNOKSTR
                            )
                        }
                    }
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private suspend fun checkComment(lotId: String): Boolean {
        val sendMessage = MessageFactoryUtil.lotInfo("MVIN", lotId, DeviceInfo.FACILITY)
        val message =
            MessageSender.send(supportFragmentManager, sendMessage, MessageName.LOTINFO)
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val nwCommentCnt = messageBody.optString("NWCOMMENTQTY")

            if (nwCommentCnt.isNotEmpty() && nwCommentCnt.toInt() > 0) {
                OkDialog.show(
                    supportFragmentManager, "읽은후 진행하세요.",
                    "LOT[ $lotId]에 읽지 않은 작업성 COMMENT가 [$nwCommentCnt]가 있습니다.", GetString.BTNOKSTR
                )

                return false
            }

            return true
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )

            return false
        }
    }
}