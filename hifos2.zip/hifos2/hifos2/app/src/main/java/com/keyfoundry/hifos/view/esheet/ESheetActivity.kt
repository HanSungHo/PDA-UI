package com.keyfoundry.hifos.view.esheet

import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.util.TypedValue
import android.view.*
import android.view.View.MeasureSpec
import android.view.inputmethod.EditorInfo
import android.widget.*
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.graphics.drawable.DrawableCompat
import androidx.core.view.*
import androidx.drawerlayout.widget.DrawerLayout
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.*
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityEsheetBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.batch.BatchActivity
import com.keyfoundry.hifos.view.cmm.WaferSelectActivity
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialogFragment
import com.keyfoundry.hifos.view.esheet.backupbay.BackupBayDialogActivity
import com.keyfoundry.hifos.view.esheet.comment.CommentListActivity
import com.keyfoundry.hifos.view.esheet.dialog.MaskLocationDialogActivity
import com.keyfoundry.hifos.view.esheet.een.EENAddActivity
import com.keyfoundry.hifos.view.esheet.een.EENSettingActivity
import com.keyfoundry.hifos.view.esheet.movein.MoveInActivity
import com.keyfoundry.hifos.view.esheet.moveout.MoveOutActivity
import com.keyfoundry.hifos.view.lot.LotStatusActivity
import com.keyfoundry.hifos.view.rcp.RCPInquireActivity
import com.keyfoundry.hifos.view.remote.RemoteMachineSelectActivity
import com.keyfoundry.hifos.view.remote.RemoteRamcoActivity
import com.keyfoundry.hifos.view.remote.RemoteFurnaceActivity
import com.keyfoundry.hifos.view.remote.RemoteFurnaceKjActivity
import com.keyfoundry.hifos.view.remote.RemoteFurnaceKECActivity
import com.keyfoundry.hifos.view.rework.ReworkActivity
import com.keyfoundry.hifos.view.sample.SampleReleaseActivity
import com.keyfoundry.hifos.view.shelf.ShelfIncomingActivity
import com.keyfoundry.hifos.view.split.SplitActivity
import com.keyfoundry.hifos.view.etchinspection.EtchInspectionActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.util.*
import kotlin.collections.HashMap


// 2020.02.06 m_sLotStatus의 예약추가  LotProcessState = ‘WAIT’ 이고, LotResUser 값이 있다면,“WAIT” 대신 “예약”으로 보여줌 (jy.Lim)

class ESheetActivity : HFActivity() {
    companion object {
        private const val TAG = "ESheetActivity"
    }
    //teset 12.23
    private lateinit var viewBinding: ActivityEsheetBinding

    private lateinit var gridService: GridService
    private lateinit var okDialogFragment: OkDialogFragment

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var autoRight = false
    private var autoLeft = false
    private val repeatDelay: Long = 50
    private val repeatUpdateHandler: Handler = Handler(Looper.getMainLooper())

    private var moveLR = 0F
    private var mLotName = ""

    private var opM = ""
    private var opS = ""

    private var goldenEqp = ""

    private lateinit var factoryName: String
    private lateinit var productName: String
    private lateinit var processFlowName: String

   // private lateinit var timeOutService: TimeOutService



    private val columnData = linkedMapOf(
        "OPERATION" to ColumnProperty("Step#", Gravity.CENTER, true, 0),
        "SUBOPERATION" to ColumnProperty("Sub#", Gravity.CENTER, true, 0),
        "PROCESSSTEP" to ColumnProperty("공정명", Gravity.START, true, 250),
        "COMMENTCNT" to ColumnProperty("C", Gravity.CENTER, false, 70),
        "INQTY" to ColumnProperty("I", Gravity.CENTER, false),
        "OUTQTY" to ColumnProperty("O", Gravity.CENTER, false),
        "SPEC" to ColumnProperty("DESCRIPTION", Gravity.START, false, 400),
        "RECIPE" to ColumnProperty("RECIPE", Gravity.START, false, 300),
        "EQPGROUP" to ColumnProperty("기준장비", Gravity.START, false, 300),
        "ISREWORK" to ColumnProperty("R", Gravity.CENTER, false),
        "ISDCOL" to ColumnProperty("D", Gravity.CENTER, false),
        "BAY" to ColumnProperty("BAY", Gravity.CENTER, false),
        "REALEQPID" to ColumnProperty("진행장비", Gravity.START, false),
        "REALRECIPE" to ColumnProperty("진행RCP", Gravity.START, false),
        "REALRETICLE" to ColumnProperty("진행MASK", Gravity.START, false),
        "STARTTIME" to ColumnProperty("투입시간", Gravity.CENTER, false),
        "INOPERNAME" to ColumnProperty("작업자", Gravity.CENTER, false),
        "ENDTIME" to ColumnProperty("완료시간", Gravity.CENTER, false),
        "OUTOPERNAME" to ColumnProperty("작업자", Gravity.CENTER, false),
        "FUTUREACTIONDESC" to ColumnProperty("Futureaction", Gravity.CENTER, false),
        "ACTIONTYPE" to ColumnProperty("Actiontype", Gravity.CENTER, false)
    )

    inner class RepetitiveUpdater : Runnable {
        override fun run() {
            try {
                if (autoRight) {
                    moveRight()
                    repeatUpdateHandler.postDelayed(RepetitiveUpdater(), repeatDelay)
                } else if (autoLeft) {
                    moveLeft()
                    repeatUpdateHandler.postDelayed(RepetitiveUpdater(), repeatDelay)
                }
            } catch (e: Exception) {
                autoRight = false
                autoLeft = false
                Log.e(TAG, "MoveButton Err : ${e.message}")
            }
        }
    }

    inner class DrawerGestureListener(
        private val operationName: String, private val lotName: String,
        private val row: CTRowLayout, private val gridData: CTMainLayout,
        private val drawer: Boolean
    ) : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(e: MotionEvent?): Boolean {
            val operType = gridService.getCellValue(row, "OPERTYPE")

            if (drawer && row.isSelected && (operType == "M" || operType == "P"))
                showDrawerList(operationName, lotName, row)

            val parentLayout = row.parent as CTSubLayout
            parentLayout.currentRowIndex = parentLayout.indexOfChild(row)

            clearColor(gridData)

            val mainRow =
                gridData.mainTable.getChildAt(parentLayout.currentRowIndex) as CTRowLayout
            val rowHeaderRow =
                gridData.rowHeaderTable.getChildAt(parentLayout.currentRowIndex) as CTRowLayout

            mainRow.isSelected = true
            rowHeaderRow.isSelected = true

            var datalistF = (row.tag as GridService.RowData).rowDataList
            opM = datalistF["OPERATION"].toString()
            opS = datalistF["SUBOPERATION"].toString()
           //  Log.d("here","확인 111111")
           // Log.d("here",opM)
           // Log.d("here",opS)

            return super.onSingleTapUp(e)
        }
    }

    inner class CommentGestureListener(
        private val dataList: HashMap<String, Any>, private val commentIntent: Intent,
        private val textView: TextView, private val lotId: String
    ) : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(e: MotionEvent?): Boolean {
            val parentRow = textView.parent as CTRowLayout
            val parentLayout = parentRow.parent as CTSubLayout

            if (e != null) {
                if (e.action == MotionEvent.ACTION_UP) {
                    val gridData = viewBinding.baseLayout.getChildAt(0) as CTMainLayout
                    clearColor(gridData)

                    val mainRow =
                        gridData.mainTable.getChildAt(parentLayout.indexOfChild(parentRow)) as CTRowLayout
                    val rowHeaderRow =
                        gridData.rowHeaderTable.getChildAt(parentLayout.indexOfChild(parentRow)) as CTRowLayout

                    mainRow.isSelected = true
                    rowHeaderRow.isSelected = true
                }
            }

            return super.onSingleTapUp(e)
        }
        override fun onDoubleTap(e: MotionEvent?): Boolean {
            commentIntent.putExtra("LOTID", lotId)
            commentIntent.putExtra("OPERATION", dataList["OPERATION"].toString())
            commentIntent.putExtra("SUBOPERATION", dataList["SUBOPERATION"].toString())
            commentIntent.putExtra("PROCESSSTEP", dataList["PROCESSSTEP"].toString())
            commentIntent.putExtra("OPERSEQUENCE", dataList["OPERSEQUENCE"].toString())

            activityResultLauncher.launch(commentIntent)

            return super.onDoubleTap(e)
        }
    }

    inner class EDCtGestureListener(
        private val dataList: HashMap<String, Any>, private val commentIntent: Intent,private val textView: TextView, private val lotId: String
    ) : GestureDetector.SimpleOnGestureListener(){
        override fun onSingleTapUp(e: MotionEvent?): Boolean {
            val parentRow = textView.parent as CTRowLayout
            val parentLayout = parentRow.parent as CTSubLayout

            if (e != null) {
                if (e.action == MotionEvent.ACTION_UP) {
                    val gridData = viewBinding.baseLayout.getChildAt(0) as CTMainLayout
                    clearColor(gridData)

                    val mainRow =
                        gridData.mainTable.getChildAt(parentLayout.indexOfChild(parentRow)) as CTRowLayout
                    val rowHeaderRow =
                        gridData.rowHeaderTable.getChildAt(parentLayout.indexOfChild(parentRow)) as CTRowLayout

                    mainRow.isSelected = true
                    rowHeaderRow.isSelected = true
                }
            }

            return super.onSingleTapUp(e)
        }

        override fun onDoubleTap(e: MotionEvent?): Boolean {
            commentIntent.putExtra("LOTID", lotId)
            commentIntent.putExtra("OPERATION", dataList["OPERATION"].toString())
            commentIntent.putExtra("SUBOPERATION", dataList["SUBOPERATION"].toString())
            commentIntent.putExtra("PROCESSSTEP", dataList["PROCESSSTEP"].toString())  //공정명
            commentIntent.putExtra("REALRECIPE", dataList["REALRECIPE"].toString())

            activityResultLauncher.launch(commentIntent)

            return super.onDoubleTap(e)
        }

    }


    inner class QtyGestureListener(
    ) : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent?): Boolean {
            mainScope.launch {
                val lotid = viewBinding.editLotNo.text.toString()
                val sendMessage = MessageFactoryUtil.getwaferinfo(lotid)

                val message =
                    MessageSender.send(supportFragmentManager, sendMessage, MessageName.GETWAFER)
                val isSuccessFul = message.isSuccessFul
                val result = message.result
                if (isSuccessFul) {
                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                    val waferlist = messageBody.optString("WAFERLIST")
                    val waferIntent = Intent(applicationContext, WaferSelectActivity::class.java)
                    waferIntent.putExtra("EDITABLE", "N")
                    waferIntent.putExtra("LOTID", viewBinding.editLotNo.text.toString())
                    waferIntent.putExtra("EXISTWAFERLIST", waferlist)
                    startActivity(waferIntent)
                }
            }
            return super.onDoubleTap(e)
        }
    }

    inner class DialogGestureListener(
        private val title: String, private val content: String
    ) : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent?): Boolean {
            okDialogFragment = OkDialogFragment(title, content, GetString.BTNOKSTR)
            okDialogFragment.show(supportFragmentManager, "okDialog")
            return super.onDoubleTap(e)
        }
    }

    inner class RowDialogGestureListener(
        private val title: String, private val content: String, private val textView: TextView
    ) : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(e: MotionEvent?): Boolean {
            val parentRow = textView.parent as CTRowLayout
            val parentLayout = parentRow.parent as CTSubLayout

            if (e != null) {
                if (e.action == MotionEvent.ACTION_UP) {
                    val gridData = viewBinding.baseLayout.getChildAt(0) as CTMainLayout
                    clearColor(gridData)

                    val mainRow =
                        gridData.mainTable.getChildAt(parentLayout.indexOfChild(parentRow)) as CTRowLayout
                    val rowHeaderRow =
                        gridData.rowHeaderTable.getChildAt(parentLayout.indexOfChild(parentRow)) as CTRowLayout

                    mainRow.isSelected = true
                    rowHeaderRow.isSelected = true
                }
            }

            return super.onSingleTapUp(e)
        }

        override fun onDoubleTap(e: MotionEvent?): Boolean {
            okDialogFragment = OkDialogFragment(title, content, GetString.BTNOKSTR)
            okDialogFragment.show(supportFragmentManager, "okDialog")
            return super.onDoubleTap(e)
        }
    }

    inner class CTESheetMain : CTMainLayout(this) {
        private var first = true
        override fun onDraw(canvas: Canvas?) {
            if (first) {
                val gridData = viewBinding.baseLayout.getChildAt(0) as CTESheetMain
                var count = 0
                for (row in gridData.mainTable.children) {
                    count++
                    val current = gridService.getCellValue(row, "ISCURRENT")
                    if (current == "Y") {
                        val height = (row as CTRowLayout).measuredHeight
                        if (count > 3) {
                            val totalHeight = height * (count - 2)
                            gridData.calculatePanScale(0F, totalHeight.toFloat(), 1F)
                            break
                        }
                    }
                }

                gridData.calculatePanScale(moveLR, 0F, 1F)

                first = false
            }

            super.onDraw(canvas)
        }
    }

    inner class ResizeGestureListener(
        private val textCell: TextView,
        private val parentRow: CTRowLayout,
        private val index: Int, private val mainBodyTable: CTMainLayout, private val type: String
    ) :
        GestureDetector.SimpleOnGestureListener() {
        private var size = 0
        private var first = true
        private lateinit var headerTable: CTSubLayout
        private lateinit var dataTable: CTSubLayout
        private lateinit var subHeaderTable: CTSubLayout
        private lateinit var subDataTable: CTSubLayout

        // 컬럼 사이즈 조절 기능
        override fun onScroll(
            e1: MotionEvent?, e2: MotionEvent?, distanceX: Float, distanceY: Float
        ): Boolean {
            if (type == GridType.CORNER_GRID) {
                headerTable = mainBodyTable.cornerTable
                dataTable = mainBodyTable.rowHeaderTable
                subHeaderTable = mainBodyTable.columnHeaderTable
                subDataTable = mainBodyTable.mainTable
            } else if (type == GridType.COLUMN_GRID) {
                headerTable = mainBodyTable.columnHeaderTable
                dataTable = mainBodyTable.mainTable
                subHeaderTable = mainBodyTable.cornerTable
                subDataTable = mainBodyTable.rowHeaderTable
            }

            size = textCell.width
            val oriSize = size

            if (size - distanceX.toInt() < 20)
                size = 20
            else
                size -= distanceX.toInt()

            parentRow.columnWidths[index] = size
            val oriProperty = columnData[textCell.tag]
            if (oriProperty != null) {
                columnData[textCell.tag.toString()] =
                    ColumnProperty(
                        oriProperty.columnVale, oriProperty.gravity, oriProperty.fixed, size
                    )
            }

            val bodyParameter = textCell.layoutParams
            bodyParameter.width = size
            textCell.layoutParams = bodyParameter

            for (subChild in dataTable.children) {
                val subRow = subChild as CTRowLayout
                subRow.columnWidths[index] = size
                val subCell = subRow.getChildAt(index) as TextView
                val subParam = subCell.layoutParams
                subParam.width = size
                subCell.layoutParams = subParam
            }

            if (type == GridType.CORNER_GRID) {
                val measureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
                headerTable.measure(measureSpec, measureSpec)

                val mainTableLayoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
                )

                mainTableLayoutParams.leftMargin = headerTable.measuredWidth
                mainTableLayoutParams.topMargin = headerTable.measuredHeight
                subDataTable.layoutParams = mainTableLayoutParams

                val columnTableLayoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
                )

                columnTableLayoutParams.leftMargin = headerTable.measuredWidth
                subHeaderTable.layoutParams = columnTableLayoutParams
            }

            mainBodyTable.bound.rightBound += (size - oriSize)

            size = oriSize

            return super.onScroll(e1, e2, distanceX, distanceY)
        }

        //기존 더블탭시 공정명 사이즈 조절기능
//        override fun onDoubleTap(e: MotionEvent?): Boolean {
//            if (type == GridType.CORNER_GRID) {
//                headerTable = mainBodyTable.cornerTable
//                dataTable = mainBodyTable.rowHeaderTable
//            } else if (type == GridType.COLUMN_GRID) {
//                headerTable = mainBodyTable.cornerTable
//                dataTable = mainBodyTable.rowHeaderTable
//            }
//
//            if (first) {
//                for (row in headerTable.children) {
//                    val cornerRow = row as CTRowLayout
//
//                    for (cell in cornerRow.children) {
//                        val textCell = cell as TextView
//
//                        val textParams = textCell.layoutParams
//                        textParams.width = ViewGroup.LayoutParams.WRAP_CONTENT
//                        textCell.layoutParams = textParams
//
//                        val measureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
//                        textCell.measure(measureSpec, measureSpec)
//
//                        if (size < textCell.measuredWidth)
//                            size = textCell.measuredWidth
//                    }
//                }
//
//                for (row in dataTable.children) {
//                    val cornerRow = row as CTRowLayout
//
//                    for (cell in cornerRow.children) {
//                        val textCell = cell as TextView
//
//                        val textParams = textCell.layoutParams
//                        textParams.width = ViewGroup.LayoutParams.WRAP_CONTENT
//                        textCell.layoutParams = textParams
//
//                        val measureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
//                        textCell.measure(measureSpec, measureSpec)
//
//                        if (size < textCell.measuredWidth)
//                            size = textCell.measuredWidth
//                    }
//                }
//
//                first = false
//            }
//
//            val oriSize = parentRow.columnWidths[index]
//            parentRow.columnWidths[index] = size
//
//            val bodyParameter = textCell.layoutParams
//            bodyParameter.width = size
//            textCell.layoutParams = bodyParameter
//
//            for (subChild in dataTable.children) {
//                val subRow = subChild as CTRowLayout
//                subRow.columnWidths[index] = size
//                val subCell = subRow.getChildAt(index) as TextView
//                val subParam = subCell.layoutParams
//                subParam.width = size
//                subCell.layoutParams = subParam
//            }
//
//            val measureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
//            mainBodyTable.cornerTable.measure(measureSpec, measureSpec)
//
//            val mainTableLayoutParams = FrameLayout.LayoutParams(
//                FrameLayout.LayoutParams.WRAP_CONTENT,
//                FrameLayout.LayoutParams.WRAP_CONTENT
//            )
//
//            mainTableLayoutParams.leftMargin = mainBodyTable.cornerTable.measuredWidth
//            mainTableLayoutParams.topMargin = mainBodyTable.cornerTable.measuredHeight
//            mainBodyTable.mainTable.layoutParams = mainTableLayoutParams
//
//            val columnTableLayoutParams = FrameLayout.LayoutParams(
//                FrameLayout.LayoutParams.WRAP_CONTENT,
//                FrameLayout.LayoutParams.WRAP_CONTENT
//            )
//
//            columnTableLayoutParams.leftMargin = mainBodyTable.cornerTable.measuredWidth
//            mainBodyTable.columnHeaderTable.layoutParams = columnTableLayoutParams
//
//            mainBodyTable.bound.rightBound += (size - oriSize)
//
//            size = oriSize
//            return super.onDoubleTap(e)
//        }
    }

    override fun onBackPressed() {
        if (viewBinding.menuDrawer.isDrawerOpen(GravityCompat.END)) {
            viewBinding.menuDrawer.closeDrawer(GravityCompat.END)
        } else {
            super.onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()

        val newTitle = "eSheet (${DeviceInfo.OPERATOR_NAME})"
        val layoutTitle = viewBinding.layoutTitle
        val textViewTitle = layoutTitle.findViewById<TextView>(R.id.txt_title)
        textViewTitle.text = newTitle

        CommonUtil.checkPDAName(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityEsheetBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

      //  timeOutService = TimeOutService(applicationContext)

        Log.d("시작", "시작")
        val t1 = System.currentTimeMillis()

        viewBinding.txtEsheetRecipe.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtEsheetMachine.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtEngr.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtEngr2.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtProduct.movementMethod = ScrollingMovementMethod.getInstance()

        //소문자 -> 대문자
        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        val newTitle = "eSheet (${DeviceInfo.OPERATOR_NAME})"
        val layoutTitle = viewBinding.layoutTitle
        val textViewTitle = layoutTitle.findViewById<TextView>(R.id.txt_title)
        textViewTitle.text = newTitle

        CommonUtil.checkPDAName(this)

        gridService = GridService(applicationContext)
        viewBinding.menuDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()
            viewBinding.editLotNo.setText(lotId)

            if (lotId.isNotEmpty()) {
                searchData(lotId)
            }
        }

        viewBinding.editLotNo.setOnEditorActionListener(onEditorActionListener)

        viewBinding.btnSearch.setOnClickListener(onSingleClickListener)
        viewBinding.btnShelf.setOnClickListener(onSingleClickListener)
        viewBinding.btnBackupBay.setOnClickListener(onSingleClickListener)
        viewBinding.btnPcm.setOnClickListener(onSingleClickListener)
        viewBinding.btnClose.setOnClickListener(onSingleClickListener)
        viewBinding.btnMlot.setOnClickListener(onSingleClickListener)
        viewBinding.btnFuture.setOnClickListener(onSingleClickListener)

        viewBinding.chkOperation.setOnCheckedChangeListener(onCheckedChangeListener)

        val qtyDetector =
            GestureDetectorCompat(this, QtyGestureListener())
        viewBinding.txtLotQty.setOnTouchListener { v, event ->
            qtyDetector.onTouchEvent(event)
            true
        }

        val t2 = System.currentTimeMillis()
        Log.d("TIME", "JSON 파싱: ${t2 - t1}")
    }


    private val onCheckedChangeListener =
        CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                columnData["OPERATION"] = ColumnProperty("Step#", Gravity.CENTER, true)
                columnData["SUBOPERATION"] = ColumnProperty("Sub#", Gravity.CENTER, true)
            } else {
                columnData["OPERATION"] = ColumnProperty("Step#", Gravity.CENTER, true, 0)
                columnData["SUBOPERATION"] = ColumnProperty("Sub#", Gravity.CENTER, true,0)
            }
        }

    private fun moveRight() {
        val main = viewBinding.baseLayout.getChildAt(0) as CTMainLayout
        val rowLayout = main.mainTable.getChildAt(0) as CTRowLayout

        var total = 0
        for (rowChild in rowLayout.children) {
            val cell = rowChild as TextView
            total += cell.measuredWidth

            if (-main.panX < total) {
                val remainCellWidth = total + main.panX
                main.calculatePanScale(remainCellWidth, 0F, 1F)
                break
            }
        }
    }

    private fun moveLeft() {
        val main = viewBinding.baseLayout.getChildAt(0) as CTMainLayout
        val rowLayout = main.mainTable.getChildAt(0) as CTRowLayout

        var total = 0
        for (rowChild in rowLayout.children) {
            val cell = rowChild as TextView
            total += cell.measuredWidth

            if (total.toFloat() == -main.panX) {
                main.calculatePanScale((-cell.measuredWidth).toFloat(), 0F, 1F)
                break
            } else if (-main.panX < total) {
                val remainCellWidth = total + main.panX
                main.calculatePanScale(-cell.measuredWidth + remainCellWidth, 0F, 1F)
                break
            }
        }
    }

    private val onEditorActionListener =
        TextView.OnEditorActionListener { v, actionId, event ->
            when (v.id) {
                viewBinding.editLotNo.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                        if (check) {
                            searchData(viewBinding.editLotNo.text.toString())
                        } else {
                            clearData()
                        }
                    } else if (event != null) {
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                            if (check) {
                                searchData(viewBinding.editLotNo.text.toString())
                            } else {
                                clearData()
                            }
                        }
                    }
                }
            }

            true
        }

    private fun searchData(lotId: String) {
        mainScope.launch {
            val startTime = System.currentTimeMillis()
            Log.d("Start ", startTime.toString())
            CommonUtil.hideKeyboard(this@ESheetActivity, currentFocus)

            clearData()

            if (lotId.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT NO를 입력하세요", GetString.BTNOKSTR
                )

                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
                return@launch
            }

            val sendMessage = MessageFactoryUtil.eSheetInfo(
                lotId, DeviceInfo.HISTORY_COUNT, DeviceInfo.FORWARD_COUNT, DeviceInfo.FACILITY
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.ESHEETINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            val midTime = System.currentTimeMillis()
            Log.d("mid ", startTime.toString())
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val jobCode = messageBody.optString("PHOTOJOBCODE")
                val lotType = messageBody.optString("PRIORITY")
                val lotStatus = messageBody.optString("STATUS")
                val engr = messageBody.optString("ENGR")// [Addition] Sep 04, 2004. I. H. Lee
                val engr2 = messageBody.optString("ENGR2")
                val reworkFlag =
                    messageBody.optString("REWORK_BACKCOL")// [Addition] Sep 18, 2012. J. Y. Lim
                val reticleList =
                    messageBody.optString("RETICLELIST")// [Addition] Dec 19, 2018. J. Y. Lim
                val lotQty =
                    messageBody.optString("PRODUCTQUANTITY")// [Addition] Dec 19, 2018. J. Y. Lim
                var maintItem = messageBody.optString("MAINTITEM")// [Addition] 2019.07.23 jy.Lim
                val lotResUser = messageBody.optString("LOTRESUSER")// [Addition] 2020.02.06 jy.Lim
                val operationType = messageBody.optString("PROCESSOPERATIONTYPE")// [Addition] 2022.10.13 jy.Lim
                val LsatLoggedOuttime = messageBody.optString("LASTLOGGEDOUTTIME")// [Addition] 2022.10.13 jy.Lim
                val LotProcessState = messageBody.optString("LOTPROCESSSTATE")// [Addition] 2022.10.13 jy.Lim
                val AutomotiveFlag = messageBody.optString("AUTOMOTIVEFLAG")// [Addition] 2023.09.22 jy.Lim
                val safeLaunchLot = messageBody.optString("SAFELAUNCHLOT")// [Addition] 2024.02.02 jy.Lim

                val holdComment = messageBody.optString("HOLD_COMMENT")

                val cutoff = messageBody.optString("CUTOFF")// [Addition] 2025.07.28
                val tat = messageBody.optString("TAT")// [Addition] 2025.07.28

                val qTimeCheck = messageBody.optString("QTIMECHECK")// [Addition] 2026.04.20
                val cescProduct = messageBody.optString("CESC")// [Addition] 2026.04.20


                val drawable = viewBinding.txtMaintItem.background

                if (drawable is GradientDrawable) {
                    drawable.mutate()

                    if (qTimeCheck == "") {
                        drawable.setColor(Color.parseColor("#FFFFFF"))
                        viewBinding.txtMaintItem.setTextColor(Color.BLACK)
                        viewBinding.txtMaintItem.setTextSize(TypedValue.COMPLEX_UNIT_SP,16F)
                    } else {
                        drawable.setColor(Color.parseColor("#FF0000"))
                        viewBinding.txtMaintItem.setTextColor(Color.YELLOW)
                        viewBinding.txtMaintItem.setTextSize(TypedValue.COMPLEX_UNIT_SP,12F)
                        maintItem += " Q-T 대상"
                    }
                }
//
//                if(qTimeCheck == ""){
//                    val drawable = viewBinding.txtMaintItem.background.mutate()
//                    DrawableCompat.setTint(drawable, Color.parseColor("#FFFFFF"))
//                    viewBinding.txtMaintItem.setTextColor(Color.BLACK)
//                    viewBinding.txtMaintItem.setTextSize(TypedValue.COMPLEX_UNIT_SP,16F)
//                } else {
//                    val drawable = viewBinding.txtMaintItem.background.mutate()
//                    DrawableCompat.setTint(drawable, Color.parseColor("#FF0000"))
//                    viewBinding.txtMaintItem.setTextColor(Color.YELLOW)
//                    viewBinding.txtMaintItem.setTextSize(TypedValue.COMPLEX_UNIT_SP,12F)
//                    maintItem += " Q-T 대상"
//                }

                viewBinding.txtMaintItem.text = maintItem
                viewBinding.txtCutoff.text = cutoff
                viewBinding.txtTat.text = tat

                goldenEqp = messageBody.optString("GOLDENPATHEQP")

                factoryName = messageBody.optString("FACTORYNAME")
                productName = messageBody.optString("PRODUCT")
                processFlowName = messageBody.optString("PROCESSFLOWNAME")

                viewBinding.txtLotStatus.setOnClickListener(null)
                if(lotStatus=="HOLD"){
                    viewBinding.txtLotStatus.setOnClickListener(object : OnSingleClickListener() {
                        override fun onSingleClick(it: View) {
                            OkDialog.show(
                                supportFragmentManager, "HOLD COMMENT",
                                holdComment, GetString.BTNOKSTR
                            )
                        }
                    })
                }

                if(AutomotiveFlag == "Y") {
                    viewBinding.imageCar.visibility = View.VISIBLE

                    if(safeLaunchLot!="") {
                        viewBinding.imageCar.setImageResource(R.drawable.carlightpink)
                    } else {
                        viewBinding.imageCar.setImageResource(R.drawable.car2)
                    }
                }
                else
                    viewBinding.imageCar.visibility = View.INVISIBLE

                viewBinding.txtJobCode.text = messageBody.optString("PHOTOJOBCODE")
                viewBinding.txtLotType.text = lotType
                viewBinding.txtLotQty.text = messageBody.optString("PRODUCTQUANTITY")

                viewBinding.txtLayer.text = "잔여 " + messageBody.optString("REMAINLAYERS")  // 2022.04.20 jy.Lim

                if (lotResUser.isNotEmpty() && lotStatus == "WAIT")
                    viewBinding.txtLotStatus.text = "예약"
                else
                    viewBinding.txtLotStatus.text = lotStatus

                viewBinding.txtEngr.text = messageBody.optString("ENGR")
                viewBinding.txtEngr2.text = messageBody.optString("ENGR2")
                viewBinding.txtProduct.text = messageBody.optString("PRODUCT")

                mLotName = messageBody.optString("ROOTLOTNAME")  // [Addition] 2021.11.04

                if (reticleList.isNotEmpty()) {
                    viewBinding.btnMask.isEnabled = true
                    viewBinding.btnMask.setOnClickListener(object : OnSingleClickListener() {
                        override fun onSingleClick(it: View) {
                            maskInfo(reticleList)
                        }
                    })
                } else {
                    viewBinding.btnMask.isEnabled = false
                    viewBinding.btnMask.setOnClickListener(null)
                }

                // 상태에 따라 TextView 색 변경
                setStateColor(lotType, lotStatus, reworkFlag, maintItem, cescProduct)

                val operationListJSON =
                    ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "ESHEETITEMS")

                if (operationListJSON.length() < 1) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "ESHEETITEMS가 존재하지 않습니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editLotNo.requestFocus()
                    viewBinding.editLotNo.selectAll()
                    return@launch
                }

                //2017.08.11 I,O (input,output 위치 변경) 요청자 이선영jj
                val gridData = setESheetGridData(columnData, operationListJSON)
                viewBinding.baseLayout.addView(gridData)

                addResizeAction(gridData) // 컬럼 사이즈 변경
                addMoveButton(gridData) // Grid 좌우 이동 버튼
                setDrawer(gridData) // 공정 터치시 사이드 메뉴
                setCurrentRowSel(gridData) // 현재공정 선택

                if (operationType == "Metrology" && LotProcessState == "WAIT")
                {
                    viewBinding.txtEsheetMachine.text = LsatLoggedOuttime
                }

                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()


                // 아래 부분 주석 해제 하면 esheet 조회시간 dialog로 확인 가능
                /*
                       delay(1)
                       val endTime = System.currentTimeMillis()
                       Log.d("end time", startTime.toString())

                       val receiveTime = (midTime-startTime).toString()
                       val renderTime = (endTime-midTime).toString()
                       val totalTime = (endTime-startTime).toString()

                       OkDialog.show(
                           supportFragmentManager, "조회시간 확인",
                           "메시지 받은 시간 : $receiveTime\n렌더링 시간 : $renderTime\n총 시간 : $totalTime", GetString.BTNOKSTR
                       )
                */
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)

                /*if(errorMessage=="timeout"){


                    ioScope.launch {
                        timeOutService.insert(
                            TimeOutInfo(
                                sendMessage,
                                wifiPower.toString(),
                                System.currentTimeMillis()
                            )
                        )
                    }
                }*/

                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )



                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
            }
        }
    }

    private fun setCurrentRowSel(gridData: CTMainLayout) {
        val rowTable = gridData.rowHeaderTable
        val mainTable = gridData.mainTable

        for (columnRow in rowTable.children) {
            val row = columnRow as CTRowLayout
            val isCurrent = gridService.getCellValue(row, "ISCURRENT")

            if (isCurrent == "Y") {
                row.isSelected = true

                val position = rowTable.indexOfChild(row)
                mainTable.getChildAt(position).isSelected = true

                break
            }
        }
    }

    private fun addResizeAction(gridData: CTMainLayout) {
        val cornerHeaderTable = gridData.cornerTable
        val columnHeaderTable = gridData.columnHeaderTable
        val rowHeaderTable = gridData.rowHeaderTable
        val mainTable = gridData.rowHeaderTable

        for (cornerRow in cornerHeaderTable.children) {
            val row = cornerRow as CTRowLayout
//            val idx = if (viewBinding.chkOperation.isChecked) 1 else 0

            for (cell in row.children) {
                val idx = row.indexOfChild(cell)
                val cellTextView = row.getChildAt(idx) as TextView

                val mDetector = GestureDetectorCompat(
                    this,
                    ResizeGestureListener(cellTextView, row, idx, gridData, GridType.CORNER_GRID)
                )

                cellTextView.setOnTouchListener { v, event ->
                    mDetector.onTouchEvent(event)

                    true
                }
            }
        }

        for (columnRow in columnHeaderTable.children) {
            val row = columnRow as CTRowLayout
//            val idx = if (viewBinding.chkOperation.isChecked) 1 else 0

            for (cell in row.children) {
                val idx = row.indexOfChild(cell)
                val cellTextView = row.getChildAt(idx) as TextView

                val mDetector = GestureDetectorCompat(
                    this,
                    ResizeGestureListener(cellTextView, row, idx, gridData, GridType.COLUMN_GRID)
                )

                cellTextView.setOnTouchListener { v, event ->
                    mDetector.onTouchEvent(event)

                    true
                }
            }
        }
    }

    private fun addMoveButton(gridData: CTMainLayout) {
        val buttonLayout = LinearLayout(this)

        val leftButton = ImageButton(this)
        leftButton.setBackgroundResource(R.drawable.move_button_ripple)
        leftButton.isLongClickable = true
        leftButton.setImageResource(R.drawable.arrow_left)
        leftButton.setOnClickListener {
            moveLeft()
        }

        leftButton.setOnLongClickListener {
            autoLeft = true
            repeatUpdateHandler.post(RepetitiveUpdater())
            false
        }

        leftButton.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_UP && autoLeft) {
                autoLeft = false
            }
            false
        }

        val rightButton = ImageButton(this)
        rightButton.setBackgroundResource(R.drawable.move_button_ripple)
        rightButton.isLongClickable = true
        rightButton.setImageResource(R.drawable.arrow_right)
        rightButton.setOnClickListener {
            moveRight()
        }

        rightButton.setOnLongClickListener {
            autoRight = true
            repeatUpdateHandler.post(RepetitiveUpdater())
            false
        }

        rightButton.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_UP && autoRight) {
                autoRight = false
            }
            false
        }

        buttonLayout.addView(leftButton)
        buttonLayout.addView(rightButton)

        buttonLayout.gravity = Gravity.END + Gravity.BOTTOM
        gridData.addView(buttonLayout)
    }

    private fun setStateColor(
        lotType: String, lotStatus: String, rework: String, maintItem: String, cescProduct: String
    ) {
        when (lotType) {
            "PS", "PH", "PH1", "PH2", "PN" -> {
                viewBinding.txtLotType.setBackgroundColor(Color.GREEN)
                viewBinding.txtLotType.setTextColor(Color.BLACK)
            }
            "S" -> {
                viewBinding.txtLotType.setBackgroundColor(Color.parseColor("#ff8000"))
                viewBinding.txtLotType.setTextColor(Color.WHITE)
            }
            "H", "H1" -> {
                viewBinding.txtLotType.setBackgroundColor(Color.YELLOW)
                viewBinding.txtLotType.setTextColor(Color.BLACK)
            }
            "H2" -> {
                viewBinding.txtLotType.setBackgroundColor(Color.parseColor("#7effff"))
                viewBinding.txtLotType.setTextColor(Color.BLACK)
            }
            "N", "NORMAL" -> {
                viewBinding.txtLotType.setBackgroundColor(Color.WHITE)
                viewBinding.txtLotType.setTextColor(Color.BLACK)
            }
        }

        when {
            rework == "REWORK" -> {// REWORK lot의 배경색을  발간색 -> 검은색으로 변경 2014.03.13 (김영민JJ요청) CSR
                viewBinding.txtLotStatus.setBackgroundResource(R.drawable.lot_rework_state)
                viewBinding.txtLotStatus.setTextColor(Color.WHITE)
            }
            lotStatus == "HOLD" -> {
                viewBinding.txtLotStatus.setBackgroundColor(Color.RED)
                viewBinding.txtLotStatus.setTextColor(Color.WHITE)
            }
            lotStatus == "RUN" -> {
                viewBinding.txtLotStatus.setBackgroundColor(Color.BLUE)
                viewBinding.txtLotStatus.setTextColor(Color.WHITE)
            }
            lotStatus == "WAIT" -> {
                viewBinding.txtLotStatus.setBackgroundColor(Color.WHITE)
                viewBinding.txtLotStatus.setTextColor(Color.BLACK)
            }
        }

        when {
            maintItem.contains("매출") || maintItem.contains("물량") -> {//( m_MaintItem.SpanIncluding(_T("매출")) == L"매출")
                viewBinding.txtJobCode.setBackgroundColor(Color.parseColor("#adff2f"))
                viewBinding.txtJobCode.setTextColor(Color.BLACK)
            }

            maintItem.contains("긴급") -> {//if( m_MaintItem.SpanIncluding(_T("긴급")) == L"긴급")
                viewBinding.txtJobCode.setBackgroundColor(Color.parseColor("#ff8c00"))
                viewBinding.txtJobCode.setTextColor(Color.BLACK)
            }

            maintItem.contains("CODE FIX") -> {
                viewBinding.txtJobCode.setBackgroundColor(Color.parseColor("#00ffff"))
                viewBinding.txtJobCode.setTextColor(Color.BLACK)
            }

            else -> {
                viewBinding.txtJobCode.background = null
                viewBinding.txtJobCode.setTextColor(Color.WHITE)
            }
        }

        viewBinding.txtLotQty.setBackgroundColor(Color.parseColor("#add8e6"))


        when {
            maintItem.contains("매출") || maintItem.contains("물량") -> {//( m_MaintItem.SpanIncluding(_T("매출")) == L"매출")
                viewBinding.txtJobCode.setBackgroundColor(Color.parseColor("#adff2f"))
                viewBinding.txtJobCode.setTextColor(Color.BLACK)
            }

            maintItem.contains("긴급") -> {//if( m_MaintItem.SpanIncluding(_T("긴급")) == L"긴급")
                viewBinding.txtJobCode.setBackgroundColor(Color.parseColor("#ff8c00"))
                viewBinding.txtJobCode.setTextColor(Color.BLACK)
            }

            maintItem.contains("CODE FIX") -> {
                viewBinding.txtJobCode.setBackgroundColor(Color.parseColor("#00ffff"))
                viewBinding.txtJobCode.setTextColor(Color.BLACK)
            }

            else -> {
                viewBinding.txtJobCode.background = null
                viewBinding.txtJobCode.setTextColor(Color.WHITE)
            }
        }

        val drawable = viewBinding.txtEngr2.background

        if (drawable is GradientDrawable) {
            drawable.mutate()

            if (lotStatus == "WAIT" && cescProduct != "") {
                drawable.setColor(Color.parseColor("#FFFF00"))
            } else {
                drawable.setColor(Color.parseColor("#FFFFFF"))
            }
        }


//        if(lotStatus == "WAIT" && cescProduct!= "") {
//            val drawable = viewBinding.txtEngr2.background as GradientDrawable
//            DrawableCompat.setTint(drawable, Color.parseColor("#FFFF00"))
//        } else {
//          //  val drawable = viewBinding.txtEngr2.background as GradientDrawable
//          //  DrawableCompat.setTint(drawable, Color.parseColor("#FFFFFF"))
//
//            val drawable = viewBinding.txtEngr2.background
//
//            if (drawable is GradientDrawable) {
//                drawable.mutate()
//                drawable.setColor(Color.parseColor("#FFFFFF"))
//            }
//        }
//
//        viewBinding.txtEngr2.setBackgroundColor(Color.parseColor("#FFFF00"))

        //viewBinding.txtEsheetRealRecipe.setBackgroundColor(Color.parseColor("#F90716"))
        //viewBinding.txtEsheetRealRecipe.setTextColor(Color.BLACK)
    }

    private fun clearData() {
        viewBinding.txtEsheetBay.text =  ""
        viewBinding.txtJobCode.text = ""
        viewBinding.txtLotType.text = ""
        viewBinding.txtLotQty.text = ""
        viewBinding.txtLotStatus.text = ""
        viewBinding.txtOperation.text = ""
        viewBinding.txtMoveinTime.text = ""
        viewBinding.txtEsheetRealRecipe.text = ""
        viewBinding.txtEsheetMachine.text = ""
        viewBinding.txtEsheetRecipe.text = ""
        viewBinding.txtEngr.text = ""
        viewBinding.txtEngr2.text = ""
        viewBinding.txtProduct.text = ""
        viewBinding.txtLayer.text = ""

        viewBinding.txtJobCode.background = null
        viewBinding.txtLotType.background = null
        viewBinding.txtLotQty.background = null
        viewBinding.txtLotStatus.background = null
        viewBinding.txtEsheetRealRecipe.background = null

        if (viewBinding.baseLayout.childCount > 0) {
            val gridData = viewBinding.baseLayout.getChildAt(0) as CTESheetMain
            moveLR = -gridData.panX
        }
        viewBinding.baseLayout.removeAllViews()

        viewBinding.btnMask.isEnabled = false
        viewBinding.btnMask.setOnClickListener(null)

        viewBinding.editLotNo.requestFocus()
        viewBinding.editLotNo.selectAll()
        mLotName = ""  //[Addition 2021.11.04]

        viewBinding.txtMaintItem.text = ""
        viewBinding.txtCutoff.text = ""
        viewBinding.txtTat.text = ""
    }

    private fun setDrawer(gridData: CTMainLayout) {
        for (row in gridData.rowHeaderTable.children) {
            val operationName = gridService.getCellValue(row, "PROCESSSTEP")
            val lotName = viewBinding.editLotNo.text.toString()
            val operType = gridService.getCellValue(row, "OPERTYPE")

            val mDetector = GestureDetectorCompat(
                this,
                DrawerGestureListener(operationName, lotName, row as CTRowLayout, gridData, true)
            )
            row.setOnTouchListener { v, event ->
                mDetector.onTouchEvent(event)
                true
            }
        }

        for (main in gridData.mainTable.children) {
            val mDetector = GestureDetectorCompat(
                this,
                DrawerGestureListener("", "", main as CTRowLayout, gridData, false)
            )
            main.setOnTouchListener { v, event ->
                mDetector.onTouchEvent(event)
                true
            }
        }
    }

    private fun clearColor(gridTable: CTMainLayout) {
        for (main in gridTable.mainTable.children)
            main.isSelected = false

        for (rowHeader in gridTable.rowHeaderTable.children)
            rowHeader.isSelected = false
    }

    private fun showDrawerList(title: String, lotName: String, row: CTRowLayout) {

        val drawMenuList = viewBinding.drawList.drawMenuList
        val drawTitle = viewBinding.drawList.menuTitle
        val listBody = viewBinding.drawList.listBody

        val singleClickListener = object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                when (it.id) {
                    viewBinding.drawList.btnMoveIn.id -> {
                        val nextIntent = Intent(applicationContext, MoveInActivity::class.java)
                        nextIntent.putExtra("LOTID", lotName)
                        activityResultLauncher.launch(nextIntent)
                    }

                    viewBinding.drawList.btnMoveOut.id -> {
                        val nextIntent = Intent(applicationContext, MoveOutActivity::class.java)
                        nextIntent.putExtra("LOTID", lotName)
                        activityResultLauncher.launch(nextIntent)
                    }

                    viewBinding.drawList.btnComment.id -> {
                        val dataList = (row.tag as GridService.RowData).rowDataList
                        val nextIntent = Intent(applicationContext, CommentListActivity::class.java)
                        nextIntent.putExtra("LOTID", lotName)
                        nextIntent.putExtra("OPERATION", dataList["OPERATION"].toString())
                        nextIntent.putExtra("SUBOPERATION", dataList["SUBOPERATION"].toString())
                        nextIntent.putExtra("PROCESSSTEP", dataList["PROCESSSTEP"].toString())
                        nextIntent.putExtra("OPERSEQUENCE", dataList["OPERSEQUENCE"].toString())
                        activityResultLauncher.launch(nextIntent)
                        viewBinding.editLotNo.requestFocus()
                        viewBinding.editLotNo.selectAll()
                    }

                    //2024-01-19 EEN기능 추가 By Sunggil Hwang
                    viewBinding.drawList.btnSettingEen.id -> {
                        val dataList = (row.tag as GridService.RowData).rowDataList

                        if(dataList["COMMENTCNT"].toString() == "0") {
                            val nextIntent = Intent(applicationContext, EENAddActivity::class.java)
                            nextIntent.putExtra("LOTID", lotName)
                            nextIntent.putExtra("FACTORYNAME", factoryName)
                            nextIntent.putExtra("PRODUCT", productName)
                            nextIntent.putExtra("ROUTE", processFlowName)
                            nextIntent.putExtra("OPERATION", dataList["OPERATION"].toString() + "-" + dataList["SUBOPERATION"].toString())
                            nextIntent.putExtra("PROCESSSTEP", dataList["PROCESSSTEP"].toString())
                            activityResultLauncher.launch(nextIntent)
                            viewBinding.editLotNo.requestFocus()
                            viewBinding.editLotNo.selectAll()
                        } else {
                            val nextIntent = Intent(applicationContext, EENSettingActivity::class.java)
                            nextIntent.putExtra("LOTID", lotName)
                            nextIntent.putExtra("FACTORYNAME", factoryName)
                            nextIntent.putExtra("PRODUCT", productName)
                            nextIntent.putExtra("ROUTE", processFlowName)
                            nextIntent.putExtra("OPERATION", dataList["OPERATION"].toString() + "-" + dataList["SUBOPERATION"].toString())
                            nextIntent.putExtra("SUBOPERATION", dataList["SUBOPERATION"].toString())
                            nextIntent.putExtra("PROCESSSTEP", dataList["PROCESSSTEP"].toString())
                            activityResultLauncher.launch(nextIntent)
                            viewBinding.editLotNo.requestFocus()
                            viewBinding.editLotNo.selectAll()
                        }
                    }

                    viewBinding.drawList.btnRework.id -> {
                        val nextIntent = Intent(applicationContext, ReworkActivity::class.java)
                        nextIntent.putExtra("LOTID", lotName)
                        activityResultLauncher.launch(nextIntent)
                    }

                    viewBinding.drawList.btnSplit.id -> {
                        val nextIntent = Intent(applicationContext, SplitActivity::class.java)
                        nextIntent.putExtra("LOTID", lotName)
                        activityResultLauncher.launch(nextIntent)
                    }

                    viewBinding.drawList.btnLotDrawStatus.id -> {
                        val nextIntent = Intent(applicationContext, LotStatusActivity::class.java)
                        nextIntent.putExtra("LOTID", lotName)
                        activityResultLauncher.launch(nextIntent)
                        viewBinding.editLotNo.requestFocus()
                        viewBinding.editLotNo.selectAll()
                    }

                    viewBinding.drawList.btnRCPSearch.id -> {
                        val nextIntent = Intent(applicationContext, RCPInquireActivity::class.java)
                        nextIntent.putExtra("LOTID", lotName)
                        activityResultLauncher.launch(nextIntent)
                        viewBinding.editLotNo.requestFocus()
                        viewBinding.editLotNo.selectAll()
                    }

                    viewBinding.drawList.btnAuto.id -> {
                        //---[Modify] Oct 13, 2011 by W. J. Kim (Combination remote dialog)
                        val nextIntent =
                            Intent(applicationContext, RemoteMachineSelectActivity::class.java)
                        nextIntent.putExtra("LOTID", lotName)
                        activityResultLauncher.launch(nextIntent)
                    }

                    viewBinding.drawList.btnBatchAuto.id -> { //---[Addition] Aug 14, 2020 by uk
                        val nextIntent = Intent(applicationContext, RemoteRamcoActivity::class.java)
                        nextIntent.putExtra("LOTID", lotName)
                        activityResultLauncher.launch(nextIntent)
                    }

                    viewBinding.drawList.btnFurnaceAuto.id -> { //---[Addition] Aug 14, 2020 by uk

                        mainScope.launch {
                            val sendMessage =
                                MessageFactoryUtil.furnace_KJCheck(lotName)
                            val message = MessageSender.send(
                                supportFragmentManager, sendMessage, MessageName.FURNACE_KJCHECK
                            )
                            val isSuccessFul = message.isSuccessFul
                            val result = message.result
                            if (isSuccessFul) {
                                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                                val valCHK = messageBody.optString("CNT")

                                if(valCHK == "0") {
                                    val nextIntent = Intent(applicationContext,RemoteFurnaceKjActivity::class.java)
                                    nextIntent.putExtra("LOTID", lotName)
                                    activityResultLauncher.launch(nextIntent)
                                }
                                else if(valCHK == "KEC") {
                                    val nextIntent2 = Intent(applicationContext,RemoteFurnaceKECActivity  ::class.java)
                                    nextIntent2.putExtra("LOTID", lotName)
                                    activityResultLauncher.launch(nextIntent2)
                                }
                                else {
                                    val nextIntent3 = Intent(applicationContext,RemoteFurnaceActivity ::class.java)
                                    nextIntent3.putExtra("LOTID", lotName)
                                    activityResultLauncher.launch(nextIntent3)
                                }
                            }
                        }

                    }

                    viewBinding.drawList.btnBatch.id ->{ //---[Addition] 2022.03.15 by jy.lim
                        val nextIntent = Intent(applicationContext,BatchActivity::class.java)
                        activityResultLauncher.launch(nextIntent)
                    }

                    viewBinding.drawList.btnSampleRelease.id ->{ //---[Addition] 2023.01.03 by.jy.lim
                        val netIntent = Intent(applicationContext,SampleReleaseActivity::class.java)
                            netIntent.putExtra("LOTID", lotName)
                        activityResultLauncher.launch(netIntent)
                    }

                    viewBinding.drawList.btnEtchInsp.id ->{//---[Addition] 2023.02.20 by.jy.lim
                        val netIntent = Intent(applicationContext,EtchInspectionActivity::class.java)
                        netIntent.putExtra("LOTID", lotName)
                        activityResultLauncher.launch(netIntent)
                    }
                }
            }
        }

        setDrawItemClickListener(row, singleClickListener)

        viewBinding.menuDrawer.addDrawerListener(listener)
        drawTitle.text = title

        // 영역 밖 선택시 Drawer 닫힘
        drawMenuList.setOnTouchListener { v, event ->
            viewBinding.menuDrawer.closeDrawers()
            true
        }

        // 영역 내에서 다른곳 터치 안되게 하기 위함
        listBody.setOnTouchListener { v, event ->
            true
        }

        viewBinding.menuDrawer.openDrawer(drawMenuList)
    }

    private val activityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                searchData(viewBinding.editLotNo.text.toString())

                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
            }

            viewBinding.menuDrawer.closeDrawers()
        }

    private val listener = object : DrawerLayout.DrawerListener {
        override fun onDrawerSlide(drawerView: View, slideOffset: Float) {}
        override fun onDrawerOpened(drawerView: View) {}
        override fun onDrawerClosed(drawerView: View) {}
        override fun onDrawerStateChanged(newState: Int) {}
    }

    private fun setDrawItemClickListener(row: CTRowLayout, clickListener: View.OnClickListener) {
        val current = gridService.getCellValue(row, "ISCURRENT")
        val operType = gridService.getCellValue(row, "OPERTYPE")
        val currentOper = gridService.getCellValue(row, "OPERATION")
        val commentCnt = gridService.getCellValue(row, "COMMENTCNT")
        val edcdata = gridService.getCellValue(row,"ISDCOL")
        val endTime =  gridService.getCellValue(row,"ENDTIME")
        val btnMoveIn = viewBinding.drawList.btnMoveIn
        val btnMoveOut = viewBinding.drawList.btnMoveOut
        val btnComment = viewBinding.drawList.btnComment
        val btnSettingEen = viewBinding.drawList.btnSettingEen
        val btnRework = viewBinding.drawList.btnRework
        val btnSplit = viewBinding.drawList.btnSplit
        val btnLotStatus = viewBinding.drawList.btnLotDrawStatus
        val btnRCP = viewBinding.drawList.btnRCPSearch
        val btnAuto = viewBinding.drawList.btnAuto
        val btnBatchAuto = viewBinding.drawList.btnBatchAuto
        val btnDrawClose = viewBinding.drawList.btnDrawClose
        val btnFurnaceAuto = viewBinding.drawList.btnFurnaceAuto
        val btnBatch = viewBinding.drawList.btnBatch
        val btnSampleRelease = viewBinding.drawList.btnSampleRelease
        val btnEtchInsp = viewBinding.drawList.btnEtchInsp


        enableMenu(btnLotStatus, true, clickListener)
        enableMenu(btnRCP, true, clickListener)
        enableMenu(btnMoveIn, true, clickListener)
        enableMenu(btnMoveOut, true, clickListener)
        enableMenu(btnRework, true, clickListener)
        enableMenu(btnSplit, true, clickListener)
        enableMenu(btnAuto, true, clickListener)
        enableMenu(btnBatchAuto, true, clickListener)
        enableMenu(btnComment, true, clickListener)
        enableMenu(btnSettingEen, true, clickListener)
        enableMenu(btnFurnaceAuto, true, clickListener)
        enableMenu(btnBatch,true,clickListener)  //2022.03.15 by jy.Lim
        enableMenu(btnSampleRelease,true,clickListener)
        enableMenu(btnEtchInsp,true,clickListener)

        if (operType == "M" || operType == "P") {
            btnLotStatus.setOnClickListener(clickListener)
            btnRCP.setOnClickListener(clickListener)
            btnDrawClose.setOnClickListener { viewBinding.menuDrawer.closeDrawers() }

            if (current != "Y") {
                enableMenu(btnMoveIn, false, null)
                enableMenu(btnMoveOut, false, null)
                enableMenu(btnRework, false, null)
                enableMenu(btnSplit, false, null)

                // 200324 UK 초기 투입 INITIAL MARKING 자동화(REMOTE)
                if (currentOper != "10005")
                    enableMenu(btnAuto, false, null)//---[Addition] May 25, 2010 by W. J. Kim

                enableMenu(btnBatchAuto, false, null)
                enableMenu(btnFurnaceAuto, false, null)
                //---[Subtraction] Oct 13, 2011 by W. J. Kim
                //pSubMenu->EnableMenuItem(ID_MENUITEM_REMOTE_IMP,MF_ENABLED | MF_GRAYED);    //---[Addition] May 25, 2010 by W. J. Kim
                //pSubMenu->EnableMenuItem(ID_MENUITEM_REMOTE_PHOTO,MF_ENABLED | MF_GRAYED);    //---[Addition] Sep 28, 2011 by W. J. Kim

                //if(m_cGrid.GetItemText(m_nCurrRow,COL_DCOLYN) != L"Y")
                //{
                //	pSubMenu->EnableMenuItem(ID_MENUITEM_DCOL,MF_ENABLED | MF_GRAYED);
                //}
            } else {
                val currentStatus = viewBinding.txtLotStatus.text

                if (currentStatus == "RUN") {
                    enableMenu(btnMoveIn, false, null)
                    //pSubMenu->EnableMenuItem(ID_MENUITEM_SPLIT,MF_ENABLED | MF_GRAYED);
                    enableMenu(btnAuto, false, null)//---[Addition] May 25, 2010 by W. J. Kim
                    enableMenu(btnBatchAuto, false, null)
                    enableMenu(btnFurnaceAuto, false, null)
                    //---[Subtraction] Oct 13, 2011 by W. J. Kim
                    //pSubMenu->EnableMenuItem(ID_MENUITEM_REMOTE_IMP,MF_ENABLED | MF_GRAYED);    //---[Addition] May 25, 2010 by W. J. Kim
                    //pSubMenu->EnableMenuItem(ID_MENUITEM_REMOTE_PHOTO,MF_ENABLED | MF_GRAYED);    //---[Addition] Sep 28, 2011 by W. J. Kim
                } else if (currentStatus == "WAIT" || currentStatus == "예약") {//[Addition] 2020.02.06 jy.Lim
                    enableMenu(btnMoveOut, false, null)
                   // enableMenu(btnRework, false, null)[Addition] 2022.05.16 jy.Lim 주석처리 추가
                } else if (currentStatus == "HOLD") { //2003.05.09 고상종 HOLD 일 경우 TRANSACTION을 일으키지 않도록 변경
                    enableMenu(btnMoveIn, false, null)
                    enableMenu(btnMoveOut, false, null)
                    enableMenu(btnRework, false, null)
                    enableMenu(btnSplit, false, null)
                    enableMenu(btnAuto, false, null)//---[Addition] May 25, 2010 by W. J. Kim
                    enableMenu(btnBatchAuto, false, null)
                    enableMenu(btnFurnaceAuto, false, null)
                    //---[Subtraction] Oct 13, 2011 by W. J. Kim
                    //pSubMenu->EnableMenuItem(ID_MENUITEM_REMOTE_IMP,MF_ENABLED | MF_GRAYED);    //---[Addition] May 25, 2010 by W. J. Kim
                    //pSubMenu->EnableMenuItem(ID_MENUITEM_REMOTE_PHOTO,MF_ENABLED | MF_GRAYED);    //---[Addition] Sep 28, 2011 by W. J. Kim
                }
            }

            if (commentCnt.isEmpty() || commentCnt == "0")
                enableMenu(btnComment, false, null)

            if (endTime.isNotEmpty())
                enableMenu(btnSettingEen, false, null)

            if(DeviceInfo.AREA == "DIFF" || DeviceInfo.AREA == "END") {
                //enableMenu(btnBatch, true, null)  // 2022.04.01 jy.Lim
            }
            else {
                enableMenu(btnBatch, false, null)  // 2022.04.01 jy.Lim
            }
        }
    }

    private fun enableMenu(button: Button, enabled: Boolean, clickListener: View.OnClickListener?) {
        if (enabled) {
            button.isEnabled = enabled
            button.setOnClickListener(clickListener)
        } else {
            button.isEnabled = enabled
            button.setOnClickListener(clickListener)
        }
    }

    private fun setESheetGridData(
        columnData: LinkedHashMap<String, ColumnProperty>, dataTable: JSONArray
    ): CTMainLayout {
        val bodyLayout = CTESheetMain()
        val columnNameList = gridService.getColumnNameList(dataTable)

        val columnHeaderList = CTSubLayout(this, GridType.COLUMN_GRID)
        val rowHeaderList = CTSubLayout(this, GridType.ROW_GRID)
        val mainBodyList = CTSubLayout(this, GridType.MAIN_GRID)
        val cornerHeaderList = CTSubLayout(this, GridType.CORNER_GRID)

        for (row in 0 until dataTable.length()) {
            val mainBodyRow = CTRowLayout(this)
            val rowHeaderRow = CTRowLayout(this)
            val columnHeaderRow = CTRowLayout(this)
            columnHeaderRow.setBackgroundColor(Color.parseColor("#e9edef"))

            val cornerHeaderRow = CTRowLayout(this)
            cornerHeaderRow.setBackgroundColor(Color.parseColor("#e9edef"))

            val colDataMap = HashMap<String, Any>()
            val columnValueList = mutableListOf<String>()

            for (columnName in columnNameList)
                colDataMap[columnName.toUpperCase(Locale.ROOT)] =
                    dataTable.getJSONObject(row).optString(columnName)

            mainBodyRow.tag = GridService.RowData(colDataMap)
            rowHeaderRow.tag = GridService.RowData(colDataMap)

            val mainDataTag = mainBodyRow.tag as GridService.RowData

            val recipe = mainDataTag.rowDataList["RECIPE"].toString()
            val changeRecipe = mainDataTag.rowDataList["CHANGERECIPE"].toString()
            val eqpGroup = mainDataTag.rowDataList["EQPGROUP"].toString()
            val changeEqpGroup = mainDataTag.rowDataList["CHANGEEQPGROUP"].toString()
            val current = mainDataTag.rowDataList["ISCURRENT"].toString()
            val startTime = mainDataTag.rowDataList["STARTTIME"].toString()
            val realEqpId = mainDataTag.rowDataList["REALEQPID"].toString()
            if (changeRecipe.isEmpty() || (recipe == changeRecipe))
                mainDataTag.rowDataList["CHANGERECIPE"] = "N"
            else
                mainDataTag.rowDataList["CHANGERECIPE"] = "Y"

            if (changeEqpGroup.isEmpty() || (eqpGroup == changeEqpGroup))
                mainDataTag.rowDataList["CHANGEEQPGROUP"] = "N"
            else
                mainDataTag.rowDataList["CHANGEEQPGROUP"] = "Y"

            if (current == "Y") {
                viewBinding.txtEsheetBay.text = mainDataTag.rowDataList["BAY"].toString()

                if (startTime.isNotEmpty()) { // MOVE IN상태이면
                    viewBinding.txtEsheetRecipe.text = ""
                    viewBinding.txtEsheetMachine.text = realEqpId         //2024.03.13 Move In 상태 일때 현재 장비 보여줌 요청자 이선영 FL
                } else {
                    val recipeContent: String
                    if (changeRecipe.isEmpty() || changeRecipe == "N") {
                        viewBinding.txtEsheetRecipe.text = recipe
                        recipeContent = recipe
                    } else {
                        viewBinding.txtEsheetRecipe.text = changeRecipe
                        recipeContent = changeRecipe
                    }

                    val recipeDetector =
                        GestureDetectorCompat(this, DialogGestureListener("RECIPE", recipeContent))
                    viewBinding.txtEsheetRecipe.setOnTouchListener { v, event ->
                        recipeDetector.onTouchEvent(event)
                        false
                    }

                    var machineContent: String
                    if (changeEqpGroup.isEmpty() || changeEqpGroup == "N") {
                        viewBinding.txtEsheetMachine.text = eqpGroup
                        machineContent = eqpGroup
                    } else {
                        viewBinding.txtEsheetMachine.text = changeEqpGroup
                        machineContent = changeEqpGroup
                    }

                    if(goldenEqp!="") {
                        machineContent =
                            "$machineContent\n\nGoldenPath 제한장비\n$goldenEqp"
                    }


                    val machineDetector =
                        GestureDetectorCompat(this, DialogGestureListener("기준장비", machineContent))
                    viewBinding.txtEsheetMachine.setOnTouchListener { v, event ->
                        machineDetector.onTouchEvent(event)
                        false
                    }

                    //추가 Metrology공정이면 마지막 Move Out시간을 보여주도록
                }
            }

            // Row당 Color설정
            val textColor = setEsheetRowColor(mainBodyRow, rowHeaderRow)

            for (columnName in columnData.keys) {
                val property = columnData[columnName] as ColumnProperty
                val columnValue = property.columnVale
                val columnGravity = property.gravity
                val columnSize = property.columnSize
                val fixed = property.fixed

                val propBackColor = property.backColor
                val probTextColor = property.textColor

                // 컬럼헤더 데이터 등록=============================================
                if (columnHeaderList.childCount == 0) {
                    val columnItem = TextView(this)
                    columnItem.gravity = Gravity.CENTER
                    columnItem.setPadding(10)
                    columnItem.setBackgroundResource(R.drawable.cellsharp)
                    columnItem.text = columnValue
                    columnItem.isSingleLine = true
                    columnItem.tag = columnName
                    gridService.setBodyCellColor(columnItem, Color.parseColor("#00000000"))
                    columnItem.setTextColor(Color.parseColor("#808080"))
                    columnValueList.add(columnName.toUpperCase(Locale.ROOT))

                    if (fixed)
                        cornerHeaderRow.addView(columnItem)
                    else
                        columnHeaderRow.addView(columnItem)

                    val bodyParameter = columnItem.layoutParams
                    bodyParameter.width = columnSize
                    columnItem.layoutParams = bodyParameter
                }

                // MainTable의 Cell데이터 등록====================================
                val cpn =
                    mainDataTag.rowDataList["CPN"].toString()//---[Addition] Dec 13, 2006 by I. H. Lee
                val operType = mainDataTag.rowDataList["OPERTYPE"].toString()
                val futureaction = mainDataTag.rowDataList["FUTUREACTIONDESC"].toString()
                val actionType = mainDataTag.rowDataList["ACTIONTYPE"].toString()

                var itemValue = dataTable.getJSONObject(row).optString(columnName)

                if (columnName == "PROCESSSTEP") {
                    if (operType != "M" && operType != "P" && operType != "S")
                        itemValue = "    $itemValue"

                    //---[Addition] Dec 13, 2006 by I. H. Lee (Begin)
                    if (cpn == "Y")
                        itemValue = "★$itemValue"
                    //---[Addition] Dec 13, 2006 by I. H. Lee (End)

                    if (current == "Y")
                        viewBinding.txtOperation.text = itemValue

                } else if (columnName == "RECIPE") {
                    itemValue = if (changeRecipe.isEmpty() || (recipe == changeRecipe))
                        recipe
                    else
                        changeRecipe

                } else if (columnName == "EQPGROUP") {
                    itemValue = if (changeEqpGroup.isEmpty() || (eqpGroup == changeEqpGroup))
                        eqpGroup
                    else
                        changeEqpGroup

                } else if (current == "Y" && columnName == "REALRECIPE") {
                    viewBinding.txtEsheetRealRecipe.text = itemValue
                    if(viewBinding.txtEsheetRealRecipe.text  !="") {
                        viewBinding.txtEsheetRealRecipe.setBackgroundColor(Color.parseColor("#F90716"))
                        viewBinding.txtEsheetRealRecipe.setTextColor(Color.YELLOW)
                    }
                } else if (current == "Y" && columnName == "STARTTIME") {
                    viewBinding.txtMoveinTime.text = itemValue
                }else if (columnName == "SPEC")
                {
                    //2023.03.23 추가
                    if(actionType =="HOLD") {
                        itemValue = "$itemValue ▶ $futureaction"
                    }
                    else if (actionType == "SKIP") {
                        itemValue =  "Engr 에 의해서 공정이 Skip 되었습니다."
                    }
                }

                val bodyItem = TextView(this)

                if (columnName == "SPEC" || columnName == "EQPGROUP" || columnName == "RECIPE") {
                    // 더블탭 시 Dialog 띄움
                    setDialog(columnName, bodyItem, itemValue)
                } else if ((operType == "M" || operType == "P") && columnName == "COMMENTCNT" && itemValue.isNotEmpty() && itemValue != "0") {
                    // Comment Activity 띄움
                    setCommentActivity(bodyItem, GridService.RowData(colDataMap))
                }else if(columnName == "ISDCOL" && itemValue == "Y"){
                    setISDActivity(bodyItem, GridService.RowData(colDataMap))
                }

                bodyItem.setPadding(10)
                bodyItem.text = itemValue
                bodyItem.isSingleLine = true
                bodyItem.gravity = columnGravity
                gridService.setBodyCellColor(bodyItem, propBackColor)

                if (columnName == "RECIPE") {
                    if (mainDataTag.rowDataList["CHANGERECIPE"] == "Y")
                        bodyItem.setBackgroundResource(R.drawable.changed_cellsharp)
                    else
                        bodyItem.setBackgroundResource(R.drawable.cellsharp)
                } else if (columnName == "EQPGROUP") {
                    if (mainDataTag.rowDataList["CHANGEEQPGROUP"] == "Y")
                        bodyItem.setBackgroundResource(R.drawable.changed_cellsharp)
                    else
                        bodyItem.setBackgroundResource(R.drawable.cellsharp)
                } else {
                    bodyItem.setBackgroundResource(R.drawable.cellsharp)
                }

                if (fixed) {
                    val colorValue = textColor["ROW"]
                    if (colorValue != null)
                        bodyItem.setTextColor(colorValue)

                    rowHeaderRow.addView(bodyItem)
                } else {
                    val colorValue = textColor["MAIN"]
                    if (colorValue != null)
                        bodyItem.setTextColor(colorValue)

                    mainBodyRow.addView(bodyItem)
                }

                val bodyParameter = bodyItem.layoutParams
                bodyParameter.width = columnSize
                bodyItem.layoutParams = bodyParameter
            }

            // MainTable의 Row데이터 등록====================================
            mainBodyRow.isFocusableInTouchMode = true
            mainBodyList.addView(mainBodyRow)

            // ColumnHeader 데이터 등록
            if (columnHeaderList.childCount == 0) {
                columnHeaderRow.tag = columnValueList
                columnHeaderList.addView(columnHeaderRow)

                cornerHeaderRow.tag = columnValueList
                cornerHeaderList.addView(cornerHeaderRow)
            }

            // RowHeader의 Row데이터 등록====================================
            rowHeaderRow.isFocusableInTouchMode = true
            rowHeaderList.addView(rowHeaderRow)
        }

        bodyLayout.addViews(mainBodyList, columnHeaderList, rowHeaderList, cornerHeaderList)

        return bodyLayout
    }

    private fun setCommentActivity(bodyItem: TextView, rowData: GridService.RowData) {
        val commentIntent = Intent(this, CommentListActivity::class.java)
        val dataList = rowData.rowDataList
        val lotId = viewBinding.editLotNo.text.toString()

        val mDetector = GestureDetectorCompat(
            this, CommentGestureListener(dataList, commentIntent, bodyItem, lotId)
        )

        bodyItem.isClickable = true
        bodyItem.setOnTouchListener { v, event ->
            mDetector.onTouchEvent(event)
            true
        }
    }

    private fun setISDActivity(bodyItem: TextView, rowData: GridService.RowData) {
        val commentIntent = Intent(this,EsheetEdcActivity::class.java)
        val dataList = rowData.rowDataList
        val lotId = viewBinding.editLotNo.text.toString()

        val mDetector = GestureDetectorCompat(
            this, CommentGestureListener(dataList, commentIntent, bodyItem, lotId)
         )

        bodyItem.isClickable = true
        bodyItem.setOnTouchListener { v, event ->
            mDetector.onTouchEvent(event)
            true
        }
    }


    private fun setDialog(columnName: String, item: TextView, itemValue: String) {
        var title = ""
        var content = ""

        when (columnName) {
            "SPEC" -> {
                title = "DESCRIPTION"
                content = """
                    |[DESCRIPTION]
                    |$itemValue
                """.trimMargin()
            }

            "EQPGROUP" -> {
                title = "기준장비"
                content = """
                    |[기준장비]
                    |$itemValue
                """.trimMargin()
            }

            "RECIPE" -> {
                title = "RECIPE"
                content = """
                    |[RECIPE]
                    |$itemValue
                """.trimMargin()
            }
            "D" ->{  //2022.10.25


            }
        }

        val mDetector = GestureDetectorCompat(this, RowDialogGestureListener(title, content, item))

        if (itemValue.isNotEmpty()) {
            item.isClickable = true
            item.setOnTouchListener { v, event ->
                mDetector.onTouchEvent(event)

                true
            }
        }

        /* 20160303
            RECT rect,rrect,crect;
            m_cGrid.GetCellRect(m_nCurrRow,1, &rect);
            m_cGrid.GetClientRect(&crect);

            int nHeight = m_cGrid.GetDefCellHeight() * 2;

            rrect.left = rect.left+10;
            rrect.right = crect.right;
            rrect.top = rect.bottom;
            rrect.bottom = rrect.top + nHeight;

            if(crect.bottom < rrect.bottom)
            {
                rrect.bottom = rect.top;
                rrect.top = rrect.bottom - nHeight;
            }

            m_strInPlaceRect = rrect;

            m_pInPlaceView = new CInPlaceView(&m_cGrid,CRect(rrect),sText,m_cGrid.GetFont());
            */
    }

    private fun setEsheetRowColor(
        mainBodyRow: CTRowLayout, rowHeaderRow: CTRowLayout
    ): HashMap<String, Int> {
        val rowData = (rowHeaderRow.tag as GridService.RowData).rowDataList
        val textColorMap = hashMapOf("ROW" to 0, "MAIN" to 0)

        when {

            //2023.03.23
            rowData["ACTIONTYPE"] == "HOLD" ->{
                mainBodyRow.setBackgroundResource(R.drawable.esheet_opertype_hold)
                rowHeaderRow.setBackgroundResource(R.drawable.esheet_opertype_hold)

                textColorMap["ROW"] = Color.BLACK
                textColorMap["MAIN"] = Color.BLACK
            }

            rowData["ACTIONTYPE"] == "SKIP" ->{
                mainBodyRow.setBackgroundResource(R.drawable.esheet_opertype_sc_color)
                rowHeaderRow.setBackgroundResource(R.drawable.esheet_opertype_sc_color)

                textColorMap["ROW"] = Color.BLACK
                textColorMap["MAIN"] = Color.BLACK
            }

            rowData["OPERTYPE"] == "S" || rowData["OPERTYPE"] == "C" -> {
                // Comment 공정의 경우 Gray로 지정
                // Comment 공정으로 이미 넘어갔다면 검은색으로 변환
                // 사용자에 의한 Skip 공정의 경우 옅은회색으로 변경(Dec 19, 2003. I. H. Lee)
                // 추가사항 : 사용자이름과 완료시간을 출력

                mainBodyRow.setBackgroundResource(R.drawable.esheet_opertype_sc_color)
                rowHeaderRow.setBackgroundResource(R.drawable.esheet_opertype_sc_color)

                textColorMap["ROW"] = Color.BLACK
                textColorMap["MAIN"] = Color.BLACK
            }

            rowData["OPERTYPE"] != "P" && rowData["OPERTYPE"] != "M" -> {
                mainBodyRow.setBackgroundResource(R.drawable.esheet_opertype_pm_color)
                rowHeaderRow.setBackgroundResource(R.drawable.esheet_opertype_pm_color)

                textColorMap["ROW"] = Color.BLACK
                textColorMap["MAIN"] = Color.BLACK
            }

            rowData["ISCURRENT"] == "Y" -> {
                mainBodyRow.setBackgroundResource(R.drawable.esheet_current_color)
                rowHeaderRow.setBackgroundResource(R.drawable.esheet_current_color)

                textColorMap["ROW"] = Color.WHITE
                textColorMap["MAIN"] = Color.WHITE
            }

            rowData["ISCURRENT"] == "N" -> {
                mainBodyRow.setBackgroundResource(R.drawable.esheet_non_current_color)
                rowHeaderRow.setBackgroundResource(R.drawable.esheet_non_current_color)

                textColorMap["ROW"] = Color.BLACK
                textColorMap["MAIN"] = Color.BLACK
            }
        }

        when {
            // 작업성/일반성 Comment가 있을 경우 BGColor = Red(Feb 25, 2004. I. H. Lee)
            rowData["COMMENTCNT"] != "" && rowData["COMMENTCNT"] != "0" -> {
                mainBodyRow.setBackgroundResource(R.drawable.esheet_comment_color)

                textColorMap["MAIN"] = Color.BLACK
            }
        }

        return textColorMap
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearch.id -> {
                    searchData(viewBinding.editLotNo.text.toString())
                }
                viewBinding.btnShelf.id -> {
                    val newIntent = Intent(applicationContext, ShelfIncomingActivity::class.java)
                    activityResultLauncher.launch(newIntent)
                }
                viewBinding.btnBackupBay.id -> {//---[Addition] Nov 7, 2012 by LJY
                    val newIntent = Intent(applicationContext, BackupBayDialogActivity::class.java)
                    activityResultLauncher.launch(newIntent)
                }
                viewBinding.btnPcm.id -> {
                    checkPCMReworkRecipe()
                }
                viewBinding.btnClose.id -> {
                    finish()
                }
                viewBinding.btnMlot.id -> {
                    //여기 추가 했습니다. 11.04
                    if (viewBinding.editLotNo.text.toString().isEmpty()) {
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            "LOT NO를 입력하세요", GetString.BTNOKSTR
                        )
                        viewBinding.editLotNo.requestFocus()
                        viewBinding.editLotNo.selectAll()
                        return
                    }
                    if (viewBinding.txtJobCode.text.toString().isEmpty()) {
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            "LOT을 조회후 실행하셔야 합니다.", GetString.BTNOKSTR
                        )
                        viewBinding.editLotNo.requestFocus()
                        viewBinding.editLotNo.selectAll()
                        return
                    }

                    if (mLotName.isEmpty()) {
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            "ROOT LOTNAME이 확인되지 않습니다.", GetString.BTNOKSTR
                        )
                    } else {
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
                            "ROOT LOTNAME : $mLotName ", GetString.BTNOKSTR
                        )
                    }
                }

                viewBinding.btnFuture.id ->{

                    if(opM =="" || opS == "")
                    {
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                            "공정을 선택해야 합니다.", GetString.BTNOKSTR
                        )
                        return
                    }
                    checkFuture()
                }
            }
        }
    }

    private fun maskInfo(reticleList: String) {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.maskInfo("T", reticleList, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MASKINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val itemList = ResponseDataToJsonUtil.getMessageBodyList(result, "ITEMS")

                for (count in 0 until itemList.length()) {
                    val row = itemList.length() - 1 - count
                    val reticleTag = itemList.getJSONObject(row).optString("RETICLETAG")
                    val product = itemList.getJSONObject(row).optString("PRODUCT")
                    val status = itemList.getJSONObject(row).optString("STATUS")
                    val isUse = itemList.getJSONObject(row).optString("ISUSE")
                    val currentLoc = itemList.getJSONObject(row).optString("CURRLOC")
                    val GIBEN = itemList.getJSONObject(row)
                        .optString("GIBEN")//---[Addition] Jul 7, 2006. by I. H. Lee. for F-5 HiFOS
                    val subLocation3 = itemList.getJSONObject(row)
                        .optString("SUBLOCATION3")//---[Addition] 2020.06.08 jy.Lim 요청자 이원영JJ
                    val afterInsp = itemList.getJSONObject(row)
                        .optString("AFTERINSP")//---[Addition] 2020.06.29 jy.Lim 요청자 이원영JJ

                    val sIsUse = if (isUse == "Y")
                        "사용가능"
                    else
                        "사용불가"

                    val maskIntent =
                        Intent(applicationContext, MaskLocationDialogActivity::class.java)
                    maskIntent.putExtra("MASKTAG", reticleTag)
                    maskIntent.putExtra("PRODUCT", product)
                    maskIntent.putExtra("GIBEN", GIBEN)
                    maskIntent.putExtra("STATUS", status)
                    maskIntent.putExtra("ISUSE", sIsUse)
                    maskIntent.putExtra("CURRENTLOC", currentLoc)
                    maskIntent.putExtra("SUBLOCATION3", subLocation3)
                    maskIntent.putExtra("AFTERINSP", afterInsp)
                    maskIntent.putExtra("LOTID", viewBinding.editLotNo.text.toString())

                    activityResultLauncher.launch(maskIntent)
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun checkPCMReworkRecipe() {
        mainScope.launch {
            val sendMessage =
                MessageFactoryUtil.pcmReworkRecipe(viewBinding.editLotNo.text.toString())
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.PCMREWORKRECIPE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val recipeList = messageBody.optString("RECIPELIST")
                val prmresult = messageBody.optString("PCMRESULT")
                val eqpLis = messageBody.optString("PCMREQPLIST")

                if(eqpLis.isNotEmpty()){
                    OkDialog.show(
                        supportFragmentManager, "PCM EQPLIST",
                        eqpLis, GetString.BTNOKSTR
                    )
                }

                if (recipeList.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, "PCM Recipe",
                        recipeList, GetString.BTNOKSTR
                    )
                }
                /*
                else {
                    OkDialog.show(
                        supportFragmentManager, "PCM Recipe",
                        "PCM Recipe가 확인되지 않습니다.", GetString.BTNOKSTR
                    )
                }
                 */

                if(prmresult.isNotEmpty()){
                    OkDialog.show(
                        supportFragmentManager, "PCM 결과",
                        prmresult, GetString.BTNOKSTR
                    )
                }

                /*
                if(recipeList.isEmpty() && prmresult.isEmpty())
                {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                        "PCM Recipe/결과값이 확인되지 않습니다. ", GetString.BTNOKSTR
                    )
                }
                */
                return@launch
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun checkFuture() {
        mainScope.launch {
            val sendMessage =
                MessageFactoryUtil.CheckFuture(viewBinding.editLotNo.text.toString(),opM,opS)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.CHECKFUTURE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val sfuturelist = messageBody.optString("FUTURELIST")

                if (sfuturelist.isNotEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, "FUTURE HOLD/SKIP",
                        sfuturelist, GetString.BTNOKSTR
                    )
                    return@launch
                } else {
                    OkDialog.show(
                        supportFragmentManager, "FUTURE HOLD/SKIP",
                        "설정된 FUTURE HOLD/SKIP이 없습니다.", GetString.BTNOKSTR
                    )
                    return@launch
                }
            } else {
                OkDialog.show(
                    supportFragmentManager, "FUTURE HOLD/SKIP",
                    "설정된 FUTURE HOLD/SKIP이 없습니다.", GetString.BTNOKSTR
                )
                return@launch
            }
        }
    }
}