package com.keyfoundry.hifos.view.dialog.fragment

import android.app.Dialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.utils.OnSingleClickListener

class OkCancelDialog : DialogFragment() {
    companion object {
        private const val TAG = "OkCancelDialog"
        const val RETURN_CODE_OK = 1
        const val RETURN_CODE_CANCEL = -1

        private var RETURN_VALUE = 0

        private var txtDialogTitle = ""
        private var txtDialogContent = ""
        private var btnOkStr = ""
        private var btnCancelStr = ""
        private lateinit var okCancelHandler: OkCancelHandler

        fun show(
            supportFragmentManager: FragmentManager,
            txtDialogTitle: String,
            txtDialogContent: String,
            btnOkStr: String,
            btnCancelStr: String
        ): Int {
            Log.d(TAG, "show")
            this.txtDialogTitle = txtDialogTitle
            this.txtDialogContent = txtDialogContent
            this.btnOkStr = btnOkStr
            this.btnCancelStr = btnCancelStr

            okCancelHandler = OkCancelHandler()

            val okCancelDialog = OkCancelDialog()

             try{
                okCancelDialog.show(supportFragmentManager, TAG)
                Looper.loop()
            } catch (e: Exception) {
                Log.e(TAG, "Error : ${e.message}")
            }

            return RETURN_VALUE
        }

        class OkCancelHandler : Handler(Looper.myLooper()!!) {
            override fun handleMessage(msg: Message) {
                Log.d(TAG, "handleMessage : $msg")
                throw RuntimeException()
            }
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return object : Dialog(requireActivity(), theme) {
            override fun onBackPressed() {
                RETURN_VALUE = RETURN_CODE_OK
                val m: Message = okCancelHandler.obtainMessage()
                okCancelHandler.sendMessage(m)
                dialog?.dismiss()
            }
        }
    }

    fun OkCancelDialog() {
        // Do not anything!!!
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.d(TAG, "onCreateView")
        val view = inflater.inflate(R.layout.fragment_dialog_ok_cancel, container, false)

        dialog?.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog?.setCancelable(false)

        val dialogTitle = view.findViewById<TextView>(R.id.txt_dialog_title)
        val dialogContent = view.findViewById<TextView>(R.id.txt_dialog_content)
        val btnOk = view.findViewById<Button>(R.id.btn_ok)
        val btnCancel = view.findViewById<Button>(R.id.btn_cancel)

        dialogTitle.text = txtDialogTitle
        dialogContent.text = txtDialogContent
        dialogContent.movementMethod = ScrollingMovementMethod()
        btnOk.text = btnOkStr
        btnCancel.text = btnCancelStr

        btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                RETURN_VALUE = RETURN_CODE_OK
                val m: Message = okCancelHandler.obtainMessage()
                okCancelHandler.sendMessage(m)
                dialog?.dismiss()
            }
        })

        btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                RETURN_VALUE = RETURN_CODE_CANCEL
                val m: Message = okCancelHandler.obtainMessage()
                okCancelHandler.sendMessage(m)
                dialog?.dismiss()
            }
        })

        return view
    }
}