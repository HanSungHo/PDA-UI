package com.keyfoundry.hifos.view.machinestatus.detail

import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.service.RetrofitSyncService
import com.keyfoundry.hifos.config.service.dto.RequestData
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.spinner.SpinnerItem
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityMachineStatusDetailBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.dialog.MaskLocationDialogActivity
import com.keyfoundry.hifos.view.machinestatus.MachineInformActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray

class MachineStatusDetailActivity : HFActivity() {
    companion object {
        private const val TAG = "MachineStatusDetailActivity"
    }

    private lateinit var viewBinding: ActivityMachineStatusDetailBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var oriEQPStatus = ""
    private var oriDownCode = ""
    private var mainState = ""
    private var chamberMachine = ""
    private var first = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityMachineStatusDetailBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editEqpId.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        if (intent.getStringExtra("EQPID")?.isNotEmpty() == true) {
            val eqpId = intent.getStringExtra("EQPID")

            viewBinding.editEqpId.setText(eqpId)
            setEQPInfo()

            viewBinding.editEqpId.requestFocus()
            viewBinding.editEqpId.selectAll()
        }

        viewBinding.editEqpId.setOnEditorActionListener(onEditorListener)
        viewBinding.spinnerComment.setOnEditorActionListener(onEditorListener)

        viewBinding.spinnerEqpState.onItemSelectedListener = itemSelectedListener
        viewBinding.spinnerDownCode.onItemSelectedListener = itemSelectedListener

        viewBinding.chkChamber.setOnCheckedChangeListener(checkedListener)

        viewBinding.btnSearchEqp.setOnClickListener(onSingleClickListener)
        viewBinding.btnChange.setOnClickListener(onSingleClickListener)
        viewBinding.btnClose.setOnClickListener(onSingleClickListener)
        viewBinding.btnMachineInform.setOnClickListener(onSingleClickListener)

    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchEqp.id -> {
                    setEQPInfo()

                    viewBinding.editEqpId.requestFocus()
                    viewBinding.editEqpId.selectAll()
                }
                viewBinding.btnChange.id -> {
                    changeData()
                }
                viewBinding.btnMachineInform.id -> {
                    moveMachineInformView()
                }
                viewBinding.btnClose.id -> {
                    setResult(RESULT_OK)
                    finish()
                }
            }
        }
    }

    private val checkedListener = CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
        if (isChecked) {
            mainScope.launch {
                if (mainState.isEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "조회된 장비 정보가 없습니다", GetString.BTNOKSTR
                    )
                }

                val sendMessage = MessageFactoryUtil.checkChamber(
                    DeviceInfo.FACILITY, viewBinding.editEqpId.text.toString(), mainState
                )

                val message = MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.CHECKCHAMBER
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result

                if (isSuccessFul) {
                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                    val machineMsg = messageBody.optString("RMAG")
                    val chamberMsg = messageBody.optString("CMAG")
                    val changeFlag = messageBody.optString("CHANGEFLAG")
                    val chamber = messageBody.optString("CHAMBER")

                    chamberMachine = chamber

                    if (!machineMsg.isNullOrEmpty()) {
                        viewBinding.chkChamber.isChecked = false
                        chamberMachine = ""
                        OkDialog.show(
                            supportFragmentManager, "확  인", machineMsg, GetString.BTNOKSTR
                        )
                    }

                    if (!chamberMsg.isNullOrEmpty()) {
                        if (changeFlag == "Y") {
                            val returnCode = OkCancelDialog.show(
                                supportFragmentManager, "확  인", chamberMsg,
                                GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
                            )
                            if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                                viewBinding.chkChamber.isChecked = false
                            }
                        } else {
                            viewBinding.chkChamber.isChecked = false
                            chamberMachine = ""
                            OkDialog.show(
                                supportFragmentManager, "확  인", chamberMsg, GetString.BTNOKSTR
                            )
                        }
                    }
                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR
                    )
                }
            }
        } else {
            chamberMachine = ""
        }
    }

    private val onEditorListener =
        TextView.OnEditorActionListener { v: TextView?, actionId: Int, event: KeyEvent? ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                when (v?.id) {
                    viewBinding.editEqpId.id -> {
                        val check = BarcodeStyle(this).eqpId(viewBinding.editEqpId)

                        if (check)
                            setEQPInfo()
                        else
                            clearInfo()

                        viewBinding.editEqpId.requestFocus()
                        viewBinding.editEqpId.selectAll()
                    }

                    viewBinding.spinnerComment.id -> {
                        CommonUtil.hideKeyboard(this, currentFocus)
                    }
                }
            } else if (event != null) { // Barcode Event
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    when (v?.id) {
                        viewBinding.editEqpId.id -> {
                            val check = BarcodeStyle(this).eqpId(viewBinding.editEqpId)

                            if (check)
                                setEQPInfo()
                            else
                                clearInfo()

                            viewBinding.editEqpId.requestFocus()
                            viewBinding.editEqpId.selectAll()
                        }

                        viewBinding.spinnerComment.id -> {
                            CommonUtil.hideKeyboard(this, currentFocus)
                        }
                    }
                }
            }

            true
        }

    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerEqpState.id -> {
                        viewBinding.spinnerDownCode.adapter = null
                        viewBinding.spinnerComment.setText("")
                        viewBinding.spinnerComment.setAdapter(null)

                        if (viewBinding.spinnerEqpState.selectedItem != null) {
                            val eqpStatus = viewBinding.spinnerEqpState.selectedItem.toString()
                            setDownCodeSpinner(eqpStatus, null)
                        }
                    }

                    viewBinding.spinnerDownCode.id -> {
                        viewBinding.spinnerComment.setText("")
                        viewBinding.spinnerComment.setAdapter(null)

                        if (viewBinding.spinnerDownCode.selectedItem != null) {
                            val downCode =
                                (viewBinding.spinnerDownCode.selectedItem as SpinnerItem).key
                            setCommentSpinner(downCode)
                        }
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private fun changeData() {
        mainScope.launch {
            if (viewBinding.spinnerEqpState.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "장비상태를 선택하세요", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.spinnerDownCode.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "DOWNCODE를 선택하세요", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.spinnerComment.adapter != null && viewBinding.spinnerComment.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "COMMENT를 입력하세요", GetString.BTNOKSTR
                )
                return@launch
            }

            val eqpId = viewBinding.editEqpId.text.toString()
            val finalTime = viewBinding.txtFinalWorkTime.text.toString()
            val downCode = viewBinding.spinnerDownCode.selectedItem.toString()

            val sendMessage = MessageFactoryUtil.checkNonLot(
                eqpId, DeviceInfo.FACILITY, finalTime,
                DeviceInfo.OPERATOR_ID, downCode
            )
            val result = RetrofitSyncService.API.hifosProcess(RequestData(sendMessage))

            val isSuccessFul = ResponseDataToJsonUtil.isSuccessFul(result)
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val nonLotCheck = messageBody.optString("NONLOTCHECK")
                val nonLotResult = messageBody.optString("NONLOTRESULT")
                val massage = messageBody.optString("NONLOTMESSGE")
                val hMessage = messageBody.optString("NONLOTHMESSGE")

                if (nonLotCheck == "Y") {
                    if (nonLotResult == "N") {
                        OkDialog.show(supportFragmentManager, hMessage, massage, GetString.BTNOKSTR)
                        return@launch
                    }
                    else {
                        val returnCode = OkCancelDialog.show(supportFragmentManager,hMessage,massage,GetString.BTNYESSTR, GetString.BTNNOSTR)

                        if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                            return@launch
                        }
                    }

                    /* 2022.06.22 Non Data미입력 또는 NG일경우 장비를 UP하는 부분이 누락되어 하기 소스를 삭제및 수정함
                    else {
                        if (oriEQPStatus != viewBinding.spinnerEqpState.selectedItem.toString() || oriDownCode != viewBinding.spinnerDownCode.selectedItem.toString()) {
                            OkDialog.show(
                                supportFragmentManager, hMessage, massage, GetString.BTNOKSTR
                            )
                            return@launch
                        } else {
                            OkDialog.show(
                                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                                "변경된 내역이 없습니다", GetString.BTNOKSTR
                            )
                            return@launch
                        }
                    }
                    */
                }

                if (oriEQPStatus != viewBinding.spinnerEqpState.selectedItem.toString() || oriDownCode != viewBinding.spinnerDownCode.selectedItem.toString()) {
                    val selectedEQPStatus =
                        (viewBinding.spinnerEqpState.selectedItem as SpinnerItem).value
                    val selectedDownCode =
                        (viewBinding.spinnerDownCode.selectedItem as SpinnerItem).key

                    val message = """
                        |상태: 
                        |$oriEQPStatus → $selectedEQPStatus
                        |DownCode: 
                        |$oriDownCode → $selectedDownCode
                        |로 변경하시겠습니까?   
                    """.trimMargin()

                    val returnCode =
                        OkCancelDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                            message, GetString.BTNYESSTR, GetString.BTNNOSTR
                        )

                    if (returnCode == OkCancelDialog.RETURN_CODE_OK)
                    {
                        if(DeviceInfo.OPERATOR_ID == "OPERATOR_ID" )
                        {
                            OkDialog.show(
                                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                                "로그인정보가 확인되지 않습니다.", GetString.BTNOKSTR
                            )
                            return@launch
                        }
                        execute()
                    }


                    return@launch
                } else {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "변경된 내역이 없습니다", GetString.BTNOKSTR
                    )

                    return@launch
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun moveMachineInformView(){
        val intent = Intent(applicationContext, MachineInformActivity::class.java)

        intent.putExtra("MACHINENAME", viewBinding.editEqpId.text.toString())

        startActivity(intent)
    }

    private suspend fun execute() {
        val eqpId = viewBinding.editEqpId.text.toString()
        val eqpStatusCode = (viewBinding.spinnerEqpState.selectedItem as SpinnerItem).value
        val eqpDownCode = (viewBinding.spinnerDownCode.selectedItem as SpinnerItem).key
        val comment = viewBinding.spinnerComment.text.toString()

        val sendMessage = MessageFactoryUtil.changeEQPStatus(
            eqpId, DeviceInfo.FACILITY, eqpStatusCode, eqpDownCode,
            comment, DeviceInfo.OPERATOR_ID, DeviceInfo.OPERATOR_NAME, chamberMachine
        )

        val message = MessageSender.send(
            supportFragmentManager, sendMessage, MessageName.CHANGEEQPSTATUS
        )
        val isSuccessFul = message.isSuccessFul
        val result = message.result

        if (isSuccessFul) {
//            setEQPInfo()
//            viewBinding.editEqpId.requestFocus()
//            viewBinding.editEqpId.selectAll()
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val sViaLoading = messageBody.optString("VAILOADING")

            if(sViaLoading != ""){
                    val returnCode = OkDialog.show(supportFragmentManager
                        , "정기 정검 도달"
                        , "["+ "$sViaLoading" + "] VIA Loading W/F 진행 필요!"
                        , GetString.BTNOKSTR)
            }

            setResult(RESULT_OK)
            finish()
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )
        }
    }

    private fun setEQPInfo() {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@MachineStatusDetailActivity, currentFocus)

            if (viewBinding.editEqpId.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "EQP ID를 입력하세요", GetString.BTNOKSTR
                )
                return@launch
            }

            clearInfo()

            val sendMessage = MessageFactoryUtil.eqpStatus(
                viewBinding.editEqpId.text.toString(), DeviceInfo.FACILITY
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.EQPSTATUS)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val operator = "${DeviceInfo.OPERATOR_NAME}(${DeviceInfo.OPERATOR_ID})"

                viewBinding.txtFacility.text = messageBody.optString("FACILITY")
                viewBinding.txtMainStatus.text = messageBody.optString("MAINSTATUS")
                viewBinding.txtSubStatus.text = messageBody.optString("SUBSTATUS")
                viewBinding.txtFinalWorkTime.text = messageBody.optString("FINALWORKTIME")
                viewBinding.txtFdcState.text = messageBody.optString("FDCDOWN")
                viewBinding.txtOperator.text = operator

                val currentEQPStatus =
                    "${messageBody.optString("EQPSTATUSCODE")}  ${messageBody.optString("EQPSTATUSDESC")}"
                val currentEQPDownCode =
                    "${messageBody.optString("DOWNCODE")}  ${messageBody.optString("DOWNDESC")}"

                oriEQPStatus = currentEQPStatus
                oriDownCode = messageBody.optString("DOWNCODE")
                mainState = messageBody.optString("MAINSTATUS")

                val statusList =
                    ResponseDataToJsonUtil.getMessageBodyInValueList(result, "STATUSITEMS", "ITEM")

                setStatusSpinner(statusList)
                setDownCodeSpinner(currentEQPStatus, currentEQPDownCode)
                setCommentSpinner(currentEQPDownCode)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editEqpId.requestFocus()
                viewBinding.editEqpId.selectAll()
            }
        }
    }

    private fun clearInfo() {
        oriEQPStatus = ""
        oriDownCode = ""
        mainState = ""
        chamberMachine = ""

        viewBinding.txtFacility.text = ""
        viewBinding.txtMainStatus.text = ""
        viewBinding.txtSubStatus.text = ""
        viewBinding.txtFinalWorkTime.text = ""
        viewBinding.txtOperator.text = ""

        viewBinding.spinnerComment.setAdapter(null)
        viewBinding.spinnerComment.setText("")

        viewBinding.spinnerEqpState.adapter = null
        viewBinding.spinnerDownCode.adapter = null

        viewBinding.chkChamber.isChecked = false
    }

    private fun setCommentSpinner(downCode: String) {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.eqpDownComment(DeviceInfo.FACILITY, downCode)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.EQPDOWNCOMMENT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val downCodeList =
                    ResponseDataToJsonUtil.getMessageBodyList(result, "DOWNCOMMENTITEMS")

                var maxWidth = viewBinding.spinnerComment.width
                val itemList = arrayListOf<String>()
                for (count in 0 until downCodeList.length()) {
                    val downComment = downCodeList.getJSONObject(count).optString("DOWNCOMMENT")

                    val getWidth = TextView(this@MachineStatusDetailActivity)
                    val width = getWidth.paint.measureText(downComment) + 100

                    if (width > maxWidth)
                        maxWidth = width.toInt()

                    itemList.add(downComment)
                }

                var first = true

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.custom_spinner_dropdown, itemList)
                viewBinding.spinnerComment.setAdapter(spinnerAdapter)
                viewBinding.spinnerComment.setOnFocusChangeListener { v, hasFocus ->
                    if (hasFocus) {
                        viewBinding.spinnerComment.showDropDown()
                        first = false
                    }
                }

                viewBinding.spinnerComment.setOnClickListener {
                    if (first)
                        viewBinding.spinnerComment.showDropDown()
                    else
                        viewBinding.spinnerComment.dismissDropDown()

                    first = !first
                }
                viewBinding.spinnerComment.dropDownWidth = maxWidth
                if (itemList.count() == 1)
                    viewBinding.spinnerComment.setText(itemList[0], false)
            }
        }
    }

    private fun setStatusSpinner(statusList: JSONArray) {
        val itemList = arrayListOf<SpinnerItem>()

        for (row in 0 until statusList.length()) {
            val status = statusList.getJSONObject(row).optString("EQPSTATUSCODE")
            val statusDesc = statusList.getJSONObject(row).optString("EQPSTATUSDESC")

            itemList.add(SpinnerItem(status, "$status  $statusDesc"))
        }

        val spinnerAdapter = ArrayAdapter(this, R.layout.contact_spinner_row_init, itemList)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerEqpState.adapter =
            InitSpinnerAdapter(spinnerAdapter, R.layout.contact_spinner_row_init, this)
    }

    private fun setDownCodeSpinner(eqpStatus: String, currentEQPDownCode: String?) {
        mainScope.launch {
            val eqpId = viewBinding.editEqpId.text.toString()

            val status = if (viewBinding.spinnerEqpState.selectedItem != null)
                (viewBinding.spinnerEqpState.selectedItem as SpinnerItem).key
            else
                eqpStatus.substring(0, eqpStatus.indexOf(" "))

            val sendMessage = MessageFactoryUtil.eqpDownCode(DeviceInfo.FACILITY, status, eqpId)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.EQPDOWNCODE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val downCodeList =
                    ResponseDataToJsonUtil.getMessageBodyList(result, "DOWNCODEITEMS")
                val itemList = arrayListOf<SpinnerItem>()
                for (row in 0 until downCodeList.length()) {
                    val downCode = downCodeList.getJSONObject(row).optString("EQPDOWNCODE")
                    val downCodeDesc = downCodeList.getJSONObject(row).optString("EQPDOWNDESC")

                    itemList.add(SpinnerItem(downCode, "$downCode  $downCodeDesc"))
                }

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerDownCode.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                if (first) {
                    for (item in itemList) {
                        if (item.toString() == currentEQPDownCode) {
                            viewBinding.spinnerDownCode.setSelection(itemList.indexOf(item) + 1)
                            break
                        }
                    }

                    first = false
                } else {
                    ///if (itemList.size == 1)
                    //    viewBinding.spinnerDownCode.setSelection(1, false)
                    //이전에는 무조건 Item
                    // 가동중 또는 비부하 다운일경우 첫번째 ITEM이 선택되도록 변경 2022.01.05
                    if(status =="R"|| status == "C") {
                        viewBinding.spinnerDownCode.setSelection(1, false)
                    }
                    else if (itemList.size == 1) {
                        viewBinding.spinnerDownCode.setSelection(1, false)
                    }
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }
}