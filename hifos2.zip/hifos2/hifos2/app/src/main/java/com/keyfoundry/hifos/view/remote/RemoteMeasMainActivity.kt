package com.keyfoundry.hifos.view.remote

import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.BarcodeStyle
import com.keyfoundry.hifos.config.utils.CommonUtil
import com.keyfoundry.hifos.config.utils.GridService
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityRemoteMeasMainBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class RemoteMeasMainActivity : HFActivity() {
    companion object {
        private const val TAG = "RemoteMeasMainActivity"
    }
    lateinit var viewBinding: ActivityRemoteMeasMainBinding
    private lateinit var gridService: GridService

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var mainEqpId = "";
    private var mainModel = "";

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityRemoteMeasMainBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)
        gridService = GridService(applicationContext)


        viewBinding.txtMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.txtMachine.setOnEditorActionListener(editorActionListener)
        viewBinding.btnSearchIngMachine.setOnClickListener(onSingleClickListener)

    }

    private val activityFactoryResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                //setEQPList()
            }
        }



    private fun clearEqpInfo() {
        mainEqpId = ""
        mainModel = ""
    }

    private fun showAITActivity(Eqpid : String) {
        val RemoteAITActivityIntent = Intent(this, RemoteAITActivity::class.java)


        RemoteAITActivityIntent.putExtra("Eqpid", Eqpid)
        activityFactoryResultLauncher.launch(RemoteAITActivityIntent)
    }

    private fun showXRFActivity(Eqpid : String) {
        val RemoteXrfActivityIntent = Intent(this, RemoteXrfActivity::class.java)


        RemoteXrfActivityIntent.putExtra("Eqpid", Eqpid)
        activityFactoryResultLauncher.launch(RemoteXrfActivityIntent)
    }

    private fun showAEGISActivity(Eqpid : String) {
        val RemoteAegisActivityIntent = Intent(this, RemoteAegisActivity::class.java)


        RemoteAegisActivityIntent.putExtra("Eqpid", Eqpid)
        activityFactoryResultLauncher.launch(RemoteAegisActivityIntent)
    }

    private fun checkEqpType() {
        mainScope.launch {

            CommonUtil.hideKeyboard(this@RemoteMeasMainActivity, currentFocus)


            if (viewBinding.txtMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "장비명을 입력하여 주세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage =
                MessageFactoryUtil.XrfEqpTypeCheck(viewBinding.txtMachine.text.toString())

            val message =
                MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.XRFEQPTYPECHECK
                )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {

                val itemsListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "ITEMS")
                for (i in 0 until itemsListJSON.length()) {
                    val items = itemsListJSON.getJSONObject(i)
                    mainModel = items.getString("MODEL")
                    mainEqpId = items.getString("MAINEQPID")
                }

                if(mainModel.contains("AIT")) {
                    showAITActivity(mainEqpId)
                    return@launch
                }
                else if(mainModel.contains("AEGIS")) {
                    showAEGISActivity(mainEqpId)
                    return@launch
                }
                else {
                    showXRFActivity(mainEqpId)
                    return@launch
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
        clearEqpInfo()
    }

    private val editorActionListener =
        TextView.OnEditorActionListener { v: TextView?, actionId: Int, event: KeyEvent? ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                when (v?.id) {
                    viewBinding.txtMachine.id -> {
//                        val check = BarcodeStyle(this).eqpId(viewBinding.txtMachine)
//
//                        if (check)
                          checkEqpType()
//
//                        viewBinding.txtMachine.requestFocus()
//                        viewBinding.txtMachine.selectAll()
                    }

                }
            } else if (event != null) { // Barcode Event
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    when (v?.id) {
                        viewBinding.txtMachine.id -> {
                            val check = BarcodeStyle(this).eqpId(viewBinding.txtMachine)
                            if (check)
                                checkEqpType()
                        }
                    }
                }
            }
            true
        }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchIngMachine.id -> {
                    checkEqpType()
                }
            }
        }
    }
}