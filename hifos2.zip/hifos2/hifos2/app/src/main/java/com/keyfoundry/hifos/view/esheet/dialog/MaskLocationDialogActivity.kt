package com.keyfoundry.hifos.view.esheet.dialog

import android.content.Context
import android.os.Bundle
import android.os.Vibrator
import android.text.InputFilter
import android.view.KeyEvent
import android.view.View
import android.view.Window
import android.view.inputmethod.EditorInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.BarcodeStyle
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityMaskLocationDialogBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDailogAlram
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MaskLocationDialogActivity : HFActivity() {

    private lateinit var viewBinding: ActivityMaskLocationDialogBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    var sLOTID = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setFinishOnTouchOutside(false)

        viewBinding = ActivityMaskLocationDialogBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        viewBinding.editSelectMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        viewBinding.editSelectMachine.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                val check = BarcodeStyle(this).eqpId(viewBinding.editSelectMachine)

                var checkCount = 0
                for (count in viewBinding.editSelectMachine.text.toString().indices) {
                    if (viewBinding.editSelectMachine.text.toString()[count] == '-')
                        checkCount++
                }
                if (checkCount == 2 ) {
                    val tempEqpId = viewBinding.editSelectMachine.text.toString().substring(0, viewBinding.editSelectMachine.text.toString().length - 2)
                    viewBinding.editSelectMachine.setText(tempEqpId)
                }

                if( viewBinding.editSelectMachine.text.contains("02-"))
                    viewBinding.editSelectMachine.setText( viewBinding.editSelectMachine.text.toString().replace("02-","01-",false))
                funcSampleCheck()
            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).eqpId(viewBinding.editSelectMachine)

                    var checkCount = 0
                    for (count in viewBinding.editSelectMachine.text.toString().indices) {
                        if (viewBinding.editSelectMachine.text.toString()[count] == '-')
                            checkCount++
                    }
                    if (checkCount == 2 ) {
                        val tempEqpId = viewBinding.editSelectMachine.text.toString().substring(0, viewBinding.editSelectMachine.text.toString().length - 2)
                        viewBinding.editSelectMachine.setText(tempEqpId)
                    }

                    if( viewBinding.editSelectMachine.text.contains("02-"))
                        viewBinding.editSelectMachine.setText( viewBinding.editSelectMachine.text.toString().replace("02-","01-",false))

                    funcSampleCheck()
                }
            }
            true
        }

        if (intent.getStringExtra("MASKTAG")?.isNotEmpty() == true) {
            viewBinding.txtMaskTag.text = intent.getStringExtra("MASKTAG")
            viewBinding.txtProductName.text = intent.getStringExtra("PRODUCT")
            viewBinding.txtGIBEN.text = intent.getStringExtra("GIBEN")
            viewBinding.txtStatus.text = intent.getStringExtra("STATUS")
            viewBinding.txtIsuse.text = intent.getStringExtra("ISUSE")
            viewBinding.txtCurrentLocation.text = intent.getStringExtra("CURRENTLOC")
            viewBinding.txtSubMachine.text = intent.getStringExtra("SUBLOCATION3")
            viewBinding.txtTestHour.text = intent.getStringExtra("AFTERINSP")
            sLOTID = intent.getStringExtra("LOTID").toString()
        }

        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                when (it) {
                    viewBinding.btnOk -> {
                        finish()
                    }
                }
            }
        })

        viewBinding.btnSample.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                when (it) {
                    viewBinding.btnSample -> {
                        funcSampleCheck()
                    }
                }
            }
        })
    }

    private fun funcSampleCheck()
    {
        mainScope.launch {
            var sLOCATION = "";
            if(viewBinding.editSelectMachine.text.toString().isEmpty()) {
                if (viewBinding.txtCurrentLocation.text.contains("투광기"))
                    sLOCATION = viewBinding.txtSubMachine.text.toString();
                else
                    sLOCATION = viewBinding.txtCurrentLocation.text.toString();
            }
            else
                sLOCATION = viewBinding.editSelectMachine.text.toString()

            if(sLOTID.isEmpty())
                return@launch
            if( sLOCATION.isEmpty())
                return@launch

            val sendMessage = MessageFactoryUtil.checkPhotoSample(
                sLOTID, sLOCATION
            )
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.CHECKPHOTOSAMPLE
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                viewBinding.txtSample.text = messageBody.optString("RET")
                viewBinding.txtTree.text  = messageBody.optString("ALIGN")
                viewBinding.txtGRADE.text  = messageBody.optString("GRADE")
                viewBinding.txtETCHRW.text  = messageBody.optString("ETCH_RW")

                var sSTOP =  messageBody.optString("STOP")
                if(sSTOP.isNotEmpty())
                {
                    OkDialog.show(
                        supportFragmentManager, "공정 중단",
                        sSTOP, GetString.BTNOKSTR
                    )
                }
            } else {

            }
        }
    }

    override fun onBackPressed() {
        return
    }
}