package com.keyfoundry.hifos.view.wafercode

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputFilter
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.TextView
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityWafercodecheckBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class Wafercodecheck : HFActivity() {
    companion object {
        private const val TAG = "WaferCodeChek"
    }
    private lateinit var viewBinding: ActivityWafercodecheckBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityWafercodecheckBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editInitialboxNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editRunboxNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        viewBinding.editInitialboxNo.setOnEditorActionListener(editorActionListener)
        viewBinding.editRunboxNo.setOnEditorActionListener(editorActionListener)
        viewBinding.btnSearchInitialNo.setOnClickListener(onSingleClickListener)
        viewBinding.btnSearchRunNo.setOnClickListener(onSingleClickListener)
        viewBinding.btnWafer.setOnClickListener(onSingleClickListener)
        viewBinding.btnClose.setOnClickListener(onSingleClickListener)

        viewBinding.spinnerReason.isEnabled = false
       // viewBinding.spinnerReason.onItemSelectedListener = selectItemListener

    }

    private val editorActionListener = TextView.OnEditorActionListener { v, actionId, event ->
        when(v.id){
            viewBinding.editInitialboxNo.id ->{
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    getinitialInfo()
                  viewBinding.editRunboxNo.selectAll()
                } else if (event != null) {
                    if(actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER){
                        getinitialInfo()
                    }
                }
            }
            viewBinding.editRunboxNo.id ->{
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val check = BarcodeStyle(this).lotId(viewBinding.editRunboxNo) //공백이 없으니 확인요망
                    if(check)
                        getWaferInfo()
                } else if (event != null){
                    if(actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER){
                        val check = BarcodeStyle(this).lotId(viewBinding.editRunboxNo)
                        if(check)
                            getWaferInfo()
                    }
                }
            }
        }
        true
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id){
                viewBinding.btnSearchInitialNo.id -> {
                    getinitialInfo()
                }
                viewBinding.btnSearchRunNo.id -> {
                    getWaferInfo()
                }
                viewBinding.btnWafer.id -> {
                    executewf()
                }
                viewBinding.btnClose.id ->{
                    finish()
                }

            }
        }
    }


    private  fun getinitialInfo(){
        mainScope.launch {
            CommonUtil.hideKeyboard(this@Wafercodecheck, currentFocus)
            if (viewBinding.editInitialboxNo.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, "ERROR",
                    "INITIAL BOX 이름을입력하여 주세요.", GetString.BTNOKSTR
                )
            }
                viewBinding.txtInitialName.text = viewBinding.editInitialboxNo.text
                viewBinding.editInitialboxNo.text.clear()
                viewBinding.btnWafer.requestFocus()

        }
    }

    private fun getWaferInfo() {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@Wafercodecheck, currentFocus)
            viewBinding.txtLotName.text = ""
            viewBinding.txtWaferName.text = ""

            if (viewBinding.editRunboxNo.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, "ERROR",
                    "RUN NAME을 입력하여 주세요.", GetString.BTNOKSTR
                )
                viewBinding.editRunboxNo.requestFocus()
                viewBinding.editRunboxNo.selectAll()

            }
            val sendMessage =
                MessageFactoryUtil.getWaferTYpe(viewBinding.editRunboxNo.text.toString())
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.GETWAFERTYPE)

            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val ItemList =
                    ResponseDataToJsonUtil.getMessageBodyList(result, "ITEMS")
                val lotID =  ItemList.getJSONObject(0).optString("LOTNAME")
                val WaferType = ItemList.getJSONObject(0).optString("WAFERTYPE")

                viewBinding.txtLotName.text = lotID
                viewBinding.txtWaferName.text = WaferType
                viewBinding.editRunboxNo.text.clear()

                val CommentListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "COMMNETLIST")
                val spinnerCommentItems = arrayListOf<String>()

                for (count in 0 until CommentListJSON.length()){
                    val commengroup = CommentListJSON.getJSONObject(count)
                    spinnerCommentItems.add(commengroup.getString("TYPEVALUE"))
                }

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, spinnerCommentItems)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerReason.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                viewBinding.spinnerReason.isEnabled = true

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.txtLotName.text = ""
                viewBinding.txtWaferName.text = ""
                viewBinding.editRunboxNo.text.clear()
                viewBinding.spinnerReason.isEnabled = false
                viewBinding.editRunboxNo.requestFocus()
                return@launch
            }
            viewBinding.editInitialboxNo.requestFocus()
        }
    }

    private fun executewf(){
        mainScope.launch {
            CommonUtil.hideKeyboard(this@Wafercodecheck, currentFocus)
            //var sCommentTemp = viewBinding.spinnerReason.selectedItem.toString()
            if (viewBinding.txtInitialName.text.isEmpty()&& viewBinding.spinnerReason.isEnabled == false ) {

                val returnCode = OkCancelDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_INFORM,
                    "INITIALBOX내용이 확인되지 않습니다.\n" +
                            "진행 하시겠습니까?",
                    GetString.BTNYESSTR,
                    GetString.BTNNOSTR
                )
                if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                    return@launch
                }

                viewBinding.editRunboxNo.requestFocus()
                viewBinding.editRunboxNo.selectAll()
            }

            if(viewBinding.txtLotName.text.isEmpty()){
                OkDialog.show(
                    supportFragmentManager, "ERROR",
                    "RUN NAME이 확인되지 않습니다.", GetString.BTNOKSTR
                )
                viewBinding.editRunboxNo.requestFocus()
                viewBinding.editRunboxNo.selectAll()
                return@launch
            }

            if(viewBinding.txtWaferName.text.isEmpty()){
                OkDialog.show(
                    supportFragmentManager, "ERROR",
                    "WAFERTYPE이 확인되지 않습니다.", GetString.BTNOKSTR
                )
                viewBinding.editRunboxNo.requestFocus()
                viewBinding.editRunboxNo.selectAll()
                return@launch
            }

            var  sComment = ""
            if (viewBinding.spinnerReason.selectedItem != null)
            {
                sComment = viewBinding.spinnerReason.selectedItem.toString()
            }

            val sendMessage = MessageFactoryUtil.ComPareWaferType(viewBinding.txtLotName.text.toString(),
                                    viewBinding.txtWaferName.text.toString(),viewBinding.txtInitialName.text.toString(),
                                    sComment, DeviceInfo.OPERATOR_ID)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.COMPAREWAFERTYPE)

            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val compareResult = messageBody.optString("COMPARERESULT")

                if(compareResult == "NG")
                {
                    OkDialog.show(
                        supportFragmentManager, "확 인",
                        "WAFER자재 확인에 실패 하였습니다.", GetString.BTNOKSTR
                    )
                }
                else
                {
                    OkDialog.show(
                        supportFragmentManager, "확 인",
                        "정상처리 되었습니다.", GetString.BTNOKSTR
                    )
                    viewBinding.txtLotName.text = ""
                    viewBinding.txtInitialName.text =""
                    viewBinding.txtWaferName.text = ""
                    viewBinding.spinnerReason.isEnabled = false
                    viewBinding.editRunboxNo.requestFocus()
                    viewBinding.editRunboxNo.selectAll()

                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }
}