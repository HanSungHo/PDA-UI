package com.keyfoundry.hifos.view.dialog.fragment

import android.app.Dialog
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.*
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.service.RetrofitSyncService
import com.keyfoundry.hifos.config.service.dto.ErrorData
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/*
* 동기방식 Dialog
* 확인 버튼을 클릭하기 전까지 뒤에오는 코드를 실행하지 않는다.
* */
class OkDialog : DialogFragment() {

    companion object {
        private const val TAG = "OkDialog"
        const val RETURN_CODE_OK = 1

        private var RETURN_VALUE = 0

        private var checkLooper = false

        private var txtDialogTitle = ""
        private var txtDialogContent = ""
        private var btnOkStr = ""
        lateinit var okHandler: OkHandler
        fun okHandlerInitialized() = ::okHandler.isInitialized

        fun show(
            supportFragmentManager: FragmentManager,
            txtDialogTitle: String,
            txtDialogContent: String,
            btnOkStr: String
        ): Int {
            Log.d(TAG, "show")
            this.txtDialogTitle = txtDialogTitle
            this.txtDialogContent = txtDialogContent
            this.btnOkStr = btnOkStr

            okHandler = OkHandler()

            val okDialog = OkDialog()

            try {
                okDialog.show(supportFragmentManager, TAG)
                checkLooper = true
                Looper.loop()
            } catch (e: Exception) {
                checkLooper = false
                Log.e(TAG, "${e.message}")
            }

            Log.e("RETURN VALUE", RETURN_VALUE.toString())
            return RETURN_VALUE
        }

        class OkHandler : Handler(Looper.myLooper()!!) {
            override fun handleMessage(msg: Message) {
                Log.d(TAG, "handleMessage : $msg")
                if(checkLooper) {
                    throw RuntimeException()
                }
            }
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return object : Dialog(requireActivity(), theme) {
            override fun onBackPressed() {
                RETURN_VALUE = RETURN_CODE_OK
                val m: Message = okHandler.obtainMessage()
                okHandler.sendMessage(m)
                dialog?.dismiss()
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.d(TAG, "onCreateView")
        val view = inflater.inflate(R.layout.fragment_dialog_ok, container, false)

        dialog?.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog?.setCancelable(false)

        val dialogTitle = view.findViewById<TextView>(R.id.txt_dialog_title)
        val dialogContent = view.findViewById<TextView>(R.id.txt_dialog_content)
        val btnOk = view.findViewById<Button>(R.id.btn_ok)

        dialogTitle.text = txtDialogTitle
        dialogContent.text = txtDialogContent
        dialogContent.movementMethod = ScrollingMovementMethod()
        btnOk.text = btnOkStr



        btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {

                //위에서 초기화가 안되있을경우 여기서 한번더 초기화하도록 수정 2021-12-02
                if(!okHandlerInitialized()) {
                    okHandler = OkHandler()
                }

                RETURN_VALUE = RETURN_CODE_OK
                val m: Message = okHandler.obtainMessage()
                okHandler.sendMessage(m)
                dialog?.dismiss()
            }
        })

        return view
    }
}