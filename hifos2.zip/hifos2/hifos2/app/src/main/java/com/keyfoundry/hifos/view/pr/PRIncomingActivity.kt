package com.keyfoundry.hifos.view.pr


import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityPrIncomingBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class PRIncomingActivity : HFActivity() {

    companion object {
        private const val TAG = "PRIncomingActivity"
    }

    private lateinit var viewBinding: ActivityPrIncomingBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    lateinit var sPRID: String
    lateinit var sVISCOSITY: String
    lateinit var sPRLOTNO: String
    lateinit var sVALIDDATE: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityPrIncomingBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.editPumpId.setOnEditorActionListener { textView, i, keyEvent ->
            if (i == EditorInfo.IME_ACTION_DONE) {
                setData()
            }
            if (keyEvent != null) {
                if (keyEvent.action == KeyEvent.ACTION_UP && keyEvent.keyCode == KeyEvent.KEYCODE_ENTER) {
                    setData()
                }
            }
            true
        }

        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnClose.setOnClickListener(onSingleClickListener)
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnOk.id -> {
                    executeInput()
                }
                viewBinding.btnClose.id -> {
                    finish()
                }
            }
        }
    }

    private fun executeInput() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.prInput(
                viewBinding.txtPrId.text.toString(), viewBinding.txtProductName.text.toString(),
                viewBinding.txtVendor.text.toString(), viewBinding.txtViscosity.text.toString(),
                viewBinding.txtLotNo.text.toString(), viewBinding.txtExpDate.text.toString(),
                DeviceInfo.OPERATOR_ID, DeviceInfo.OPERATOR_NAME
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.PRINPUT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                viewBinding.editPumpId.setText("")
                clearData()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

                viewBinding.editPumpId.setText("")
                clearData()
            }
        }
    }

    private fun setData() {
        if (viewBinding.editPumpId.text.toString().replace(" ", "") == "") {  // 공백 CHECK
            OkDialog.show(
                supportFragmentManager, "READING ERROR", "PUMP ID가 확인되지 않습니다.", GetString.BTNOKSTR
            )
        } else {
            val sinPR = viewBinding.editPumpId.text.toString()
            sPRID = sinPR.substring(0, 4)
            sVISCOSITY = sinPR.substring(4, 8)

            when (sinPR.length) {
                25 -> {
                    sPRLOTNO = sinPR.substring(14, 19)
                    sVALIDDATE = sinPR.substring(19)
                }
                28 -> {
                    sPRLOTNO = sinPR.substring(14, 19) + sinPR.substring(19, 22)
                    sVALIDDATE = sinPR.substring(22)
                }
                29 -> {
                    sPRLOTNO = sinPR.substring(14, 20) + "-" + sinPR.substring(19, 22)
                    sVALIDDATE = sinPR.substring(23)
                }
                else -> {
                    OkDialog.show(
                        supportFragmentManager, "READING ERROR",
                        "BARCODE형식이 일치하지 않습니다. 교체할 PR병의 BARCODE를 다시 읽어주세요.", GetString.BTNOKSTR
                    )
                    return
                }
            }

            getPRInfo(sPRID, sPRLOTNO, sVISCOSITY, sVALIDDATE)
        }
    }

    private fun getPRInfo(prId: String, prLotNo: String, viscosity: String, validDate: String) {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.getPrInfo(prId, prLotNo, viscosity, validDate)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.PRINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val sPrcomp = messageBody.optString("PRCOMP")
                val sPrDesc = messageBody.optString("PRDESC")

                viewBinding.txtPrId.text = prId
                viewBinding.txtLotNo.text = prLotNo
                viewBinding.txtProductName.text = sPrDesc
                viewBinding.txtExpDate.text = validDate
                viewBinding.txtViscosity.text = viscosity
                viewBinding.txtVendor.text = sPrcomp
                viewBinding.btnOk.isEnabled = true
                // viewBinding.btnOk.requestFocus()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearData() {
        viewBinding.txtPrId.text = ""
        viewBinding.txtLotNo.text = ""
        viewBinding.txtProductName.text = ""
        viewBinding.txtExpDate.text = ""
        viewBinding.txtViscosity.text = ""
        viewBinding.txtVendor.text = ""
        viewBinding.btnOk.isEnabled = false
    }
}