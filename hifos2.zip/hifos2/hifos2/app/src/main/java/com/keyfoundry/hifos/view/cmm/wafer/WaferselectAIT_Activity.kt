package com.keyfoundry.hifos.view.cmm.wafer

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.view.View
import android.widget.Button
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivityWaferselectAitBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import java.text.DecimalFormat


class WaferselectAIT_Activity : HFActivity() {
    init {
        this.update = false
    }

    companion object {
        private const val TAG = "WaferselectAITActivity"
    }

    private lateinit var viewBinding: ActivityWaferselectAitBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var selectWafer: SelectWafer

    private var fixedCount = 0
    private var sequence = ""
    private var createCategoryDummy = ""
    private var selectedMachine = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityWaferselectAitBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.txtWaferList.movementMethod = ScrollingMovementMethod.getInstance()

        sequence = intent.getStringExtra("SEQUENCE").toString()

        if (intent.getStringExtra("FIXEDCOUNT")?.isNotEmpty() == true)
            fixedCount = intent.getStringExtra("FIXEDCOUNT")!!.toInt()

        selectWafer = SelectWafer(fixedCount)

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()
            viewBinding.editLotNo.setText(lotId)
        }

        var editable = true
        if (intent.getStringExtra("EDITABLE")?.isNotEmpty() == true) {
            val edit = intent.getStringExtra("EDITABLE").toString()

            if (edit == "N") {
                setInvisibleButton()
                editable = false
            }
        }

        if (intent.getStringExtra("CATEGORY")?.isNotEmpty() == true)
            createCategoryDummy = intent.getStringExtra("CATEGORY").toString()

        if (createCategoryDummy != "COUNT" && intent.getStringExtra("EXISTWAFERLIST")
                ?.isNotEmpty() == true
        ) {
            val existWaferList = intent.getStringExtra("EXISTWAFERLIST")
            val disableWaferList = intent.getStringExtra("DISABLEWAFERLIST")
            val selectWaferList = intent.getStringExtra("SELECTWAFERLIST")

            setWaferButtonList(existWaferList, editable, disableWaferList, selectWaferList)
        }

        //setDisable()

        viewBinding.btnSelectAll.setOnClickListener(onSingleClickListener)
        viewBinding.btnModify.setOnClickListener(onSingleClickListener)
        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
    }

//    private val editorActionListener =
//        TextView.OnEditorActionListener { v, actionId, event ->
//            if (actionId == EditorInfo.IME_ACTION_DONE) {
//                val check = BarcodeStyle(this).eqpId(viewBinding.editMachineName)
//
//                if (check)
//                    getDummyCMachineInfo(viewBinding.editMachineName.text.toString())
//            } else if (event != null) {
//                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
//                    val check = BarcodeStyle(this).eqpId(viewBinding.editMachineName)
//
//                    if (check)
//                        getDummyCMachineInfo(viewBinding.editMachineName.text.toString())
//                }
//            }
//
//            true
//        }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSelectAll.id -> {
                    selectAll()
                }
                viewBinding.btnModify.id -> {
                    resetWafer()
                }
                viewBinding.btnOk.id -> {
                    sendWaferList()
                }
                viewBinding.btnCancel.id -> {
                    cancel()
                }
            }
        }
    }

    private fun selectAll() {
        var realCount = fixedCount - selectWafer.currentCount

        if (realCount == 0) {
            for (count in 0 until viewBinding.rcWaferList.childCount) {
                val waferButton =
                    viewBinding.rcWaferList.layoutManager?.findViewByPosition(count) as Button

                if (waferButton.isEnabled && waferButton.isSelected) {
                    waferButton.performClick()
                    realCount++
                }
            }
        } else {
            for (count in 0 until viewBinding.rcWaferList.childCount) {
                val waferButton =
                    viewBinding.rcWaferList.layoutManager?.findViewByPosition(count) as Button

                if (waferButton.isEnabled && !waferButton.isSelected && realCount > 0) {
                    waferButton.performClick()
                    realCount--
                }
            }
        }
    }

    private fun resetWafer() {
        var realCount = selectWafer.currentCount

        for (count in 0 until viewBinding.rcWaferList.childCount) {
            val waferButton =
                viewBinding.rcWaferList.layoutManager?.findViewByPosition(count) as Button

            if (waferButton.isEnabled && waferButton.isSelected && realCount > 0) {
                waferButton.performClick()
                realCount--
            }
        }
    }

    private fun sendWaferList() {
        val returnIntent = Intent()
        returnIntent.putExtra("SEQUENCE", sequence)
        returnIntent.putExtra("SELECTEDWAFERLIST", viewBinding.txtWaferList.text.toString())
        returnIntent.putExtra("SELECTEDMACHINE", selectedMachine)

        setResult(Activity.RESULT_OK, returnIntent)

        finish()
    }

    private fun cancel() {
        val returnIntent = Intent()
        setResult(Activity.RESULT_CANCELED, returnIntent)

        finish()
    }

    private fun setWaferButtonList(
        waferList: String?, editable: Boolean, disableList: String?, selectList: String?
    ) {
        if (waferList != null) {
            val slotMap = makeSlotMapList(waferList)
            viewBinding.rcWaferList.layoutManager =
                object : GridLayoutManager(this, 5, LinearLayoutManager.VERTICAL, false) {
                    override fun canScrollVertically(): Boolean {
                        return false
                    }
                }

            viewBinding.rcWaferList.adapter = WaferAdapter(
                this, slotMap, editable,
                disableList, selectList, selectWafer, supportFragmentManager
            )
        }
    }

    private fun setInvisibleButton() {
        viewBinding.btnSelectAll.visibility = View.INVISIBLE
        viewBinding.btnModify.visibility = View.GONE
        viewBinding.btnOk.visibility = View.GONE

        viewBinding.editLotNo.isEnabled = false
    }

    private fun makeSlotMapList(waferString: String): MutableList<WaferInfo> {
        val waferList = waferString.split(",")
        val wafercount = waferList.count(); //요기서 수정을 해야함.
        var value = ""
        var key = ""
        val slotMapList = mutableListOf<WaferInfo>()
        var bresult = false

        var slotIndex = 0
        for (i in 1..25) {

            if(wafercount < i) {
                value = ""
                key = ""
            }
            else {
                key = waferList[slotIndex]
                value = key.substring(key.lastIndexOf(".") + 1, key.length)
            }

            //val key = waferList[slotIndex]
            //val value = key.substring(key.lastIndexOf(".") + 1, key.length)

            val df = DecimalFormat("00")
            val buttonIndex = df.format(i)

            bresult = false
            for(iw in 0..wafercount-1) {
                var tempkey = waferList[iw]
                var tempvalue =  tempkey.substring(tempkey.lastIndexOf(".") + 1, tempkey.length)

                if(buttonIndex == tempvalue) {
                    key = waferList[iw]
                    value = key.substring(key.lastIndexOf(".") + 1, key.length)
                    bresult = true
                }
            }

            if(!bresult)
            {
                value = ""
                key = ""
            }

            if(value == buttonIndex.toString()){
                val waferInfo = WaferInfo(key, buttonIndex.toString())
                waferInfo.machine = ""
                slotMapList.add(waferInfo)
                slotIndex++
            } else {
                val waferInfo = WaferInfo("empty", buttonIndex.toString())
                waferInfo.machine = ""
                slotMapList.add(waferInfo)
            }
        }

        return slotMapList
    }
}
