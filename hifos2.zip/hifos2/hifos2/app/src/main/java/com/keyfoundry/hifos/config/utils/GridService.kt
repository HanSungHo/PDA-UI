package com.keyfoundry.hifos.config.utils

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ShapeDrawable
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.core.view.GestureDetectorCompat
import androidx.core.view.children
import androidx.core.view.setPadding
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.grid.*
import org.json.JSONArray
import java.util.*
import kotlin.collections.HashMap

/*
* 그리드 관련 서비스를 제공하는 class
* */
class GridService(val context: Context) {
    fun getColumnNameList(itemList: JSONArray): MutableList<String> {
        return itemList.getJSONObject(0).keys().asSequence().toMutableList()
    }

    // 선택한 grid의 데이터를 추출하는 함수
    fun getCellValue(v: View, columnName: String): String {
        val rowData = v.tag as RowData
        val dataList = rowData.rowDataList

        return dataList[columnName].toString()
    }

    fun getCellValue(v: CTRowLayout, columnIndex: Int): String =
        (v.getChildAt(columnIndex) as TextView).text.toString()

    // 컬럼의 Index를 추출 하는 함수
    fun getColumnIndex(dataTable: CTMainLayout, columnName: String): Int {
        val columnRow = dataTable.columnHeaderTable.getChildAt(0) as TableRow
        val columnList = columnRow.tag as MutableList<*>

        return columnList.indexOf(columnName)
    }

    fun getCurrentRow(dataTable: CTMainLayout): CTRowLayout {
        val mainTable = dataTable.mainTable

        return mainTable.getChildAt(mainTable.currentRowIndex) as CTRowLayout
    }

    // Set ColumnData in Row
    class RowData(val rowDataList: HashMap<String, Any>)

    // GridLayout을 만들어 주는 함수
    fun setGridPropData(
        columnMap: LinkedHashMap<String, ColumnProperty>,
        dataTable: JSONArray
    ): CTMainLayout {
        val bodyLayout = CTMainLayout(context)

        val columnNameList = this.getColumnNameList(dataTable)

        val columnHeaderList = CTSubLayout(context, GridType.COLUMN_GRID)
        val rowHeaderList = CTSubLayout(context, GridType.ROW_GRID)
        val mainBodyList = CTSubLayout(context, GridType.MAIN_GRID)
        val cornerHeaderList = CTSubLayout(context, GridType.CORNER_GRID)

        var fixedRow = false

        for (row in 0 until dataTable.length()) {
            val mainBodyRow = CTRowLayout(context)
            mainBodyRow.setBackgroundResource(R.drawable.rowcolor)
            mainBodyRow.isFocusableInTouchMode = true

            val rowHeaderRow = CTRowLayout(context)
            rowHeaderRow.setBackgroundResource(R.drawable.rowcolor)
            rowHeaderRow.isFocusableInTouchMode = true

            val cornerHeaderRow = CTRowLayout(context)
            cornerHeaderRow.setBackgroundColor(Color.parseColor("#e9edef"))

            val columnHeaderRow = CTRowLayout(context)
            columnHeaderRow.setBackgroundColor(Color.parseColor("#e9edef"))
            val columnValueList = mutableListOf<String>()

            val colDataMap = HashMap<String, Any>()
            for (columnName in columnNameList)
                colDataMap[columnName.toUpperCase(Locale.ROOT)] =
                    dataTable.getJSONObject(row).optString(columnName)

            mainBodyRow.tag = RowData(colDataMap)

            for (columnName in columnMap.keys) {
                val property = columnMap[columnName] as ColumnProperty
                val columnValue = property.columnVale
                val columnGravity = property.gravity
                val fixed = property.fixed

                val editable = property.editable
                val columnSize = property.columnSize
                val backColor = property.backColor
                val textColor = property.textColor

                // 컬럼헤더 데이터 등록=============================================
                if (columnHeaderList.childCount == 0) {
                    val columnItem = TextView(context)

                    columnItem.gravity = Gravity.CENTER
                    columnItem.setPadding(10)
                    columnItem.setBackgroundResource(R.drawable.cellsharp)
                    setBodyCellColor(columnItem, Color.parseColor("#00000000"))
                    columnItem.text = columnValue
                    columnItem.isSingleLine = true
                    columnItem.setTextColor(Color.parseColor("#808080"))
                    columnValueList.add(columnName.toUpperCase(Locale.ROOT))

                    if (fixed) {
                        cornerHeaderRow.addView(columnItem)

                        if (!fixedRow)
                            fixedRow = true
                    } else {
                        columnHeaderRow.addView(columnItem)
                    }

                    val columnParameter = columnItem.layoutParams
                    columnParameter.width = columnSize
                    columnItem.layoutParams = columnParameter
                }
                // ==========================================================

                // MainTable의 Cell데이터 등록====================================
                var bodyItem = TextView(context)
                if (editable)
                    bodyItem = EditText(context)
                bodyItem.gravity = columnGravity
                bodyItem.setPadding(10)
                bodyItem.isSingleLine = true
                bodyItem.setBackgroundResource(R.drawable.cellsharp)

                setBodyCellColor(bodyItem, backColor)
                bodyItem.setTextColor(textColor)

                val itemValue = dataTable.getJSONObject(row).optString(columnName)
                bodyItem.text = itemValue

                if (fixed)
                    rowHeaderRow.addView(bodyItem)
                else
                    mainBodyRow.addView(bodyItem)

                val bodyParameter = bodyItem.layoutParams
                bodyParameter.width = columnSize
                bodyItem.layoutParams = bodyParameter

                // ==========================================================
            }

            // MainTable의 Row데이터 등록====================================
            rowHeaderList.addView(rowHeaderRow)
            mainBodyList.addView(mainBodyRow)

            // ColumnHeader 데이터 등록
            if (columnHeaderList.childCount == 0) {
                columnHeaderRow.tag = columnValueList
                columnHeaderList.addView(columnHeaderRow)
            }

            if (cornerHeaderList.childCount == 0) {
                cornerHeaderRow.tag = columnValueList
                cornerHeaderList.addView(cornerHeaderRow)
            }
        }

        if (fixedRow)
            bodyLayout.addViews(mainBodyList, columnHeaderList, rowHeaderList, cornerHeaderList)
        else
            bodyLayout.addViews(mainBodyList, columnHeaderList)

        return bodyLayout
    }

    fun setGridPropData(
        columnMap: LinkedHashMap<String, ColumnProperty>,
        dataTable: JSONArray, colRowColor: Int, colTextColor: Int
    ): CTMainLayout {
        val bodyLayout = CTMainLayout(context)

        val columnNameList = this.getColumnNameList(dataTable)

        val columnHeaderList = CTSubLayout(context, GridType.COLUMN_GRID)
        val rowHeaderList = CTSubLayout(context, GridType.ROW_GRID)
        val mainBodyList = CTSubLayout(context, GridType.MAIN_GRID)
        val cornerHeaderList = CTSubLayout(context, GridType.CORNER_GRID)

        for (row in 0 until dataTable.length()) {
            val mainBodyRow = CTRowLayout(context)
            mainBodyRow.setBackgroundResource(R.drawable.rowcolor)
            mainBodyRow.isFocusableInTouchMode = true

            val columnHeaderRow = CTRowLayout(context)
            columnHeaderRow.setBackgroundColor(colRowColor)
            val columnValueList = mutableListOf<String>()

            val colDataMap = HashMap<String, Any>()
            for (columnName in columnNameList)
                colDataMap[columnName.toUpperCase(Locale.ROOT)] =
                    dataTable.getJSONObject(row).optString(columnName)

            mainBodyRow.tag = RowData(colDataMap)

            for (columnName in columnMap.keys) {
                val property = columnMap[columnName] as ColumnProperty
                val columnValue = property.columnVale
                val columnGravity = property.gravity
                val editable = property.editable
                val columnSize = property.columnSize

                val backColor = property.backColor
                val textColor = property.textColor

                // 컬럼헤더 데이터 등록=============================================
                if (columnHeaderList.childCount == 0) {
                    val columnItem = TextView(context)

                    columnItem.gravity = Gravity.CENTER
                    columnItem.setPadding(10)
                    columnItem.setBackgroundResource(R.drawable.cellsharp)
                    setBodyCellColor(columnItem, Color.parseColor("#00000000"))
                    columnItem.text = columnValue
                    columnItem.isSingleLine = true
                    columnItem.setTextColor(colTextColor)
                    columnValueList.add(columnName.toUpperCase(Locale.ROOT))

                    columnHeaderRow.addView(columnItem)

                    val columnParameter = columnItem.layoutParams
                    columnParameter.width = columnSize
                    columnItem.layoutParams = columnParameter
                }
                // ==========================================================

                // MainTable의 Cell데이터 등록====================================
                var bodyItem = TextView(context)
                if (editable)
                    bodyItem = EditText(context)
                bodyItem.gravity = columnGravity
                bodyItem.setPadding(10)
                bodyItem.setBackgroundResource(R.drawable.cellsharp)

                setBodyCellColor(bodyItem, backColor)

                bodyItem.setTextColor(textColor)

                val itemValue = dataTable.getJSONObject(row).optString(columnName)
                bodyItem.text = itemValue

                mainBodyRow.addView(bodyItem)

                val bodyParameter = bodyItem.layoutParams
                bodyParameter.width = columnSize
                bodyItem.layoutParams = bodyParameter

                // ==========================================================
            }

            // MainTable의 Row데이터 등록====================================
            mainBodyList.addView(mainBodyRow)

            // ColumnHeader 데이터 등록
            if (columnHeaderList.childCount == 0) {
                columnHeaderRow.tag = columnValueList
                columnHeaderList.addView(columnHeaderRow)
            }

            // RowHeader의 Row데이터 등록====================================
            val rowHeaderRow = CTRowLayout(context)
            val rowItem = TextView(context)
            rowHeaderRow.addView(rowItem)
            rowHeaderList.addView(rowHeaderRow)
            // ==========================================================
        }

        for (col in 0 until columnHeaderList.childCount) {
            val cornerHeaderRow = CTRowLayout(context)

            for (row in 0 until rowHeaderList.childCount) {
                val cornerItem = TextView(context)
                cornerHeaderRow.addView(cornerItem)
            }

            cornerHeaderList.addView(cornerHeaderRow)
        }

        bodyLayout.addViews(mainBodyList, columnHeaderList, rowHeaderList, cornerHeaderList)

        return bodyLayout
    }

    fun setBodyCellColor(bodyItem: View, color: Int) {
        when (val background = bodyItem.background) {
            is ShapeDrawable -> {
                background.paint.color = color
            }
            is GradientDrawable -> {
                background.setColor(color)
            }
            is ColorDrawable -> {
                background.color = color
            }
        }
    }

    fun setResize(
        targetTable: CTSubLayout, gridType: String, gridData: CTMainLayout,
        columnData: LinkedHashMap<String, ColumnProperty>
    ) {
        for (columnRow in targetTable.children) {
            val row = columnRow as CTRowLayout

            for (cell in row.children) {
                val idx = row.indexOfChild(cell)
                val cellTextView = row.getChildAt(idx) as TextView

                val mDetector = GestureDetectorCompat(
                    context,
                    ResizeGestureListener(cellTextView, row, idx, gridData, gridType, columnData)
                )

                cellTextView.setOnTouchListener { v, event ->
                    mDetector.onTouchEvent(event)

                    true
                }
            }
        }
    }

    inner class ResizeGestureListener(
        private val textCell: TextView,
        private val parentRow: CTRowLayout,
        private val index: Int,
        private val mainBodyTable: CTMainLayout,
        private val type: String,
        private val columnData: LinkedHashMap<String, ColumnProperty>
    ) :
        GestureDetector.SimpleOnGestureListener() {
        private var size = 0
        private var first = true
        private lateinit var headerTable: CTSubLayout
        private lateinit var dataTable: CTSubLayout
        private lateinit var subHeaderTable: CTSubLayout
        private lateinit var subDataTable: CTSubLayout

        // 컬럼 사이즈 조절 기능
        override fun onScroll(
            e1: MotionEvent?, e2: MotionEvent?, distanceX: Float, distanceY: Float
        ): Boolean {
            if (type == GridType.CORNER_GRID) {
                headerTable = mainBodyTable.cornerTable
                dataTable = mainBodyTable.rowHeaderTable
                subHeaderTable = mainBodyTable.columnHeaderTable
                subDataTable = mainBodyTable.mainTable
            } else if (type == GridType.COLUMN_GRID) {
                headerTable = mainBodyTable.columnHeaderTable
                dataTable = mainBodyTable.mainTable
            }

            size = textCell.width
            val oriSize = size

            //최대로 줄일 수 있는 사이즈
            if (size - distanceX.toInt() < 20)
                size = 20
            else
                size -= distanceX.toInt()

            parentRow.columnWidths[index] = size

            // 다시 조회할 경우에도 조절한 사이즈 유지하도록 함.
            // ColumnData를 전역변수로 선언하고 사용해야함 ex)eSheet소스 확인
            val oriProperty = columnData[textCell.tag]
            if (oriProperty != null) {
                columnData[textCell.tag.toString()] = ColumnProperty(
                    oriProperty.columnVale, oriProperty.gravity, oriProperty.fixed, size
                )
            }

            val bodyParameter = textCell.layoutParams
            bodyParameter.width = size
            textCell.layoutParams = bodyParameter

            for (subChild in dataTable.children) {
                val subRow = subChild as CTRowLayout
                subRow.columnWidths[index] = size
                val subCell = subRow.getChildAt(index) as TextView
                val subParam = subCell.layoutParams
                subParam.width = size
                subCell.layoutParams = subParam
            }

            if (type == GridType.CORNER_GRID) {
                val measureSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                headerTable.measure(measureSpec, measureSpec)

                val mainTableLayoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
                )

                mainTableLayoutParams.leftMargin = headerTable.measuredWidth
                mainTableLayoutParams.topMargin = headerTable.measuredHeight
                subDataTable.layoutParams = mainTableLayoutParams

                val columnTableLayoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
                )

                columnTableLayoutParams.leftMargin = headerTable.measuredWidth
                subHeaderTable.layoutParams = columnTableLayoutParams
            }

            mainBodyTable.bound.rightBound += (size - oriSize)

            size = oriSize

            return super.onScroll(e1, e2, distanceX, distanceY)
        }

        //기존 더블탭시 공정명 사이즈 조절기능
//        override fun onDoubleTap(e: MotionEvent?): Boolean {
//            if (type == GridType.CORNER_GRID) {
//                headerTable = mainBodyTable.cornerTable
//                dataTable = mainBodyTable.rowHeaderTable
//            } else if (type == GridType.COLUMN_GRID) {
//                headerTable = mainBodyTable.cornerTable
//                dataTable = mainBodyTable.rowHeaderTable
//            }
//
//            if (first) {
//                for (row in headerTable.children) {
//                    val cornerRow = row as CTRowLayout
//
//                    for (cell in cornerRow.children) {
//                        val textCell = cell as TextView
//
//                        val textParams = textCell.layoutParams
//                        textParams.width = ViewGroup.LayoutParams.WRAP_CONTENT
//                        textCell.layoutParams = textParams
//
//                        val measureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
//                        textCell.measure(measureSpec, measureSpec)
//
//                        if (size < textCell.measuredWidth)
//                            size = textCell.measuredWidth
//                    }
//                }
//
//                for (row in dataTable.children) {
//                    val cornerRow = row as CTRowLayout
//
//                    for (cell in cornerRow.children) {
//                        val textCell = cell as TextView
//
//                        val textParams = textCell.layoutParams
//                        textParams.width = ViewGroup.LayoutParams.WRAP_CONTENT
//                        textCell.layoutParams = textParams
//
//                        val measureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
//                        textCell.measure(measureSpec, measureSpec)
//
//                        if (size < textCell.measuredWidth)
//                            size = textCell.measuredWidth
//                    }
//                }
//
//                first = false
//            }
//
//            val oriSize = parentRow.columnWidths[index]
//            parentRow.columnWidths[index] = size
//
//            val bodyParameter = textCell.layoutParams
//            bodyParameter.width = size
//            textCell.layoutParams = bodyParameter
//
//            for (subChild in dataTable.children) {
//                val subRow = subChild as CTRowLayout
//                subRow.columnWidths[index] = size
//                val subCell = subRow.getChildAt(index) as TextView
//                val subParam = subCell.layoutParams
//                subParam.width = size
//                subCell.layoutParams = subParam
//            }
//
//            val measureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
//            mainBodyTable.cornerTable.measure(measureSpec, measureSpec)
//
//            val mainTableLayoutParams = FrameLayout.LayoutParams(
//                FrameLayout.LayoutParams.WRAP_CONTENT,
//                FrameLayout.LayoutParams.WRAP_CONTENT
//            )
//
//            mainTableLayoutParams.leftMargin = mainBodyTable.cornerTable.measuredWidth
//            mainTableLayoutParams.topMargin = mainBodyTable.cornerTable.measuredHeight
//            mainBodyTable.mainTable.layoutParams = mainTableLayoutParams
//
//            val columnTableLayoutParams = FrameLayout.LayoutParams(
//                FrameLayout.LayoutParams.WRAP_CONTENT,
//                FrameLayout.LayoutParams.WRAP_CONTENT
//            )
//
//            columnTableLayoutParams.leftMargin = mainBodyTable.cornerTable.measuredWidth
//            mainBodyTable.columnHeaderTable.layoutParams = columnTableLayoutParams
//
//            mainBodyTable.bound.rightBound += (size - oriSize)
//
//            size = oriSize
//            return super.onDoubleTap(e)
//        }
    }

}

