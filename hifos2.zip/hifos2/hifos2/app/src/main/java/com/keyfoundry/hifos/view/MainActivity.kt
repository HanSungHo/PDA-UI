package com.keyfoundry.hifos.view

import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.util.TypedValue
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.ServerType
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.domain.ServerInfo
import com.keyfoundry.hifos.config.service.RetrofitSyncService
import com.keyfoundry.hifos.config.service.RetrofitUpdateService
import com.keyfoundry.hifos.config.service.room.ServerInfoService
import com.keyfoundry.hifos.config.service.room.SettingInfoService
import com.keyfoundry.hifos.config.service.room.UserInfoService
import com.keyfoundry.hifos.config.service.udp.UDPReceiver
import com.keyfoundry.hifos.config.service.udp.UDPService
import com.keyfoundry.hifos.config.utils.CommonUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivityMainBinding
import com.keyfoundry.hifos.view.batch.BatchActivity
import com.keyfoundry.hifos.view.chat.ChatListActivity
import com.keyfoundry.hifos.view.dialog.SystemSettingDialogActivity
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.diff.DiffInstParameterActivity
import com.keyfoundry.hifos.view.dispatching.DispatchingActivity
import com.keyfoundry.hifos.view.esd.ESDMasterActivity
import com.keyfoundry.hifos.view.esheet.ESheetActivity
import com.keyfoundry.hifos.view.esheet.moveout.InputScopeDataActivity
import com.keyfoundry.hifos.view.etch.ETCHActivity
import com.keyfoundry.hifos.view.gas.GasActivity
import com.keyfoundry.hifos.view.lot.LotStatusActivity
import com.keyfoundry.hifos.view.lot.LotStatusByBayActivity
import com.keyfoundry.hifos.view.machinestatus.MachineStatusActivity
import com.keyfoundry.hifos.view.mask.MaskLocationActivity
import com.keyfoundry.hifos.view.mask.MultiMaskLocationActivity
import com.keyfoundry.hifos.view.merge.AutoMergeActivity
import com.keyfoundry.hifos.view.merge.MergeActivity
import com.keyfoundry.hifos.view.operationprogress.OperationProgressActivity
import com.keyfoundry.hifos.view.pr.PRChangeActivity
import com.keyfoundry.hifos.view.rcp.RCPInquireActivity
import com.keyfoundry.hifos.view.remote.RemoteFurnaceInitActivity
import com.keyfoundry.hifos.view.remote.RemoteMeasMainActivity
import com.keyfoundry.hifos.view.remote.RemoteWetActivity
import com.keyfoundry.hifos.view.remote.TestTuningActivity
import com.keyfoundry.hifos.view.sample.SampleReleaseActivity
import com.keyfoundry.hifos.view.shelf.ShelfIncomingActivity
import com.keyfoundry.hifos.view.side.SideDummyActivity
import com.keyfoundry.hifos.view.split.SplitActivity
import com.keyfoundry.hifos.view.testresult.TestResultInputActivity
import com.keyfoundry.hifos.view.udpsend.UDPSendActivity
import com.keyfoundry.hifos.view.wafercode.Wafercodecheck
import com.keyfoundry.hifos.view.web.WipInquiryActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class MainActivity : HFActivity() {
    companion object {
        private const val TAG = "MainActivity"
    }

    private lateinit var viewBinding: ActivityMainBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var serverInfoService: ServerInfoService
    private lateinit var settingInfoService: SettingInfoService
    private lateinit var userInfoService: UserInfoService

    private val udpReceiver = UDPReceiver()
    private var isSettingCheck = false
    private var isLoginCheck = false

    // -- override --
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.appbar_setting, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_setting -> {
                val intent = Intent(applicationContext, SystemSettingDialogActivity::class.java)
                startActivity(intent)

                return true
            }
        }

        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(udpReceiver)
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.appToolbar.title = ""
        setSupportActionBar(viewBinding.appToolbar)

        LocalBroadcastManager.getInstance(this)
            .registerReceiver(udpReceiver, IntentFilter(DeviceInfo.UDP_RECEIVER_FILTER))

        settingInfoService = SettingInfoService(applicationContext)
        serverInfoService = ServerInfoService(applicationContext)
        userInfoService = UserInfoService(applicationContext)


        val udpServiceIntent = Intent(this, UDPService::class.java)

        startForegroundService(udpServiceIntent)

        // set System Setting
        initSystemSetting()

        checkLoginState()
        CommonUtil.checkPDAName(this)

        // set Button Event
        viewBinding.btnTestResultInput.setOnClickListener(singleClickListener)
        viewBinding.btnDiffParam.setOnClickListener(singleClickListener)
        viewBinding.btnWetAuto.setOnClickListener(singleClickListener)
        viewBinding.btnShelfIncoming.setOnClickListener(singleClickListener)
        viewBinding.btnPrChange.setOnClickListener(singleClickListener)
        //       viewBinding.btnPrIncoming.setOnClickListener(singleClickListener)
        viewBinding.btnEsheet.setOnClickListener(singleClickListener)
        viewBinding.btnChat.setOnClickListener(singleClickListener)
        viewBinding.btnLotStatusByBay.setOnClickListener(singleClickListener)
        viewBinding.btnLotStatus.setOnClickListener(singleClickListener)
        viewBinding.btnSideDmm.setOnClickListener(singleClickListener)
        viewBinding.btnEtch.setOnClickListener(singleClickListener)
        viewBinding.btnSplit.setOnClickListener(singleClickListener)
        viewBinding.btnMaskLocation.setOnClickListener(singleClickListener)
        viewBinding.btnMachineStatus.setOnClickListener(singleClickListener)
        viewBinding.btnBatch.setOnClickListener(singleClickListener)
        viewBinding.btnDispatching.setOnClickListener(singleClickListener)
//        viewBinding.btnReTransfer.setOnClickListener(singleClickListener)
        viewBinding.btnRcp.setOnClickListener(singleClickListener)
        viewBinding.btnLogin.setOnClickListener(singleClickListener)
        viewBinding.btnSetting.setOnClickListener(singleClickListener)
        viewBinding.btnOut.setOnClickListener(singleClickListener)
        viewBinding.btnFurnaceRemote.setOnClickListener(singleClickListener)
        viewBinding.btnSampleRelese.setOnClickListener(singleClickListener)
        viewBinding.btnMeasRemote.setOnClickListener(singleClickListener)
        viewBinding.btnGas.setOnClickListener(singleClickListener)
        viewBinding.btnCVDTEST.setOnClickListener(singleClickListener)
        viewBinding.btnWafeMaterialCheck.setOnClickListener(singleClickListener)
        viewBinding.btnESDMaster.setOnClickListener(singleClickListener)
        viewBinding.btnAddOperationProgress.setOnClickListener(singleClickListener)
        //viewBinding.btnMeasRemote.visibility = View.GONE
        //viewBinding.btnAITRemote.setOnClickListener(singleClickListener)
        viewBinding.btnMerge.setOnClickListener(singleClickListener)
        viewBinding.btnAutoMerge.setOnClickListener(singleClickListener)
        viewBinding.btnInputScopeData.setOnClickListener(singleClickListener)
        viewBinding.btnMaskLocation2.setOnClickListener(singleClickListener)

        viewBinding.btnWipInquiry.setOnClickListener(singleClickListener)
        showMessageButton()
    }

    override fun onResume() {
        super.onResume()

        showMessageButton()
        CommonUtil.checkPDAName(this)
        setBluetoothName()
    }

    override fun onBackPressed() {
        exitHifos()
    }

    private fun showMessageButton() {
        if (DeviceInfo.PERMISSION == "H") {
     //       viewBinding.btnSendMessage.visibility = View.VISIBLE
            viewBinding.btnSendMessage.setOnClickListener(singleClickListener)
        } else {
            viewBinding.btnSendMessage.visibility = View.GONE
            viewBinding.btnSendMessage.setOnClickListener(null)
        }

        if(DeviceInfo.GASINPUT == "Y") {
            viewBinding.btnGas.visibility = View.VISIBLE
            viewBinding.btnGas.setOnClickListener(singleClickListener)
        }else {
            viewBinding.btnGas.visibility = View.GONE
            viewBinding.btnGas.setOnClickListener(null)
        }
    }

    private val singleClickListener = object : OnSingleClickListener() {
        private var clickSetting = false
        private var clickLogin = false

        var newIntent = Intent()

        override fun onSingleClick(it: View) {
            when (it) {
                //종료
                viewBinding.btnOut -> {
                    exitHifos()
                    return
                }
                // 환경설정
                viewBinding.btnSetting -> {
                    newIntent = Intent(applicationContext, SettingActivity::class.java)
                    clickSetting = true
                }
                // 로그인
                viewBinding.btnLogin -> {
                    newIntent = Intent(applicationContext, LoginActivity::class.java)
                    clickLogin = true
                }
                // 검사결과 입력
                viewBinding.btnTestResultInput -> {
                    newIntent = Intent(applicationContext, TestResultInputActivity::class.java)
                }
                // Diff 계측 Parameter 입력
                viewBinding.btnDiffParam -> {
                    newIntent = Intent(applicationContext, DiffInstParameterActivity::class.java)
                }
                // Wet 자동화
                viewBinding.btnWetAuto -> {
                    newIntent = Intent(applicationContext, RemoteWetActivity::class.java)
                }
                // Shelf 입고
                viewBinding.btnShelfIncoming -> {
                    newIntent = Intent(applicationContext, ShelfIncomingActivity::class.java)
                }
                // PR 교체
                viewBinding.btnPrChange -> {
                    newIntent = Intent(applicationContext, PRChangeActivity::class.java)
                }
                // PR 입고
//                viewBinding.btnPrIncoming -> {
//                    newIntent = Intent(applicationContext, PRIncomingActivity::class.java)
//                }
                // Esheet
                viewBinding.btnEsheet -> {
                    newIntent = Intent(applicationContext, ESheetActivity::class.java)
                }

                viewBinding.btnChat -> {
                    newIntent = Intent(applicationContext, ChatListActivity::class.java)
                }
                // Bay 별 Lot 현황
                viewBinding.btnLotStatusByBay -> {
                    newIntent = Intent(applicationContext, LotStatusByBayActivity::class.java)
                }
                // Lot 상태
                viewBinding.btnLotStatus -> {
                    newIntent = Intent(applicationContext, LotStatusActivity::class.java)
                }
                // Side Dmm
                viewBinding.btnSideDmm -> {
                    newIntent = Intent(applicationContext, SideDummyActivity::class.java)
                }
                // ETCH
                viewBinding.btnEtch -> {
                    newIntent = Intent(applicationContext, ETCHActivity::class.java)
                }
                // Split
                viewBinding.btnSplit -> {
                    newIntent = Intent(applicationContext, SplitActivity::class.java)
                }
                // Mask Location
                viewBinding.btnMaskLocation -> {
                    newIntent = Intent(applicationContext, MaskLocationActivity::class.java)
                }
                // Machine Status
                viewBinding.btnMachineStatus -> {
                    newIntent = Intent(applicationContext, MachineStatusActivity::class.java)
                }
                // Batch
                viewBinding.btnBatch -> {
                    newIntent = Intent(applicationContext, BatchActivity::class.java)
                }
                // Dispatching
                viewBinding.btnDispatching -> {
                    newIntent = Intent(applicationContext, DispatchingActivity::class.java)
                }
                // 반송
//                viewBinding.btnReTransfer -> {
//                    newIntent = Intent(applicationContext, ReTransferActivity::class.java)
//                }
                // 계측 RCP 조회
                viewBinding.btnRcp -> {
                    newIntent = Intent(applicationContext, RCPInquireActivity::class.java)
                }

                viewBinding.btnSendMessage -> {
                    newIntent = Intent(applicationContext, UDPSendActivity::class.java)
                }

                viewBinding.btnFurnaceRemote -> {
                    newIntent = Intent(applicationContext, RemoteFurnaceInitActivity::class.java)
                }

                viewBinding.btnSampleRelese ->{
                    newIntent = Intent(applicationContext,SampleReleaseActivity::class.java)
                }

                viewBinding.btnMeasRemote ->{
                    newIntent = Intent(applicationContext,RemoteMeasMainActivity::class.java)
                }

                viewBinding.btnGas ->{
                    newIntent = Intent(applicationContext, GasActivity::class.java)
                }
//
//                viewBinding.btnAITRemote ->{
//                    newIntent = Intent(applicationContext,RemoteAITActivity::class.java)
//                }


                viewBinding.btnCVDTEST ->{
                    newIntent = Intent(applicationContext, TestTuningActivity::class.java)
                }

                viewBinding.btnWafeMaterialCheck ->{
                    newIntent = Intent(applicationContext , Wafercodecheck::class.java)
                }

                viewBinding.btnESDMaster ->{
                    newIntent = Intent(applicationContext, ESDMasterActivity::class.java)
                }

                viewBinding.btnAddOperationProgress ->{
                    newIntent = Intent(applicationContext, OperationProgressActivity::class.java)
                }

                viewBinding.btnMerge ->{
                    newIntent = Intent(applicationContext, MergeActivity::class.java)
                }
                viewBinding.btnAutoMerge ->{
                    newIntent = Intent(applicationContext, AutoMergeActivity::class.java)
                }
                viewBinding.btnInputScopeData ->{
                    newIntent = Intent(applicationContext, InputScopeDataActivity::class.java)
                }
                //mask 일괄변경
                viewBinding.btnMaskLocation2 ->{
                    newIntent = Intent(applicationContext, MultiMaskLocationActivity::class.java)
                }

                viewBinding.btnWipInquiry ->{
                    newIntent = Intent(applicationContext, WipInquiryActivity::class.java)
                }
            }

            // checking
            if (!isSettingCheck) {
                if (clickSetting) {
                    activityFactoryResultLauncher.launch(newIntent)
                } else {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_WARNING,
                        "환경설정 정보가 필요합니다", GetString.BTNOKSTR
                    )

                    clickLogin = false
                    clickSetting = false
                }
            } else if (!isLoginCheck) {
                if (clickLogin || clickSetting) {
                    activityFactoryResultLauncher.launch(newIntent)
                } else {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_WARNING,
                        "Log In 정보가 필요합니다", GetString.BTNOKSTR
                    )

                    clickLogin = false
                    clickSetting = false
                }
            } else if (isLoginCheck) {
                if (clickLogin) {
                    logoutOK()

                    clickLogin = false
                    clickSetting = false
                } else {
                    activityFactoryResultLauncher.launch(newIntent)
                }
            }
        }

        private val activityFactoryResultLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
                if (it.resultCode == RESULT_OK) {
                    it.data?.let { intent ->
                        if (clickLogin) {
                            val operatorName = intent.getStringExtra(GetString.OPERNAME)
                            loginAfter(operatorName.toString())
                        }
                        if (clickSetting) {
                            isSettingCheck = true
                        }
                    }
                }

                this.clickSetting = false
                this.clickLogin = false
            }
    }

    private fun initServerInfo() {
        ioScope.launch {
            val serverInfoList = serverInfoService.selectAll()
            if (serverInfoList.size != 2) {
                serverInfoService.deleteAll()
                serverInfoService.insert(
                    ServerInfo(
                        ServerType.PROD_MOBILE_SERVER_NAME, ServerType.PROD_MOBILE_SERVER_IP,
                        ServerType.PROD_SERVER, true
                    )
                )
                serverInfoService.insert(
                    ServerInfo(
                        ServerType.DEV_MOBILE_SERVER_NAME, ServerType.DEV_MOBILE_SERVER_IP,
                        ServerType.DEV_SERVER, false
                    )
                )
            }

            setServerInfo()
        }
    }

    // -- private --
    private fun initSystemSetting() {
        setBluetoothName()
        setSettingInfo()
        initServerInfo()
    }

    private fun setServerInfo() {
        ioScope.launch {
            val serverInfo = serverInfoService.getSelectedServerInfo()
            val updateServerUrl = serverInfoService.getUpdateServerUrl()
            ServerType.MOBILE_SERVER_URL =
                "http://${serverInfo.serverUrl}:${ServerType.MOBILE_SERVER_PORT}"
            ServerType.UPDATE_SERVER_URL =
                "http://${updateServerUrl}:${ServerType.UPDATE_SERVER_PORT}"

            RetrofitSyncService.reInit(ServerType.MOBILE_SERVER_URL)
            RetrofitUpdateService.reInit(ServerType.UPDATE_SERVER_URL)

            DeviceInfo.MOBILE_SERVER_NAME = serverInfo.serverName
            //     DeviceInfo.MOBILE_SERVER_URL = ServerType.UPDATE_SERVER_URL
        }
    }

    private fun setSettingInfo() {
        ioScope.launch {
            val settingInfo = settingInfoService.selectSettingInfo()
            if (settingInfo != null) {
                isSettingCheck = true

                // set DeviceInfo
                DeviceInfo.FACILITY = settingInfo.facility
                DeviceInfo.AREA = settingInfo.area
                DeviceInfo.BAY = settingInfo.bay
                DeviceInfo.HISTORY_COUNT = settingInfo.historyCount.toString()
                DeviceInfo.FORWARD_COUNT = settingInfo.forwardCount.toString()
            } else {
                isSettingCheck = false
            }
        }
    }

    private fun setBluetoothName() {
        val title = "HiFOS (${DeviceInfo.DEVICE_NAME})"
        viewBinding.mainTitle.text = title
    }

    private fun logoutOK() {
        val returnCode = OkCancelDialog.show(
            supportFragmentManager,
            GetString.TXTDIALOGTITLE_LOGOUT, GetString.TXTDIALOGMESSAGE_LOGOUT,
            GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
        )
        if (returnCode == OkCancelDialog.RETURN_CODE_OK) {
            logoutAfter()

            viewBinding.btnSendMessage.visibility = View.GONE
            viewBinding.btnSendMessage.setOnClickListener(null)

            viewBinding.btnGas.visibility =  View.GONE
            viewBinding.btnGas.setOnClickListener(null)
        }
    }

    private fun loginAfter(operName: String) {
        mainScope.launch {
            val loginText = """
                |"$operName 님"
                |${GetString.TXTDIALOGTITLE_LOGOUT}
            """.trimMargin()
            viewBinding.btnLogin.text = loginText
            viewBinding.btnLogin.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
            isLoginCheck = true
        }
    }

    private fun logoutAfter() {
        setBtnLogout()
        OkDialog.show(
            supportFragmentManager, GetString.TXTDIALOGTITLE_LOGOUT, "로그아웃 성공", GetString.BTNOKSTR
        )
        ioScope.launch {
            DeviceInfo.OPERATOR_ID = "OPERATOR_ID"
            DeviceInfo.OPERATOR_NAME = "OPERATOR_NAME"
            DeviceInfo.PERMISSION = "PERMISSION"

            userInfoService.logOut()
        }
    }

    private fun setBtnLogout() {
        isLoginCheck = false
        //viewBinding.btnLogin.background(D)
        viewBinding.btnLogin.text = GetString.TXTDIALOGTITLE_LOGIN
        viewBinding.btnLogin.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f);
    }

    private fun checkLoginState() {
        ioScope.launch {
            if (userInfoService.checkLoginState()) {
                val userInfo = userInfoService.selectUserInfo()

                if (userInfo != null) {
                    DeviceInfo.OPERATOR_ID = userInfo.operId
                    DeviceInfo.OPERATOR_NAME = userInfo.operName
                    DeviceInfo.PERMISSION = userInfo.permission
                }

                loginAfter(DeviceInfo.OPERATOR_NAME)
            }
        }
    }

    private fun exitHifos() {
        mainScope.launch {
            val returnCode = OkCancelDialog.show(
                supportFragmentManager, "종 료", "프로그램을 종료하시겠습니까?",
                GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
            )

            if (returnCode == OkCancelDialog.RETURN_CODE_OK) {
                ioScope.launch { userInfoService.logOut() }
                finish()
            }
        }
    }
}