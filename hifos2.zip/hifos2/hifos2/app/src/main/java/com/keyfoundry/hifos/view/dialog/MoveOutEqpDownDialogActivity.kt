package com.keyfoundry.hifos.view.dialog

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.Window
import android.widget.CheckBox
import androidx.core.view.isGone
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityMoveoutEqpDownDialogBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.movein.MoveInActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject


class MoveOutEqpDownDialogActivity : HFActivity() {
    companion object {
        private const val TAG = "MoveOutEqpDownDialogActivity"
    }

    init {
        this.update = false
    }

    private lateinit var viewBinding: ActivityMoveoutEqpDownDialogBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)

    val checkBoxList: MutableList<CheckBox> = mutableListOf()


    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setFinishOnTouchOutside(false)

        viewBinding = ActivityMoveoutEqpDownDialogBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.chkMain.text = intent.getStringExtra("MACHINE")
        val chamberList = JSONArray(intent.getStringExtra("CHAMBERLIST"))


        checkBoxList.add(viewBinding.chkMain)

        if (chamberList.length() > 0) {
            for (i in 0 until chamberList.length()) {
                val chamber = chamberList[i] as JSONObject
                val ch = chamber.getString("CH")
                val mesState = chamber.getString("MESSTATE")

                val checkBox = when (i) {
                    0 -> viewBinding.chkCh1
                    1 -> viewBinding.chkCh2
                    2 -> viewBinding.chkCh3
                    3 -> viewBinding.chkCh4
                    4 -> viewBinding.chkCh5
                    5 -> viewBinding.chkCh6
                    else -> null
                }

                checkBox?.apply {
                    text = ch
                    isEnabled = mesState == "RUN"
                    isChecked = mesState == "RUN"
                    isGone = false
                }

                if(checkBox?.isEnabled == true){
                    checkBoxList.add(checkBox!!)
                }
            }
        } else {
            viewBinding.linearChamberDiv.isGone = true
            viewBinding.chkAll.isGone = true
        }

        viewBinding.chkAll.setOnCheckedChangeListener { buttonView, isChecked ->

            if(viewBinding.chkAll.isChecked) {
                for(checkBox in checkBoxList){
                    checkBox.isChecked = true
                }

            } else {
                if(checkBoxChecked()) {
                    for(checkBox in checkBoxList){
                        checkBox.isChecked = false
                    }
                }
            }
        }

        for(checkBox in checkBoxList){
            checkBox.setOnCheckedChangeListener { buttonView, isChecked ->
                if (!isChecked) {
                    viewBinding.chkAll.isChecked = false

                }
            }
        }

        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                bibuhaDownEqp()
            }
        })

        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val returnIntent = Intent(applicationContext, MoveInActivity::class.java)
                setResult(Activity.RESULT_OK, returnIntent)
                finish()
            }
        })
    }

    private fun checkBoxChecked(): Boolean {

        for(checkBox in checkBoxList){
            if(!checkBox.isChecked){
                return false
            }
        }

        return true
  }

    override fun onBackPressed() {
        viewBinding.btnOk.performClick()
    }

    private fun bibuhaDownEqp(){

        var mainFlag = "Y"
        var chamberFlag = false;

        if(!viewBinding.chkMain.isChecked){
            mainFlag = "N"
        }

        val eqpList = StringBuilder()

        var isFirstCheckBox = true
        for (checkBox in checkBoxList) {
            if (checkBox.isChecked && checkBox!=viewBinding.chkMain) {
                if (isFirstCheckBox) {
                    eqpList.append(checkBox.text)
                    isFirstCheckBox = false
                } else {
                    eqpList.append(",").append(checkBox.text)
                }
                chamberFlag = true
            }
        }

        if(!chamberFlag && mainFlag =="N"){
            OkDialog.show(supportFragmentManager
                , GetString.TXTDIALOGTITLE_WARNING
                , "최소 하나의 장비 또는 챔버를 선택 하세요"
                , GetString.BTNOKSTR)
            return
        }

        val sendMessage = MessageFactoryUtil.changeEQPStatus(
            viewBinding.chkMain.text.toString(),
            DeviceInfo.FACILITY,
            "C  비부하(LOAD DOWN)",
            "CA001",
            "PDA_MVOUT_DOWN",
            DeviceInfo.OPERATOR_ID,
            DeviceInfo.OPERATOR_NAME,
            if (chamberFlag) eqpList.toString() else "",
            mainFlag
        )

        mainScope.launch {
            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.CHANGEEQPSTATUS)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
               // val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

//                val returnCode = OkDialog.show(
//                    supportFragmentManager,
//                    GetString.TXTDIALOGTITLE_OK,
//                    "장비상태가 변경되었습니다.",
//                    GetString.BTNOKSTR,
//                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)
            }

            val returnIntent = Intent(applicationContext, MoveInActivity::class.java)
            setResult(Activity.RESULT_OK, returnIntent)
            finish()
        }
    }
}