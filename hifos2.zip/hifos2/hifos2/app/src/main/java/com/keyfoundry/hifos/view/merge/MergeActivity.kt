package com.keyfoundry.hifos.view.merge

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.StrictMode
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.TableRow
import android.widget.TextView

import androidx.core.view.*
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.CTSubLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityMergeBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.lot.LotStatusActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class MergeActivity : HFActivity() {

    companion object {
        private const val TAG = "MergeViewActivity"
    }

    private lateinit var viewBinding: ActivityMergeBinding

    private lateinit var gridService: GridService
    private lateinit var gridList: CTMainLayout
    private lateinit var columnData : LinkedHashMap<String, ColumnProperty>

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    lateinit var gMainLotId: String

    lateinit var selectedRow: CTRowLayout
    private var selectAll = false
    private var selectedRowList = arrayListOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityMergeBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.editLotNo.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        viewBinding.txtReworkState.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtProduct.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtRoute.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtArea.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtProcessNum.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtProcessStep.movementMethod = ScrollingMovementMethod.getInstance()

        viewBinding.editLotNo.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                if (check)
                    getMergeLotInfo()
                else
                    clearData()
            } else if (event != null) { // Barcode Event
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).lotId(viewBinding.editLotNo)

                    if (check)
                        getMergeLotInfo()
                    else
                        clearData()
                }
            }

            true
        }

        gridService = GridService(applicationContext)
        setGrid()

        viewBinding.btnExecute.setOnClickListener(onClickListener)
        viewBinding.btnClose.setOnClickListener(onClickListener)
        viewBinding.btnSearchLotNo.setOnClickListener(onClickListener)
        viewBinding.btnAllSelect.setOnClickListener(onClickListener)
        viewBinding.btnLotInfo.setOnClickListener(onClickListener)


    }

    private val onClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnExecute.id -> executeMerge()
                viewBinding.btnClose.id -> finish()
                viewBinding.btnSearchLotNo.id -> getMergeLotInfo()
                viewBinding.btnAllSelect.id -> selectAllRow()
                viewBinding.btnLotInfo.id -> inquireLotInfo(viewBinding.editLotNo.text.toString())
            }
        }
    }

    private fun setGrid(){
        columnData = linkedMapOf(
            "LOTNAME" to ColumnProperty("LOT ID", Gravity.LEFT, false),
            "PRODUCTSPECNAME" to ColumnProperty("제품", Gravity.LEFT, false),
            "PROCESSFLOWNAME" to ColumnProperty("ROUTE", Gravity.LEFT, false),
            "OPERATIONDESCRIPTION" to ColumnProperty("공정 DESC", Gravity.LEFT, false),
            "PROCESSOPERATIONNAME" to ColumnProperty("공정", Gravity.LEFT, false),
            "JOBCODE" to ColumnProperty("JOB CODE", Gravity.LEFT, false),
            "PRODUCTQUANTITY" to ColumnProperty("QTY", Gravity.LEFT, false)
        )

        var setGridList = JSONArray()
        val emptyObject = JSONObject()
        emptyObject.put("NUM", 0)
        setGridList.put(emptyObject)

        gridList = gridService.setGridPropData(columnData, setGridList)

        viewBinding.baseLayout.addView(gridList)

    }

    private fun getMergeLotInfo(){
        clearData()

        mainScope.launch {
            CommonUtil.hideKeyboard(this@MergeActivity, currentFocus)

            val lotId = viewBinding.editLotNo.text.toString()

            if (lotId.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT ID을 입력하세요", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.getMergeLot(DeviceInfo.FACILITY,lotId)

            val message = MessageSender.send( supportFragmentManager, sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val messageListJSON = ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "ITEMS")

                if(messageBody.optString("CHECKMFGGROUP2")=="Y"){
                    val returnCode = OkCancelDialog.show(
                        supportFragmentManager,
                        GetString.TXTDIALOGTITLE_WARNING,
                        "자동화 진행 이력이 확인되지 않습니다.\n진행 하시겠습니까?",
                        GetString.BTNYESSTR,
                        GetString.BTNNOSTR
                    )
                    if (returnCode == OkCancelDialog.RETURN_CODE_CANCEL) {
                        return@launch
                    }
                }

                gMainLotId = viewBinding.editLotNo.text.toString()

                viewBinding.txtArea.text = messageBody.optString("AREA")
                viewBinding.txtHoldState.text = messageBody.optString("LOTHOLDSTATE")
                viewBinding.txtProcessNum.text = messageBody.optString("PROCESSOPERATIONNAME")
                viewBinding.txtProcessStep.text = messageBody.optString("OPERATIONDESCRIPTION")
                viewBinding.txtProduct.text = messageBody.optString("PRODUCTSPECNAME")
                viewBinding.txtQty.text = messageBody.optString("PRODUCTQUANTITY")
                viewBinding.txtReworkState.text = messageBody.optString("REWORKSTATE")
                viewBinding.txtRoute.text = messageBody.optString("PROCESSFLOWNAME")

                if(messageListJSON.length()==0){
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "Merge할 Lot이 없습니다.", GetString.BTNOKSTR
                    )
                    return@launch
                }

                if(messageBody.optString("CHILDLOT")=="Y"){
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_WARNING,
                        "Merge 대상이 Child Lot입니다.\n확인 후 Merge 진행하시길 바랍니다.", GetString.BTNOKSTR
                    )
                }

                gridList = gridService.setGridPropData(columnData, messageListJSON)
                viewBinding.baseLayout.addView(gridList)

                selectLotList(gridList)

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
                gMainLotId = ""
                viewBinding.editLotNo.setText("")
                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
            }
        }
    }

    private fun executeMerge(){
        if(selectedRowList.size==0){
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "Merge할 LOT을 선택해주세요.", GetString.BTNOKSTR
            )
            return;
        }

        var arrMergeLot = ""

        for (i in 0 until selectedRowList.count()) {
            val gridList = viewBinding.baseLayout.getChildAt(0) as CTMainLayout
            val rowData = gridList.mainTable.getChildAt(selectedRowList[i]) as CTRowLayout
            val selectedLotId = gridService.getCellValue(rowData, "LOTNAME")
            val qty = gridService.getCellValue(rowData, "PRODUCTQUANTITY")

            /*if(selectedLotId.length < gMainLotId.length){
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "Merge의 방향이 잘못된 것 같습니다.", GetString.BTNOKSTR
                )
                return;
            }*/

            if(arrMergeLot == ""){
                arrMergeLot = "$selectedLotId $qty"
            } else {
                arrMergeLot += ",$selectedLotId $qty"
            }
        }

        mainScope.launch {
            CommonUtil.hideKeyboard(this@MergeActivity, currentFocus)

            val lotId = viewBinding.editLotNo.text.toString()

            if (lotId.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT ID을 입력하세요", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.executeMergeLot(DeviceInfo.FACILITY,
                gMainLotId,
                viewBinding.txtProduct.text.toString(),
                viewBinding.txtRoute.text.toString(),
                viewBinding.txtProcessNum.text.toString(),
                viewBinding.txtQty.text.toString(),
                DeviceInfo.OPERATOR_ID,
                viewBinding.editComment.text.toString(),
                arrMergeLot
            )

            val message = MessageSender.send( supportFragmentManager, sendMessage, MessageName.MESSAGE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                if(messageBody.optString("FAILLOTNAME")!=""){
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        messageBody.optString("FAILLOTNAME"), GetString.BTNOKSTR
                    )
                }

                if(messageBody.optString("SUCCESS") == "Y"){
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                        "작업을 수행하였습니다.", GetString.BTNOKSTR
                    )
                    clearData()
                    viewBinding.editLotNo.setText("")
                    viewBinding.editLotNo.requestFocus()
                }


            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
                viewBinding.editLotNo.requestFocus()
                viewBinding.editLotNo.selectAll()
            }
        }
    }

    inner class RowGestureListener : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(event: MotionEvent): Boolean {
            selectedRow.isSelected = !selectedRow.isSelected

            val rowIndex = ((selectedRow.parent) as CTSubLayout).indexOfChild(selectedRow)

            if (selectedRow.isSelected)
                selectedRowList.add(rowIndex)
            else
                selectedRowList.remove(rowIndex)

            return true
        }
    }

    private fun selectLotList(gridData: CTMainLayout) {
        val mainTable = gridData.mainTable

        for (row in 0 until mainTable.size) {
            val tableRow = mainTable.getChildAt(row) as CTRowLayout
            tableRow.setBackgroundResource(R.drawable.selected_grid_row)

            val mDetector = GestureDetectorCompat(this, RowGestureListener())

            tableRow.setOnTouchListener { v, event ->
                selectedRow = v as CTRowLayout

                return@setOnTouchListener (mDetector.onTouchEvent(event))
            }
        }
    }

    private fun selectAllRow() {
        if (viewBinding.baseLayout.childCount < 1)
            return

        val gridList = viewBinding.baseLayout.getChildAt(0) as CTMainLayout

        selectAll = !selectAll

        for (i in 0 until gridList.mainTable.childCount) {
            val rowData = gridList.mainTable.getChildAt(i) as CTRowLayout

            if (!rowData.isGone) {
                if (selectAll) {
                    rowData.isSelected = true
                    selectAll = true
                    selectedRowList.add(i)
                } else {
                    rowData.isSelected = false
                    selectAll = false
                    selectedRowList.remove(i)
                }
            }
        }

        if (selectedRowList.isNotEmpty())
            selectedRowList = selectedRowList.distinct().toCollection(ArrayList())
    }

    private fun inquireLotInfo(sLot: String){
        val nextIntent = Intent(applicationContext, LotStatusActivity::class.java)
        nextIntent.putExtra("LOTID", sLot)
        startActivity(nextIntent)
    }

    private fun clearData(){
        viewBinding.txtRoute.text = ""
        viewBinding.txtArea.text = ""
        viewBinding.txtHoldState.text = ""
        viewBinding.txtProcessNum.text = ""
        viewBinding.txtProcessStep.text = ""
        viewBinding.txtProduct.text = ""
        viewBinding.txtQty.text = ""
        viewBinding.txtReworkState.text = ""
        viewBinding.editComment.setText("")
        viewBinding.baseLayout.removeAllViews()

        gMainLotId = ""
        selectedRowList = arrayListOf<Int>()
    }

}