package com.keyfoundry.hifos.view.mask

import android.os.Bundle
import android.text.InputFilter
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.TextView
import androidx.core.view.GestureDetectorCompat
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.BarcodeStyle
import com.keyfoundry.hifos.config.utils.CommonUtil
import com.keyfoundry.hifos.config.utils.MessageFactoryUtil
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.databinding.ActivityMaskLocationBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MaskLocationActivity : HFActivity() {

    private lateinit var viewBinding: ActivityMaskLocationBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var reticleId = ""
    private var currentSpinnerId = 0

    inner class SelectAllGestureListener(private val selectedView: EditText) :
        GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent?): Boolean {
            selectedView.clearFocus()
            selectedView.selectAll()
            return super.onDoubleTap(e)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityMaskLocationBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        initDisable()

        viewBinding.editMaskTag.setOnEditorActionListener(editorActionListener)
        viewBinding.editLocation.setOnEditorActionListener(editorActionListener)
        viewBinding.editMachine.setOnEditorActionListener(editorActionListener)


        val selectAllDetector =
            GestureDetectorCompat(this, SelectAllGestureListener(viewBinding.editMaskTag))
        viewBinding.editMaskTag.setOnTouchListener { v, event ->
            selectAllDetector.onTouchEvent(event)
        }

        viewBinding.chkManual.setOnCheckedChangeListener(checkedChangeListener)

        viewBinding.spinnerFloor.setOnTouchListener(onTouchListener)
        viewBinding.spinnerStatus.setOnTouchListener(onTouchListener)
        viewBinding.spinnerCurrentLocation.setOnTouchListener(onTouchListener)
        viewBinding.spinnerDetailLocation.setOnTouchListener(onTouchListener)

        viewBinding.spinnerFloor.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerStatus.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerCurrentLocation.onItemSelectedListener = itemSelectListener
        viewBinding.spinnerDetailLocation.onItemSelectedListener = itemSelectListener

        viewBinding.btnOk.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnOk.id -> {
                    changeMaskLoc()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    private val onTouchListener = View.OnTouchListener { v, event ->
        currentSpinnerId = v.id
        v.performClick()
    }

    private val itemSelectListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerFloor.id -> {
                        if (currentSpinnerId == parent.id) {
                            viewBinding.spinnerStatus.adapter = null
                            viewBinding.spinnerCurrentLocation.adapter = null
                            viewBinding.spinnerDetailLocation.adapter = null

                            setStatusSpinner()
                        }
                    }
                    viewBinding.spinnerStatus.id -> {
                        if (currentSpinnerId == parent.id) {
                            viewBinding.spinnerCurrentLocation.adapter = null
                            viewBinding.spinnerDetailLocation.adapter = null

                            setCurrentLocSpinner()
                        }
                    }
                    viewBinding.spinnerCurrentLocation.id -> {
                        if (currentSpinnerId == parent.id) {
                            viewBinding.spinnerDetailLocation.adapter = null
                            setDetailLocation()
                        }
                    }
                    viewBinding.spinnerDetailLocation.id -> {
                        if (currentSpinnerId == parent.id) {
                            if (viewBinding.spinnerDetailLocation.selectedItem != null)
                                checkPMSShelf(viewBinding.spinnerDetailLocation.selectedItem.toString())
                        }
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private val checkedChangeListener =
        CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            currentSpinnerId = 0
            manualLocationCombo(isChecked)
            if (isChecked) {
                setFloorSpinner()
                setStatusSpinner()
            }
        }

    private fun setCurrentLocSpinner() {
        mainScope.launch {
            if (viewBinding.spinnerStatus.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "상태를 선택해주세요", GetString.BTNOKSTR
                )

                return@launch
            }

            val status = viewBinding.spinnerStatus.selectedItem.toString()
            val floor = if (viewBinding.spinnerFloor.selectedItem != null)
                viewBinding.spinnerFloor.selectedItem.toString()
            else
                ""

            val sendMessage =
                MessageFactoryUtil.maskLocGroupInfo(status, floor, DeviceInfo.FACILITY)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MASKLOCGROUPINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val locGroupList = ResponseDataToJsonUtil.getMessageBodyList(result, "LOCGROUPS")

                val itemList = arrayListOf<String>()
                for (count in 0 until locGroupList.length()) {
                    val locGroup = locGroupList.getJSONObject(count).optString("LOCGROUP")
                    itemList.add(locGroup)
                }

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerCurrentLocation.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setDetailLocation() {
        mainScope.launch {
            if (viewBinding.spinnerStatus.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "상태를 선택해주세요", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.spinnerCurrentLocation.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "현재위치를 선택해주세요", GetString.BTNOKSTR
                )

                return@launch
            }
            val status = viewBinding.spinnerStatus.selectedItem.toString()
            val floor = if (viewBinding.spinnerFloor.selectedItem != null)
                viewBinding.spinnerFloor.selectedItem.toString()
            else
                ""

            val sendMessage = MessageFactoryUtil.maskLocationInfo(
                status, viewBinding.spinnerCurrentLocation.selectedItem.toString(),
                floor, DeviceInfo.FACILITY
            )
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MASKLOCGROUPINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val locationList = ResponseDataToJsonUtil.getMessageBodyList(result, "LOCATIONS")

                val itemList = arrayListOf<String>()
                for (count in 0 until locationList.length()) {
                    val location = locationList.getJSONObject(count).optString("LOCATION")
                    itemList.add(location)
                }

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerDetailLocation.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setFloorSpinner() {
        val itemList = arrayListOf("2F", "4F", "6F")
        val spinnerAdapter =
            ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerFloor.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
    }

    private fun setStatusSpinner() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.maskStatusInfo(DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MASKSTATUSINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val statusList = ResponseDataToJsonUtil.getMessageBodyList(result, "STATUSES")

                val itemList = arrayListOf<String>()
                for (count in 0 until statusList.length()) {
                    val status = statusList.getJSONObject(count).optString("STATUS")
                    itemList.add(status)
                }

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerStatus.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun initDisable() {
        viewBinding.chkManual.isChecked = false
        viewBinding.chkManual.isEnabled = false
        viewBinding.spinnerStatus.isEnabled = false
        viewBinding.spinnerCurrentLocation.isEnabled = false
        viewBinding.spinnerDetailLocation.isEnabled = false
        viewBinding.btnOk.isEnabled = false

        manualLocationCombo(viewBinding.chkManual.isChecked)
    }

    private fun manualLocationCombo(check: Boolean) {
        viewBinding.spinnerFloor.isEnabled = check
        viewBinding.spinnerStatus.isEnabled = check
        viewBinding.spinnerCurrentLocation.isEnabled = check
        viewBinding.spinnerDetailLocation.isEnabled = check

        if (!check) {
            viewBinding.spinnerFloor.adapter = null
            viewBinding.spinnerStatus.adapter = null
            viewBinding.spinnerCurrentLocation.adapter = null
            viewBinding.spinnerDetailLocation.adapter = null
        }
    }

    private val editorActionListener = TextView.OnEditorActionListener { v, actionId, event ->
        when (v.id) {
            viewBinding.editMaskTag.id -> {
                if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                    setMaskInfo()
                } else if (event != null) { // Barcode Event
                    if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                        setMaskInfo()
                    }
                }
            }
            viewBinding.editLocation.id -> {
                if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                    val check = BarcodeStyle(this).eqpId(viewBinding.editLocation)

                    if (check)
                        checkPMSShelf(viewBinding.editLocation.text.toString())
                } else if (event != null) { // Barcode Event
                    if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                        val check = BarcodeStyle(this).eqpId(viewBinding.editLocation)

                        if (check)
                            checkPMSShelf(viewBinding.editLocation.text.toString())
                    }
                }
            }
            viewBinding.editMachine.id -> {
                if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                    CommonUtil.hideKeyboard(this, currentFocus)
                } else if (event != null) { // Barcode Event
                    if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                        CommonUtil.hideKeyboard(this, currentFocus)
                    }
                }
            }
        }

        true
    }

    private fun clearInfo() {
        viewBinding.txtShelf.text = ""
        viewBinding.txtProduct.text = ""
        viewBinding.txtStatus.text = ""
        viewBinding.txtUseYn.text = ""
        viewBinding.txtCurrentLocation.text = ""
        viewBinding.editMachine.setText("")
        viewBinding.txtTest.text = ""

        reticleId = ""

        initDisable()
    }

    private fun setMaskInfo() {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@MaskLocationActivity, currentFocus)

            clearInfo()

            if (viewBinding.editMaskTag.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "위치 변경할 Mask를 읽어주세요.", GetString.BTNOKSTR
                )

                viewBinding.editMaskTag.requestFocus()
                viewBinding.editMaskTag.selectAll()
                return@launch
            }

            val currentText = viewBinding.editMaskTag.text.toString()
            val maskId = currentText.substring(0, currentText.length - 1)
            reticleId = maskId
            viewBinding.editMaskTag.setText(maskId)

            val sendMessage = MessageFactoryUtil.maskInfo(maskId, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MASKINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val facility = messageBody.optString("FACILITY")
                val reticleTag = messageBody.optString("RETICLETAG")
                val product = messageBody.optString("PRODUCT")
                val status = messageBody.optString("STATUS")
                val isUse = messageBody.optString("ISUSE")
                val currLoc = messageBody.optString("CURRLOC")
                val subLocation3 =
                    messageBody.optString("SUBLOCATION3")//---[Addition] Mar 07, 2006. 의뢰장비 관련 Handling
                val psmMaskFlag =
                    messageBody.optString("CUSTOMER")//---[Addition] 2018.01.26 PSM 확인 POP_UP창 추가
                val rmsInspFlag =
                    messageBody.optString("RMSINSP")//---[Addition] 2018.04.05 노광전검사 이력을 확인후 검사skip를 보여줌
                val rmsID = messageBody.optString("RMSID")//---[Addition] 2018.04.10 노광전검사 flag
                val shelf = messageBody.optString("SHELF")//---[Addition] 2018.11.28 최근SHELF DATA 받기
                val pellicle = messageBody.optString("PELLICLE")

                viewBinding.editMaskTag.setText(reticleTag)
                viewBinding.txtShelf.text = shelf//---[Addition] 2018.11.28 최근SHELF DATA 받기
                viewBinding.txtProduct.text = product
                viewBinding.txtStatus.text = status
                viewBinding.txtPellicle.text = pellicle
                viewBinding.txtPsm.text = psmMaskFlag

                if (isUse == "사용가능")
                    viewBinding.txtUseYn.text = "사용가능"
                else
                    viewBinding.txtUseYn.text = "사용불가"

                viewBinding.txtCurrentLocation.text = currLoc
                viewBinding.editMachine.setText(subLocation3)//---[Addition] Mar 07, 2006. 의뢰장비 관련 Handling

                //---[Addition] 2018.11.28 최근SHELF DATA 받기로 대체
//                if (psmMaskFlag == "Y") {
//                    viewBinding.txtShelf.text = "N2BOX 전용"//---[Addition] 2018.11.28 최근SHELF DATA 받기로 대체
//                } else {
//                    viewBinding.txtShelf.text = ""//---[Addition] 2018.11.28 최근SHELF DATA 받기로 대체
//                }

                if (rmsInspFlag == "RUN") {
                    viewBinding.txtTest.text = ""
                } else {
                    if (rmsID == "Y")
                        viewBinding.txtTest.text = "SKIP"
                    else
                        viewBinding.txtTest.text = ""
                }

                viewBinding.chkManual.isEnabled = true
                viewBinding.btnOk.isEnabled = true

                viewBinding.editLocation.requestFocus()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun checkPMSShelf(mask: String) {
        CommonUtil.hideKeyboard(this, currentFocus)

        if (viewBinding.editMaskTag.text.isEmpty()) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "MASK를 입력하세요.", GetString.BTNOKSTR
            )

            viewBinding.editMaskTag.requestFocus()
            viewBinding.editMaskTag.selectAll()
            return
        }

        if (viewBinding.txtProduct.text == "PM")
            checkPM()
        else
            checkMaskPMS(mask)
    }

    private fun checkMaskPMS(pmsShelf: String) {
        mainScope.launch {
            val sendMessage =
                MessageFactoryUtil.checkMaskPMS(viewBinding.editMaskTag.text.toString(), pmsShelf)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.CHECKMASKPMS)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val checkPSMShelf = messageBody.optString("CHECKPSMSHELF")

                if (checkPSMShelf == "N") {
                    val checkMsg = """
                        |PSM MASK 입니다.
                        |전용 SHELF를 지정해야 합니다.
                    """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        checkMsg, GetString.BTNOKSTR
                    )

                    if (!viewBinding.chkManual.isChecked)
                        viewBinding.editLocation.setText("")
                    else
                        setDetailLocation()

                    return@launch
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun checkPM() {
        mainScope.launch {
            val maskId = viewBinding.editMaskTag.text.toString()
            val machineName = viewBinding.editLocation.text.toString()

            val sendMessage = MessageFactoryUtil.checkPellicle(maskId, machineName)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.CHECKPELLICLE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val checkPellicle = messageBody.optString("CHECKPELLICLE")

                if (checkPellicle == "N") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "Pellicle이 다른 장비입니다.", GetString.BTNOKSTR
                    )

                    if (!viewBinding.chkManual.isChecked)
                        viewBinding.editLocation.setText("")
                    else
                        setDetailLocation()

                    return@launch
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun changeMaskLoc() {
        mainScope.launch {
            if (viewBinding.editMaskTag.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "MASK를 입력하세요.", GetString.BTNOKSTR
                )
                return@launch
            }

            var locType = ""
            var location = ""
            var etcStatus = ""
            var etcLocation = ""
            var etcDetailLocation = ""
            var floor = ""
            if (viewBinding.chkManual.isChecked) {
                locType = "ETC"

                if (viewBinding.spinnerStatus.selectedItem == null) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "변경할 STATUS를 입력하세요.", GetString.BTNOKSTR
                    )
                    return@launch
                } else {
                    etcStatus = viewBinding.spinnerStatus.selectedItem.toString()
                }


                if (viewBinding.spinnerCurrentLocation.selectedItem == null) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "변경할 위치를 입력하세요.", GetString.BTNOKSTR
                    )
                    return@launch
                } else {
                    etcLocation = viewBinding.spinnerCurrentLocation.selectedItem.toString()
                }

                if (viewBinding.spinnerDetailLocation.selectedItem == null) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "변경할 상세위치를 입력하세요.", GetString.BTNOKSTR
                    )
                    return@launch
                } else {
                    etcDetailLocation = viewBinding.spinnerDetailLocation.selectedItem.toString()
                }

                if (viewBinding.spinnerFloor.selectedItem != null)
                    floor = viewBinding.spinnerFloor.selectedItem.toString()

            } else {
                if (viewBinding.editLocation.text.isEmpty()) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "위치를 입력하세요.", GetString.BTNOKSTR
                    )
                    return@launch
                }

                location = viewBinding.editLocation.text.toString()
            }

            val sendMessage = MessageFactoryUtil.changeMaskLocation(
                reticleId, DeviceInfo.FACILITY, locType, location, etcStatus,
                etcLocation, etcDetailLocation, viewBinding.editMachine.text.toString(),
                DeviceInfo.OPERATOR_ID, floor
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.CHECKPELLICLE)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val reticles = messageBody.optString("RETCILES")
                val count = messageBody.optString("SCOUNT")

                if (count.isNotEmpty()) {
                    if (count.toInt() == 1) {
                        OkDialog.show(
                            supportFragmentManager, GetString.BTNOKSTR,
                            "$reticles 위치가 변경되었습니다.", GetString.BTNOKSTR
                        )
                    } else if (count.toInt() > 1) {
                        val countMsg = """
                            |동일한 Serial/위치인 MASK가 변경되었습니다.
                            |[$reticles]
                        """.trimMargin()
                        OkDialog.show(
                            supportFragmentManager, GetString.BTNOKSTR,
                            countMsg, GetString.BTNOKSTR
                        )
                    }
                }

                viewBinding.editMaskTag.setText("")
                viewBinding.editMaskTag.requestFocus()
                viewBinding.editLocation.setText("")
                clearInfo()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }
}