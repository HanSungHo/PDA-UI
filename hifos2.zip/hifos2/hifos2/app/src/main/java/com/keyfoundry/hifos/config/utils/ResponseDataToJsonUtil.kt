package com.keyfoundry.hifos.config.utils

import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.service.dto.ResponseData
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/*
* JSON String을 파싱하기 위한 Class
* */
class ResponseDataToJsonUtil {
    companion object {

        // 받은 메시지 성공 여부 체크
        // status 가  PASS 일경우 true, FAIL또는 다른 오류가 있을 경우 fail 반환
        fun isSuccessFul(responseData: ResponseData): Boolean {
            val statusCode = responseData?.statusCode
            val result = JSONObject(responseData?.result)

            if (statusCode == 200
                && result.getString(GetString.STATUS).equals(GetString.PASS)
            )
                return true

            return false
        }

        fun isMessageBodyCheck(responseData: ResponseData): Boolean {
            val statusCode = responseData?.statusCode
            val result = JSONObject(responseData?.result)

            if (!result.getString(GetString.MSGBODY).equals(""))
                return true

            return false
        }

        fun getResult(responseData: ResponseData): JSONObject {

            return JSONObject(responseData?.result)
        }

        // MSGBODY안에 있는 내용을 추출
        fun getMessageBody(responseData: ResponseData): JSONObject {
            val result = JSONObject(responseData?.result)

            return result.getJSONObject(GetString.MSGBODY)

        }

        // ITEM Array 추출
        fun getMessageBodyList(responseData: ResponseData, listName: String): JSONArray {
            val msgBody = getMessageBody(responseData)

            return msgBody.getJSONObject(listName)
                .getJSONArray(GetString.ITEM)

        }

        // ITEM Array 추출
        // 빈 Array 일 경우 체크하여 반환
        fun getMessageBodyNullCheckList(responseData: ResponseData, listName: String): JSONArray {
            val msgBody = getMessageBody(responseData)

            val messageList = msgBody.optJSONObject(listName)
            if (messageList != null) {
                return messageList.optJSONArray(GetString.ITEM)
            } else {
                return JSONArray()
            }

        }

        // listname Array 추출
        // 빈 Array 일 경우 체크하여 반환
        fun getMessageBodyInValueNullCheckList(
            responseData: ResponseData, bodyName: String, listName: String
        ): JSONArray {
            val msgBody = getMessageBody(responseData)

            val messageList = msgBody.optJSONObject(listName)
            if (messageList != null) {
                return messageList.optJSONArray(bodyName)
            } else {
                return JSONArray()
            }

        }

        // listname Array 추출
        fun getMessageBodyInValueList(
            responseData: ResponseData, bodyName: String, listName: String
        ): JSONArray {
            val msgBody = getMessageBody(responseData)

            return msgBody.getJSONObject(bodyName).getJSONArray(listName)
        }

        fun getMessageBodyObject(responseData: ResponseData, listName: String): JSONObject {
            val msgBody = getMessageBody(responseData)

            return msgBody.getJSONObject(listName)
                .getJSONObject(GetString.ITEM)

        }

        fun checkMessageBodyList(responseData: ResponseData, listName: String): String {
            val msgBody = getMessageBody(responseData)
            val result = msgBody.getJSONObject(listName).get(GetString.ITEM)

            return if (result is JSONObject) {
                GetString.JSONOBJECT
            } else {
                GetString.JSONARRAY
            }
        }

        // Status가 Fail 일경우 Error 메시지 추출
        fun getErrorMessage(responseData: ResponseData): String {
            return try {
                val jsonObject = JSONObject(responseData.result)
                jsonObject.optString(GetString.ERRMSG)
            } catch (e: JSONException) {
                responseData.result
            }
        }

    }
}