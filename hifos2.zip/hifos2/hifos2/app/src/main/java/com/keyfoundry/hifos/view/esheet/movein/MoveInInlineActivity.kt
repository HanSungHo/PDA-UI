package com.keyfoundry.hifos.view.esheet.movein

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.GestureDetectorCompat
import androidx.core.view.children
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.*
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityMoveInInlineBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.MachineSelectDialogActivity
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.dialog.MaskLocationDialogActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*

class MoveInInlineActivity : HFActivity() {
    init {
        this.update = false
    }

    companion object {
        private const val TAG = "MoveInInlineActivity"
    }

    private lateinit var viewBinding : ActivityMoveInInlineBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var gridService: GridService
    private lateinit var gridData: CTMainLayout

    private lateinit var operation  : String

    private lateinit var m_sCommentQty  : String
    private lateinit var m_sNRWCmtCount  : String

    var identCodeList = ""

    private var inlineItems = arrayListOf<String>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityMoveInInlineBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        gridService = GridService(applicationContext)

        viewBinding.txtMaskTag.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtInlineRcp.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtProductName.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtAlignStepper.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtAlignStepper2.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtAlignStepper3.movementMethod = ScrollingMovementMethod.getInstance()


        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            viewBinding.txtLotNo.text = intent.getStringExtra("LOTID")
            operation = intent.getStringExtra("OPERATION").toString()
        }

        viewBinding.btnFullIl.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                fullIinline()
            }
        })

        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                val returnIntent = Intent(applicationContext, MoveInActivity::class.java)
                setResult(Activity.RESULT_CANCELED, returnIntent)
                finish()
            }
        })

        viewBinding.btnRealMaskTag.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                getMaskLocationInfo()
            }
        })

        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                inlineSet()
            }
        })

        getInlineInfo()
    }

    private val machineSelectDialogActivityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                it.data?.let { intent ->
                    val eqpGroup = intent.getStringExtra("EQPGROUP").toString()
                    val eqpId = intent.getStringExtra("EQPID").toString()
                    val recipe = intent.getStringExtra("RECIPE").toString()

                    finishInlineSet(eqpGroup, eqpId, recipe)
                }
            }
        }

    private fun finishInlineSet(eqpGroup:String, eqpId:String, recipe:String){
        val nest = viewBinding.spinnerNest.selectedItem.toString()
        val returnIntent = Intent()
        returnIntent.putExtra("EQPGROUP",eqpGroup)
        returnIntent.putExtra("EQPID",eqpId)
        returnIntent.putExtra("RECIPE",recipe)
        returnIntent.putExtra("COMMENTQTY",m_sCommentQty)
        returnIntent.putExtra("NRWCMTCOUNT",m_sNRWCmtCount)
        returnIntent.putExtra("NEST", nest)
        returnIntent.putExtra("ITDENTCODE", identCodeList)
        returnIntent.putExtra("MASKTAG", viewBinding.txtMaskTag.text.toString())

        setResult(Activity.RESULT_OK, returnIntent)
        finish()
    }

    private fun getInlineInfo(){
        mainScope.launch {
            val lotId = viewBinding.txtLotNo.text.toString()
            val sendMessage = MessageFactoryUtil.inlineInfo(lotId, DeviceInfo.FACILITY, operation)

            val message = MessageSender.send(supportFragmentManager,sendMessage, MessageName.INLINEINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                setInlineRcpSpinner(arrayListOf<String>("1","2","3","4"))
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sProduct = messageBody.optString("PRODUCT")
                val sOperation = messageBody.optString("OPERATION")
                val sPhotoJobCode = messageBody.optString("PHOTOJOBCODE")
                val sReticleTag = messageBody.optString("MASKTAG")
                val sChangeReticleTag = messageBody.optString("CHANGEMASKTAG")
                val sInlineRecipe = messageBody.optString("INLINERECIPE")
                val sProcesStep = messageBody.optString("PROCESSSTEP")
                val sQuantity = messageBody.optString("QUANTITY")

                val sCriticalStepper = messageBody.optString("CRITICAL_STEPPER")
                val sCriticalStepper2 = messageBody.optString("CRITICAL_STEPPER2")
                val sCriticalStepper3 = messageBody.optString("CRITICAL_STEPPER3")

                var maskTag = ""

                if(sChangeReticleTag != "" && sReticleTag!=sChangeReticleTag) {
                    maskTag = sChangeReticleTag
                    viewBinding.txtMaskTag.setTextColor(Color.RED)
                } else {
                    maskTag = sReticleTag
                }

                viewBinding.txtJob.text = sPhotoJobCode
                viewBinding.txtCurrentProcess.text = "$sProcesStep($sOperation)"
                viewBinding.txtMaskTag.text = maskTag
                viewBinding.txtInlineRcp.text = sInlineRecipe
                viewBinding.txtProductName.text = sProduct
                viewBinding.txtQuantity.text = sQuantity
                viewBinding.txtAlignStepper.text = sCriticalStepper
                viewBinding.txtAlignStepper2.text = sCriticalStepper2
                viewBinding.txtAlignStepper3.text = sCriticalStepper3

                val spinnerBayItems = arrayListOf<String>()
                val maskTagList = maskTag.split(",")
                for(mask in maskTagList) {
                    if(mask.isNotEmpty()) {
                        spinnerBayItems.add(mask)
                    }
                }
                setRealMaskTagSpinner(spinnerBayItems)

                val inLineListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "INLINEITEMS")

                val columnData = linkedMapOf(
                    "SUBPROCESSSTEP" to ColumnProperty("공정명", Gravity.START, false),
                    "ISCOMPLETE" to ColumnProperty("IL", Gravity.START, false),
                    "LOCALRECIPE" to ColumnProperty("Local Rcp", Gravity.START, false),
                    "WORKEDEQP" to ColumnProperty("장비", Gravity.START, false),
                    "IDENTCODE" to ColumnProperty("IC", Gravity.START, false, 0),
                    "SUBOPERATION" to ColumnProperty("SO", Gravity.START, false, 0)
                )

                gridData = gridService.setGridPropData(columnData, inLineListJSON)

                val columnIndex = gridService.getColumnIndex(gridData, "ISCOMPLETE")
                for(row in gridData.mainTable.children){
                    val rowData = row as CTRowLayout
                    val cellData = rowData.getChildAt(columnIndex) as TextView

                    if(cellData.text == "Y") {
                        row.setBackgroundColor(Color.BLACK)

                        for(cell in rowData.children)
                            (cell as TextView).setTextColor(Color.RED)

                        val rowData = (row.tag) as GridService.RowData
                        (rowData.rowDataList)["ISCOMPLETE"] = "C"
                        cellData.text = "C"

                        viewBinding.btnFullIl.isEnabled = false
                    }
                }

                viewBinding.baseLayout.addView(gridData)

                selectOperation(gridData)

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

            }

        }
    }

    private fun getMaskLocationInfo(){
        mainScope.launch {
            if(viewBinding.spinnerRealMaskTag.selectedItem?.toString().isNullOrEmpty()){
                OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , "Mask Tag를 선택 해 주세요."
                    , GetString.BTNOKSTR)
                return@launch
            }
            val reticleId = viewBinding.spinnerRealMaskTag.selectedItem.toString()
          //  val reticleId = viewBinding.txtMaskTag.text.toString()

            val sendMessage = MessageFactoryUtil.maskLocationInfo("T", reticleId, DeviceInfo.FACILITY)

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.MASKLOCATIONINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "ITEMS")
                val messageBody = messageListJSON.getJSONObject(0)

                val sReticlaTag = messageBody.optString("RETICLETAG")
                val sProduct = messageBody.optString("PRODUCT")
                val sGiben = messageBody.optString("GIBEN")
                val sStatus = messageBody.optString("STATUS")
                var sIsUse = messageBody.optString("ISUSE")
                val sCurrLoc = messageBody.optString("CURRLOC")
                val sSubLocation3 = messageBody.optString("SUBLOCATION3")
                val sAfterInsp = messageBody.optString("AFTERINSP")

                if(sIsUse.equals("Y")){
                    sIsUse = "사용가능"
                }
                else {
                    sIsUse = "사용불가"
                }
                val maskLocationDialogIntent = Intent(applicationContext, MaskLocationDialogActivity::class.java)

                maskLocationDialogIntent.putExtra("MASKTAG", sReticlaTag)
                maskLocationDialogIntent.putExtra("PRODUCT", sProduct)
                maskLocationDialogIntent.putExtra("GIBEN", sGiben)
                maskLocationDialogIntent.putExtra("STATUS", sStatus)
                maskLocationDialogIntent.putExtra("ISUSE", sIsUse)
                maskLocationDialogIntent.putExtra("CURRENTLOC", sCurrLoc)
                maskLocationDialogIntent.putExtra("SUBLOCATION3", sSubLocation3)
                maskLocationDialogIntent.putExtra("AFTERINSP", sAfterInsp)

                startActivity(maskLocationDialogIntent)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)
            }
        }
    }

    private fun inlineSet() {
        mainScope.launch {
            val maskTag = viewBinding.txtMaskTag.text.toString()
            val quantity = viewBinding.txtQuantity.text.toString()
            var isFullInline = "N"
            var inLineitemsSum =""

            if(inlineItems.count()==0){
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 할 공정을 선택하세요", GetString.POSITIVEBTNSTR)
                return@launch
            }
            if(maskTag.isEmpty() && inLineitemsSum.contains("<IDENTCODE>E</IDENTCODE>"))
            {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행할 MASK TAG를 선택하세요.", GetString.POSITIVEBTNSTR)
                return@launch
            }

            if (viewBinding.spinnerNest.selectedItem?.toString().isNullOrBlank())
            {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행할 NEST를 선택하세요.", GetString.POSITIVEBTNSTR)
                return@launch
            }

            for(i in 0 until inlineItems.count()){
                inLineitemsSum += inlineItems.get(i)
            }

            if(inlineItems.count()==3){
                isFullInline = "Y"
            }

            val lotId = viewBinding.txtLotNo.text.toString()
            val product = viewBinding.txtProductName.text.toString()

            val sendMessage = MessageFactoryUtil.inlineSet(lotId, DeviceInfo.FACILITY, operation ,maskTag,quantity,isFullInline,inLineitemsSum)

            val message = MessageSender.send(supportFragmentManager,sendMessage,MessageName.INLINESET)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sIsExposure =  messageBody.optString("ISEXPOSURE")
                val sEqpGroup = messageBody.optString("EQPGROUP")
                val sExpEqpGroup = messageBody.optString("EXPEQPGROUP")
                val sSubOperation = messageBody.optString("SUBOPERATION")
                m_sCommentQty = messageBody.optString("COMMENTQTY")
                m_sNRWCmtCount = messageBody.optString("NRWCOMMENTQTY")


                val machineSelectDialogIntent = Intent(applicationContext, MachineSelectDialogActivity::class.java)

                machineSelectDialogIntent.putExtra("IDENTCODELIST", identCodeList)
                machineSelectDialogIntent.putExtra("ISEXPOSURE", sIsExposure)
                machineSelectDialogIntent.putExtra("EQPGROUP", sEqpGroup)
                machineSelectDialogIntent.putExtra("EXPEQPGROUP", sExpEqpGroup)
                machineSelectDialogIntent.putExtra("OPERATION", operation)
                machineSelectDialogIntent.putExtra("SUBOPERATION", sSubOperation)
                machineSelectDialogIntent.putExtra("PRODUCT", product)
                machineSelectDialogIntent.putExtra("LOTID", lotId)

                machineSelectDialogActivityResultLauncher.launch(machineSelectDialogIntent)

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(supportFragmentManager
                    , GetString.TXTDIALOGTITLE_ERROR
                    , errorMessage
                    , GetString.BTNOKSTR)

            }

        }
    }

    private fun setInlineRcpSpinner(items : ArrayList<String>){
        //1. set spinner
        val myAdapter = ArrayAdapter(this, R.layout.contact_spinner_row_init, items)
        myAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerNest.adapter = InitSpinnerAdapter(myAdapter, R.layout.contact_spinner_row_init, applicationContext)

    }

    private fun setRealMaskTagSpinner(items : ArrayList<String>){
        //1. set spinner
        val myAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        viewBinding.spinnerRealMaskTag.adapter = myAdapter
    }

    inner class DrawerGestureListener(
        private val isComplete: String,
        private val row: CTRowLayout,
        private val preRow: CTRowLayout?,
        private val nextRow: CTRowLayout?,
        private val gridData: CTMainLayout,
    ) : GestureDetector.SimpleOnGestureListener() {

        override fun onSingleTapUp(e: MotionEvent?): Boolean {
            val ilColumnIndex = gridService.getColumnIndex(gridData, "ISCOMPLETE")
            val subOperationColumnIndex = gridService.getColumnIndex(gridData, "SUBOPERATION")
            val identCodeColumnIndex = gridService.getColumnIndex(gridData, "IDENTCODE")

            var preIlTextView : TextView? = null

            if(preRow!=null) {
                preIlTextView = preRow.getChildAt(ilColumnIndex) as TextView
            }

            var nextIlTextView : TextView? = null

            if(nextRow!=null) {
                nextIlTextView = nextRow.getChildAt(ilColumnIndex) as TextView
            }

            val ilTextView = row.getChildAt(ilColumnIndex) as TextView
            val subOperationTextView = row.getChildAt(subOperationColumnIndex) as TextView
            val identCodeTextView = row.getChildAt(identCodeColumnIndex) as TextView

            val subOperation = subOperationTextView.text
            val identCode = identCodeTextView.text

            if(preIlTextView?.text!="N" && ilTextView.text == "N") {
                row.setBackgroundColor(Color.RED)
                ilTextView.text = "Y"

                for(col in 0 until row.childCount) {
                    val rowText = row.getChildAt(col) as TextView
                    rowText.setTextColor(Color.WHITE)
                }

                identCodeList += identCode

                inlineItems.add("""
                |<ITEM>
                |<SUBOPERATION>$subOperation</SUBOPERATION>
                |<IDENTCODE>$identCode</IDENTCODE>
                |</ITEM>
                |""".trimMargin())
            } else if(nextIlTextView?.text!="Y"&& ilTextView.text == "Y") {
                row.setBackgroundColor(Color.parseColor("#00FFFFFF"))
                ilTextView.text = "N"
                for(col in 0 until row.childCount) {
                    val rowText = row.getChildAt(col) as TextView
                    rowText.setTextColor(Color.BLACK)
                }
                inlineItems.removeLast()
                identCodeList = identCodeList.dropLast(1)
            }
            return super.onSingleTapUp(e)
        }
    }

    private fun selectOperation(gridData: CTMainLayout) {
        for(i in 0 until gridData.mainTable.children.count()){
            val row =  gridData.mainTable.children.elementAt(i)
            var preRow : View? = null
            var nextRow : View? = null
            if(i!=0) {
                preRow = gridData.mainTable.children.elementAt(i - 1)
            }
            if(i!=gridData.mainTable.children.count()-1) {
                nextRow = gridData.mainTable.children.elementAt(i + 1)
            }
            val isComplete = gridService.getCellValue(row, "ISCOMPLETE")

            val mDetector = GestureDetectorCompat(this, DrawerGestureListener(isComplete, row as CTRowLayout, preRow as CTRowLayout?, nextRow as CTRowLayout?, gridData))

            row.setOnTouchListener { v, event ->
                mDetector.onTouchEvent(event)

                true
            }
        }
    }


    private fun fullIinline() {
        identCodeList = "CED"
        inlineItems.clear()
        for (row in gridData.mainTable.children) {
            val ilColumnIndex = gridService.getColumnIndex(gridData, "ISCOMPLETE")
            val subOperationColumnIndex = gridService.getColumnIndex(gridData, "SUBOPERATION")
            val identCodeColumnIndex = gridService.getColumnIndex(gridData, "IDENTCODE")

            val ilTextView = (row as CTRowLayout).getChildAt(ilColumnIndex) as TextView
            ilTextView.text = "Y"
            row.setBackgroundColor(Color.RED)

            for (col in 0 until row.childCount) {
                val rowText = row.getChildAt(col) as TextView
                rowText.setTextColor(Color.WHITE)
            }

            val subOperationTextView = row.getChildAt(subOperationColumnIndex) as TextView
            val identCodeTextView = row.getChildAt(identCodeColumnIndex) as TextView

            val subOperation = subOperationTextView.text
            val identCode = identCodeTextView.text

            inlineItems.add(
                """
                |<ITEM>
                |<SUBOPERATION>$subOperation</SUBOPERATION>
                |<IDENTCODE>$identCode</IDENTCODE>
                |</ITEM>
                |""".trimMargin()
            )
        }
    }
}
