package com.keyfoundry.hifos.view.dialog

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.Window
import android.view.inputmethod.EditorInfo
import androidx.core.view.isGone
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityMachineSelectDialogBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.movein.MoveInInlineActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MachineSelectDialogActivity : HFActivity() {
    companion object {
        private const val TAG = "MachineSelectDialogActivity"
    }

    init {
        this.update = false
    }

    private lateinit var viewBinding: ActivityMachineSelectDialogBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    enum class RadioType { START, EXPOSURE }

    private lateinit var m_sOperation: String
    private lateinit var m_sSubOperation: String
    private lateinit var m_sProduct: String
    private lateinit var m_sLotId: String

    private lateinit var m_sIsExposure: String

    private var m_sSelNormalEqp = ""
    private var m_sSelExposureEqp = ""

    private var identCodeList = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setFinishOnTouchOutside(false)

        viewBinding = ActivityMachineSelectDialogBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //소문자 -> 대문자
        viewBinding.editStartSelectMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())
        viewBinding.editExposureSelectMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        viewBinding.txtExposureStandardMachine.movementMethod =
            ScrollingMovementMethod.getInstance()
        viewBinding.txtStartStandardMachine.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtStartRecipe.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtExposureRecipe.movementMethod = ScrollingMovementMethod.getInstance()

        checkedRadioButton(RadioType.START)

        viewBinding.radioStartMachine.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                Log.d(TAG, "checked start radio")
                checkedRadioButton(RadioType.START)
            }
        }

        viewBinding.radioExposureMachine.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                Log.d(TAG, "checked exposure radio")
                checkedRadioButton(RadioType.EXPOSURE)
            }
        }

        viewBinding.editStartSelectMachine.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                val check = BarcodeStyle(this).eqpId(viewBinding.editStartSelectMachine)
                if (check && ValidateCheck(this).equipment(
                        viewBinding.txtStartStandardMachine.text.toString(),
                        viewBinding.editStartSelectMachine.text.toString()
                    )
                ) {
                    getRealEqp(viewBinding.editStartSelectMachine.text.toString())
                }


            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).eqpId(viewBinding.editStartSelectMachine)

                    if (check && ValidateCheck(this).equipment(
                            viewBinding.txtStartStandardMachine.text.toString(),
                            viewBinding.editStartSelectMachine.text.toString()
                        )
                    ) {
                        getRealEqp(viewBinding.editStartSelectMachine.text.toString())
                    }

                }
            }

            true
        }

        viewBinding.editExposureSelectMachine.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                val check = BarcodeStyle(this).eqpId(viewBinding.editExposureSelectMachine)
                if (check && ValidateCheck(this).equipment(
                        viewBinding.txtExposureStandardMachine.text.toString(),
                        viewBinding.editExposureSelectMachine.text.toString()
                    )
                ) {
                    getRealEqp(viewBinding.editExposureSelectMachine.text.toString())
                }

            } else if (event != null) {
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    val check = BarcodeStyle(this).eqpId(viewBinding.editExposureSelectMachine)
                    if (check && ValidateCheck(this).equipment(
                            viewBinding.txtExposureStandardMachine.text.toString(),
                            viewBinding.editExposureSelectMachine.text.toString()
                        )
                    ) {
                        getRealEqp(viewBinding.editExposureSelectMachine.text.toString())
                    }

                }
            }

            true
        }
        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                onOk()
            }
        })

        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                finish()
            }
        })

        setParam()
    }

    override fun onBackPressed() {
        viewBinding.btnOk.performClick()
    }

    private fun onOk() {
        var eqpId = ""
        var eqpGroup = ""
        var recipe = ""

        if (m_sIsExposure != "Y" || identCodeList == "E") {
            if (m_sSelNormalEqp.isEmpty()) {
                val returnCode = OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    "장비를 입력하세요.",
                    GetString.BTNOKSTR
                )
                return
            }
            eqpGroup = viewBinding.txtStartStandardMachine.text.toString()
            recipe = viewBinding.txtStartRecipe.text.toString()
            eqpId = m_sSelNormalEqp
        } else {
            if (m_sSelNormalEqp.isEmpty()) {
                val returnCode = OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    "Normal장비를 입력하세요.",
                    GetString.BTNOKSTR
                )
                return
            }

            if (m_sSelExposureEqp.isEmpty()) {
                val returnCode = OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    "Exposure장비를 입력하세요.",
                    GetString.BTNOKSTR
                )
                return
            }

            eqpGroup =
                viewBinding.txtStartStandardMachine.text.toString() + "|" + viewBinding.txtExposureStandardMachine.text.toString()
            recipe =
                viewBinding.txtStartRecipe.text.toString() + "|" + viewBinding.txtExposureRecipe.text.toString()
            eqpId = m_sSelNormalEqp + "|" + m_sSelExposureEqp
        }

        val returnIntent = Intent(applicationContext, MoveInInlineActivity::class.java)

        returnIntent.putExtra("EQPGROUP", eqpGroup)
        returnIntent.putExtra("EQPID", eqpId)
        returnIntent.putExtra("RECIPE", recipe)

        setResult(Activity.RESULT_OK, returnIntent)
        finish()
    }

    private fun checkedRadioButton(radioType: RadioType) {
        when (radioType) {
            RadioType.START -> {
                viewBinding.radioStartMachine.isChecked = true
                viewBinding.radioExposureMachine.isChecked = false
                viewBinding.layoutStart.setBackgroundColor(Color.rgb(255, 242, 129))
                viewBinding.layoutExposure.setBackgroundColor(Color.WHITE)

                viewBinding.editStartSelectMachine.isEnabled = true
                viewBinding.editExposureSelectMachine.isEnabled = false
                viewBinding.editStartSelectMachine.requestFocus()

            }
            RadioType.EXPOSURE -> {
                viewBinding.radioStartMachine.isChecked = false
                viewBinding.radioExposureMachine.isChecked = true
                viewBinding.layoutExposure.setBackgroundColor(Color.rgb(255, 242, 129))
                viewBinding.layoutStart.setBackgroundColor(Color.WHITE)

                viewBinding.editStartSelectMachine.isEnabled = false
                viewBinding.editExposureSelectMachine.isEnabled = true
                viewBinding.editExposureSelectMachine.requestFocus()

            }

        }
    }

    private fun setParam() {
        viewBinding.editStartSelectMachine.requestFocus()

        identCodeList = intent.getStringExtra("IDENTCODELIST").toString()
        val sEqpGroup = intent.getStringExtra("EQPGROUP").toString()
        val sExpEqpGroup = intent.getStringExtra("EXPEQPGROUP").toString()


        m_sIsExposure = intent.getStringExtra("ISEXPOSURE").toString()
        m_sOperation = intent.getStringExtra("OPERATION").toString()
        m_sSubOperation = intent.getStringExtra("SUBOPERATION").toString()
        m_sProduct = intent.getStringExtra("PRODUCT").toString()
        m_sLotId = intent.getStringExtra("LOTID").toString()

        viewBinding.txtStartStandardMachine.text = sEqpGroup

        if (m_sIsExposure != "Y" || identCodeList == "E") {
            viewBinding.layoutExposure.isGone = true
        } else {
            viewBinding.txtExposureStandardMachine.text = sExpEqpGroup
        }
    }

    private fun getRealEqp(eqpId: String) {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.realEqpId(DeviceInfo.FACILITY, eqpId, "")

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.REALEQPID)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val sEqpId = messageBody.optString("EQPID")

                if (viewBinding.radioStartMachine.isChecked) {
                    m_sSelNormalEqp = sEqpId
                } else {
                    m_sSelExposureEqp = sEqpId
                }

                getRecipeInfo(sEqpId)

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )
            }

        }
    }

    private fun getRecipeInfo(eqpId: String) {
        mainScope.launch {
            var subOperation = m_sSubOperation

            if (viewBinding.radioExposureMachine.isChecked) {
                subOperation = "E"
            }

            val sendMessage = MessageFactoryUtil.recipeInfo(
                "Y",
                m_sLotId,
                m_sOperation,
                subOperation,
                m_sProduct,
                eqpId,
                "",
                DeviceInfo.FACILITY
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.RECIPEINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val recipe = messageBody.optString("RECIPE")

                if (m_sIsExposure == "Y" && identCodeList != "E") {
                    if (viewBinding.radioStartMachine.isChecked) {
                        viewBinding.txtStartRecipe.text = recipe
                        viewBinding.radioExposureMachine.isChecked = true
                    } else {
                        viewBinding.txtExposureRecipe.text = recipe
                        //viewBinding.editExposureSelectMachine.isFocusable = false
                    }
                } else {
                    viewBinding.txtStartRecipe.text = recipe
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                val returnCode = OkDialog.show(
                    supportFragmentManager,
                    GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage,
                    GetString.BTNOKSTR
                )
            }
        }
    }

}