package com.keyfoundry.hifos.view.lot

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.core.view.GestureDetectorCompat
import androidx.core.view.children
import androidx.core.view.size
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.grid.CTMainLayout
import com.keyfoundry.hifos.config.grid.CTRowLayout
import com.keyfoundry.hifos.config.grid.CTSubLayout
import com.keyfoundry.hifos.config.grid.ColumnProperty
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityLotStatusByBayBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDialogFragment
import com.keyfoundry.hifos.view.esheet.ESheetActivity
import com.keyfoundry.hifos.view.retransfer.ReTransferActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class LotStatusByBayActivity : HFActivity() {
    companion object {
        private const val TAG = "LotStatusByBayActivity"
    }

    private lateinit var viewBinding: ActivityLotStatusByBayBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private lateinit var gridService: GridService

    private lateinit var selectedRow: CTRowLayout
    private var selectedRowCount = 0
    private val selectedRowList = arrayListOf<Int>()

    inner class MyGestureListener : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(e: MotionEvent?): Boolean {
            if (!selectedRow.isSelected && selectedRowCount + 1 > 6) {
                OkDialogFragment(
                    GetString.TXTDIALOGTITLE_ERROR,
                    "최대 6개까지 지정할수 있습니다.",
                    GetString.BTNOKSTR
                ).show(supportFragmentManager, "okDialog")
            } else {
                selectedRow.isSelected = !selectedRow.isSelected

                val rowIndex = ((selectedRow.parent) as CTSubLayout).indexOfChild(selectedRow)

                if (selectedRow.isSelected) {
                    selectedRowCount++
                    selectedRowList.add(rowIndex)
                } else {
                    selectedRowCount--
                    selectedRowList.remove(rowIndex)
                }

                if (selectedRowCount != 1)
                    buttonEnable(false)
                else
                    buttonEnable(true)
            }
            return super.onSingleTapUp(e)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityLotStatusByBayBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        gridService = GridService(applicationContext)

        setSpinnerBay()
        viewBinding.spinnerBay.onItemSelectedListener = itemSelectedListener

        viewBinding.btnSearchLot.setOnClickListener(onSingleClickListener)
        viewBinding.btnSelectedCancel.setOnClickListener(onSingleClickListener)
        viewBinding.btnEsheet.setOnClickListener(onSingleClickListener)
        viewBinding.btnStockerOut.setOnClickListener(onSingleClickListener)
        viewBinding.btnCarry.setOnClickListener(onSingleClickListener)
        viewBinding.btnBayClose.setOnClickListener(onSingleClickListener)

        viewBinding.editJob.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { // KeyBoard Event
                searchLotList()
                viewBinding.editJob.selectAll()
            } else if (event != null) { // Barcode Event
                if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                    searchLotList()
                    viewBinding.editJob.selectAll()
                }
            }

            true
        }
    }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSearchLot.id -> {
                    searchLotList()
                    viewBinding.editJob.selectAll()
                }
                viewBinding.btnStockerOut.id -> {
                    executeSTKout()
                }
                viewBinding.btnSelectedCancel.id -> {
                    if (viewBinding.mainBody.childCount > 0) {
                        val gridList = viewBinding.mainBody.getChildAt(0) as CTMainLayout
                        val mainTable = gridList.mainTable

                        for (row in 0 until mainTable.size) {
                            val tableRow = mainTable.getChildAt(row) as CTRowLayout

                            if (tableRow.isSelected)
                                tableRow.isSelected = false
                        }

                        selectedRowList.clear()
                        selectedRowCount = 0
                        buttonEnable(false)
                    }
                }
                viewBinding.btnEsheet.id -> {
                    executeEsheet()
                }
                viewBinding.btnCarry.id -> {
                    executeCarry()
                }
                viewBinding.btnBayClose.id -> {
                    finish()
                }
            }
        }

    }

    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerBay.id -> {
                        setSpinnerSTK()
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private fun executeEsheet() {
        if (selectedRowCount != 1) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "eSheet조회는 한개의 LOT만 선택하세요.", GetString.BTNOKSTR
            )
        }

        val nextIntent = Intent(this, ESheetActivity::class.java)
        val gridBody = viewBinding.mainBody.getChildAt(0) as CTMainLayout
        val rowData =
            gridBody.mainTable.getChildAt(selectedRowList[0]) as CTRowLayout
        val lotName = gridService.getCellValue(rowData, "LOTID")

        nextIntent.putExtra("LOTID", lotName)

        startActivity(nextIntent)
    }

    private fun setSpinnerBay() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.areaBayInfo(DeviceInfo.AREA, DeviceInfo.FACILITY)
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.AREABAYINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val bayListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "BAYS")

                val spinnerBayItems = arrayListOf<String>()

                for (i in 0 until bayListJSON.length()) {
                    val bay = bayListJSON.getJSONObject(i)
                    spinnerBayItems.add(bay.getString("BAY"))
                }

                setBaySpinner(spinnerBayItems)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setBaySpinner(itemList: ArrayList<String>) {
        val spinnerAdapter = ArrayAdapter(this, R.layout.contact_spinner_row_init, itemList)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerBay.adapter =
            InitSpinnerAdapter(spinnerAdapter, R.layout.contact_spinner_row_init, this)
    }

    private fun clearData() {
        viewBinding.spinnerStk.adapter = null
        viewBinding.editJob.setText("")
        viewBinding.mainBody.removeAllViews()

        buttonEnable(false)
    }

    private fun setSpinnerSTK() {
        mainScope.launch {
            clearData()

            if (viewBinding.spinnerBay.selectedItem == null)
                return@launch

            val sendMessage =
                MessageFactoryUtil.bayStockerInfo(
                    viewBinding.spinnerBay.selectedItem.toString(), DeviceInfo.FACILITY
                )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.BAYSTOCKERINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val stkListJSON = ResponseDataToJsonUtil.getMessageBodyList(result, "STOCKERS")

                val spinnerSTKItems = arrayListOf<String>()

                for (i in 0 until stkListJSON.length()) {
                    val stk = stkListJSON.getJSONObject(i)
                    spinnerSTKItems.add(stk.getString("STOCKER"))
                }

                setSTKSpinner(spinnerSTKItems)
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setSTKSpinner(itemList: ArrayList<String>) {
        itemList.add("모두")

        val spinnerAdapter = ArrayAdapter(this, R.layout.contact_spinner_row_init, itemList)
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerStk.adapter =
            InitSpinnerAdapter(spinnerAdapter, R.layout.contact_spinner_row_init, this)

        viewBinding.spinnerStk.setSelection(1, false)
    }

    private fun clearGridData() {
        viewBinding.mainBody.removeAllViews()
        selectedRow = CTRowLayout(this)
        selectedRowCount = 0
        selectedRowList.clear()
    }

    private fun searchLotList() {
        mainScope.launch {
            CommonUtil.hideKeyboard(this@LotStatusByBayActivity, currentFocus)

            clearGridData()

            if (viewBinding.spinnerBay.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "BAY를 선택해주세요", GetString.BTNOKSTR
                )
                return@launch
            }

            if (viewBinding.spinnerStk.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "STK를 선택해주세요", GetString.BTNOKSTR
                )
                return@launch
            }

            val sendMessage = MessageFactoryUtil.blstInfo(
                viewBinding.spinnerBay.selectedItem.toString(),
                viewBinding.spinnerStk.selectedItem.toString(),
                viewBinding.editJob.text.toString(),
                DeviceInfo.FACILITY
            )

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.BLSTINFO)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                val itemList =
                    ResponseDataToJsonUtil.getMessageBodyInValueList(result, "BLSTITEMS", "ITEM")

                val columnData = linkedMapOf(
                    "JOBCODE" to ColumnProperty("JOB", Gravity.CENTER, false),
                    "PROCESSSTEP" to ColumnProperty("공정명", Gravity.START, false),
                    "LOTID" to ColumnProperty("LOT ID", Gravity.CENTER, false),
                    "LOCATION" to ColumnProperty("상태", Gravity.CENTER, false),
                    "QUANTITY" to ColumnProperty("수량", Gravity.CENTER, false),
                    "LOC_TYPE" to ColumnProperty("위치구분", Gravity.CENTER, false)
                )

                val gridList = gridService.setGridPropData(columnData, itemList)
                viewBinding.mainBody.addView(gridList)
                setSelectRowColor(gridList)

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    fun setSelectRowColor(gridList: CTMainLayout) {
        val mainTable = gridList.mainTable
        selectedRowCount = 0

        for (row in mainTable.children) {
            val tableRow = row as CTRowLayout
            tableRow.setBackgroundResource(R.drawable.selected_grid_row)

            val mDetector = GestureDetectorCompat(this, MyGestureListener())

            tableRow.setOnTouchListener { v, event ->
                selectedRow = v as CTRowLayout

                return@setOnTouchListener (mDetector.onTouchEvent(event))
            }
        }
    }

    private fun executeSTKout() {
        if (viewBinding.mainBody.childCount < 1) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "조회된 데이터가 없습니다.", GetString.BTNOKSTR
            )

            return
        }

        val gridBody = viewBinding.mainBody.getChildAt(0) as CTMainLayout

        val rowList = selectedRowList.sorted()

        var lotIdList = ""

        for (row in rowList) {
            val rowData = gridBody.mainTable.getChildAt(row) as CTRowLayout
            val lotId = gridService.getCellValue(rowData, "LOTID")
            val locType = gridService.getCellValue(rowData, "LOC_TYPE")

            if (locType != "S") {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "LOT NO [$lotId]는 STOCKER내에 있지 않습니다", GetString.BTNOKSTR
                )
                return
            }

            lotIdList += "    $lotId\n"
        }

        lotIdList = lotIdList.substring(0, lotIdList.lastIndexOf("\n"))

        var out = ""
        if (viewBinding.radioOneOut.isChecked)
            out = "OUT"
        else if (viewBinding.radioTwoOut.isChecked)
            out = "2OUT"

        val message = """
            |LOT NO:
            |$lotIdList
            |를 $out PORT로 출고 하시겠습니까?
        """.trimMargin()

        val returnCode = OkCancelDialog.show(
            supportFragmentManager, GetString.TXTDIALOGTITLE_OK, message,
            GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
        )

        if (returnCode == OkCancelDialog.RETURN_CODE_OK) {
            stockerOut()
        }
    }

    private fun stockerOut() {
        mainScope.launch {
            var port = ""

            if (viewBinding.radioOneOut.isChecked)
                port = "OUT"
            else if (viewBinding.radioTwoOut.isChecked)
                port = "2OUT"

            val gridBody = viewBinding.mainBody.getChildAt(0) as CTMainLayout
            val rowList = selectedRowList.sorted()

            var itemList = ""

            for (row in rowList) {
                val rowData = gridBody.mainTable.getChildAt(row) as CTRowLayout
                val lotId = gridService.getCellValue(rowData, "LOTID")
                val stockerId = gridService.getCellValue(rowData, "LOCATION")

                itemList += """
                        |<ITEM>
                        |<LOTID>$lotId</LOTID>
                        |<STOCKER>$stockerId</STOCKER>
                        |</ITEM>
                    """.trimMargin()
            }

            val sendMessage =
                MessageFactoryUtil.stockOut(DeviceInfo.FACILITY, port, rowList.count(), itemList)

            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.STOCKOUT)
            val isSuccessFul = message.isSuccessFul
            val result = message.result

            if (isSuccessFul) {
                searchLotList()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )

            }

        }
    }

    private fun executeCarry() {
        if (viewBinding.mainBody.childCount < 1) {
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "조회된 데이터가 없습니다.", GetString.BTNOKSTR
            )

            return
        }

        val gridBody = viewBinding.mainBody.getChildAt(0) as CTMainLayout
        val rowData = gridBody.mainTable.getChildAt(selectedRowList[0]) as CTRowLayout
        val locType = gridService.getCellValue(rowData, "LOC_TYPE")

        if (locType != "S") {
            val message = """
                |현재 LOT이 STOCKER내에 있지 않습니다.
                |STOCKER에 입고후 반송하세요.
            """.trimMargin()

            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                message, GetString.BTNOKSTR
            )
            return
        }

        val lotName = gridService.getCellValue(rowData, "LOTID")

        val nextIntent = Intent(this, ReTransferActivity::class.java)

        nextIntent.putExtra("LOTID", lotName)

        startActivity(nextIntent)
    }

    private fun buttonEnable(state: Boolean) {
        viewBinding.radioOneOut.isChecked = true
        viewBinding.radioTwoOut.isChecked = false

        viewBinding.btnEsheet.isEnabled = state
//        viewBinding.btnCarry.isEnabled = state
    }
}