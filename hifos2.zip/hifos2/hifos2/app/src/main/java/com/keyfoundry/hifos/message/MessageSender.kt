package com.keyfoundry.hifos.message

import android.util.Log
import androidx.fragment.app.FragmentManager
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.service.RetrofitSyncService
import com.keyfoundry.hifos.config.service.dto.ErrorData
import com.keyfoundry.hifos.config.service.dto.RequestData
import com.keyfoundry.hifos.config.service.dto.ResponseData
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.view.dialog.fragment.LoadingBar
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import kotlinx.coroutines.*
import kotlin.system.exitProcess

/*
* 모바일 서버로 메시지를 전송 및 응답 받은 메시지를 담는 Class
* */
class MessageSender {

    companion object {
        private const val TAG = "MessageSender"
        const val ERRORMSG_MSGBODY = "BODY가 존재하지 않습니다"

        suspend fun send(
            supportFragmentManager: FragmentManager, sendMessage: String, messageName: String
        ): Message {
            var message = Message(ResponseData("", 0), false)

            val e = LoadingBar.getInstance()
            try {
                e.show(supportFragmentManager, LoadingBar.TAG)
            } catch(ex: Exception){
            }


            withContext(Dispatchers.IO) {
                message = try {
                    val result = RetrofitSyncService.API.hifosProcessMessage(
                        RequestData(sendMessage),
                        messageName
                    )
                    checkValidate(result)
                } catch (e: Exception) {
                    setExceptionMessage(e.message)
                }
                Log.d(TAG, "$message")
            }


            e.close()

            return message
        }

        // Loadingbar 없는 send
        suspend fun send(
             sendMessage: String, messageName: String
        ): Message {
            var message = Message(ResponseData("", 0), false)

            // 사용자 아이디가 OPERATOR_ID로 초기화 될 경우 서버에 메시지를 안보내기 위하여 추가
            if(DeviceInfo.OPERATOR_ID=="OPERATOR_ID"){
                message = Message(ResponseData("오류가 발생하였습니다.\n이전화면으로 돌아가주세요.", 0), false)
                return message
            }

            withContext(Dispatchers.IO) {
                message = try {
                    val result = RetrofitSyncService.API.hifosProcessMessage(
                        RequestData(sendMessage),
                        messageName
                    )
                    checkValidate(result)
                } catch (e: Exception) {
                    setExceptionMessage(e.message)
                }
                Log.d(TAG, "$message")
            }

            return message
        }

        suspend fun checkAPI(supportFragmentManager: FragmentManager): ResponseData {
            return withContext(Dispatchers.IO) {
                var responseData = ResponseData("", 0)
                LoadingBar.show(supportFragmentManager)
                try {
                    responseData = RetrofitSyncService.API.hifosCheck()
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        OkDialog.show(
                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                            "${e.message}", GetString.BTNOKSTR
                        )
                    }
                } finally {
                    LoadingBar.hide(supportFragmentManager)
                }
                Log.d(TAG, "$responseData")
                responseData
            }
        }

        private fun setExceptionMessage(errorMessage: String?): Message {
            val message = Message(ResponseData("", 0), false)
            val errMsg = """
                    |{"${GetString.ERRMSG}":"$errorMessage"}"
                    """.trimMargin()
            message.result = ResponseData(errMsg, 0)
            message.isSuccessFul = false

            return message
        }

        private fun checkValidate(result: ResponseData): Message {
            val message = Message(ResponseData("", 0), false)
            val isSuccessFul = ResponseDataToJsonUtil.isSuccessFul(result)

            if (isSuccessFul) {
                // 1. CHECK MSGBODY
                if (ResponseDataToJsonUtil.isMessageBodyCheck(result)) {
                    message.result = result
                    message.isSuccessFul = true
                } else {
                    val errorMessage = """
                    |{"${GetString.ERRMSG}":"$ERRORMSG_MSGBODY"}"
                    """.trimMargin()
                    message.result = ResponseData(errorMessage, 0)
                    message.isSuccessFul = false
                }
            } else {
                message.result = result
                message.isSuccessFul = false
            }

            return message
        }
    }
}