package com.keyfoundry.hifos.view.remote

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Vibrator
import android.text.InputFilter
import android.text.method.ScrollingMovementMethod
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CompoundButton
import androidx.activity.result.contract.ActivityResultContracts
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.const.MessageName
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.*
import com.keyfoundry.hifos.databinding.ActivityRemoteImpMainBinding
import com.keyfoundry.hifos.message.MessageSender
import com.keyfoundry.hifos.view.dialog.RemoteRecipeDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkCancelDialog
import com.keyfoundry.hifos.view.dialog.fragment.OkDailogAlram
import com.keyfoundry.hifos.view.dialog.fragment.OkDialog
import com.keyfoundry.hifos.view.esheet.comment.CommentListActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RemoteImpMainActivity : HFActivity() {
    companion object {
        private const val TAG = "RemoteImpMainActivity"
    }

    private lateinit var viewBinding: ActivityRemoteImpMainBinding

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var lsChangeRecipe = false
    private var lsChangeEqpGroup = false
    private var isMainEqp = ""
    private var searchRecipe = ""
    private var searchArea = ""
    private var searchOpType = ""
    private var searchEqpType = ""
    private var searchOperation = ""
    private var searchSubOperation = ""
    private var searchProcessStep = ""
    private var searchOperSeq = ""
    private var exposure = false
    private var oriBay = ""
    private var oriStk = ""

    private var rfReadCount = 0 //[Addition] Jul 24, 2005. I. H. Lee

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityRemoteImpMainBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.txtMachine.movementMethod = ScrollingMovementMethod.getInstance()
        viewBinding.txtEngineer.movementMethod = ScrollingMovementMethod.getInstance()

        //소문자 -> 대문자
        viewBinding.editSelectMachine.filters = arrayOf<InputFilter>(InputFilter.AllCaps())

        initDisable()

        if (intent.getStringExtra("LOTID")?.isNotEmpty() == true) {
            val lotId = intent.getStringExtra("LOTID").toString()
            viewBinding.txtLotNo.text = lotId
            //---[Modification] Mar 26, 2007. by I. H. Lee (Begin)
            setLotInfo(lotId)
            //---[Modification] Mar 26, 2007. by I. H. Lee (End)
            if (intent.getStringExtra("EQPID")?.isNotEmpty() == true) {
                val eqpId = intent.getStringExtra("EQPID").toString()
                viewBinding.editSelectMachine.setText(eqpId)

                getMachineInfo(eqpId)
            }
        }

        viewBinding.editSelectMachine.setOnEditorActionListener { v, actionId, event ->
            when (v.id) {
                viewBinding.editSelectMachine.id -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        val check = BarcodeStyle(this).eqpId(viewBinding.editSelectMachine)

                        if (check)
                            getMachineInfo(viewBinding.editSelectMachine.text.toString())
                    } else if (event != null) { // Barcode Event
                        if (actionId == 0 && event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_ENTER) {
                            val check = BarcodeStyle(this).eqpId(viewBinding.editSelectMachine)

                            if (check)
                                getMachineInfo(viewBinding.editSelectMachine.text.toString())
                        }
                    }
                }
            }

            true
        }

        viewBinding.chkCarry.setOnCheckedChangeListener(checkedChangeListener)

        viewBinding.spinnerPort.onItemSelectedListener = itemSelectedListener
        viewBinding.spinnerBay.onItemSelectedListener = itemSelectedListener
        viewBinding.spinnerRecipe.onItemSelectedListener = itemSelectedListener

        viewBinding.btnClearPort.setOnClickListener(onSingleClickListener)
        viewBinding.btnBatch.setOnClickListener(onSingleClickListener)
        viewBinding.btnReadComment.setOnClickListener(onSingleClickListener)
        viewBinding.btnStart.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)
    }

    private val checkedChangeListener =
        CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                viewBinding.spinnerBay.isEnabled = true
                viewBinding.spinnerStk.isEnabled = true

                setBaySpinner()
            } else {
                clearSpinnerInfo()
            }
        }

    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnClearPort.id -> {
                    executeClearPort()
                }
                viewBinding.btnBatch.id -> {
                    executeBatch()
                }
                viewBinding.btnReadComment.id -> {
                    executeComment()
                }
                viewBinding.btnStart.id -> {
                    executeStart()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerPort.id -> {
                        setPortState()
                    }
                    viewBinding.spinnerBay.id -> {
                        setStkSpinner()
                    }
                    viewBinding.spinnerRecipe.id -> {
                        memorizationRecipe()
                    }
                }
            }
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }

    private fun clearSpinnerInfo() {
        if (viewBinding.spinnerBay.selectedItem != null)
            oriBay = viewBinding.spinnerBay.selectedItem.toString()

        if (viewBinding.spinnerStk.selectedItem != null)
            oriStk = viewBinding.spinnerStk.selectedItem.toString()

        viewBinding.spinnerBay.adapter = null
        viewBinding.spinnerStk.adapter = null

        viewBinding.spinnerBay.isEnabled = false
        viewBinding.spinnerStk.isEnabled = false
    }

    private fun setBaySpinner() {
        mainScope.launch {
            val sendMessage = MessageFactoryUtil.areaBayInfo(DeviceInfo.FACILITY)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.AREABAYINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val bays = ResponseDataToJsonUtil.getMessageBodyList(result, "BAYS")

                val bayList = arrayListOf<String>()
                for (count in 0 until bays.length())
                    bayList.add(bays.getJSONObject(count).optString("BAY"))

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, bayList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerBay.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                if (oriBay.isNotEmpty() && bayList.contains(oriBay)) {
                    val index = bayList.indexOf(oriBay) + 1
                    viewBinding.spinnerBay.setSelection(index, false)
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setStkSpinner() {
        mainScope.launch {
            if (viewBinding.spinnerBay.selectedItem == null)
                return@launch

            val bay = viewBinding.spinnerBay.selectedItem.toString()
            val sendMessage = MessageFactoryUtil.bayStockerInfo(bay, DeviceInfo.FACILITY)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.BAYSTOCKERINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val stockers = ResponseDataToJsonUtil.getMessageBodyList(result, "STOCKERS")

                val stkList = arrayListOf<String>()
                for (count in 0 until stockers.length())
                    stkList.add(stockers.getJSONObject(count).optString("STOCKER"))

                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, stkList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerStk.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                if (oriStk.isNotEmpty() && stkList.contains(oriStk)) {
                    val index = stkList.indexOf(oriStk) + 1
                    viewBinding.spinnerStk.setSelection(index, false)
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun executeClearPort() {
        mainScope.launch {
            if (viewBinding.spinnerPort.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Port를 먼저 선택하세요.", GetString.BTNOKSTR
                )

                return@launch
            }

            val portName = viewBinding.spinnerPort.selectedItem.toString()
            val changeCheck = OkCancelDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                "PORT [$portName]을(를) 초기화 하고 [IDLE]상태로 바꾸시겠습니까?",
                GetString.POSITIVEBTNSTR, GetString.NEGATIVEBTNSTR
            )

            if (changeCheck == OkCancelDialog.RETURN_CODE_CANCEL)
                return@launch

            val sendMessage = MessageFactoryUtil.machinePortClean(isMainEqp, portName)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MACHINEPORTCLEAR
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                OkDialog.show(
                    supportFragmentManager, "DOOR OPEN",
                    "해당 PORT 초기화 명령을 전송하였습니다.", GetString.BTNOKSTR
                )

                setPortState()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun executeBatch() {
        if (viewBinding.txtLotNo.text.isEmpty() || viewBinding.editSelectMachine.text.isEmpty() || viewBinding.spinnerRecipe.selectedItem == null) {
            OkDialog.show(
                supportFragmentManager, "PORT WORNING",
                "진행 정보가 부족합니다. 장비를 다시 조회 후 진행바랍니다.", GetString.BTNOKSTR
            )

            return
        }

        val nextIntent = Intent(this, RemoteImpBatchActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
        nextIntent.putExtra("EQPID", viewBinding.editSelectMachine.text.toString())

        activityFactoryResultLauncher.launch(nextIntent)
    }

    private val activityFactoryResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                finish()
            }
        }

    private fun executeComment() {
        val nextIntent = Intent(this, CommentListActivity::class.java)
        nextIntent.putExtra("LOTID", viewBinding.txtLotNo.text.toString())
        nextIntent.putExtra("OPERATION", searchOperation)
        nextIntent.putExtra("SUBOPERATION", searchSubOperation)
        nextIntent.putExtra("PROCESSSTEP", searchProcessStep)
        nextIntent.putExtra("OPERSEQUENCE", searchOperSeq)

        startActivity(nextIntent)
    }

    private fun executeStart() {
        mainScope.launch {
            if (viewBinding.editSelectMachine.text.isEmpty()) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행장비를 입력하세요.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.spinnerPort.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행 Port를 선택하세요.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.spinnerRecipe.selectedItem == null) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "진행Rcp를 선택하세요.", GetString.BTNOKSTR
                )

                return@launch
            }

            if (viewBinding.chkCarry.isChecked) {
                if (viewBinding.spinnerBay.selectedItem == null) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "BAY를 선택하세요.", GetString.BTNOKSTR
                    )

                    return@launch
                }

                if (viewBinding.spinnerStk.selectedItem == null) {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "STOCKER를 선택하세요.", GetString.BTNOKSTR
                    )

                    return@launch
                }
            }

            val checkMessage = MessageFactoryUtil.lotInfo(
                "MVIN", viewBinding.txtLotNo.text.toString(), DeviceInfo.FACILITY
            )

            val commentMessage = MessageSender.send(
                supportFragmentManager, checkMessage, MessageName.LOTINFO
            )
            val isCommentSuccessFul = commentMessage.isSuccessFul
            val commentResult = commentMessage.result
            if (isCommentSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(commentResult)
                val nwCommentQty = messageBody.optString("NWCOMMENTQTY")
                if (nwCommentQty.isNotEmpty() && nwCommentQty.toInt() > 0) {
                    val commentMsg = """
                        |읽지 않은 작업성 COMMENT가 [$nwCommentQty]가 있습니다.
                        |읽은후 진행하세요.
                    """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        commentMsg, GetString.BTNOKSTR
                    )

                    return@launch
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(commentResult)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }

            //레시피 확인 Dialog
            val recipeIntent = Intent(this@RemoteImpMainActivity, RemoteRecipeDialog::class.java)
            recipeIntent.putExtra(
                RemoteRecipeDialog.RECIPE_LIST,
                viewBinding.spinnerRecipe.selectedItem.toString()
            )
            activityRecipeResultLauncher.launch(recipeIntent)
        }
    }

    private val activityRecipeResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                execute()
            }
        }

    private fun execute() {
        mainScope.launch {
            val machineName = viewBinding.editSelectMachine.text.toString()
            val lotName = viewBinding.txtLotNo.text.toString()
            val portName = viewBinding.spinnerPort.selectedItem.toString()
            val recipeName = viewBinding.spinnerRecipe.selectedItem.toString()
            val jotCode = viewBinding.txtJobCode.text.toString()
            val productName = viewBinding.txtProduct.text.toString()
            var isCarry = "N"
            var bay = ""
            var stocker = ""

            if (viewBinding.chkCarry.isChecked) {
                isCarry = "Y"
                bay = viewBinding.spinnerBay.selectedItem.toString()
                stocker = viewBinding.spinnerStk.selectedItem.toString()
            }

            val sendMessage = MessageFactoryUtil.impRemoteStart(
                machineName, searchEqpType, lotName, portName, recipeName, jotCode,
                productName, searchOperation, isCarry, bay, stocker, DeviceInfo.OPERATOR_ID
            )

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.IMPREMOTESTART
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                setResult(RESULT_OK)
                finish()
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDailogAlram.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR, applicationContext,
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                )
            }
        }
    }

    private fun clearPortState() {
        viewBinding.txtPortState.text = null
        viewBinding.txtPortState.background = null
    }

    private fun setPortState() {
        mainScope.launch {
            clearPortState()

            if (viewBinding.spinnerPort.selectedItem == null)
                return@launch

            viewBinding.btnClearPort.isEnabled = false
            viewBinding.btnBatch.isEnabled = false
            val portName = viewBinding.spinnerPort.selectedItem.toString()

            val sendMessage = MessageFactoryUtil.machinePortStatus(isMainEqp, portName)
            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.MACHINEPORTSTATUS
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val portState = messageBody.optString("PORTSTATENAME")
                val portLotName = messageBody.optString("PORTLOTNAME")
                val ackMsg = messageBody.optString("ACKMSG")
                val allState = messageBody.optString("ALLSTATE")

                viewBinding.txtPortState.text = portState
                setPortColor(portState)

                if (portState == "RUN" || portState == "PENDING" || portState == "RESERVED" || portState == "COMPLETE") {
                    val portError = """
                        |해당 PORT가 진행중입니다.
                        |장비 및 진행할 LOT을 다시 확인 바랍니다.
                    """.trimMargin()
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        portError, GetString.BTNOKSTR
                    )

                    viewBinding.btnClearPort.isEnabled = true
                    viewBinding.btnStart.isEnabled = false

                    if (ackMsg.isNotEmpty()) {
                        OkDialog.show(
                            supportFragmentManager, "PORT WORNING",
                            ackMsg, GetString.BTNOKSTR
                        )
                    }
                } else if (portState == "IDLE") {
                    OkDialog.show(
                        supportFragmentManager, "장비 MASSAGE",
                        "CST가 LOAD되어 있지 않습니다.", GetString.BTNOKSTR
                    )
                    viewBinding.btnStart.isEnabled = false
                } else if (portState.isEmpty()) {
                    val portMessage = """
                        |"PORT 정보를 가져올 수 없습니다.
                        |잠시후 다시 확인 바랍니다.
                    """.trimMargin()
                    OkDialog.show(
                        supportFragmentManager, "장비 MASSAGE",
                        portMessage, GetString.BTNOKSTR
                    )

                    viewBinding.btnStart.isEnabled = false
                    viewBinding.btnBatch.isEnabled = false
                    viewBinding.btnClearPort.isEnabled = false
                } else {
                    if (searchEqpType == "VARIAN_MC" && portState == "READY") {
                        viewBinding.btnStart.isEnabled = true
                        viewBinding.btnClearPort.isEnabled = false

                        if (portName == "1" && allState == "Y")
                            viewBinding.btnBatch.isEnabled = true

                    } else {
                        viewBinding.btnStart.isEnabled = true
                        viewBinding.btnClearPort.isEnabled = true
                    }
                }

            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun setPortColor(portState: String) {
        when (portState) {
            "RUN" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.BLUE)
                viewBinding.txtPortState.setTextColor(Color.WHITE)
            }
            "PENDING" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portPending))
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "READY" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.GREEN)
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "RESERVED" -> {
                viewBinding.txtPortState.setBackgroundColor(Color.YELLOW)
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "COMPLETE" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portCompleted))
                viewBinding.txtPortState.setTextColor(Color.BLACK)
            }
            "IDLE" -> {
                viewBinding.txtPortState.setBackgroundColor(getColor(R.color.portIdle))
                viewBinding.txtPortState.setTextColor(Color.WHITE)
            }
        }
    }

    private fun initDisable() {
        viewBinding.chkCarry.isChecked = false

        viewBinding.btnReadComment.isEnabled = false
        viewBinding.btnClearPort.isEnabled = false
        viewBinding.chkCarry.isEnabled = false
        viewBinding.spinnerBay.isEnabled = false
        viewBinding.spinnerStk.isEnabled = false
        viewBinding.btnBatch.isEnabled = false
        viewBinding.btnReadComment.isEnabled = false
        viewBinding.btnStart.isEnabled = false

        rfReadCount = 0
    }

    private fun clearLotInfo() {
        searchRecipe = ""
        lsChangeRecipe = false
        lsChangeEqpGroup = false
        searchArea = ""
        searchOpType = ""
        searchOperation = ""
        searchSubOperation = ""
        searchProcessStep = ""
        searchOperSeq = ""

        viewBinding.txtCommentCount.text = ""
        viewBinding.txtMachine.text = ""
        viewBinding.txtJobCode.text = ""
        viewBinding.txtProduct.text = ""
        viewBinding.txtCurrentOperation.text = ""
        viewBinding.txtQty.text = ""
        viewBinding.txtFacility.text = DeviceInfo.FACILITY
        viewBinding.txtCustomer.text = ""
        viewBinding.txtSaleType.text = ""
        viewBinding.txtEngineer.text = ""
        viewBinding.txtPacking.text = ""
        viewBinding.txtGoodChips.text = ""

        viewBinding.spinnerRecipe.adapter = null
    }

    private fun setLotInfo(lotId: String) {
        mainScope.launch {
            clearLotInfo()

            val sendMessage = MessageFactoryUtil.lotInfo("MVIN", lotId, DeviceInfo.FACILITY)

            val message = MessageSender.send(
                supportFragmentManager, sendMessage, MessageName.LOTINFO
            )
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                val product = messageBody.optString("PRODUCT")
                val facility = messageBody.optString("FACILITY")
                val operation = messageBody.optString("OPERATION")
                val customer = messageBody.optString("CUSTOMER")
                val category = messageBody.optString("CATEGORY")
                val engineer = messageBody.optString("ENGINEER")
                val packing = messageBody.optString("PACKING")
                val qty = messageBody.optString("QUANTITY")
                val goodChips = messageBody.optString("GOODCHIPS")
                val recipe = messageBody.optString("RECIPE")
                val changeRecipe = messageBody.optString("CHANGERECIPE")
                val eqpGroup = messageBody.optString("EQPGROUP")
                val changeEqpGroup = messageBody.optString("CHANGEEQPGROUP")
                val commentQty = messageBody.optString("COMMENTQTY")
                val nwCommentQty = messageBody.optString("NWCOMMENTQTY")
                val batchId = messageBody.optString("BATCHID")
                val area = messageBody.optString("AREA")
                val workedEqpId = messageBody.optString("WORKEDEQPID")
                val workedRecipe = messageBody.optString("WORKEDRECIPE")
                val workedReticle = messageBody.optString("WORKEDRETICLE")
                val jobCode = messageBody.optString("JOBCODE")
                val processStep = messageBody.optString("PROCESSSTEP")
                val subOperation = messageBody.optString("SUBOPERATION")
                val opType = messageBody.optString("OPTYPE")
                val status = messageBody.optString("STATUS")
                val state = messageBody.optString("STATE")
                val holdStatus = messageBody.optString("HOLDSTATUS")
                val operSeq = messageBody.optString("OPERSEQUENCE")
                val etcMsg = messageBody.optString("ETCMSG")
                val machineName = messageBody.optString("MACHINENAME")
                val portName = messageBody.optString("PORTNAME")
                val machineRecipeName = messageBody.optString("MACHINERECIPENAME")
                val lotResUser = messageBody.optString("LOTRESUSER")
                val skipAllowFlag = messageBody.optString("SKIPALLOWFLAG")

                if (status == "RUN") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "이미 MOVE IN된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.isEnabled = false
                    return@launch
                }

                if (state != "WIP") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "$state 상태 입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.isEnabled = false
                    return@launch
                }

                if (holdStatus == "ONHOLD") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "HOLD된 LOT입니다. 자동화 진행이 불가합니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.isEnabled = false
                    return@launch
                }

                if (area != "IMP") {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        "IMP공정이 아닙니다. LOT을 확인 후 진행 바랍니다.", GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.isEnabled = false
                    return@launch
                }

                viewBinding.txtCommentCount.text = commentQty

                if (changeRecipe.isNotEmpty()) {
                    if (recipe == changeRecipe) {
                        searchRecipe = recipe
                        lsChangeRecipe = false
                    } else {
                        searchRecipe = changeRecipe
                        lsChangeRecipe = true
                    }
                } else {
                    searchRecipe = recipe
                    lsChangeRecipe = false
                }

                if (changeEqpGroup.isNotEmpty()) {
                    if (eqpGroup == changeEqpGroup) {
                        viewBinding.txtMachine.text = eqpGroup
                        lsChangeEqpGroup = false
                    } else {
                        viewBinding.txtMachine.text = changeEqpGroup
                        lsChangeEqpGroup = true
                    }
                } else {
                    viewBinding.txtMachine.text = eqpGroup
                    lsChangeEqpGroup = false
                }

                val currentStep = "$processStep($operation$subOperation)"

                viewBinding.txtJobCode.text = jobCode
                viewBinding.txtProduct.text = product
                viewBinding.txtCurrentOperation.text = currentStep
                viewBinding.txtQty.text = qty
                viewBinding.txtFacility.text = facility
                viewBinding.txtCustomer.text = customer
                viewBinding.txtSaleType.text = category
                viewBinding.txtEngineer.text = engineer
                viewBinding.txtPacking.text = packing
                viewBinding.txtGoodChips.text = goodChips

                searchArea = area
                searchOpType = opType
                searchOperation = operation
                searchSubOperation = subOperation
                searchProcessStep = processStep
                searchOperSeq = operSeq

                val itemList = searchRecipe.split(";")
                val spinnerAdapter =
                    ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, itemList)
                spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                viewBinding.spinnerRecipe.adapter = InitSpinnerAdapter(
                    spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                )

                if (etcMsg.isNotEmpty()) {
                    OkDialog.show(supportFragmentManager, "정보", etcMsg, GetString.BTNOKSTR)
                }

                viewBinding.btnReadComment.isEnabled = commentQty.toInt() > 0

                if (nwCommentQty.isNotEmpty() && nwCommentQty.toInt() > 0) {
                    val commentMsg = """
                        |읽지 않은 작업성 COMMENT가 [$nwCommentQty]가 있습니다.
                        |읽은후 진행하세요.
                    """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_OK,
                        commentMsg, GetString.BTNOKSTR
                    )
                }

                if (lotResUser.isNotEmpty()) {
                    val checkMsg = """
                        |작업 예약되었거나 진행중인 LOT입니다.
                        |이력 확인 후 진행바랍니다.
                    """.trimMargin()

                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        checkMsg, GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.isEnabled = false
                    viewBinding.spinnerRecipe.isEnabled = false
                    viewBinding.spinnerPort.isEnabled = false
                    viewBinding.btnStart.isEnabled = false

                    return@launch
                }
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    errorMessage, GetString.BTNOKSTR
                )
            }
        }
    }

    private fun clearMachineInfo() {
        isMainEqp = ""
        searchEqpType = ""

        viewBinding.spinnerPort.adapter = null
        viewBinding.btnClearPort.isEnabled = false

        clearPortState()
    }

    private fun getMachineInfo(eqpId: String) {
        mainScope.launch {
            clearMachineInfo()

            if (searchArea == "PHOTO" && searchOpType == "P" && exposure) {
                OkDialog.show(
                    supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                    "PHOTO진행 LOT입니다. PHOTO 자동화 기능을 이용해 주세요.", GetString.BTNOKSTR
                )

                viewBinding.editSelectMachine.requestFocus()
                viewBinding.editSelectMachine.selectAll()
                return@launch
            }

            var isMachineName = eqpId
            isMainEqp = eqpId


            val valEqpId = viewBinding.txtMachine.text.toString()
            if (searchOpType != "M" && valEqpId != "FAB2" && valEqpId != "FAB5" && valEqpId != "FAB7" && searchArea != "PQC") {
                val sendMessage = MessageFactoryUtil.remoteEqpInfo(isMachineName)

                val message = MessageSender.send(
                    supportFragmentManager, sendMessage, MessageName.REMOTEEQPINFO
                )
                val isSuccessFul = message.isSuccessFul
                val result = message.result
                if (isSuccessFul) {
                    val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
                    val mainEqp = messageBody.optString("MAINEQPID")
                    val procEqp = messageBody.optString("PROCEQPID")
                    val eqpArea = messageBody.optString("EQPAREA")
                    val eqpType = messageBody.optString("EQPTYPE")
                    //2015.06.01 장비 PM 주기 체크 수정
                    val pmMessage = messageBody.optString("PMMESSAGE")
                    val portName = messageBody.optString("PORTNAME")

                    if (pmMessage.isNotEmpty()) {
                        OkDialog.show(
                            supportFragmentManager, "PM주기 경고",
                            pmMessage, GetString.BTNOKSTR
                        )
                    }

                    val portList = portName.split(",")
                    val spinnerAdapter =
                        ArrayAdapter(
                            applicationContext,
                            R.layout.contact_spinner_row_init,
                            portList
                        )
                    spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
                    viewBinding.spinnerPort.adapter = InitSpinnerAdapter(
                        spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
                    )

                    isMainEqp = procEqp
                    isMachineName = procEqp
                    searchEqpType = eqpType

                    val check = ValidateCheck(this@RemoteImpMainActivity).equipment(
                        viewBinding.txtMachine.text.toString(), isMachineName
                    )

                    if (!check) {
//                        OkDialog.show(
//                            supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
//                            "[$isMachineName]장비가 기준장비에 존재하지 않습니다.", GetString.BTNOKSTR
//                        )

                        viewBinding.editSelectMachine.setText("")
                        viewBinding.editSelectMachine.requestFocus()

                        return@launch
                    }
                } else {
                    val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR
                    )

                    viewBinding.editSelectMachine.setText("")
                    viewBinding.editSelectMachine.requestFocus()
                    return@launch
                }
            }

            viewBinding.editSelectMachine.setText(isMachineName)
            getRecipeInfo()

            viewBinding.editSelectMachine.requestFocus()
            viewBinding.editSelectMachine.selectAll()
        }
    }

    private suspend fun getRecipeInfo() {
        val lotId = viewBinding.txtLotNo.text.toString()
        val product = viewBinding.txtProduct.text.toString()

        val sendMessage = MessageFactoryUtil.recipeInfo(
            "N", lotId, searchOperation, searchSubOperation,
            product, isMainEqp, searchOpType, DeviceInfo.FACILITY
        )

        val message = MessageSender.send(
            supportFragmentManager, sendMessage, MessageName.RECIPEINFO
        )
        val isSuccessFul = message.isSuccessFul
        val result = message.result
        if (isSuccessFul) {
            val messageBody = ResponseDataToJsonUtil.getMessageBody(result)
            val recipe = messageBody.optString("RECIPE")
            //2010.03.15 김웅제 Recipe Parsing Logic 추가
            val lastIndex = recipe.lastIndexOf(":")

            val recipeList = arrayListOf<String>()

            if (recipe.lastIndexOf(":") > 0) {
                val mainRecipe = recipe.substring(0, lastIndex + 1)
                val subRecipe = recipe.substring(lastIndex + 1, recipe.length)

                val subRecipeList = subRecipe.split(",")
                for (sub in subRecipeList)
                    recipeList.add(mainRecipe + sub)
            } else {
                recipeList.add(recipe)
            }

            recipeList.sort()

            val spinnerAdapter =
                ArrayAdapter(applicationContext, R.layout.contact_spinner_row_init, recipeList)
            spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
            viewBinding.spinnerRecipe.adapter = InitSpinnerAdapter(
                spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
            )

            viewBinding.spinnerRecipe.setSelection(1, false)
            viewBinding.chkCarry.isEnabled = true
            //---[Addition] Mar 26, 2007. by I. H. Lee (End)
        } else {
            val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)
            OkDialog.show(
                supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                errorMessage, GetString.BTNOKSTR
            )

            viewBinding.btnClearPort.isEnabled = false
        }
    }

    private fun memorizationRecipe() {
        mainScope.launch {
            if (viewBinding.spinnerRecipe.selectedItem == null)
                return@launch

            val recipe = viewBinding.spinnerRecipe.selectedItem.toString()
            val lotId = viewBinding.txtLotNo.text.toString()

            var portId = ""

            // 20210907 추가
            val chEqpId = viewBinding.editSelectMachine.text.toString()

            val sendMessage =
                MessageFactoryUtil.memorization(chEqpId, recipe, lotId, portId, chEqpId,"","IMP")
            val message =
                MessageSender.send(supportFragmentManager, sendMessage, MessageName.MEMORIZATION)
            val isSuccessFul = message.isSuccessFul
            val result = message.result
            if (isSuccessFul) {
                val messageBody = ResponseDataToJsonUtil.getMessageBody(result)

                val popUp = messageBody.optString("POPUP")

                if (popUp.isNotEmpty())
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_INFORM,
                        popUp, GetString.BTNOKSTR
                    )
            } else {
                val errorMessage = ResponseDataToJsonUtil.getErrorMessage(result)

                if (errorMessage == MessageSender.ERRORMSG_MSGBODY) {

                } else {
                    OkDialog.show(
                        supportFragmentManager, GetString.TXTDIALOGTITLE_ERROR,
                        errorMessage, GetString.BTNOKSTR
                    )
                    viewBinding.btnStart.isEnabled = false
                }

            }
        }
    }
}