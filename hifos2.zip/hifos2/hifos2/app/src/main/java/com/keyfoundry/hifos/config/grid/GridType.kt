package com.keyfoundry.hifos.config.grid

class GridType {
    companion object {
        const val MAIN_GRID = "MAIN"
        const val COLUMN_GRID = "COLUMN"
        const val ROW_GRID = "ROW"
        const val CORNER_GRID = "CORNER"
    }
}