package com.keyfoundry.hifos.config.service.room

import android.content.Context
import com.keyfoundry.hifos.config.dao.ServerInfoDao
import com.keyfoundry.hifos.config.domain.ServerInfo
import com.keyfoundry.hifos.config.service.HifosDBHelper

class ServerInfoService {
    var db : HifosDBHelper
    var serverInfoDao : ServerInfoDao

    constructor(context: Context){
        db = HifosDBHelper.getInstance(context)!!
        serverInfoDao = db.serverInfoDao()
    }

    fun insert(serverInfo: ServerInfo){
        serverInfoDao.insert(serverInfo)
    }

    fun selectAll(): List<ServerInfo> {
        return serverInfoDao.getAll()
    }

    fun deleteAll() {
        serverInfoDao.deleteAll()
    }

    fun selectServerInfo(serverType: String): ServerInfo {
        return serverInfoDao.getServerInfo(serverType)
    }

    fun updateServerInfo(serverUrl: String, serverType: String, selected:Boolean) {
        serverInfoDao.updateServerInfo(serverUrl, serverType, selected)
    }

    fun getSelectedServerInfo() : ServerInfo {
        return serverInfoDao.getSelectedServerInfo()
    }

    fun getUpdateServerUrl() : String {
        return serverInfoDao.getUpdateServerUrl()
    }
}