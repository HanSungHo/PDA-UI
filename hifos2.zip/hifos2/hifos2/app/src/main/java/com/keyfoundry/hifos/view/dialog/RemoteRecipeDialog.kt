package com.keyfoundry.hifos.view.dialog

import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.View
import android.view.Window
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivityRemoteRecipeDialogBinding

class RemoteRecipeDialog : HFActivity() {
    companion object {
        private const val TAG = "RemoteRecipeDialogActivity"
        const val RECIPE_LIST = "RECIPE_LIST"
        const val LOT_NO = "LOT_NO"
    }

    init {
        this.update = false
    }

    private lateinit var viewBinding: ActivityRemoteRecipeDialogBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setFinishOnTouchOutside(false)

        viewBinding = ActivityRemoteRecipeDialogBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.txtRecipe.movementMethod = ScrollingMovementMethod()
        viewBinding.txtLotNo.movementMethod = ScrollingMovementMethod()

        // set Param
        if (intent.getStringExtra(RECIPE_LIST)?.isNotEmpty() == true) {
            val recipeList = intent.getStringExtra(RECIPE_LIST).toString()
            viewBinding.txtRecipe.text = recipeList
        }

        if (intent.getStringExtra(LOT_NO)?.isNotEmpty() == true) {
            val lotNo = intent.getStringExtra(LOT_NO).toString()
            viewBinding.txtLotNo.text = lotNo
        } else {
            viewBinding.txtSelectLot.visibility = View.GONE
            viewBinding.txtLotNo.visibility = View.GONE
        }

        // set
        viewBinding.txtRecipe.isSelected = true
        //viewBinding.txtLotNo.isSelected = true

        viewBinding.btnOk.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                setResult(RESULT_OK)
                finish()
            }
        })

        viewBinding.btnCancel.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(it: View) {
                setResult(RESULT_CANCELED)
                finish()
            }
        })
    }

    override fun onBackPressed() {
        viewBinding.btnOk.performClick()
    }
}