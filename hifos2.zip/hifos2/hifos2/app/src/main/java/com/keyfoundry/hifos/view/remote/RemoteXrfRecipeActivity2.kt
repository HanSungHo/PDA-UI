package com.keyfoundry.hifos.view.remote

import android.os.Bundle
import android.text.InputFilter
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import com.keyfoundry.hifos.R
import com.keyfoundry.hifos.config.customview.HFActivity
import com.keyfoundry.hifos.config.spinner.InitSpinnerAdapter
import com.keyfoundry.hifos.config.utils.GridService
import com.keyfoundry.hifos.config.utils.OnSingleClickListener
import com.keyfoundry.hifos.databinding.ActivityRemoteXrfRecipeSet2Binding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class RemoteXrfRecipeActivity2 : HFActivity() {
    companion object {
        private const val TAG = "RemoteXrfRecipeActivity2"
    }

    lateinit var viewBinding: ActivityRemoteXrfRecipeSet2Binding
    private lateinit var gridService: GridService

    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val ioScope = CoroutineScope(Dispatchers.IO)

    private var mainEqpId = "";

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityRemoteXrfRecipeSet2Binding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        gridService = GridService(applicationContext)

        if (intent.getStringExtra("SLOT")?.isNotEmpty() == true) {
            val eqpId = intent.getStringExtra("SLOT")

            viewBinding.txtSlot.setText(eqpId)

            viewBinding.txtSlot.requestFocus()
            viewBinding.txtSlot.selectAll()
        }

        viewBinding.btnSave.setOnClickListener(onSingleClickListener)
        viewBinding.btnCancel.setOnClickListener(onSingleClickListener)


        //리스트 임의생성

        val Itemname = "2016 LINE-SPT,2010_계측기";
        val ItemList = Itemname.split(",")
        val spinnerAdapter =
            ArrayAdapter(
                applicationContext,
                R.layout.contact_spinner_row_init,
                ItemList
            )
        spinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerItem.adapter = InitSpinnerAdapter(
            spinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )

        val eqpname = "4M12-03";
        val eqpList = eqpname.split(",")
        val eqpspinnerAdapter =
            ArrayAdapter(
                applicationContext,
                R.layout.contact_spinner_row_init,
                eqpList
            )
        eqpspinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerProdeqp.adapter = InitSpinnerAdapter(
            eqpspinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )

        val samplename = "MDS SAMPLE,THK Al 40000,THK Al 5000 350C25,THK Al 5000 350C50,THK Al 5000 400C35,THK Al 8400 350C25,THK Al 8500 350C35,BPSG B-α보정/BPSG P-α보정,BPSG B농도/BPSG P농도,BPSG B농도-Low/BPSG P농도-Low,Al 두께,Al40 두께,CVD-TiN 두께,IMP-Ti 두께,Ti 두께,TiN 두께,W NC,W 두께,WSiX,Al α보정,Al40 α보정,CVD-TiN α보정,IMP-Ti α보정,Ti α보정,TiN α보정,W NC α보정,W α보정,WSiX α보정";
        val sampleList = samplename.split(",")
        val samplespinnerAdapter =
            ArrayAdapter(
                applicationContext,
                R.layout.contact_spinner_row_init,
                sampleList
            )
        samplespinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerMds.adapter = InitSpinnerAdapter(
            samplespinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )

        val Paraname = "CH2,CH3,CH4,NONE,THICKNESS";
        val ParaList = Paraname.split(",")
        val ParaspinnerAdapter =
            ArrayAdapter(
                applicationContext,
                R.layout.contact_spinner_row_init,
                ParaList
            )
        ParaspinnerAdapter.setDropDownViewResource(R.layout.custom_spinner_dropdown)
        viewBinding.spinnerPara.adapter = InitSpinnerAdapter(
            ParaspinnerAdapter, R.layout.contact_spinner_row_init, applicationContext
        )
        viewBinding.spinnerPara.onItemSelectedListener = itemSelectedListener
    }


    private val onSingleClickListener = object : OnSingleClickListener() {
        override fun onSingleClick(it: View) {
            when (it.id) {
                viewBinding.btnSave.id -> {
                    execute()
                }
                viewBinding.btnCancel.id -> {
                    finish()
                }
            }
        }
    }

    private fun execute()
    {
        intent.putExtra("PRODEQP",viewBinding.spinnerProdeqp.selectedItem.toString())
        intent.putExtra("SAMPLE",viewBinding.spinnerMds.selectedItem.toString())
        intent.putExtra("PARA",viewBinding.spinnerPara.selectedItem.toString())
        intent.putExtra("RECIPE",viewBinding.txtRecipe.text.toString())
        intent.putExtra("SLOT",viewBinding.txtSlot.text.toString())
        setResult(RESULT_OK, intent)
        finish()
    }

    private val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (parent != null) {
                when (parent.id) {
                    viewBinding.spinnerPara.id -> {
                        mainScope.launch {
                            if (viewBinding.spinnerPara.selectedItem == null)

                            else {
                                viewBinding.txtRecipe.setText("TEST RECIPE")
                            }
                        }

                    }
                }
            }
        }override fun onNothingSelected(parent: AdapterView<*>?) {}
    }
}

