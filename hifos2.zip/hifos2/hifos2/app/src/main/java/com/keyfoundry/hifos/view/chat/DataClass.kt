package com.keyfoundry.hifos.view.chat

// Device
data class Device(
    val id: String,
    val ip: String,
    val bay: String,
    val area: String,
    val userName : String,
    var isSelected: Boolean = false
)

// TreeItem
sealed class TreeItem {
    data class AreaItem(val area: AreaGroup, var isExpanded: Boolean = true) : TreeItem()
    data class BayItem(val bay: BayGroup, var isExpanded: Boolean = true) : TreeItem()
    data class DeviceItem(val device: Device) : TreeItem()
}

// AreaGroup/BayGroup 편의 객체
data class AreaGroup(
    val areaName: String,
    val bays: MutableList<BayGroup>,
    var isSelected: Boolean = false
)

data class BayGroup(
    val bayName: String,
    val devices: MutableList<Device>,
    var isSelected: Boolean = false
)