package com.keyfoundry.hifos.config.dao

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.keyfoundry.hifos.config.service.HifosDBHelper
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.IOException

@RunWith(AndroidJUnit4::class)
class MachineInfoTest {
    //private lateinit var machineInfoDao: MachineInfoDao
    private lateinit var db: HifosDBHelper

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, HifosDBHelper::class.java).build()
        //machineInfoDao = db.machineInfoDao()
    }

    @After
    @Throws(IOException::class)
    fun closeDb() {
        db.close()
    }

    @Test
    @Throws(Exception::class)
    fun machineInfoTest() = runBlocking {
//        var machineInfoList = machineInfoDao.getAll();
//
//        if(machineInfoList.isNotEmpty()){
//            machineInfoDao.deleteAll()
//        }
//
//        val machineInfo = MachineInfo("test","AAA","192.168.50.180",ServerType.SELECTED_SERVER, System.currentTimeMillis())
//        machineInfoDao.insert(machineInfo)
//
//        machineInfoList = machineInfoDao.getAll();
//
//        Assert.assertThat(machineInfoList.size, IsEqual.equalTo(1))
//        Assert.assertThat("test", IsEqual.equalTo(machineInfoList.get(0).deviceName))
//        Assert.assertThat(ServerType.DEFAULT_SERVER, IsEqual.equalTo(machineInfoList.get(0).serverType))
    }


}