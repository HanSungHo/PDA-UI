package com.keyfoundry.hifos.config.service

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.keyfoundry.hifos.config.domain.UserInfo
import com.keyfoundry.hifos.config.service.room.UserInfoService
import kotlinx.coroutines.runBlocking
import org.hamcrest.core.IsEqual
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class UserInfoServiceTest {
    private lateinit var userInfoService: UserInfoService

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        userInfoService = UserInfoService(context)
    }

    @Test
    @Throws(Exception::class)
    fun userInfoServiceTest() = runBlocking {

        userInfoService.insert(UserInfo("Test","Test Name", "FABCJ4","END", "BP01","",false,System.currentTimeMillis()))
        val userInfo = userInfoService.selectUserInfo()

        if (userInfo != null) {
            Assert.assertThat(userInfo.operId, IsEqual.equalTo("Test"))
            Assert.assertThat(userInfo.operName, IsEqual.equalTo("Test Name"))
        }
    }


}