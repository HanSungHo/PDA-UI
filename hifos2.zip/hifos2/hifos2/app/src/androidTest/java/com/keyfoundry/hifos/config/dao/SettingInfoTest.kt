package com.keyfoundry.hifos.config.dao

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.keyfoundry.hifos.config.service.HifosDBHelper
import com.keyfoundry.hifos.config.domain.SettingInfo
import kotlinx.coroutines.runBlocking
import org.hamcrest.core.IsEqual
import org.junit.After
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.IOException

@RunWith(AndroidJUnit4::class)
class SettingInfoTest {
    private lateinit var settingInfoDao: SettingInfoDao
    private lateinit var db: HifosDBHelper

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, HifosDBHelper::class.java).build()
        settingInfoDao = db.settingInfoDao()
    }

    @After
    @Throws(IOException::class)
    fun closeDb() {
        db.close()
    }

    @Test
    @Throws(Exception::class)
    fun settingInfoTest() = runBlocking {


        val settingInfo = SettingInfo("Test","Test Name","Test Bay", 0,0, System.currentTimeMillis())
        settingInfoDao.insert(settingInfo)

        var settingInfoList = settingInfoDao.getAll();

        Assert.assertThat(settingInfoList.size, IsEqual.equalTo(1))
        Assert.assertThat("Test", IsEqual.equalTo(settingInfoList.get(0).facility))

    }




}