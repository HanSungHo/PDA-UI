package com.keyfoundry.hifos.config.dao

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.keyfoundry.hifos.config.service.HifosDBHelper
import com.keyfoundry.hifos.config.domain.UserInfo
import kotlinx.coroutines.runBlocking
import org.hamcrest.core.IsEqual
import org.junit.After
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.IOException

@RunWith(AndroidJUnit4::class)
class UserInfoTest {
    private lateinit var userInfoDao: UserInfoDao
    private lateinit var db: HifosDBHelper

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, HifosDBHelper::class.java).build()
        userInfoDao = db.userInfoDao()
    }

    @After
    @Throws(IOException::class)
    fun closeDb() {
        db.close()
    }

    @Test
    @Throws(Exception::class)
    fun userInfoTest() = runBlocking {
        var userInfoList = userInfoDao.getAll();

        if(userInfoList.isNotEmpty()){
            userInfoDao.deleteAll()
        }

        val userInfo = UserInfo("Test","Test Name", "FABCJ4","CVD", "","",false,System.currentTimeMillis())
        userInfoDao.insert(userInfo)

        userInfoList = userInfoDao.getAll();

        Assert.assertThat(userInfoList.size, IsEqual.equalTo(1))
        Assert.assertThat("FABCJ4", IsEqual.equalTo(userInfoList.get(0).facility))
    }




}