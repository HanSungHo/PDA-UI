package com.keyfoundry.hifos.config.service

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.keyfoundry.hifos.config.domain.SettingInfo
import com.keyfoundry.hifos.config.service.room.SettingInfoService
import kotlinx.coroutines.runBlocking
import org.hamcrest.core.IsEqual
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SettingInfoServiceTest {
    private lateinit var settingInfoService: SettingInfoService

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        settingInfoService = SettingInfoService(context)
    }

    @Test
    @Throws(Exception::class)
    fun settingInfoServiceTest() = runBlocking {

        settingInfoService.insert(SettingInfo("FABCJ4","END","BP01",1,1, System.currentTimeMillis()))
        val settingInfo = settingInfoService.selectSettingInfo()

        Assert.assertThat(settingInfo.facility, IsEqual.equalTo("FABCJ4"))
        Assert.assertThat(settingInfo.area, IsEqual.equalTo("END"))
    }


}