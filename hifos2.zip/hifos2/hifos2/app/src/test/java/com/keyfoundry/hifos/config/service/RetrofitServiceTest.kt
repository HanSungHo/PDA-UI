package com.keyfoundry.hifos.config.service

import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.service.dto.RequestData
import com.keyfoundry.hifos.config.utils.ResponseDataToJsonUtil
import com.keyfoundry.hifos.message.SendMessageHeader
import com.keyfoundry.hifos.message.SendMessageManager
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.junit.Test

class RetrofitServiceTest {

    @Test
    fun test_serverAlive ()  = runBlocking {
        var statusCode = 0
        try {
            val response = RetrofitSyncService.API.hifosCheck()
            statusCode = response.statusCode
        }catch (e : Exception){
            println(e.message)
        }

        if(statusCode != 200){
            println("Hello")
        }else{
            println(statusCode)
        }
    }

    @Test
    fun message_GETDISPATCHER ()  = runBlocking {
        var statusCode = 0
        try {
            val sendMessageHeader = SendMessageHeader(
                "GETDISPATCH",
                DeviceInfo.MOBILE_SERVER_NAME,
                DeviceInfo.DEVICE_NAME,
                "P",
                "YES",
                "",
                "",
                ""
            )

            val sendMessageBody = """
                    |<RESERVE>T</RESERVE>
                    |<RTD>4D5C-08</RTD>
                    |<WET></WET>
                  """.trimMargin()

            val sendMessage = SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
            println(sendMessage)

            val result = RetrofitSyncService.API.hifosProcess(RequestData(sendMessage))
            println(result.toString())

            val reserveLotList: JSONArray =
                ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "RESERVELOT")
            val disparcherLotList =
                ResponseDataToJsonUtil.getMessageBodyNullCheckList(result, "DISPLOT")

            println("reserveLot List : " + reserveLotList.toString())
            println("disparcherLotList List : " + disparcherLotList.toString())


        }catch (e : Exception){
            println(e.message)
        }

        if(statusCode != 200){
            println("Hello")
        }else{
            println(statusCode)
        }
    }




}