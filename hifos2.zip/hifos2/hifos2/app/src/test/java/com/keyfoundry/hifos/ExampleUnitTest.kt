package com.keyfoundry.hifos

import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.ServerType
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import okhttp3.internal.wait
import org.junit.Test

import org.junit.Assert.*
import java.net.URL

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        val tempEqpId = "ab-22"
        val onlyEQPLastIdx = tempEqpId.lastIndexOf("-")
        val onlyEqpId = tempEqpId.substring(0, onlyEQPLastIdx)
    }

    @Test
    fun urlStringTest(){
        val vURL = URL(ServerType.DEFAULT_MOBILE_SERVER_URL)
        println(vURL)
        println(vURL.host)
        println(vURL.port)
    }

    @Test
    fun test(){
        val test ="ABCDE"


        val waferId = test.subSequence(test.length-2, test.length)

        println(waferId)
    }

    suspend fun test1(){
        println("test1")
        delay(2000)
        println("test1 nice")
    }

    suspend fun test2(){
        println("test2")
        delay(1000)
        println("test2 nice")
    }

    @Test
    fun hello() = runBlocking{
        val test1 = async {  test1() }
        val test2 = async {  test2() }
    }
}