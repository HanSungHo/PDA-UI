package com.keyfoundry.hifos.message




import org.junit.Test


class SendMessageMessageTest {

    @Test
    fun SendMessageLOGIN() {

    }

    @Test
    fun SendMessageAREABAYINFO() {


    }


}