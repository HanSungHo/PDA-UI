package com.keyfoundry.hifos.config.utils




import com.keyfoundry.hifos.config.const.DeviceInfo
import com.keyfoundry.hifos.config.const.GetString
import com.keyfoundry.hifos.config.service.RetrofitSyncService
import com.keyfoundry.hifos.config.service.dto.RequestData
import com.keyfoundry.hifos.config.service.dto.ResponseData
import com.keyfoundry.hifos.message.Message
import com.keyfoundry.hifos.message.SendMessageHeader
import com.keyfoundry.hifos.message.SendMessageManager
import kotlinx.coroutines.runBlocking

import org.junit.Test
import java.lang.Exception


class ResponseDataUtilTest {

    @Test
    fun jsonParsing_LOT_STATUS() {
        try {
            //-- 1. set send message
            val sendMessageHeader = SendMessageHeader("LOTINFO","MPC110369","FA001","P","YES","","","")
            val sendMessageBody = """
                    |<TYPE>NORMAL</TYPE>
                    |<LOTID>TJ00001</LOTID>
                    |<FACILITY>FABCJ4</FACILITY>
                  """.trimMargin()

//            val sendMessage = SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)

//            val sendMessage = ResponseDataUtil.getMessageSet("LOTINFO", sendMessageBody)
//            val response = RetrofitService.API.hifosProcess(RequestData(sendMessage)).execute()
//
//            println(response)
//            println(response.body())

        } catch (e: Exception) {
            println(e)
        }
    }

    @Test
    fun jsonParsing_BTY() {
        try {
            //-- 1. set send message
            val sendMessageHeader = SendMessageHeader("BLSTINFO","MPC110369","FA001","P","YES","","","")
            val sendMessageBody = """
                    |<BAY>5DP01</BAY>
                    |<STOCKER>5SD11</STOCKER>
                    |<JOBCODE></JOBCODE>
                    |<FACILITY>FABCJ4</FACILITY>
                  """.trimMargin()

//            val sendMessage = SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)

//            val sendMessage = ResponseDataUtil.getMessageSet("BLSTINFO", sendMessageBody)
//            val response = RetrofitService.API.hifosProcess(RequestData(sendMessage)).execute()

//            println(response)
//            println(response.body())
//            println(sendMessage)

        } catch (e: Exception) {
            println(e)
        }
    }


    @Test
    fun messageBody_Test() = runBlocking {
        val sendMessageHeader =SendMessageHeader("ETCH_COMMRCPFROMB", "MPC110369", DeviceInfo.DEVICE_NAME, "P", "YES", "", "", "")
        val sendMessageBody = """
                           |<LOTID>EP01922X1</LOTID>
                          """.trimMargin()

        var message  = Message(ResponseData("",0),false)

        try{
            val sendMessage = SendMessageManager.getSendMessage(sendMessageHeader, sendMessageBody)
            val result = RetrofitSyncService.API.hifosProcessMessage(RequestData(sendMessage), "hh")

            println(result)
            message = checkValidate(result)
            println(message)
            println(ResponseDataToJsonUtil.isSuccessFul(result))
            println(ResponseDataToJsonUtil.isMessageBodyCheck(result))

        } catch (e: Exception){
            message = setExceptionMessage(e.message)
        }

        print(ResponseDataToJsonUtil.getErrorMessage(message.result))
    }

    private fun setExceptionMessage(errorMessage : String?) : Message {
        var message  = Message(ResponseData("",0),false)
        val errorMessage = """
                    |{"${GetString.ERRMSG}":"$errorMessage"}"
                    """.trimMargin()
        message.result = ResponseData(errorMessage,0)
        message.isSuccessFul = false

        return message
    }

    private fun checkValidate(result : ResponseData) : Message {
        var message  = Message(ResponseData("",0),false)
        val isSuccessFul = ResponseDataToJsonUtil.isSuccessFul(result)

        if(isSuccessFul){
            // 1. CHECK MSGBODY
            if(ResponseDataToJsonUtil.isMessageBodyCheck(result)){
                message.result = result
                message.isSuccessFul = true
            }else{
                val errorMessage = """
                    |{"${GetString.ERRMSG}":"error"}"
                    """.trimMargin()
                message.result = ResponseData(errorMessage,0)
                message.isSuccessFul = false
            }
        }else{
            message.result = result
            message.isSuccessFul = false
        }

        return message
    }

}