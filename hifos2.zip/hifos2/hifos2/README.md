# Hifos APP

---

### Hifos APP Android Version 

![hifos main](./image-guide/main.png)


---

## 1. Layout

---
Layout 종류

- LinearLayout
- RelativeLayout
- FrameLayout
- TableLayout


#### ● LinearLayout


---

## 2. 그리드

---
### 화면

    그리드를 사용하는 화면 목록 
    ex) eSheet, DIFF 계측 PARAMETER 입력, DISPATCHING
- ESheet (ESheetActivity)

![hifos main](./image-guide/grid/esheet.png)

- DIFF 계측 PARAMETER 입력 (DiffInstParameterActivity)

![hifos main](./image-guide/grid/diff.png)

- DISPATCHING (DispatchingActivity)

![hifos main](./image-guide/grid/dispatching.png)

- BATCH (BatchActivity)
- COMMENT LIST (CommentListActivity)
- BATCH MVIN (BatchMoveInActivity)
- BATCH MVOU (BatchMoveOutActivity)
- INLINE 공정 선택 (MoveInInlineActivity)
- 계측 공정 선택 (ProcessInquireActivity)
- ETCH 조건표 조회 (ETCHActivity)
- BAY별 LOT 현황(LotStatusByBayActivity)
- 장비상태 (MachineStatusActivity)
- 계측 RCP 조회 (RCPInquireActivity)
- RCP 조건 (RemoteEtchCommRcpActivity)
- SPLIT (SplitActivity)

---
### 그리드 구성요소 (ex: Esheet 기준)

|Corner Header|Column Header|
|-------------|-------------|
|Row Header   |Main         |

    전체 = CTMainLayout
    각 속성 = CTSubLayout
    sub 속성 = CTRowLayout

    Main 의 컬럼 수 = Column Header 의 컬럼 수
    Main 의 로우 수 = Row Header 의 로우 수

    Corner Header 의 컬럼 수 = Row Header 의 컬럼 수
    Corner Header 의 로우 수 = Column Header 의 로우 수

ex) DIFF 계측 PARAMETER 입력 grid

![hifos main](./image-guide/grid/diff-detail.png)

```kotlin
val columnData = linkedMapOf(
    "PARAMETERNO" to ColumnProperty("NO", Gravity.CENTER, 200),
    "TITLEPARAMETER" to ColumnProperty("PARA", Gravity.CENTER, 200),
    "MINVALUE" to ColumnProperty("MIN", Gravity.CENTER, 200),
    "MAXVALUE" to ColumnProperty("MAX", Gravity.CENTER, 200),
    "QUANTITY" to ColumnProperty("DATA", Gravity.CENTER, 200, true),
)

val mainGrid = gridService.setGridPropData(columnData, gridData)
viewBinding.baseLayout.addView(mainGrid)

val mainTable = mainGrid.mainTable

for(mainRow in mainTable.children){
    mainRow.setOnClickListener {
        val rowData = it.tag as GridService.RowData
        val dataList = rowData.rowDataList

        Toast.makeText(this, "${dataList["DATA"]}", Toast.LENGTH_SHORT).show()
    }
}
```

: